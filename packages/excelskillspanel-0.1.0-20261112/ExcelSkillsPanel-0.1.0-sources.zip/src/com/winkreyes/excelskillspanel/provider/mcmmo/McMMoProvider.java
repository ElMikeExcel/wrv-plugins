package com.winkreyes.excelskillspanel.provider.mcmmo;

import com.gmail.nossr50.api.ExperienceAPI;
import com.gmail.nossr50.datatypes.skills.PrimarySkillType;
import com.winkreyes.excelskillspanel.core.PanelModel;
import com.winkreyes.excelskillspanel.core.SkillMath;
import com.winkreyes.excelskillspanel.provider.SkillsProvider;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * Provider #1 — mcMMO (the commercial core). Maps the 19
 * PrimarySkillTypes to panel rows through mcMMO's PUBLIC API
 * (com.gmail.nossr50.api.ExperienceAPI) behind a softdepend: no
 * mcMMO code is copied into this plugin, so mcMMO updates carry
 * the panel. This class is only ever loaded when the mcMMO
 * plugin is present and enabled (registration is guarded in the
 * plugin's onEnable).
 *
 * Read semantics, verified against the WRV fork's ExperienceAPI
 * source: getLevel(Player, PrimarySkillType); getXP(Player,
 * String) = XP into the current level; getXPToNextLevel(Player,
 * String) = the level's TOTAL XP span; getPowerLevel(Player);
 * getPowerLevelCap(). The String forms resolve the skill by its
 * display name (SkillTools.matchSkill).
 *
 * The optional rank label comes from mcMMO's own PlaceholderAPI
 * surface (%mcmmo_rank_&lt;skill&gt;%, DESIGN §7.2) read through
 * the WRV provider package's PAPI reflection helper; absent PAPI,
 * the row simply carries no rank — never an invented one.
 *
 * A skill whose read throws is skipped with a WARNING (logged,
 * never silent); the remaining skills still render.
 *
 * Excel — Wink Reyes Valley (Iris / Mike).
 */
public final class McMMoProvider implements SkillsProvider {

    /** The 19 primary skills in PrimarySkillType declaration
     *  order, with display names and Java icon material names
     *  (resolved by name at render time; an unknown name falls
     *  back to NAME_TAG in the presentation). */
    public record SkillDef(PrimarySkillType type, String displayName, String iconKey) {}

    public static final List<SkillDef> SKILLS = List.of(
            new SkillDef(PrimarySkillType.ACROBATICS, "Acrobatics", "FEATHER"),
            new SkillDef(PrimarySkillType.ALCHEMY, "Alchemy", "BREWING_STAND"),
            new SkillDef(PrimarySkillType.ARCHERY, "Archery", "BOW"),
            new SkillDef(PrimarySkillType.AXES, "Axes", "IRON_AXE"),
            new SkillDef(PrimarySkillType.CROSSBOWS, "Crossbows", "CROSSBOW"),
            new SkillDef(PrimarySkillType.EXCAVATION, "Excavation", "IRON_SHOVEL"),
            new SkillDef(PrimarySkillType.FISHING, "Fishing", "FISHING_ROD"),
            new SkillDef(PrimarySkillType.HERBALISM, "Herbalism", "WHEAT"),
            new SkillDef(PrimarySkillType.MACES, "Maces", "MACE"),
            new SkillDef(PrimarySkillType.MINING, "Mining", "IRON_PICKAXE"),
            new SkillDef(PrimarySkillType.REPAIR, "Repair", "ANVIL"),
            new SkillDef(PrimarySkillType.SALVAGE, "Salvage", "GOLD_INGOT"),
            new SkillDef(PrimarySkillType.SMELTING, "Smelting", "FURNACE"),
            new SkillDef(PrimarySkillType.SPEARS, "Spears", "IRON_SPEAR"),
            new SkillDef(PrimarySkillType.SWORDS, "Swords", "IRON_SWORD"),
            new SkillDef(PrimarySkillType.TAMING, "Taming", "BONE"),
            new SkillDef(PrimarySkillType.TRIDENTS, "Tridents", "TRIDENT"),
            new SkillDef(PrimarySkillType.UNARMED, "Unarmed", "LEATHER_CHESTPLATE"),
            new SkillDef(PrimarySkillType.WOODCUTTING, "Woodcutting", "OAK_LOG"));

    private final Logger log;

    public McMMoProvider(Logger log) {
        this.log = log;
    }

    @Override
    public String id() { return "mcmmo"; }

    @Override
    public ProviderData collect(Player player) {
        List<PanelModel.SkillRow> rows = new ArrayList<>();
        for (SkillDef def : SKILLS) {
            try {
                int level = ExperienceAPI.getLevel(player, def.type());
                String rank = com.winkreyes.excelskillspanel.provider.papi.PapiReads.get(
                        player, "%mcmmo_rank_" + def.type().name().toLowerCase() + "%");
                if (def.type().isChildSkill()) {
                    // Child skills (Salvage, Smelting) have a level
                    // but no XP: the XP reads throw
                    // UnsupportedOperationException for them
                    // (rig-proven). Level-only row, no bar.
                    rows.add(SkillMath.childRow(def.type().name().toLowerCase(),
                            def.displayName(), def.iconKey(), level, rank));
                    continue;
                }
                int xpInto = ExperienceAPI.getXP(player, def.displayName());
                int xpSpan = ExperienceAPI.getXPToNextLevel(player, def.displayName());
                rows.add(SkillMath.mcmmoRow(def.type().name().toLowerCase(),
                        def.displayName(), def.iconKey(), level, xpInto, xpSpan, rank));
            } catch (Throwable t) {
                log.warning("ExcelSkillsPanel: mcMMO read failed for " + def.displayName()
                        + " (" + player.getName() + "): " + t.getClass().getSimpleName()
                        + ": " + t.getMessage() + " — row omitted, never faked");
            }
        }
        List<PanelModel.HeaderBlock> headers = new ArrayList<>();
        try {
            headers.add(SkillMath.powerHeader(ExperienceAPI.getPowerLevel(player),
                    ExperienceAPI.getPowerLevelCap()));
        } catch (Throwable t) {
            log.warning("ExcelSkillsPanel: mcMMO Power Level read failed for "
                    + player.getName() + ": " + t.getClass().getSimpleName()
                    + ": " + t.getMessage() + " — header block omitted");
        }
        return new ProviderData(headers, rows, List.of());
    }
}
