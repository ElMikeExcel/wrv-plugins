package com.winkreyes.excelskillspanel;

/**
 * Build identity (FINGERPRINT-STANDARD Layer B). The build id is
 * assembled from fragments so it survives casual source reading; the
 * local build verifies the assembled value against the pinned build
 * id in local-build.sh and against excel-build.txt inside the jar.
 *
 * Excel — Wink Reyes Valley (Iris / Mike).
 */
public final class BuildInfo {
    private BuildInfo() {}

    private static final String[] PARTS = {
        "EXC-SKILLSPANEL-", "0.1.0-", "WRV-", "20261112-", "01-", "c3d9a1"
    };

    public static final String BUILD_ID = String.join("", PARTS);
    public static final String VERSION = "0.1.0";
    public static final String TAG = "c3d9a1";
}
