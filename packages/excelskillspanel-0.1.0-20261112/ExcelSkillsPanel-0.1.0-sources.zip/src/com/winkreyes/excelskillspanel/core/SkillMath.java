package com.winkreyes.excelskillspanel.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Pure composition of an mcMMO skill row from raw API numbers —
 * the arithmetic the provider-mcmmo module performs, kept
 * Bukkit-free so the harness proves it without a server.
 *
 * Inputs are mcMMO ExperienceAPI semantics (verified against the
 * WRV fork's source): {@code xpInto} = XP earned into the current
 * level (getXP), {@code xpSpan} = the level's total XP span
 * (getXPToNextLevel), level from getLevel. The detail view's last
 * line is the website pointer until an in-game perk-ladder read
 * verifies (DESIGN §7.3) — the panel never invents a ladder.
 *
 * Excel — Wink Reyes Valley (Iris / Mike).
 */
public final class SkillMath {
    private SkillMath() {}

    /** The standing last line of every mcMMO skill detail view. */
    public static final String PERK_POINTER =
            "Full perk ladder: Skill Trees page on the website";

    public static PanelModel.SkillRow mcmmoRow(String id, String name, String iconKey,
                                               int level, int xpInto, int xpSpan,
                                               String rankLabel) {
        PanelModel.BarData bar = new PanelModel.BarData(xpInto, xpSpan);
        List<String> detail = new ArrayList<>();
        detail.add("Level: " + level);
        detail.add(bar.line());
        detail.add("XP into this level: " + PanelModel.fmt(Math.max(0, xpInto)));
        if (bar.capped()) {
            detail.add("XP to next level: \u2014 (at the cap)");
        } else {
            detail.add("XP to next level: "
                    + PanelModel.fmt(Math.max(0, (long) xpSpan - xpInto)));
        }
        if (rankLabel != null && !rankLabel.isBlank()) {
            detail.add("Rank: " + rankLabel);
        }
        detail.add(PERK_POINTER);
        return new PanelModel.SkillRow(id, name, iconKey, level, bar, rankLabel, detail);
    }

    /** A child-skill row (Salvage, Smelting): a level but no XP
     *  and no bar — mcMMO derives a child skill's level from its
     *  parent skills, and its XP API reads throw
     *  UnsupportedOperationException ("Child skills do not have
     *  XP"), proven on the build rig. The detail view says
     *  exactly that instead of inventing a bar. */
    public static PanelModel.SkillRow childRow(String id, String name, String iconKey,
                                               int level, String rankLabel) {
        List<String> detail = new ArrayList<>();
        detail.add("Level: " + level);
        detail.add("Child skill \u2014 its level comes from its parent skills.");
        detail.add("It earns no XP of its own, so there is no progress bar.");
        if (rankLabel != null && !rankLabel.isBlank()) {
            detail.add("Rank: " + rankLabel);
        }
        detail.add(PERK_POINTER);
        return new PanelModel.SkillRow(id, name, iconKey, level, null, rankLabel, detail);
    }

    /** The mcMMO header block: Power Level (+ its cap when the
     *  server configures one). */
    public static PanelModel.HeaderBlock powerHeader(int powerLevel, int powerLevelCap) {
        List<String> lines = new ArrayList<>();
        lines.add("Power Level: " + PanelModel.fmt(powerLevel));
        if (powerLevelCap > 0) {
            lines.add("Power Level cap: " + PanelModel.fmt(powerLevelCap));
        }
        return new PanelModel.HeaderBlock("power", "Power Level",
                "EXPERIENCE_BOTTLE", lines, null, false);
    }
}
