package com.winkreyes.excelskillspanel.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Pure composition of the WRV Magic header block (DESIGN §7.2/§7.3
 * as superseded by the run-273 verification + Mike's Q2 FULL
 * HEADER ruling): the provider fills a {@link MagicData} DTO from
 * verified reads only — every field is nullable, and a null field
 * OMITS its line. The panel never fakes a header field: a read
 * that fails simply does not appear.
 *
 * Sources per field (all verified in MAGIC-HEADER-VERIFICATION):
 * - level / xpInto / xpToNext / totalXp / manaBoostPct: the
 *   ExcelMagicLevel PlaceholderAPI surface.
 * - rankName / rankKey / nextRankName: the Magic API — the
 *   ACTIVE WAND's path (Mage.getActiveWand -&gt; Wand.getPath -&gt;
 *   ProgressionPath.getName/getKey/getNextPath), rig-settled as
 *   the read that returns the rank name as displayed (the class
 *   chain reports the class's base path instead; see
 *   MagicApiReads). className: Mage.getActiveClass().getName().
 * - mana / manaMaxEffective / manaRegenEffective: Mage.getMana /
 *   getEffectiveManaMax / getEffectiveManaRegeneration.
 * - regenBoostPct / costReductionPct: ExcelMagicLevel's reward
 *   table applied to the level (per-level fractions from its own
 *   live config x (level - 1) — RewardTable.boostAt's formula).
 * - totalCasts: ExcelMagicLevel's store (PlayerRecord.totalCasts,
 *   "informational"). It is labelled "casts" — NEVER "credited":
 *   its equivalence to the rank-driving credited-cast count is
 *   unverified (DESIGN §7.2).
 * - sealsBroken: the GuildGate reflective read (GuildGateReads
 *   pattern), rendered "Guild seals: N of 5".
 *
 * Excel — Wink Reyes Valley (Iris / Mike).
 */
public final class MagicLines {
    private MagicLines() {}

    /** ExcelMagicLevel's canonical explainer (MagicLevelCommand.
     *  EXPLAINER, verbatim) — the Magic detail view's lead text. */
    public static final String EXPLAINER =
            "Your path and the seals decide what you can cast. Your Magic Level decides how strong "
            + "your casting is \u2014 a bigger mana pool, faster regen, cheaper casts. "
            + "It never locks or unlocks a spell.";

    /** Every Magic header input; null = the read was unavailable
     *  and the line is omitted. */
    public record MagicData(
            Integer level, Long xpInto, Long xpToNext, Long totalXp,
            String rankName, String rankKey, String nextRankName, String className,
            Float mana, Integer manaMaxEffective, Integer manaRegenEffective,
            String manaBoostPct, String regenBoostPct, String costReductionPct,
            Long totalCasts, Integer sealsBroken) {}

    /** Magic XP bar: span = into + to-next. ExcelMagicLevel's
     *  surface reports to-next as 0 exactly at the level cap
     *  (the expansion's own contract), so to-next 0 maps to
     *  BarData's capped sentinel — full bar, MAX label — rather
     *  than a fake "into / into" span. Null when the level
     *  surface is absent. */
    public static PanelModel.BarData magicBar(MagicData d) {
        if (d.level() == null || d.xpInto() == null || d.xpToNext() == null) return null;
        if (d.xpToNext() == 0) return new PanelModel.BarData(d.xpInto(), 0);
        return new PanelModel.BarData(d.xpInto(), d.xpInto() + d.xpToNext());
    }

    /** The boosts line, or null when no boost surface read. At
     *  Magic Level 1 there are no boosts yet (ExcelMagicLevel's
     *  own wording); from level 2 the verified percentages show. */
    public static String boostsLine(MagicData d) {
        if (d.level() == null) return null;
        if (d.level() < 2) return "Boosts: none yet \u2014 they start at Magic Level 2";
        List<String> parts = new ArrayList<>();
        if (d.manaBoostPct() != null) parts.add("mana pool +" + d.manaBoostPct() + "%");
        if (d.regenBoostPct() != null) parts.add("mana regen +" + d.regenBoostPct() + "%");
        if (d.costReductionPct() != null) parts.add("cast cost -" + d.costReductionPct() + "%");
        if (parts.isEmpty()) return null;
        return "Boosts: " + String.join(", ", parts);
    }

    /** The header block's lines, in display order. */
    public static List<String> headerLines(MagicData d) {
        List<String> lines = new ArrayList<>();
        if (d.level() != null) {
            StringBuilder lvl = new StringBuilder("Magic Level " + d.level());
            if (d.totalXp() != null) lvl.append(" \u2014 ").append(PanelModel.fmt(d.totalXp())).append(" XP total");
            lines.add(lvl.toString());
        }
        if (d.rankName() != null && !d.rankName().isBlank()) {
            lines.add("Rank: " + d.rankName());
        } else if (d.rankKey() != null && !d.rankKey().isBlank()) {
            lines.add("Rank: " + d.rankKey());
        }
        if (d.className() != null && !d.className().isBlank()) {
            lines.add("Class: " + d.className());
        }
        if (d.nextRankName() != null && !d.nextRankName().isBlank()) {
            lines.add("Next rank: " + d.nextRankName());
        }
        if (d.mana() != null && d.manaMaxEffective() != null) {
            lines.add("Mana: " + Math.round(d.mana()) + " / " + PanelModel.fmt(d.manaMaxEffective()));
        }
        if (d.manaRegenEffective() != null) {
            lines.add("Mana regen: " + d.manaRegenEffective());
        }
        String boosts = boostsLine(d);
        if (boosts != null) lines.add(boosts);
        if (d.totalCasts() != null) {
            lines.add("Total casts: " + PanelModel.fmt(d.totalCasts()));
        }
        if (d.sealsBroken() != null) {
            lines.add("Guild seals: " + d.sealsBroken() + " of 5");
        }
        return List.copyOf(lines);
    }

    /** The header block, or null when nothing at all read (no
     *  Magic block rather than an empty one). */
    public static PanelModel.HeaderBlock headerBlock(MagicData d) {
        List<String> lines = headerLines(d);
        if (lines.isEmpty()) return null;
        return new PanelModel.HeaderBlock("magic", "Magic", "BLAZE_ROD",
                lines, magicBar(d), true);
    }

    /** The Magic detail view: the canonical explainer, then every
     *  header line, then the bar numbers line. */
    public static List<String> detailLines(MagicData d) {
        List<String> lines = headerLines(d);
        if (lines.isEmpty()) return List.of();
        List<String> out = new ArrayList<>();
        out.add(EXPLAINER);
        out.add("");
        out.addAll(lines);
        PanelModel.BarData bar = magicBar(d);
        if (bar != null) out.add("Magic XP: " + bar.line());
        return List.copyOf(out);
    }

    /** Percent formatting identical to ExcelMagicLevel's own
     *  Percents.format (BigDecimal, scale 4, trailing zeros
     *  stripped): 0.0125 -&gt; "1.25", 0.095 -&gt; "9.5", 0 -&gt; "0" —
     *  so a boost percentage reads the same on the panel as in
     *  /magiclevel's chat output. */
    public static String percentOf(double fraction) {
        return java.math.BigDecimal.valueOf(fraction)
                .multiply(java.math.BigDecimal.valueOf(100))
                .setScale(4, java.math.RoundingMode.HALF_UP)
                .stripTrailingZeros()
                .toPlainString();
    }
}
