package com.winkreyes.excelskillspanel;

import com.gmail.nossr50.datatypes.skills.PrimarySkillType;
import com.winkreyes.excelskillspanel.bukkit.BedrockForms;
import com.winkreyes.excelskillspanel.core.MagicLines;
import com.winkreyes.excelskillspanel.core.PanelModel;
import com.winkreyes.excelskillspanel.core.SkillMath;
import com.winkreyes.excelskillspanel.provider.mcmmo.McMMoProvider;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * ExcelSkillsPanel harness: the pure model (bars, rows, the Magic
 * header composition), the provider seam's mcMMO skill census,
 * and the Bedrock form handler proof against the REAL Cumulus
 * classes in the staged Geyser jar (the Summons 0.1.8 pattern —
 * forms must not only SEND, taps must ARRIVE).
 *
 * Excel — Wink Reyes Valley (Iris / Mike).
 */
class PanelTest {

    // ----------------- bars -----------------

    @Test
    void barMath() {
        PanelModel.BarData half = new PanelModel.BarData(1000, 2000);
        assertEquals(0.5, half.fraction());
        assertEquals(50, half.percent());
        assertEquals("\u25B0\u25B0\u25B0\u25B0\u25B0\u25B1\u25B1\u25B1\u25B1\u25B1", half.bar());
        assertEquals("\u25B0\u25B0\u25B0\u25B0\u25B0\u25B1\u25B1\u25B1\u25B1\u25B1 50% \u2014 1,000 / 2,000 XP",
                half.line());
        assertEquals("\u25B0\u25B0\u25B0\u25B0\u25B0\u25B1\u25B1\u25B1\u25B1\u25B1 50%", half.compact());
    }

    @Test
    void barClampsAndCaps() {
        PanelModel.BarData over = new PanelModel.BarData(3000, 2000);
        assertEquals(1.0, over.fraction(), "over-full clamps to 100%");
        assertEquals(100, over.percent());
        PanelModel.BarData negative = new PanelModel.BarData(-50, 2000);
        assertEquals(0.0, negative.fraction(), "negative into clamps to 0");
        PanelModel.BarData capped = new PanelModel.BarData(500, 0);
        assertTrue(capped.capped(), "span 0 is the cap");
        assertEquals(1.0, capped.fraction());
        assertTrue(capped.line().endsWith("MAX"), "capped line says MAX, no invented fraction");
        assertTrue(capped.compact().endsWith("MAX"));
        PanelModel.BarData empty = new PanelModel.BarData(0, 2000);
        assertEquals(0, empty.percent());
        assertEquals("\u25B1\u25B1\u25B1\u25B1\u25B1\u25B1\u25B1\u25B1\u25B1\u25B1", empty.bar());
    }

    @Test
    void numberFormatting() {
        assertEquals("1,240", PanelModel.fmt(1240));
        assertEquals("0", PanelModel.fmt(0));
        assertEquals("17,821", PanelModel.fmt(17821));
    }

    // ----------------- mcMMO rows (pure composition) -----------------

    @Test
    void mcmmoRowComposition() {
        PanelModel.SkillRow row = SkillMath.mcmmoRow("mining", "Mining", "IRON_PICKAXE",
                214, 1240, 2000, null);
        assertEquals("Mining 214 \u25B0\u25B0\u25B0\u25B0\u25B0\u25B0\u25B1\u25B1\u25B1\u25B1 62%",
                row.compactLine());
        assertEquals("Mining \u2014 Lv 214", row.buttonLabel());
        assertEquals(List.of(
                "Level: 214",
                "\u25B0\u25B0\u25B0\u25B0\u25B0\u25B0\u25B1\u25B1\u25B1\u25B1 62% \u2014 1,240 / 2,000 XP",
                "XP into this level: 1,240",
                "XP to next level: 760",
                SkillMath.PERK_POINTER), row.detailLines());
    }

    @Test
    void mcmmoRowRankAndCap() {
        PanelModel.SkillRow ranked = SkillMath.mcmmoRow("mining", "Mining", "IRON_PICKAXE",
                10, 5, 100, "Adept");
        assertTrue(ranked.detailLines().contains("Rank: Adept"),
                "a verified rank label shows in the detail view");
        PanelModel.SkillRow capped = SkillMath.mcmmoRow("mining", "Mining", "IRON_PICKAXE",
                1000, 0, 0, null);
        assertTrue(capped.detailLines().get(3).contains("at the cap"),
                "a capped skill's detail says so instead of a fake remainder");
        PanelModel.SkillRow blank = SkillMath.mcmmoRow("mining", "Mining", "IRON_PICKAXE",
                10, 5, 100, " ");
        assertFalse(blank.detailLines().toString().contains("Rank:"),
                "a blank rank label is treated as absent");
    }

    @Test
    void childSkillRowComposition() {
        // Salvage / Smelting: a level but no XP and no bar —
        // mcMMO's XP reads throw for child skills (rig-proven).
        PanelModel.SkillRow row = SkillMath.childRow("salvage", "Salvage", "GOLD_INGOT",
                12, null);
        assertNull(row.bar(), "a child row carries no bar");
        assertEquals("Salvage 12 (child skill)", row.compactLine());
        assertEquals("Salvage \u2014 Lv 12", row.buttonLabel());
        assertEquals("Level: 12", row.detailLines().get(0));
        assertTrue(row.detailLines().get(1).contains("parent skills"));
        assertEquals(SkillMath.PERK_POINTER,
                row.detailLines().get(row.detailLines().size() - 1));
    }

    @Test
    void powerHeaderComposition() {
        PanelModel.HeaderBlock withCap = SkillMath.powerHeader(1234, 5000);
        assertEquals(List.of("Power Level: 1,234", "Power Level cap: 5,000"), withCap.lines());
        PanelModel.HeaderBlock noCap = SkillMath.powerHeader(42, 0);
        assertEquals(List.of("Power Level: 42"), noCap.lines(),
                "an unconfigured cap (0) is omitted, not printed as a cap of 0");
    }

    @Test
    void mcmmoSkillCensusIsThe19() {
        assertEquals(19, McMMoProvider.SKILLS.size(), "the panel maps all 19 primary skills");
        assertEquals(19, PrimarySkillType.values().length,
                "the fork's PrimarySkillType census the design verified");
        for (McMMoProvider.SkillDef def : McMMoProvider.SKILLS) {
            assertNotNull(def.type());
            assertFalse(def.displayName().isBlank());
            assertFalse(def.iconKey().isBlank());
        }
        // declaration order preserved end to end
        assertEquals(PrimarySkillType.ACROBATICS, McMMoProvider.SKILLS.get(0).type());
        assertEquals(PrimarySkillType.WOODCUTTING, McMMoProvider.SKILLS.get(18).type());
    }

    // ----------------- Magic header composition -----------------

    private static MagicLines.MagicData fullMagic() {
        return new MagicLines.MagicData(
                12, 1240L, 760L, 54321L,
                "Apprentice", "apprentice", "Master", "Mage",
                60.0f, 150, 25,
                "13.75", "13.75", "5.5",
                1234L, 4);
    }

    @Test
    void magicHeaderFullComposition() {
        MagicLines.MagicData d = fullMagic();
        List<String> lines = MagicLines.headerLines(d);
        assertEquals(List.of(
                "Magic Level 12 \u2014 54,321 XP total",
                "Rank: Apprentice",
                "Class: Mage",
                "Next rank: Master",
                "Mana: 60 / 150",
                "Mana regen: 25",
                "Boosts: mana pool +13.75%, mana regen +13.75%, cast cost -5.5%",
                "Total casts: 1,234",
                "Guild seals: 4 of 5"), lines);
        PanelModel.HeaderBlock block = MagicLines.headerBlock(d);
        assertNotNull(block);
        assertTrue(block.hasDetail(), "the Magic block opens the detail view");
        assertEquals(new PanelModel.BarData(1240, 2000), block.bar(),
                "the Magic bar spans into + to-next");
    }

    @Test
    void magicHeaderOmitsWhatDidNotRead() {
        MagicLines.MagicData sparse = new MagicLines.MagicData(
                null, null, null, null,
                null, null, null, null,
                null, null, null,
                null, null, null,
                null, null);
        assertNull(MagicLines.headerBlock(sparse),
                "nothing read -> no Magic block at all, never an empty or faked one");
        MagicLines.MagicData levelOnly = new MagicLines.MagicData(
                3, 10L, 90L, 250L,
                null, null, null, null,
                null, null, null,
                null, null, null,
                null, null);
        assertEquals(List.of("Magic Level 3 \u2014 250 XP total"),
                MagicLines.headerLines(levelOnly));
        // rank falls back to the KEY only when the name did not read
        MagicLines.MagicData keyOnly = new MagicLines.MagicData(
                null, null, null, null,
                null, "apprentice", null, null,
                null, null, null,
                null, null, null,
                null, null);
        assertEquals(List.of("Rank: apprentice"), MagicLines.headerLines(keyOnly));
    }

    @Test
    void magicBoostsLineLevels() {
        MagicLines.MagicData one = new MagicLines.MagicData(
                1, 0L, 100L, 0L, null, null, null, null, null, null, null,
                "0", "0", "0", null, null);
        assertEquals("Boosts: none yet \u2014 they start at Magic Level 2",
                MagicLines.boostsLine(one), "level 1 mirrors ExcelMagicLevel's own wording");
        MagicLines.MagicData poolOnly = new MagicLines.MagicData(
                5, 0L, 100L, 400L, null, null, null, null, null, null, null,
                "5", null, null, null, null);
        assertEquals("Boosts: mana pool +5%", MagicLines.boostsLine(poolOnly),
                "unread boost parts are omitted, not zero-filled");
    }

    @Test
    void magicBarAtCap() {
        MagicLines.MagicData capped = new MagicLines.MagicData(
                20, 500L, 0L, 99999L, null, null, null, null, null, null, null,
                null, null, null, null, null);
        PanelModel.BarData bar = MagicLines.magicBar(capped);
        assertNotNull(bar);
        assertTrue(bar.line().endsWith("MAX"),
                "to-next 0 with XP banked renders the capped bar (span = into)");
        assertNull(MagicLines.magicBar(new MagicLines.MagicData(
                null, null, null, null, null, null, null, null, null, null, null,
                null, null, null, null, null)), "no level surface -> no bar");
    }

    @Test
    void magicCastsNeverLabelledCredited() {
        for (String line : MagicLines.headerLines(fullMagic())) {
            assertFalse(line.toLowerCase().contains("credited"),
                    "casts are labelled casts, never credited: " + line);
        }
        for (String line : MagicLines.detailLines(fullMagic())) {
            assertFalse(line.toLowerCase().contains("credited"),
                    "the detail view keeps the same label discipline: " + line);
        }
    }

    @Test
    void magicDetailLeadsWithExplainer() {
        List<String> detail = MagicLines.detailLines(fullMagic());
        assertEquals(MagicLines.EXPLAINER, detail.get(0),
                "the detail view leads with the canonical explainer");
        assertTrue(detail.contains("Magic XP: "
                        + "\u25B0\u25B0\u25B0\u25B0\u25B0\u25B0\u25B1\u25B1\u25B1\u25B1 62% \u2014 1,240 / 2,000 XP"),
                "the detail view carries the bar numbers line");
        assertTrue(MagicLines.detailLines(new MagicLines.MagicData(
                null, null, null, null, null, null, null, null, null, null, null,
                null, null, null, null, null)).isEmpty(),
                "no reads -> no detail view");
    }

    @Test
    void percentFormattingMatchesExcelMagicLevel() {
        // ExcelMagicLevel Percents.format's own documented examples
        assertEquals("1.25", MagicLines.percentOf(0.0125));
        assertEquals("9.5", MagicLines.percentOf(0.095));
        assertEquals("23.75", MagicLines.percentOf(0.2375));
        assertEquals("0", MagicLines.percentOf(0.0));
        // the reward-table formula at level 12: per-level x 11
        assertEquals("13.75", MagicLines.percentOf(0.0125 * 11));
        assertEquals("5.5", MagicLines.percentOf(0.005 * 11));
    }

    // ----------------- panel assembly -----------------

    @Test
    void panelBodyAndChatLines() {
        PanelModel.Panel panel = new PanelModel.Panel(
                List.of(SkillMath.powerHeader(100, 0),
                        MagicLines.headerBlock(fullMagic())),
                List.of(SkillMath.mcmmoRow("mining", "Mining", "IRON_PICKAXE",
                        214, 1240, 2000, null)),
                MagicLines.detailLines(fullMagic()));
        String body = panel.bedrockBody();
        assertTrue(body.startsWith("Power Level\nPower Level: 100\n\nMagic\n"),
                "headers lead the Bedrock body, in provider order");
        assertTrue(body.contains("Guild seals: 4 of 5"));
        assertTrue(body.endsWith("Mining 214 "
                        + "\u25B0\u25B0\u25B0\u25B0\u25B0\u25B0\u25B1\u25B1\u25B1\u25B1 62%"),
                "the compact skill lines close the body");
        List<String> chat = panel.chatLines();
        assertEquals("Skills", chat.get(0));
        assertTrue(chat.contains("Mining 214 "
                + "\u25B0\u25B0\u25B0\u25B0\u25B0\u25B0\u25B1\u25B1\u25B1\u25B1 62%"),
                "the chat fallback carries the same compact lines");
        assertTrue(panel.hasMagicDetail());
        assertNotNull(panel.header("magic"));
        assertNull(panel.header("nope"));
    }

    // ----------------- Bedrock form handler (real Cumulus) -----------------

    @Test
    void bedrockFormsHandlerShape() throws Exception {
        // Structural pin on the compiled BedrockForms: the NEW
        // Cumulus + Geyser-only path is what ships (the Summons
        // 0.1.8 shape); the dead 0.1.7 shape stays out.
        byte[] bytes;
        try (var in = PanelTest.class.getResourceAsStream(
                "/com/winkreyes/excelskillspanel/bukkit/BedrockForms.class")) {
            assertNotNull(in, "BedrockForms.class is on the test classpath");
            bytes = in.readAllBytes();
        }
        String pool = new String(bytes, java.nio.charset.StandardCharsets.ISO_8859_1);
        assertTrue(pool.contains("org.geysermc.cumulus.form.SimpleForm"), "the NEW Cumulus SimpleForm");
        assertTrue(pool.contains("org.geysermc.cumulus.form.util.FormBuilder"), "the new FormBuilder");
        assertTrue(pool.contains("resultHandler"), "the handler attaches via FormBuilder.resultHandler");
        assertTrue(pool.contains("clickedButtonId"), "the index unwraps via SimpleFormResponse.clickedButtonId");
        assertTrue(pool.contains("connectionByUuid"), "the connection is looked up by player uuid");
        assertFalse(pool.contains("org.geysermc.cumulus.SimpleForm"),
                "the OLD Cumulus SimpleForm is gone");
        assertFalse(pool.contains("validResultHandler"), "the 0.1.7 handler hunt is gone");
        assertFalse(pool.contains("floodgate"), "the Floodgate attempt is gone — Geyser class loader only");
    }

    @Test
    void bedrockFormsHandlerDeliversEveryIndex() throws Exception {
        // Behavioral proof against the REAL Cumulus classes in
        // the staged Geyser jar (local-build.sh passes its path):
        // for each form shape the panel sends, a synthetic
        // response is driven through the handler
        // BedrockForms.buildForm attached — via
        // FormImpl.callResultHandler AND via the raw-payload
        // entry (SimpleFormDefinition.handleFormResponse). A
        // closed form must report -1.
        String geyserJar = System.getProperty("skillspanel.test.geyserJar");
        String guavaJar = System.getProperty("skillspanel.test.guavaJar");
        String gsonJar = System.getProperty("skillspanel.test.gsonJar");
        assertNotNull(geyserJar, "local-build.sh passes -Dskillspanel.test.geyserJar");
        java.net.URLClassLoader l = new java.net.URLClassLoader(new java.net.URL[]{
                java.nio.file.Path.of(geyserJar).toUri().toURL(),
                java.nio.file.Path.of(guavaJar).toUri().toURL(),
                java.nio.file.Path.of(gsonJar).toUri().toURL()},
                PanelTest.class.getClassLoader());
        Class<?> formImpl = Class.forName("org.geysermc.cumulus.form.impl.FormImpl", true, l);
        Class<?> resultT = Class.forName("org.geysermc.cumulus.response.result.FormResponseResult", true, l);
        Class<?> validT = Class.forName("org.geysermc.cumulus.response.result.ValidFormResponseResult", true, l);
        Class<?> respImpl = Class.forName("org.geysermc.cumulus.response.impl.SimpleFormResponseImpl", true, l);
        Class<?> buttonT = Class.forName("org.geysermc.cumulus.component.ButtonComponent", true, l);
        Class<?> responseT = Class.forName("org.geysermc.cumulus.response.FormResponse", true, l);
        java.lang.reflect.Method respOf = respImpl.getMethod("of", int.class, buttonT);
        java.lang.reflect.Method validOf = validT.getMethod("of", responseT);
        java.lang.reflect.Method callHandler = formImpl.getMethod("callResultHandler", resultT);
        java.lang.reflect.Method closedOf = resultT.getMethod("closed");
        Object definition = Class.forName("org.geysermc.cumulus.form.impl.simple.SimpleFormDefinition", true, l)
                .getMethod("instance").invoke(null);
        java.lang.reflect.Method handleRaw = definition.getClass().getMethod("handleFormResponse",
                Class.forName("org.geysermc.cumulus.form.Form", true, l), String.class);
        java.util.logging.Logger log = java.util.logging.Logger.getLogger("skillspanel-test");
        java.util.Map<String, List<String>> shapes = new java.util.LinkedHashMap<>();
        shapes.put("panel", List.of("Magic \u2014 details", "Mining \u2014 Lv 214",
                "Fishing \u2014 Lv 3", "Close"));
        shapes.put("skill-detail", List.of("Back to Skills"));
        shapes.put("magic-detail", List.of("Back to Skills"));
        for (var shape : shapes.entrySet()) {
            java.util.concurrent.atomic.AtomicInteger got =
                    new java.util.concurrent.atomic.AtomicInteger(Integer.MIN_VALUE);
            Object form = BedrockForms.buildForm(l, "Skills", "body",
                    shape.getValue(), got::set, log);
            List<?> buttons = (List<?>) form.getClass().getMethod("buttons").invoke(form);
            assertEquals(shape.getValue().size(), buttons.size(),
                    shape.getKey() + " form carries its buttons");
            for (int i = 0; i < buttons.size(); i++) {
                got.set(Integer.MIN_VALUE);
                callHandler.invoke(form, validOf.invoke(null, respOf.invoke(null, i, buttons.get(i))));
                assertEquals(i, got.get(),
                        shape.getKey() + " button " + i + " reaches the callback via callResultHandler");
                got.set(Integer.MIN_VALUE);
                handleRaw.invoke(definition, form, String.valueOf(i));
                assertEquals(i, got.get(),
                        shape.getKey() + " button " + i + " reaches the callback via the raw payload path");
            }
            got.set(Integer.MIN_VALUE);
            callHandler.invoke(form, closedOf.invoke(null));
            assertEquals(-1, got.get(), shape.getKey() + ": a closed form reports -1");
            got.set(Integer.MIN_VALUE);
            handleRaw.invoke(definition, form, "null");
            assertEquals(-1, got.get(), shape.getKey() + ": the client's close payload reports -1");
        }
    }
}
