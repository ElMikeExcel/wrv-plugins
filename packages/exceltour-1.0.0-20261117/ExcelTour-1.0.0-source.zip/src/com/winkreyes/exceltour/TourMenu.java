package com.winkreyes.exceltour;

import com.winkreyes.exceltour.core.Progress;
import com.winkreyes.exceltour.core.Route;
import com.winkreyes.exceltour.core.Step;
import com.winkreyes.exceltour.core.TextPlain;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/**
 * The Java tour view (DESIGN §5.2) — an inventory menu opened by
 * /tour, /tour menu, and the compass-menu Guide entry. Same
 * information and controls as the Bedrock form: current step,
 * Repeat, Next/Done (when allowed), Skip (when allowed), Restart
 * (two-click confirm), Stop tour. Reading the view advances nothing.
 */
public final class TourMenu implements InventoryHolder {
    private final ExcelTour plugin;
    private final Player viewer;
    private final boolean confirmRestart;
    private Inventory inventory;

    public TourMenu(ExcelTour plugin, Player viewer, boolean confirmRestart) {
        this.plugin = plugin; this.viewer = viewer; this.confirmRestart = confirmRestart;
    }

    @Override public Inventory getInventory() { return inventory; }
    public boolean isConfirmRestart() { return confirmRestart; }

    public void open() {
        String routeId = plugin.engine().activeRouteId(viewer.getUniqueId());
        Route route = routeId == null ? plugin.defaultRoute() : plugin.engine().route(routeId);
        if (route == null) {
            viewer.sendMessage(Component.text("No tour routes are loaded right now.", NamedTextColor.RED));
            return;
        }
        Progress p = plugin.engine().progress(viewer.getUniqueId(), route.id);
        inventory = Bukkit.createInventory(this, 27,
                Component.text("Guide — " + TextPlain.plain(route.displayName), NamedTextColor.DARK_AQUA));
        if (p == null || p.state == Progress.State.NOT_STARTED) {
            inventory.setItem(13, item(Material.COMPASS, "Start: " + TextPlain.plain(route.displayName),
                    List.of(TextPlain.plain(route.description), "Click to begin the tour.")));
            inventory.setItem(26, item(Material.BARRIER, "Close", List.of()));
        } else if (p.state == Progress.State.COMPLETED) {
            inventory.setItem(13, item(Material.COMPASS, TextPlain.plain(route.displayName) + " — finished",
                    List.of("You finished this tour" + (p.completions > 0 ? " (" + p.completions + "x)" : "") + ".",
                            "Click Restart below to walk it again.")));
            inventory.setItem(22, item(Material.CLOCK, confirmRestart ? "Click again to confirm restart" : "Restart tour",
                    List.of("Back to Step 1.")));
            inventory.setItem(26, item(Material.BARRIER, "Close", List.of()));
        } else {
            Step step = route.stepById(p.currentStepId);
            if (step == null) { viewer.sendMessage(Component.text("Your tour step could not be found — it has been reset.", NamedTextColor.RED)); return; }
            inventory.setItem(13, item(Material.BOOK,
                    "Step " + route.indexOf(step.id) + " of " + route.steps.size() + " — " + TextPlain.plain(step.title),
                    wrap(TextPlain.plain(step.body), step.hint)));
            inventory.setItem(10, item(Material.PAPER, "Repeat", List.of("Hear this step again.")));
            if (step.trigger.menuAdvanceable())
                inventory.setItem(12, item(Material.LIME_DYE, "Done — next step", List.of("I did this step.")));
            if (step.skippable)
                inventory.setItem(14, item(Material.FEATHER, "Skip", List.of("Pass this step.")));
            inventory.setItem(16, item(Material.CLOCK, confirmRestart ? "Click again to confirm restart" : "Restart",
                    List.of("Back to Step 1 (finished count kept).")));
            inventory.setItem(22, item(Material.GRAY_DYE, "Stop tour", List.of("End the tour; you can start again any time.")));
            inventory.setItem(26, item(Material.BARRIER, "Close", List.of()));
        }
        viewer.openInventory(inventory);
    }

    private static List<String> wrap(String body, String hint) {
        java.util.List<String> lines = new java.util.ArrayList<>();
        String cur = "";
        for (String w : body.split(" ")) {
            if (cur.length() + w.length() > 38) { lines.add(cur); cur = w; } else cur = cur.isEmpty() ? w : cur + " " + w;
        }
        if (!cur.isEmpty()) lines.add(cur);
        if (hint != null) { lines.add(""); lines.add("Hint: " + TextPlain.plain(hint)); }
        return lines;
    }

    static ItemStack item(Material mat, String name, List<String> lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.displayName(Component.text(name, NamedTextColor.WHITE));
            java.util.List<Component> loreC = new java.util.ArrayList<>();
            for (String l : lore) loreC.add(Component.text(l, NamedTextColor.GRAY));
            meta.lore(loreC);
            it.setItemMeta(meta);
        }
        return it;
    }
}
