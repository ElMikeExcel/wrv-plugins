package com.winkreyes.exceltour;

/** Version fragments for the in-jar fingerprint gate (house pattern). */
public final class BuildInfo {
    public static final String VERSION = "1.0.0";
    public static final String BUILD_ID = "EXC-TOUR-1.0.0-WRV-20261111-01-t0ur";
    public static final String BUILD_TAG = "t0ur";
    private BuildInfo() {}
}
