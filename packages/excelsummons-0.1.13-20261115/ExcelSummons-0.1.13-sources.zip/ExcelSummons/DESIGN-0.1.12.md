# ExcelSummons 0.1.12 — GameplayEvent emitter adoption (design note)

Follow-on named by the ExcelProtect 0.1.10 Audit Watch build
(P-PROTECT-WATCH-1, run 364): Protect's audit watch can only log
summon refusals it can observe (PreCast sightings, stamped
source=observed_precast, no reason). Summons now EMITS its own
facts through Protect's GameplayEvent door
(api/GameplayEvent + ExcelProtectAPI.gameplay, 0.1.10), with the
bridge's true reasons and the same numbers shown to the player.

## Contract (mirrored from Protect's consumer, AuditWatch)

- Kinds fired: summon_refusal, summon_spawn, summon_despawn,
  mana_reserve. (spell_cast is Protect's own Magic feed.)
- Every field map carries player + player_uuid + source=
  ExcelSummons; values are String/Number/Boolean only (the
  consumer copies nothing else); summon is the family base key.
- summon_refusal: reason cap (cap_kind = spell_cap | total_cap |
  server_ceiling) or reserve_ceiling | reserve_floor, plus the
  player-shown numbers and the message text. Fired for EVERY
  refusal (the 1.5 s chat throttle does not gate the record) at
  PreCast (stage=prec_cast) and at the onCast backstop
  (stage=capture_backstop).
- summon_spawn: at cast capture (origin=cast) and at sweep
  adoption (origin=adopted), with entity_uuid / entity_type /
  branch / expires_ms.
- summon_despawn: from the ONE removal funnel (finalizeRemoval),
  reason expired | dismissed | died | unloaded | caster_left
  (the silent caster-leaves path), plus the released applied
  hold. Server-shutdown removals in onDisable do not fire (the
  funnel is not used there; Protect's observed feed covers the
  registry drop).
- mana_reserve: the bridge's OWN applied numbers, fired paired
  with each spawn/despawn while the owner is online (skipped
  offline — Protect's derived line covers that moment).

## Mechanism (house isolation pattern)

- GameplayEmit (pure): builds every field map + reason maps;
  unit-tested off-server.
- GameplaySink (plain seam) + protect/ProtectGameplayGateway:
  the ONLY class linking ExcelProtect's API; compiles against
  the 0.1.10 jar, never bundled.
- GameplayDoor: binds the gateway only when the ExcelProtect
  plugin is present + enabled (at enable, and again on
  PluginEnableEvent for late enables); otherwise NOOP. No
  plugin.yml dependency is added — the door is opportunistic
  and fire-and-forget, exactly per the contract.
- Door refuses incomplete maps (no player name) before firing,
  mirroring the consumer's drop rule.

## Ordering

Installs AFTER ExcelSummons 0.1.11 (which installs after BB-11
0.1.10). ExcelProtect 0.1.10 is NOT a hard gate — without it the
door stays unbound and Summons behaves exactly as 0.1.11 — but
the audit payoff (emitter-grade refusal/reserve records) exists
only once Protect 0.1.10 is live.
