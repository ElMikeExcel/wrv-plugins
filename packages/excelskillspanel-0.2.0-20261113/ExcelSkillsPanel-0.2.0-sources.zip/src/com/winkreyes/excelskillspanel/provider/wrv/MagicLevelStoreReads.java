package com.winkreyes.excelskillspanel.provider.wrv;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * The two ExcelMagicLevel values its PlaceholderAPI surface does
 * not expose in 0.2.0 (the optional placeholder additions in
 * DESIGN §7.4 were not built): a player's TOTAL CASTS and the
 * reward table's regen / cost per-level fractions. Both are read
 * from ExcelMagicLevel's own live state, fail-soft, and only
 * ever ADD lines to the header — a failed read omits, never
 * substitutes.
 *
 * Total casts (PlayerRecord.totalCasts, "informational"):
 * 1) the LIVE in-memory store, reached reflectively through the
 *    plugin instance's store field (public PlayerStore.find /
 *    PlayerRecord.totalCasts on the far side — the same
 *    reflective-read family as the GuildGate pattern);
 * 2) failing that, ExcelMagicLevel's persisted players.yml in
 *    its data folder (the store's own SPEC §7.1 format:
 *    players.&lt;uuid&gt;.total-casts; at most one debounce
 *    window stale).
 * The value is labelled "casts" on the panel — never "credited"
 * (DESIGN §7.2: equivalence to the rank-driving credited-cast
 * count is unverified).
 *
 * Boost fractions: ExcelMagicLevel's live config.yml
 * (rewards.per-level.*) — the exact fractions its RewardTable
 * was built from; the header applies boostAt's formula
 * (per-level x (level - 1)) in MagicLines' percent formatting.
 *
 * Excel — Wink Reyes Valley (Iris / Mike).
 */
public final class MagicLevelStoreReads {
    private MagicLevelStoreReads() {}

    /** Total casts for a player, or null when no read succeeds. */
    public static Long totalCasts(UUID uuid, Logger log) {
        Plugin eml = emlPlugin();
        if (eml == null) return null;
        Long live = liveStoreCasts(eml, uuid);
        if (live != null) return live;
        try {
            File file = new File(eml.getDataFolder(), "players.yml");
            if (!file.isFile()) return null;
            YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
            String path = "players." + uuid + ".total-casts";
            return yaml.contains(path) ? yaml.getLong(path) : null;
        } catch (Throwable t) {
            log.warning("ExcelSkillsPanel: ExcelMagicLevel players.yml casts read failed: "
                    + t.getClass().getSimpleName() + ": " + t.getMessage()
                    + " — casts line omitted");
            return null;
        }
    }

    /** Reflective read of the live in-memory store. Any mismatch
     *  (a future ExcelMagicLevel reshaping its internals) falls
     *  back to the persisted file — logged once here at FINE-plus
     *  via the caller's warning only when both routes fail. */
    private static Long liveStoreCasts(Plugin eml, UUID uuid) {
        try {
            Field storeField = eml.getClass().getDeclaredField("store");
            storeField.setAccessible(true);
            Object store = storeField.get(eml);
            if (store == null) return null;
            Method find = store.getClass().getMethod("find", UUID.class);
            Object record = find.invoke(store, uuid);
            if (record == null) return null;
            Method totalCasts = record.getClass().getMethod("totalCasts");
            Object value = totalCasts.invoke(record);
            return value instanceof Number ? ((Number) value).longValue() : null;
        } catch (Throwable t) {
            return null;
        }
    }

    /** The reward table's per-level fractions from ExcelMagicLevel's
     *  live config: [manaRegenerationBoost, costReduction], or null
     *  when the config cannot be read. */
    public static double[] perLevelBoosts() {
        Plugin eml = emlPlugin();
        if (eml == null) return null;
        try {
            File file = new File(eml.getDataFolder(), "config.yml");
            if (!file.isFile()) return null;
            YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
            double regen = yaml.getDouble("rewards.per-level.mana-regeneration-boost", Double.NaN);
            double cost = yaml.getDouble("rewards.per-level.cost-reduction", Double.NaN);
            if (Double.isNaN(regen) || Double.isNaN(cost)) return null;
            return new double[]{regen, cost};
        } catch (Throwable t) {
            return null;
        }
    }

    private static Plugin emlPlugin() {
        Plugin eml = Bukkit.getPluginManager().getPlugin("ExcelMagicLevel");
        return eml != null && eml.isEnabled() ? eml : null;
    }
}
