package com.winkreyes.excelskillspanel.provider.wrv;

import com.winkreyes.excelskillspanel.core.MagicLines;
import com.winkreyes.excelskillspanel.core.PanelModel;
import com.winkreyes.excelskillspanel.provider.SkillsProvider;
import com.winkreyes.excelskillspanel.provider.papi.PapiReads;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.List;
import java.util.logging.Logger;

/**
 * Provider #2 — the WRV-only Magic module (DESIGN §7.3: excluded
 * from any commercial build). Supplies the FULL Magic header
 * (Mike's Q2 ruling) from verified reads only:
 *
 * - Magic Level + XP bar + total XP + mana-pool boost %: the
 *   ExcelMagicLevel PlaceholderAPI surface
 *   (%excelmagiclevel_level/_xp/_next/_total_xp/_mana_boost%).
 * - Rank name/key, next rank, class name, absolute mana pool and
 *   regen: the Magic API chain in MagicApiReads (verified run
 *   273, rig-proven — see RIG-RESULTS.md).
 * - Regen / cast-cost boost %: ExcelMagicLevel's reward-table
 *   formula over its live config fractions (MagicLevelStoreReads).
 * - Total casts (labelled "casts", never "credited"): the
 *   ExcelMagicLevel store reads.
 * - "Guild seals: N of 5": the GuildGate reflective read.
 *
 * Composition is pure (MagicLines): every field that fails to
 * read is omitted from the header — the panel never fakes a
 * field. Failures log at WARNING (never silent).
 *
 * Excel — Wink Reyes Valley (Iris / Mike).
 */
public final class MagicHeaderProvider implements SkillsProvider {

    private final Logger log;

    public MagicHeaderProvider(Logger log) {
        this.log = log;
    }

    @Override
    public String id() { return "magic"; }

    @Override
    public ProviderData collect(Player player) {
        // --- ExcelMagicLevel PAPI surface ---
        Integer level = PapiReads.getInt(player, "%excelmagiclevel_level%");
        Long xpInto = PapiReads.getLong(player, "%excelmagiclevel_xp%");
        Long xpToNext = PapiReads.getLong(player, "%excelmagiclevel_next%");
        Long totalXp = PapiReads.getLong(player, "%excelmagiclevel_total_xp%");
        String manaBoost = PapiReads.get(player, "%excelmagiclevel_mana_boost%");
        if (level == null && pluginPresent("ExcelMagicLevel")) {
            log.warning("ExcelSkillsPanel: ExcelMagicLevel is enabled but its "
                    + "PlaceholderAPI surface returned no level for " + player.getName()
                    + " — Magic Level lines omitted (check PlaceholderAPI)");
        }

        // --- Magic API chain (rank + absolute mana) ---
        String rankName = null, rankKey = null, nextRankName = null, className = null;
        Float mana = null;
        Integer manaMax = null, manaRegen = null;
        if (pluginPresent("Magic")) {
            try {
                MagicApiReads.MagicApiData api = MagicApiReads.read(player);
                if (api != null) {
                    rankName = api.rankName();
                    rankKey = api.rankKey();
                    nextRankName = api.nextRankName();
                    className = api.className();
                    mana = api.mana();
                    manaMax = api.manaMaxEffective();
                    manaRegen = api.manaRegenEffective();
                } else {
                    log.warning("ExcelSkillsPanel: Magic is enabled but no mage read "
                            + "for " + player.getName() + " — rank/mana lines omitted");
                }
            } catch (Throwable t) {
                log.warning("ExcelSkillsPanel: Magic API read failed for " + player.getName()
                        + ": " + t.getClass().getSimpleName() + ": " + t.getMessage()
                        + " — rank/mana lines omitted, never faked");
            }
        }

        // --- regen / cost boost % via the reward-table formula ---
        String regenBoost = null, costReduction = null;
        if (level != null && level >= 2) {
            double[] perLevel = MagicLevelStoreReads.perLevelBoosts();
            if (perLevel != null) {
                regenBoost = MagicLines.percentOf(perLevel[0] * (level - 1));
                costReduction = MagicLines.percentOf(perLevel[1] * (level - 1));
            }
        }

        Long casts = MagicLevelStoreReads.totalCasts(player.getUniqueId(), log);
        Integer seals = GuildSealsReads.sealsBrokenCount();

        MagicLines.MagicData data = new MagicLines.MagicData(
                level, xpInto, xpToNext, totalXp,
                rankName, rankKey, nextRankName, className,
                mana, manaMax, manaRegen,
                manaBoost, regenBoost, costReduction,
                casts, seals);
        PanelModel.HeaderBlock block = MagicLines.headerBlock(data);
        if (block == null) return ProviderData.empty();
        return new ProviderData(List.of(block), List.of(), MagicLines.detailLines(data));
    }

    private static boolean pluginPresent(String name) {
        Plugin p = Bukkit.getPluginManager().getPlugin(name);
        return p != null && p.isEnabled();
    }
}
