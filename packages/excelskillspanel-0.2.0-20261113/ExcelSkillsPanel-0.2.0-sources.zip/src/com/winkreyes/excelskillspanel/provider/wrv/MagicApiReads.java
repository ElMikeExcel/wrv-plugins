package com.winkreyes.excelskillspanel.provider.wrv;

import com.elmakers.mine.bukkit.api.magic.Mage;
import com.elmakers.mine.bukkit.api.magic.MageClass;
import com.elmakers.mine.bukkit.api.magic.MageController;
import com.elmakers.mine.bukkit.api.magic.MagicAPI;
import com.elmakers.mine.bukkit.api.magic.ProgressionPath;
import com.elmakers.mine.bukkit.api.wand.Wand;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;

/**
 * The Magic API reads behind the FULL Magic header (Mike's Q2
 * ruling). The call chain was verified desk-side in run 273
 * against the real Magic-11.2.5.jar, and the ONE open question
 * it left — which exact read returns the rank NAME as displayed
 * — was settled on this build's local rig (RIG-RESULTS.md):
 *
 * RIG FINDING (Nov 12, 2026, fixture = Mike's real mage data):
 * Mage.getActiveClass().getPath() reports the class's BASE path
 * ("Beginner") whether or not a wand is held — it does NOT
 * follow the player's progression. The rank a player actually
 * holds lives on their ACTIVE WAND: Mage.getActiveWand() -&gt;
 * Wand.getPath() (a WandUpgradePath, which extends
 * ProgressionPath) returned "Apprentice" for Mike's fixture,
 * matching the wand item's own lore line "Rank: Apprentice
 * (ceiling: Master)" exactly. The mana reads, by contrast, DO
 * follow the held wand through the mage's effective values
 * (pool 51 -&gt; 154 on equip, the apprentice override + boosts).
 *
 * So the rank source order is:
 * 1) the active wand's path (the displayed rank);
 * 2) the active class's path (no wand in hand — the class's own
 *    standing, honestly labelled by being the only read left);
 * 3) the active properties' path (CasterProperties.getPath —
 *    the ExcelMagicLevel rig route).
 * The next-rank line comes from the SAME path object's
 * getNextPath(). Names arrive with legacy color codes embedded
 * ("§aApprentice"); the panel strips them — the name as
 * displayed, without formatting bytes that the Java chest's
 * component text would print literally.
 *
 * Mana: mage.getMana() / getEffectiveManaMax() /
 * getEffectiveManaRegeneration() — absolute values, verified in
 * run 273 and cross-checked on the rig.
 *
 * Every value that cannot be read stays null — the composer
 * omits the line; nothing is ever substituted. This class
 * references Magic API types directly and is only loaded when
 * the Magic plugin is present (guarded by the provider, which
 * catches linkage failures as a logged omission).
 *
 * Excel — Wink Reyes Valley (Iris / Mike).
 */
public final class MagicApiReads {
    private MagicApiReads() {}

    /** The Magic-API slice of the header DTO; all fields nullable. */
    public record MagicApiData(String rankName, String rankKey, String nextRankName,
                               String className, Float mana, Integer manaMaxEffective,
                               Integer manaRegenEffective) {}

    public static MagicApiData read(Player player) {
        MageController controller = controller();
        if (controller == null) return null;
        Mage mage = controller.getMage(player);
        if (mage == null) return null;

        String className = null;
        MageClass active = mage.getActiveClass();
        if (active != null) className = stripLegacy(active.getName());

        ProgressionPath path = null;
        try {
            Wand wand = mage.getActiveWand();
            if (wand != null) path = wand.getPath();
        } catch (Throwable ignored) {
            // fall through to the class path
        }
        if (path == null && active != null) {
            try { path = active.getPath(); } catch (Throwable ignored) {}
        }
        if (path == null) {
            try {
                if (mage.getActiveProperties() != null) {
                    path = mage.getActiveProperties().getPath();
                }
            } catch (Throwable ignored) {
                // omission is honest; the composer drops the line
            }
        }

        String rankName = null, rankKey = null, nextRankName = null;
        if (path != null) {
            rankName = stripLegacy(path.getName());
            rankKey = path.getKey();
            ProgressionPath next = path.getNextPath();
            if (next != null) nextRankName = stripLegacy(next.getName());
        }

        Float mana = null;
        Integer manaMax = null, manaRegen = null;
        try { mana = mage.getMana(); } catch (Throwable ignored) {}
        try { manaMax = mage.getEffectiveManaMax(); } catch (Throwable ignored) {}
        try { manaRegen = mage.getEffectiveManaRegeneration(); } catch (Throwable ignored) {}
        return new MagicApiData(rankName, rankKey, nextRankName, className,
                mana, manaMax, manaRegen);
    }

    /** Remove legacy (§) formatting codes from a Magic display
     *  name: "§aApprentice" -&gt; "Apprentice". */
    static String stripLegacy(String s) {
        if (s == null) return null;
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\u00A7' && i + 1 < s.length()) { i++; continue; }
            out.append(c);
        }
        return out.toString();
    }

    /** The controller route ExcelMagicLevel's MagicBridge proves:
     *  the MagicAPI service first, the plugin-instance cast as
     *  the fallback. */
    static MageController controller() {
        try {
            RegisteredServiceProvider<MagicAPI> rsp =
                    Bukkit.getServicesManager().getRegistration(MagicAPI.class);
            if (rsp != null && rsp.getProvider() != null) {
                return rsp.getProvider().getController();
            }
        } catch (Throwable ignored) {
            // fall through to the plugin-cast route
        }
        try {
            Plugin magic = Bukkit.getPluginManager().getPlugin("Magic");
            if (magic instanceof MagicAPI api) return api.getController();
        } catch (Throwable ignored) {
            // no controller: caller omits the Magic API lines
        }
        return null;
    }
}
