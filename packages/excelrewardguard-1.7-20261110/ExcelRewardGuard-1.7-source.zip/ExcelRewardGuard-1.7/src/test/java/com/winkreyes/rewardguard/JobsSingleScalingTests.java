package com.winkreyes.rewardguard;

/**
 * Regression suite for the 1.2 Jobs XP double-scale bug, fixed in 1.3.
 *
 * The bug (proven from the live Jobs database, REWARDGUARD-AUDIT-2026-10-18.md):
 * Jobs fires BOTH JobsPrePaymentEvent and JobsExpGainEvent for one kill,
 * and the XP amount chains through them — the pre-payment event's XP is
 * the value the XP-gain event then carries. 1.2 scaled XP in both
 * handlers, so farmed Jobs XP was paid at the farm percent squared
 * (0.55 x 0.55 = 0.3025) while money, which only passes through the
 * pre-payment event, was paid correctly at 0.55. The audit's farm batches
 * sit at exactly x0.3025 on XP and x0.55 on money, Kailey's spawner
 * window (193 kills) included.
 *
 * The 1.3 fix is structural channel ownership in JobsVeto:
 *   - onPrePayment scales money and points ONLY, never the event's XP;
 *   - onExpGain scales XP ONLY, exactly once.
 * This suite composes RewardScale in exactly the handlers' order and
 * shape (the same modelling convention RewardScaleTests uses for
 * McMmoVeto), and pins three things: the fixed pipeline pays base x rate
 * per channel; the OLD 1.2 composition reproduces the audit's squared
 * rate (so the test demonstrably models the real pipeline); and natural
 * kills, rate 0 and rate 1 behave exactly.
 */
public final class JobsSingleScalingTests {
    private static int assertions;
    private static void check(boolean condition) { assertions++; if (!condition) throw new AssertionError("check " + assertions); }

    /** One kill's rewards as Jobs carries them: money, points, XP. */
    private record Payment(double money, double points, double exp) { }

    /** JobsVeto.onPrePayment, 1.3 shape: farmed -> scale money+points, NEVER touch XP. Natural -> untouched. */
    private static Payment prePayment(Payment in, boolean farmed, double rate) {
        if (!farmed || rate >= 1.0) return in;
        return new Payment(RewardScale.scaleRate(in.money(), rate),
                           RewardScale.scaleRate(in.points(), rate),
                           in.exp());
    }

    /** JobsVeto.onExpGain, 1.3 shape: farmed -> scale XP exactly once. Money/points are not in this event. */
    private static Payment expGain(Payment in, boolean farmed, double rate) {
        if (!farmed || rate >= 1.0) return in;
        return new Payment(in.money(), in.points(), RewardScale.scaleRate(in.exp(), rate));
    }

    /** The full kill pipeline in the order Jobs fires it. */
    private static Payment pipeline(Payment base, boolean farmed, double rate) {
        return expGain(prePayment(base, farmed, rate), farmed, rate);
    }

    /** The 1.2 composition: pre-payment ALSO scaled XP. Kept here to prove the model reproduces the audited bug. */
    private static Payment pipeline12(Payment base, boolean farmed, double rate) {
        Payment afterPre = farmed
            ? new Payment(RewardScale.scaleRate(base.money(), rate),
                          RewardScale.scaleRate(base.points(), rate),
                          RewardScale.scaleRate(base.exp(), rate))
            : base;
        return expGain(afterPre, farmed, rate);
    }

    public static void main(String[] args) {
        // The audit's canonical kill: Hunter zombie, modelled natural XP
        // 16.02, money 10.00, points 5.00.
        Payment base = new Payment(10.0, 5.0, 16.02);

        // --- The fix at the new rate (0.33): each channel scaled ONCE. ---
        Payment fixed = pipeline(base, true, 0.33);
        check(fixed.money() == 3.30);          // 10.00 x 0.33, once
        check(fixed.points() == 1.65);         // 5.00 x 0.33, once
        check(fixed.exp() == 5.29);            // 16.02 x 0.33 = 5.2866 -> 5.29, once
        check(fixed.exp() == RewardScale.scaleRate(16.02, 0.33));
        // ...and NOT the squared application: a second scaling of the same
        // XP would land at 1.75 (5.29 x 0.33). The fixed pipeline's output
        // must differ from it, or the bug is back.
        check(fixed.exp() != RewardScale.scaleRate(fixed.exp(), 0.33));
        check(RewardScale.scaleRate(fixed.exp(), 0.33) == 1.75);

        // --- The old 1.2 composition at the old rate reproduces the audit. ---
        Payment buggy = pipeline12(base, true, 0.55);
        check(buggy.money() == 5.50);                       // money was always right: x0.55 once
        check(buggy.exp() == 4.85);                         // 16.02 -> 8.81 -> 4.85 under per-step cent rounding
        double ratio = buggy.exp() / base.exp();
        check(Math.abs(ratio - 0.3025) < 0.001);            // == the audit's x0.3025 cluster (0.55 squared)
        check(buggy.money() / base.money() == 0.55);        // money ratio stayed exactly 0.55 in the same batches

        // --- The fixed pipeline at the OLD rate pays the full 0.55 on XP. ---
        Payment fixedAt55 = pipeline(base, true, 0.55);
        check(fixedAt55.exp() == 8.81);                     // 16.02 x 0.55, once — what 1.2 intended and never paid
        check(fixedAt55.money() == 5.50);

        // --- Natural kills pass through EXACTLY at any rate (no rounding dust). ---
        Payment odd = new Payment(3.333, 0.065, 16.025);
        Payment natural = pipeline(odd, false, 0.33);
        check(natural.money() == 3.333);
        check(natural.points() == 0.065);
        check(natural.exp() == 16.025);
        Payment natural12 = pipeline12(odd, false, 0.55);
        check(natural12.exp() == 16.025);                   // the bug only ever bit farmed kills

        // --- Fall-softened kills compose identically (classification-agnostic once farmed). ---
        Payment fall = pipeline(base, true, 0.33);
        check(fall.equals(fixed));                          // same numbers as the origin-classified kill above

        // --- Rate 0: every channel zero (the handlers also cancel). ---
        Payment zeroed = pipeline(base, true, 0.0);
        check(zeroed.money() == 0.0);
        check(zeroed.points() == 0.0);
        check(zeroed.exp() == 0.0);

        // --- Rate 1: exact pass-through, unrounded, even for farmed kills. ---
        Payment full = pipeline(odd, true, 1.0);
        check(full.money() == 3.333);
        check(full.points() == 0.065);
        check(full.exp() == 16.025);

        // --- Money never enters the XP event: after pre-payment, the
        // XP-gain step cannot move money (channel separation). ---
        Payment afterPre = prePayment(base, true, 0.33);
        check(afterPre.money() == 3.30);
        check(afterPre.exp() == 16.02);                     // pre-payment leaves XP at the unscaled base...
        Payment afterGain = expGain(afterPre, true, 0.33);
        check(afterGain.money() == 3.30);                   // ...the XP step leaves money where pre-payment put it
        check(afterGain.exp() == 5.29);                     // ...and scales the still-unscaled XP exactly once

        System.out.println("PASS " + assertions + " jobs single-scaling assertions (1.3 pipeline pays rate once per channel; 1.2 composition reproduces the audited 0.3025 bug; natural/0/1 exact)");
    }
}
