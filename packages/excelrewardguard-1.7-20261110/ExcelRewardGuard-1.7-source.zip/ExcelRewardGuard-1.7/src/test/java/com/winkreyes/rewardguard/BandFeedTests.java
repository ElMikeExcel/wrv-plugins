package com.winkreyes.rewardguard;

import java.lang.reflect.Method;
import java.util.UUID;

/**
 * The band governor's feed contract, exercised FUNCTIONALLY against
 * the real ExcelBossTrial 0.2.4 jar on the test classpath: the same
 * Class.forName + getMethod + invoke path integration/BossTrialFeed
 * runs in production, driving a real XpBandTokens store bound into
 * the real BossTrialAPI. If the feed's shape ever drifts - a renamed
 * method, a changed TTL semantic, an unbound store answering
 * non-null - this suite fails at build time instead of the governor
 * silently misbehaving on the live server.
 */
public final class BandFeedTests {
    private static int assertions;

    private static void check(boolean condition) {
        assertions++;
        if (!condition) throw new AssertionError("check " + assertions);
    }

    public static void main(String[] args) throws Exception {
        Class<?> api = Class.forName("com.winkreyes.excelbosstrial.api.BossTrialAPI");
        Class<?> tokensType = Class.forName("com.winkreyes.excelbosstrial.core.XpBandTokens");
        Method bindFeed = api.getMethod("bindFeed", tokensType);
        Method unbindFeed = api.getMethod("unbindFeed");
        Method poll = api.getMethod("pollXpBandVerdict", UUID.class, long.class);
        Method pending = api.getMethod("pendingXpBandVerdicts", UUID.class, long.class);
        Method plant = tokensType.getMethod("plant", UUID.class, boolean.class, long.class);
        Object tokens = tokensType.getDeclaredConstructor().newInstance();

        UUID ana = UUID.randomUUID();
        UUID ben = UUID.randomUUID();

        // Unbound feed: no opinion (the listener-absent / pre-bind state).
        check(poll.invoke(null, ana, 100L) == null);
        check((Integer) pending.invoke(null, ana, 100L) == 0);

        bindFeed.invoke(null, tokens);

        // A planted excluded verdict answers FALSE exactly once.
        plant.invoke(tokens, ana, false, 1_000L);
        check(Boolean.FALSE.equals(poll.invoke(null, ana, 1_001L)));
        check(poll.invoke(null, ana, 1_001L) == null);

        // A planted counted verdict answers TRUE.
        plant.invoke(tokens, ana, true, 1_010L);
        check(Boolean.TRUE.equals(poll.invoke(null, ana, 1_011L)));

        // FIFO pairing across players stays separate.
        plant.invoke(tokens, ana, false, 1_020L);
        plant.invoke(tokens, ben, true, 1_020L);
        check((Integer) pending.invoke(null, ana, 1_020L) == 1);
        check(Boolean.TRUE.equals(poll.invoke(null, ben, 1_021L)));
        check(Boolean.FALSE.equals(poll.invoke(null, ana, 1_021L)));

        // TTL: planted at T answers at T + 5 and is gone at T + 6
        // (XpBandTokens.TTL_TICKS - the number the API javadoc states).
        plant.invoke(tokens, ana, false, 2_000L);
        check(Boolean.FALSE.equals(poll.invoke(null, ana, 2_005L)));
        plant.invoke(tokens, ana, false, 2_100L);
        check(poll.invoke(null, ana, 2_106L) == null);

        // Unbind returns the feed to no-opinion.
        plant.invoke(tokens, ana, false, 3_000L);
        unbindFeed.invoke(null);
        check(poll.invoke(null, ana, 3_001L) == null);

        // The signature pin is exact: a one-arg poll must NOT exist,
        // so a drifted API fails loudly here rather than binding wrong.
        boolean oneArgMissing = false;
        try {
            api.getMethod("pollXpBandVerdict", UUID.class);
        } catch (NoSuchMethodException expected) {
            oneArgMissing = true;
        }
        check(oneArgMissing);

        System.out.println("PASS " + assertions + " band-feed functional assertions against the real ExcelBossTrial 0.2.4 jar");
    }
}
