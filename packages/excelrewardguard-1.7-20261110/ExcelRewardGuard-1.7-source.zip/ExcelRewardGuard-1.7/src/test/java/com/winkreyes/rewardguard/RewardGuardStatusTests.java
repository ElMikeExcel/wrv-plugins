package com.winkreyes.rewardguard;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Tests for the 1.7 console-admin status surface: the permission gate
 * (console always, in-game only with excelrewardguard.admin), the
 * status-args shape, the exact reply lines built from a snapshot of
 * REAL fields/counters (farm rates, boss band rate, fall threshold,
 * Jobs/mcMMO/elite intervention counters, seal-step state), the
 * seal-state wording for every shape (off / un-read / live / source
 * lost / par unpinned), and the plugin.yml gate (version 1.7, the
 * rewardguard command, the admin node defaulting to op, and the
 * shipped author line carried from the 1.6 jar).
 */
public final class RewardGuardStatusTests {
    private static int assertions;
    private static void check(boolean condition) { assertions++; if (!condition) throw new AssertionError("check " + assertions); }
    private static void eq(String actual, String expected) { assertions++; if (!expected.equals(actual)) throw new AssertionError("expected <" + expected + ">, got <" + actual + ">"); }

    private static RewardGuardStatus.Snapshot snap(boolean sealOn, int seals, boolean live, Double par) {
        return new RewardGuardStatus.Snapshot("1.7", 0.33, 0.33, 0.25, true, 50, 3,
            12L, 34L, 5L, sealOn, seals, SealStep.MAX_SEALS, live, 0.05, 0.10, par, 4,
            false, false, 2L, "spawn_origin_spawner");
    }

    public static void main(String[] args) throws Exception {
        // The gate: console always passes; in-game needs the node.
        check(RewardGuardStatus.canUse(true, false));
        check(RewardGuardStatus.canUse(true, true));
        check(RewardGuardStatus.canUse(false, true));
        check(!RewardGuardStatus.canUse(false, false));
        eq(RewardGuardStatus.ADMIN_PERMISSION, "excelrewardguard.admin");
        eq(RewardGuardStatus.COMMAND_NAME, "rewardguard");

        // Args shape: exactly ["status"], case-insensitive.
        check(RewardGuardStatus.isStatusArgs(new String[]{"status"}));
        check(RewardGuardStatus.isStatusArgs(new String[]{"STATUS"}));
        check(!RewardGuardStatus.isStatusArgs(new String[]{}));
        check(!RewardGuardStatus.isStatusArgs(new String[]{"status", "extra"}));
        check(!RewardGuardStatus.isStatusArgs(new String[]{"bogus"}));
        check(!RewardGuardStatus.isStatusArgs(null));

        eq(RewardGuardStatus.usageLine(), "Usage: /rewardguard status");
        check(RewardGuardStatus.denialLine().contains("excelrewardguard.admin"));

        // Exact reply for the live-shaped snapshot.
        List<String> lines = RewardGuardStatus.format(snap(true, 2, true, 1234.5));
        check(lines.size() == 6);
        eq(lines.get(0), "ExcelRewardGuard 1.7 status:");
        eq(lines.get(1), "Farm rates: Jobs 33% (config jobs-farm-rate: 0.33), mcMMO 33% (config mcmmo-farm-rate: 0.33); boss band 25% (config boss-band-rate: 0.25, verdict feed connected).");
        eq(lines.get(2), "Fall-softened threshold: 50% of max health (config farm-fall-damage-percent: 50); fall records tracked now: 3.");
        eq(lines.get(3), "Interventions since enable: Jobs 12, mcMMO 34, elite verdicts 5.");
        eq(lines.get(4), "Seal step: ON; money +5% per seal flat, XP +10% per seal faded to par; seals 2 of 5 (source live); par 1234.5 (4 player powers observed).");
        eq(lines.get(5), "Audit log OFF; debug logging OFF; suppression window 2 ticks; most recent farmed origin: spawn_origin_spawner.");

        // Seal wording shapes.
        check(RewardGuardStatus.format(snap(false, -1, false, null)).get(4)
            .equals("Seal step: OFF (config seal-step-enabled: false); no seal bonus applies."));
        check(RewardGuardStatus.format(snap(true, -1, false, null)).get(4)
            .contains("seals not yet read (ExcelGuildGate has not answered)"));
        check(RewardGuardStatus.format(snap(true, 0, true, null)).get(4)
            .contains("seals 0 of 5 (source live); par not yet pinned (4 player powers observed)"));
        check(RewardGuardStatus.format(snap(true, 3, false, null)).get(4)
            .contains("(source UNAVAILABLE - step suspended)"));

        // Feed-inactive and null-origin fallbacks render honestly.
        RewardGuardStatus.Snapshot noFeed = new RewardGuardStatus.Snapshot("1.7", 1.0, 0.0, 0.25, false, 50, 0,
            0L, 0L, 0L, true, 0, 5, true, 0.05, 0.10, null, 0, true, true, 2L, null);
        List<String> nf = RewardGuardStatus.format(noFeed);
        check(nf.get(1).contains("Jobs 100%"));
        check(nf.get(1).contains("mcMMO 0%"));
        check(nf.get(1).contains("verdict feed inactive - hits pay full"));
        check(nf.get(5).contains("Audit log ON; debug logging ON"));
        check(nf.get(5).contains("most recent farmed origin: window."));

        // plugin.yml gate: read the file build.sh copies into the jar.
        Path yml = Path.of("src/main/resources/plugin.yml");
        check(Files.exists(yml));
        String text = Files.readString(yml);
        check(text.contains("version: '1.7'"));
        check(text.contains("author: Moon (provenance candidate) and Argus (enforcement completion)"));
        check(!text.contains("authors: [Iris, Mike]"));
        check(text.contains("  rewardguard:"));
        check(text.contains("usage: /rewardguard status"));
        check(text.contains("permission: excelrewardguard.admin"));
        check(text.contains("  excelrewardguard.admin:"));
        check(text.contains("default: op"));

        System.out.println("PASS " + assertions + " rewardguard-status assertions (gate, args, exact lines, seal shapes, plugin.yml)");
    }
}
