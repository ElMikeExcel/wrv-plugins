package com.winkreyes.rewardguard;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.List;
import java.util.logging.Logger;

/**
 * Tests for the 1.3 audit log: the exact line format (this file is the
 * acceptance evidence of the NEXT audit, so its shape is pinned), the
 * rate rendering, and the enable/disable file behaviour — default OFF
 * must create no file and write nothing.
 */
public final class AuditLogTests {
    private static int assertions;
    private static void check(boolean condition) { assertions++; if (!condition) throw new AssertionError("check " + assertions); }

    public static void main(String[] args) throws Exception {
        Instant when = Instant.parse("2026-10-18T18:45:00Z");

        // Exact format, one line per channel.
        check(AuditLog.format(when, "Kailey", "spawn_origin_spawner", "jobs-money", 10.0, 0.33, 3.30)
            .equals("2026-10-18T18:45:00Z player=Kailey origin=spawn_origin_spawner channel=jobs-money base=10.00 rate=0.33 paid=3.30"));
        check(AuditLog.format(when, "Kailey", "fall_softened", "jobs-xp", 16.02, 0.33, 5.29)
            .equals("2026-10-18T18:45:00Z player=Kailey origin=fall_softened channel=jobs-xp base=16.02 rate=0.33 paid=5.29"));
        check(AuditLog.format(when, "Jester_Turtle", "spawn_origin_spawner", "mcmmo-xp", 100.0, 0.33, 33.0)
            .equals("2026-10-18T18:45:00Z player=Jester_Turtle origin=spawn_origin_spawner channel=mcmmo-xp base=100.00 rate=0.33 paid=33.00"));

        // Blocked adjustments (rate 0) are recorded with paid 0.00 and rate 0.
        check(AuditLog.format(when, "Kailey", "spawn_egg", "jobs-xp", 16.02, 0.0, 0.0)
            .equals("2026-10-18T18:45:00Z player=Kailey origin=spawn_egg channel=jobs-xp base=16.02 rate=0 paid=0.00"));
        // Rate 1 renders as 1 (no trailing zeros).
        check(AuditLog.format(when, "Kailey", "spawn_egg", "jobs-money", 10.0, 1.0, 10.0)
            .contains(" rate=1 "));
        // Tokens never carry spaces into the single-line format.
        check(AuditLog.format(when, "Cool Girl", "some origin", "jobs-xp", 1.0, 0.33, 0.33)
            .contains("player=Cool_Girl origin=some_origin"));
        check(AuditLog.format(when, null, null, "jobs-xp", 1.0, 0.33, 0.33)
            .contains("player=unknown origin=unknown"));

        // Disabled: no file, no writes, not even the parent directory.
        Path dir = Files.createTempDirectory("rewardguard-audit-test");
        Path offFile = dir.resolve("off/audit.log");
        AuditLog off = new AuditLog(offFile, false, Logger.getLogger("audit-test"));
        check(!off.enabled());
        off.record("Kailey", "spawn_origin_spawner", "jobs-money", 10.0, 0.33, 3.30);
        check(!Files.exists(offFile));
        check(!Files.exists(offFile.getParent()));

        // Enabled: creates parent dirs, appends one line per record, in order.
        Path onFile = dir.resolve("on/audit.log");
        AuditLog on = new AuditLog(onFile, true, Logger.getLogger("audit-test"));
        check(on.enabled());
        on.record("Kailey", "spawn_origin_spawner", "jobs-money", 10.0, 0.33, 3.30);
        on.record("Kailey", "spawn_origin_spawner", "jobs-xp", 16.02, 0.33, 5.29);
        List<String> lines = Files.readAllLines(onFile);
        check(lines.size() == 2);
        check(lines.get(0).contains("player=Kailey origin=spawn_origin_spawner channel=jobs-money base=10.00 rate=0.33 paid=3.30"));
        check(lines.get(1).contains("channel=jobs-xp base=16.02 rate=0.33 paid=5.29"));
        // A second AuditLog over the same file (a reload) appends, never truncates.
        AuditLog again = new AuditLog(onFile, true, Logger.getLogger("audit-test"));
        again.record("Kailey", "fall_softened", "mcmmo-xp", 50.0, 0.33, 16.50);
        check(Files.readAllLines(onFile).size() == 3);
        check(Files.readAllLines(onFile).get(2).contains("channel=mcmmo-xp base=50.00 rate=0.33 paid=16.50"));

        System.out.println("PASS " + assertions + " audit-log assertions (exact line format, rate rendering, token safety, disabled writes nothing, enabled appends across reloads)");
    }
}
