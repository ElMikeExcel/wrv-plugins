package com.winkreyes.rewardguard;

/**
 * Policy tests for the 1.3 decimal farm rates (pure logic, no server).
 * The rates under test are Mike's Oct 18, 2026 call: 0.33 on both the Jobs
 * and mcMMO paths, replacing the 55% shared percent of 1.2. The rounding
 * contract matches the percent math it replaces: half-up to 2 decimals in
 * between, exactly 0 at rate 0, exact pass-through at rate 1.
 */
public final class FarmRateTests {
    private static int assertions;
    private static void check(boolean condition) { assertions++; if (!condition) throw new AssertionError("check " + assertions); }

    private static void checkParse(Object raw, double rate, boolean adjusted) {
        RewardScale.ParsedRate parsed = RewardScale.parseRate(raw);
        check(parsed.rate() == rate);
        check(parsed.adjusted() == adjusted);
    }

    public static void main(String[] args) {
        // Scaling math at 0.33: Jobs-style doubles.
        check(RewardScale.scaleRate(10.0, 0.33) == 3.3);
        check(RewardScale.scaleRate(20.0, 0.33) == 6.6);
        check(RewardScale.scaleRate(100.0, 0.33) == 33.0);
        check(RewardScale.scaleRate(16.02, 0.33) == 5.29);  // 5.2866 -> 5.29 (the audit's Hunter base XP)
        check(RewardScale.scaleRate(1.0, 0.33) == 0.33);
        check(RewardScale.scaleRate(0.0, 0.33) == 0.0);
        // Rounding: half-up to cents, same contract as the percent math.
        check(RewardScale.scaleRate(0.05, 0.33) == 0.02);   // 0.0165 -> 0.02
        check(RewardScale.scaleRate(3.33, 0.33) == 1.10);   // 1.0989 -> 1.10
        check(RewardScale.scaleRate(2.5, 0.33) == 0.83);    // 0.825 -> 0.83 (half-up)

        // Scaling math at 0.33: mcMMO-style floats.
        check(RewardScale.scaleFloatRate(100.0f, 0.33) == 33.0f);
        check(RewardScale.scaleFloatRate(7.0f, 0.33) == 2.31f);
        check(RewardScale.scaleFloatRate(50.0f, 0.33) == 16.5f);

        // Rate 0: everything scales to exactly zero (handlers also cancel).
        check(RewardScale.scaleRate(10.0, 0.0) == 0.0);
        check(RewardScale.scaleRate(0.01, 0.0) == 0.0);
        check(RewardScale.scaleFloatRate(100.0f, 0.0) == 0.0f);

        // Rate 1 is a true no-op: exact values back, NO rounding — a rate of
        // 1 can never shave a reward by dust.
        check(RewardScale.scaleRate(10.0, 1.0) == 10.0);
        check(RewardScale.scaleRate(0.065, 1.0) == 0.065);
        check(RewardScale.scaleRate(3.333, 1.0) == 3.333);
        check(RewardScale.scaleFloatRate(4.55f, 1.0) == 4.55f);

        // Config parsing: missing, valid, endpoints, out-of-range, invalid.
        checkParse(null, 0.33, false);      // missing key -> shipped default, normal path
        checkParse(0.33, 0.33, false);
        checkParse(0.5, 0.5, false);        // fractions are the normal form for rates
        checkParse(0, 0.0, false);          // integer 0 is a valid rate (block the path)
        checkParse(1, 1.0, false);          // integer 1 is a valid rate (no reduction)
        checkParse("0.25", 0.25, false);    // numeric string counts
        checkParse(" 0.4 ", 0.4, false);    // whitespace tolerated
        checkParse(1.5, 1.0, true);         // above 1 -> clamped to 1, flagged
        checkParse(33, 1.0, true);          // percent-style 33 clamps to 1, flagged — rates are fractions
        checkParse(-0.2, 0.0, true);        // below 0 -> clamped to 0, flagged
        checkParse("abc", 0.33, true);      // unparseable -> default, flagged
        checkParse("55%", 0.33, true);      // percent text is not a rate -> default, flagged
        checkParse(Double.NaN, 0.33, true); // NaN -> default, flagged
        checkParse(Boolean.TRUE, 0.33, true); // wrong type -> default, flagged

        // A caller-chosen default is honoured (the two knobs parse independently).
        RewardScale.ParsedRate custom = RewardScale.parseRate(null, 0.5);
        check(custom.rate() == 0.5);
        check(!custom.adjusted());
        RewardScale.ParsedRate customBad = RewardScale.parseRate("junk", 0.5);
        check(customBad.rate() == 0.5);
        check(customBad.adjusted());

        // Independence of the two knobs: each parses from its own raw value;
        // changing one never moves the other (the 1.2 shared-percent coupling
        // is gone by construction — the handlers read separate fields).
        check(RewardScale.parseRate(0.33).rate() == 0.33);
        check(RewardScale.parseRate(0.75).rate() == 0.75);

        // Startup-log labels.
        check(RewardScale.percentLabel(0.33).equals("33%"));
        check(RewardScale.percentLabel(0.5).equals("50%"));
        check(RewardScale.percentLabel(1.0).equals("100%"));
        check(RewardScale.percentLabel(0.0).equals("0%"));
        check(RewardScale.percentLabel(0.335).equals("33.5%"));

        System.out.println("PASS " + assertions + " farm-rate assertions (0.33 math, rounding, 0/1 endpoints, rate parsing, knob independence, labels)");
    }
}
