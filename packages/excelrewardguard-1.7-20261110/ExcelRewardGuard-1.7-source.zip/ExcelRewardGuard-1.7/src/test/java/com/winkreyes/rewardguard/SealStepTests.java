package com.winkreyes.rewardguard;

import java.util.List;
import java.util.UUID;

/**
 * Policy tests for the 1.4 seal step (pure logic, no server). The shape
 * under test is Mike's hybrid, adopted Oct 19, 2026 from the reward audit:
 * Jobs money flat +5% per seal with no fade; Jobs XP and mcMMO XP at the
 * full +10% per seal faded by 1 - power/par, par being the live top-3
 * mean mcMMO power pinned per seal. Silence is structural: the classes
 * under test import no Bukkit type and hold no messaging surface at all,
 * and the handlers that consume them contain no player-messaging call
 * (verified by source grep in the 1.4 build report).
 */
public final class SealStepTests {
    private static int assertions;
    private static void check(boolean condition) { assertions++; if (!condition) throw new AssertionError("check " + assertions); }
    private static void checkClose(double actual, double expected) {
        assertions++;
        if (!(Math.abs(actual - expected) <= 1e-9)) {
            throw new AssertionError("check " + assertions + ": expected " + expected + " but was " + actual);
        }
    }

    private static final UUID A = UUID.fromString("00000000-0000-0000-0000-00000000000a");
    private static final UUID B = UUID.fromString("00000000-0000-0000-0000-00000000000b");
    private static final UUID C = UUID.fromString("00000000-0000-0000-0000-00000000000c");
    private static final UUID D = UUID.fromString("00000000-0000-0000-0000-00000000000d");
    private static final UUID E = UUID.fromString("00000000-0000-0000-0000-00000000000e");

    public static void main(String[] args) {
        // ---------------------------------------------------------------
        // Pure money step: flat +5% per seal, seals 0..5, no fade.
        // ---------------------------------------------------------------
        check(SealStep.moneyMultiplier(0, 0.05) == 1.0);
        checkClose(SealStep.moneyMultiplier(1, 0.05), 1.05);
        checkClose(SealStep.moneyMultiplier(2, 0.05), 1.10);
        checkClose(SealStep.moneyMultiplier(3, 0.05), 1.15);
        checkClose(SealStep.moneyMultiplier(4, 0.05), 1.20);
        checkClose(SealStep.moneyMultiplier(5, 0.05), 1.25);
        // Counts outside the campaign clamp, never extrapolate.
        checkClose(SealStep.moneyMultiplier(9, 0.05), 1.25);
        check(SealStep.moneyMultiplier(-3, 0.05) == 1.0);
        check(SealStep.clampSeals(-2) == 0);
        check(SealStep.clampSeals(9) == 5);
        // A zero step is an operator off-ramp: no bonus at any seal.
        check(SealStep.moneyMultiplier(5, 0.0) == 1.0);

        // ---------------------------------------------------------------
        // Pure fade: full at power 0, linear to par, exactly zero AT and
        // ABOVE par — the leaders' rates cannot move, by construction.
        // ---------------------------------------------------------------
        check(SealStep.fade(0, 1550.0) == 1.0);
        checkClose(SealStep.fade(775, 1550.0), 0.5);
        check(SealStep.fade(1550, 1550.0) == 0.0);
        check(SealStep.fade(2000, 1550.0) == 0.0);
        check(SealStep.fade(300, null) == 0.0);       // unpinned par: no bonus
        check(SealStep.fade(300, 0.0) == 0.0);
        check(SealStep.fade(300, -5.0) == 0.0);
        check(SealStep.fade(-10, 1550.0) == 1.0);    // negative power reads as 0

        // ---------------------------------------------------------------
        // Pure XP multiplier at the audit's own worked numbers.
        // ---------------------------------------------------------------
        // Seal 3, par 1550, power 300: keeps ~81% of the step -> +24.19%.
        checkClose(SealStep.xpMultiplier(3, 0.10, 300, 1550.0), 1.0 + 0.30 * (1.0 - 300.0 / 1550.0));
        // Seal 5, power 0: the full +50%.
        checkClose(SealStep.xpMultiplier(5, 0.10, 0, 2450.0), 1.50);
        // At par and above par the multiplier is EXACTLY 1 — not a
        // rounding of 1.001, exactly no bonus (the cap-date guarantee).
        check(SealStep.xpMultiplier(5, 0.10, 2450, 2450.0) == 1.0);
        check(SealStep.xpMultiplier(5, 0.10, 2600, 2450.0) == 1.0);
        check(SealStep.xpMultiplier(1, 0.10, 665, 653.0) == 1.0);
        // Seal 1 at power 0: +10%.
        checkClose(SealStep.xpMultiplier(1, 0.10, 0, 650.0), 1.10);
        // Unknowns fail to NO shaping, each on its own.
        check(SealStep.xpMultiplier(3, 0.10, null, 1550.0) == 1.0);  // power unknown
        check(SealStep.xpMultiplier(3, 0.10, 300, null) == 1.0);     // par unpinned
        check(SealStep.xpMultiplier(0, 0.10, 0, 650.0) == 1.0);      // no seal stands

        // ---------------------------------------------------------------
        // Par candidate: top-3 mean, and only ever from 3+ readings.
        // ---------------------------------------------------------------
        check(SealStep.parCandidate(List.of()) == -1.0);
        check(SealStep.parCandidate(List.of(665, 658)) == -1.0);
        check(SealStep.parCandidate(null) == -1.0);
        checkClose(SealStep.parCandidate(List.of(665, 658, 636)), 653.0);
        checkClose(SealStep.parCandidate(List.of(100, 900, 300, 650)), (900.0 + 650.0 + 300.0) / 3.0);
        checkClose(SealStep.parCandidate(List.of(636, 665, 658, 69)), 653.0); // order-independent

        // ---------------------------------------------------------------
        // Multiplier application: the >1-capable rounding contract.
        // ---------------------------------------------------------------
        check(SealStep.applyMultiplier(10.0, 1.25) == 12.50);
        check(SealStep.applyMultiplier(10.0, 1.50) == 15.00);
        check(SealStep.applyMultiplier(19.30, 1.05) == 20.27);  // 20.265 -> 20.27 half-up
        check(SealStep.applyMultiplier(3.33, 1.10) == 3.66);    // 3.663 -> 3.66
        check(SealStep.applyMultiplier(7.77, 1.0) == 7.77);    // exact pass-through
        check(SealStep.applyMultiplier(7.77, 0.0) == 0.0);
        // Composition, SPEC §6 order: base x farm x step, rounded once.
        check(SealStep.applyMultiplier(10.0, 0.33 * 1.05) == 3.47);  // 3.465 -> 3.47
        check(SealStep.applyMultiplier(10.0, 0.33 * 1.0) == 3.30);   // farm alone: 1.3's number
        check(SealStep.applyMultiplierFloat(100.0f, 1.25) == 125.0f);
        check(SealStep.applyMultiplierFloat(7.0f, 0.33 * 1.05) == 2.43f); // 2.4255 -> 2.43

        // ---------------------------------------------------------------
        // State: the money step needs only a standing seal; the XP step
        // additionally waits for par and for the player's own reading.
        // ---------------------------------------------------------------
        SealStepState state = new SealStepState(true, 0.05, 0.10);
        check(state.moneyMultiplier(true) == 1.0);          // seals never read
        check(state.xpMultiplier(A, true) == 1.0);
        state.observeSeals(1);
        checkClose(state.moneyMultiplier(true), 1.05);      // money applies at once
        check(state.xpMultiplier(A, true) == 1.0);          // XP waits: no par, no power
        state.observePower(A, 665);
        state.observePower(B, 658);
        check(state.pinnedPar() == null);                   // two readings: no top 3 yet
        check(state.xpMultiplier(A, true) == 1.0);
        Double pinned = state.observePower(C, 636);
        check(pinned != null && pinned == 653.0);           // third reading pins par
        check(state.pinnedPar() == 653.0);
        check(state.xpMultiplier(A, true) == 1.0);          // leader above par: exactly none
        checkClose(state.xpMultiplier(C, true), 1.0 + 0.10 * (1.0 - 636.0 / 653.0));
        checkClose(state.xpMultiplier(D, true), 1.0);       // unknown player: no step...
        state.observePower(D, 69);
        checkClose(state.xpMultiplier(D, true), 1.0 + 0.10 * (1.0 - 69.0 / 653.0)); // ...until observed
        state.observePower(E, 0);
        checkClose(state.xpMultiplier(E, true), 1.10);      // power 0: full step
        // A pinned par never drifts, even when a bigger power arrives.
        state.observePower(E, 5000);
        check(state.pinnedPar() == 653.0);
        // Seal source down: every channel fails to no shaping.
        check(state.moneyMultiplier(false) == 1.0);
        check(state.xpMultiplier(D, false) == 1.0);
        // Disabled state: nothing applies even with seals, par and power.
        SealStepState off = new SealStepState(false, 0.05, 0.10);
        off.observeSeals(5);
        off.observePower(A, 0);
        off.observePower(B, 0);
        off.observePower(C, 0);
        check(off.moneyMultiplier(true) == 1.0);
        check(off.xpMultiplier(A, true) == 1.0);

        // ---------------------------------------------------------------
        // State: a later seal pins a FRESH par from the current readings;
        // the earlier seal's par stays on record.
        // ---------------------------------------------------------------
        SealStepState campaign = new SealStepState(true, 0.05, 0.10);
        campaign.observeSeals(1);
        campaign.observePower(A, 665);
        campaign.observePower(B, 658);
        campaign.observePower(C, 636);
        check(campaign.pinnedPar(1) == 653.0);
        campaign.observePower(A, 1400);
        campaign.observePower(B, 1300);
        campaign.observePower(C, 1200);
        check(campaign.pinnedPar(1) == 653.0);              // seal 1's line is history
        Double pinned2 = campaign.observeSeals(2);
        check(pinned2 != null && pinned2 == 1300.0);        // (1400+1300+1200)/3
        check(campaign.pinnedPar() == 1300.0);
        checkClose(campaign.moneyMultiplier(true), 1.10);
        check(campaign.xpMultiplier(A, true) == 1.0);       // 1400 > par 1300

        // ---------------------------------------------------------------
        // Serialization: pins, powers and the standing count survive a
        // restart; corrupt lines cost nothing but themselves.
        // ---------------------------------------------------------------
        String saved = campaign.serialize();
        SealStepState restored = new SealStepState(true, 0.05, 0.10);
        int entries = restored.deserialize(saved);
        check(entries == 6);                                 // seals + 2 pars + 3 powers
        check(restored.seals() == 2);
        check(restored.pinnedPar(1) == 653.0);
        check(restored.pinnedPar(2) == 1300.0);
        check(restored.powerOf(A) == 1400);
        check(restored.knownPowerCount() == 3);
        checkClose(restored.moneyMultiplier(true), 1.10);
        SealStepState tolerant = new SealStepState(true, 0.05, 0.10);
        int kept = tolerant.deserialize("seals=3\nnonsense\npar.x=abc\npar.2=-4\npower.not-a-uuid=5\npar.3=1550.5\n");
        check(kept == 2);                                    // seals + par.3 only
        check(tolerant.seals() == 3);
        check(tolerant.pinnedPar(3) == 1550.5);
        check(tolerant.pinnedPar(2) == null);

        // ---------------------------------------------------------------
        // Step-rate parsing reuses the farm-rate contract with the
        // step defaults: missing -> default unflagged; junk -> default
        // flagged; percent-style traps clamp instead of exploding.
        // ---------------------------------------------------------------
        RewardScale.ParsedRate moneyDefault = RewardScale.parseRate(null, SealStep.DEFAULT_MONEY_STEP);
        check(moneyDefault.rate() == 0.05 && !moneyDefault.adjusted());
        RewardScale.ParsedRate xpDefault = RewardScale.parseRate(null, SealStep.DEFAULT_XP_STEP);
        check(xpDefault.rate() == 0.10 && !xpDefault.adjusted());
        RewardScale.ParsedRate junk = RewardScale.parseRate("soon", SealStep.DEFAULT_XP_STEP);
        check(junk.rate() == 0.10 && junk.adjusted());
        RewardScale.ParsedRate trap = RewardScale.parseRate(5, SealStep.DEFAULT_MONEY_STEP);
        check(trap.rate() == 1.0 && trap.adjusted());

        System.out.println("PASS " + assertions + " seal-step assertions (money seals 0-5, fade below/at/above par, "
            + "unknowns fail to no shaping, par pinning + no drift, composition, serialization)");
    }
}
