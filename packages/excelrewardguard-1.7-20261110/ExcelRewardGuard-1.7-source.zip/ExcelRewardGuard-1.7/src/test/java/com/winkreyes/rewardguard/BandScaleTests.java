package com.winkreyes.rewardguard;

/**
 * The band governor's factor logic (1.5): only an explicit FALSE
 * verdict scales, at exactly the configured rate; every other input -
 * counted verdict, no verdict, dead feed - is factor 1.0. This is the
 * fail-safe core of Option B, pinned so a future refactor cannot
 * quietly turn "no opinion" into a reduction.
 */
public final class BandScaleTests {
    private static int assertions;

    private static void check(boolean condition) {
        assertions++;
        if (!condition) throw new AssertionError("check " + assertions);
    }

    private static void eq(double actual, double expected) {
        assertions++;
        if (Math.abs(actual - expected) > 1e-9) {
            throw new AssertionError("expected " + expected + ", got " + actual);
        }
    }

    public static void main(String[] args) {
        // The verdict truth table.
        check(BandScale.isBanded(Boolean.FALSE));
        check(!BandScale.isBanded(Boolean.TRUE));
        check(!BandScale.isBanded(null));

        // The factor: FALSE pays the configured rate, everything else full.
        eq(BandScale.bandFactor(Boolean.FALSE, 0.25), 0.25);
        eq(BandScale.bandFactor(Boolean.FALSE, 0.0), 0.0);   // rate 0 = cheesed hits earn nothing
        eq(BandScale.bandFactor(Boolean.FALSE, 1.0), 1.0);   // rate 1 = governor changes nothing
        eq(BandScale.bandFactor(Boolean.FALSE, 0.5), 0.5);
        eq(BandScale.bandFactor(Boolean.TRUE, 0.25), 1.0);   // counted hit pays full at any rate
        eq(BandScale.bandFactor(Boolean.TRUE, 0.0), 1.0);
        eq(BandScale.bandFactor(null, 0.25), 1.0);           // no opinion pays full
        eq(BandScale.bandFactor(null, 0.0), 1.0);            // no verdict can ever zero a gain

        // The shipped constants are the settled design's numbers.
        eq(BandScale.DEFAULT_BAND_RATE, 0.25);
        check("boss_band_excluded".equals(BandScale.BAND_ORIGIN));

        // The config path: absent key parses to the default unadjusted;
        // an explicit value parses to itself (RewardScale.parseRate is
        // the same parser the farm rates use).
        RewardScale.ParsedRate absent = RewardScale.parseRate(null, BandScale.DEFAULT_BAND_RATE);
        eq(absent.rate(), 0.25);
        check(!absent.adjusted());
        RewardScale.ParsedRate explicit = RewardScale.parseRate(0.5, BandScale.DEFAULT_BAND_RATE);
        eq(explicit.rate(), 0.5);
        check(!explicit.adjusted());

        // The composition McMmoVeto performs (farm x band x step), at
        // the values the live server runs at 0 seals: step = 1.0.
        eq(1.0 * BandScale.bandFactor(Boolean.FALSE, 0.25) * 1.0, 0.25);
        eq(0.33 * BandScale.bandFactor(Boolean.FALSE, 0.25) * 1.0, 0.0825);
        eq(0.33 * BandScale.bandFactor(Boolean.TRUE, 0.25) * 1.0, 0.33);
        eq(0.33 * BandScale.bandFactor(null, 0.25) * 1.0, 0.33);

        System.out.println("PASS " + assertions + " band-scale assertions (verdict truth table, fail-safe nulls, config default, composition)");
    }
}
