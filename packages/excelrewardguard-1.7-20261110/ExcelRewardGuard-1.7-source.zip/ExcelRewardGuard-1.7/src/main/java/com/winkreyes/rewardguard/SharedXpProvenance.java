// Excel signature - WRV scoped Together XP copy provenance; offline candidate.
package com.winkreyes.rewardguard;
import java.util.*;
import java.lang.ref.*;
/** Receipt proves an exact source event passed RewardGuard. No blanket source-enum bypass. */
public final class SharedXpProvenance {
    public record Identity(UUID player, String skill, String reason) {}
    public record Gain(Identity who, float amount) {}
    private static final class Receipt {
        final Identity source; final long tick; final Thread thread;
        final Set<UUID> receivers = new HashSet<>();
        Receipt(Identity s,long t) { source=s;tick=t;thread=Thread.currentThread(); }
    }
    private static final class Scope {
        final Gain expected; final long tick; final Thread thread; boolean used;
        Object preEvent, gainEvent; Gain boundGain;
        Scope(Gain g,long t) {expected=g;tick=t;thread=Thread.currentThread();}
    }
    // Values deliberately do not strongly retain the weak event key.
    private static final class EventKey extends WeakReference<Object> {
        final int hash;
        EventKey(Object event,ReferenceQueue<Object> queue) { super(event,queue);hash=System.identityHashCode(event); }
        @Override public int hashCode(){return hash;}
        @Override public boolean equals(Object other){return this==other||(other instanceof EventKey k&&get()!=null&&get()==k.get());}
    }
    private final ReferenceQueue<Object> expired=new ReferenceQueue<>();
    private final Map<EventKey,Receipt> receipts = new HashMap<>();
    private void purge(){Reference<?> k;while((k=expired.poll())!=null)receipts.remove(k);}
    private final ThreadLocal<Scope> active = new ThreadLocal<>();
    private final Thread owner;
    public SharedXpProvenance() { owner=Thread.currentThread(); }
    private static boolean positive(float f) {return Float.isFinite(f)&&f>0;}
    public void record(Object exactEvent, Identity source, float afterGuard, long tick) {
        if(Thread.currentThread()!=owner||active.get()!=null||exactEvent==null||source==null||!positive(afterGuard))return;
        // An event gets one source receipt, not refreshed/replaced by repeated callbacks.
        purge();
        receipts.putIfAbsent(new EventKey(exactEvent,expired),new Receipt(source,tick));
    }
    public boolean run(Object exactSourceEvent, Identity source, Gain copy,long tick,Runnable synchronousGrant) {
        if(Thread.currentThread()!=owner||active.get()!=null||copy==null||copy.who()==null||!positive(copy.amount())||synchronousGrant==null)return false;
        purge();
        Receipt r=receipts.get(new EventKey(exactSourceEvent,null));
        if(r==null||r.thread!=Thread.currentThread()||r.tick!=tick||!r.source.equals(source)
                ||!source.skill().equals(copy.who().skill())||!source.reason().equals(copy.who().reason())
                ||source.player().equals(copy.who().player())||!r.receivers.add(copy.who().player()))return false;
        active.set(new Scope(copy,tick));
        try {synchronousGrant.run();return true;} finally {active.remove();}
    }
    private Scope scope(long tick) {
        Scope s=active.get();
        return s!=null&&!s.used&&s.thread==Thread.currentThread()&&s.tick==tick?s:null;
    }
    // The native observer is invoked before dispatch for this exact invocation.
    // Ordinary nested calls cannot inherit either callback.
    public void bindPre(Object exact, Gain event, long tick) {
        Scope s=scope(tick);
        if(s==null||s.preEvent!=null||exact==null||!s.expected.equals(event))
            throw new IllegalStateException("Excel shared XP pre-event binding rejected");
        s.preEvent=exact;
    }
    public void bindGain(Object exact, Gain event, long tick) {
        Scope s=scope(tick);
        if(s==null||s.preEvent==null||s.gainEvent!=null||exact==null||event==null
                ||!s.expected.who().equals(event.who())||!Float.isFinite(event.amount())||event.amount()<0)
            throw new IllegalStateException("Excel shared XP gain-event binding rejected");
        // Pre-event listeners may legitimately adjust the amount. Bind what the
        // native invocation actually carries forward, not an inferred tuple.
        s.gainEvent=exact;s.boundGain=event;
    }
    // Bukkit listeners may change the amount after native creation. Exact event
    // identity and recipient/skill/reason, not mutable amount, preserve provenance.
    // The native request amount is validated once at bindPre.
    public boolean matchesPre(Object exact, Gain event,long tick) {
        Scope s=scope(tick);
        return s!=null&&s.preEvent==exact&&event!=null&&s.expected.who().equals(event.who());
    }
    public boolean consume(Object exact,Gain event,long tick) {
        Scope s=scope(tick);
        if(s==null||s.gainEvent!=exact||event==null||!s.boundGain.who().equals(event.who()))return false;
        s.used=true;return true;
    }
}
