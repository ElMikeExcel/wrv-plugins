package com.winkreyes.rewardguard.integration;

import com.winkreyes.rewardguard.ExcelRewardGuard;
import java.lang.reflect.Method;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

/**
 * The client half of the XP band governor (1.5): polls
 * ExcelBossTrial's verdict feed (BossTrialAPI.pollXpBandVerdict,
 * 0.2.4+) by reflection, exactly as the main class reads
 * GuildGateAPI and for the same reason - no compile dependency, so
 * this plugin loads and runs identically when ExcelBossTrial is
 * absent. The feed contract (BossTrialAPI's javadoc is the
 * authority): one verdict token per governed, mcMMO-paying hit,
 * planted by BossTrial in hit order; a poll consumes the oldest
 * fresh token for the player and answers whether that hit counted
 * toward its seal; tokens expire 5 server ticks after their hit.
 *
 * FAIL-SAFE, stated as code: every path that cannot produce a
 * verdict - plugin absent, plugin older than 0.2.4 (no such
 * method), feed unbound, reflection failure - polls as null, and
 * null means "no opinion", which BandScale turns into full pay.
 * The governor therefore cannot reduce a single XP point unless
 * BossTrial positively classified the matching hit as not counted.
 * A reflection failure after a successful connect is logged ONCE
 * and the feed then stays silent (no per-gain log spam); the
 * verdict-less gains simply pay full.
 *
 * The tick handed to the feed is Bukkit.getCurrentTick() - the same
 * clock BossTrial stamps its tokens with. (RewardGuard's own tick
 * counter is a different clock, started at this plugin's enable; it
 * is never used here.)
 *
 * This class is only constructed when the mcMMO integration is
 * relevant, but it references no mcMMO classes itself.
 */
public final class BossTrialFeed {
    private final ExcelRewardGuard plugin;
    private final Method pollMethod;
    private final boolean connected;
    private volatile boolean dead;

    public BossTrialFeed(ExcelRewardGuard plugin) {
        this.plugin = plugin;
        Method found = null;
        Plugin bossTrial = Bukkit.getPluginManager().getPlugin("ExcelBossTrial");
        if (bossTrial != null && bossTrial.isEnabled()) {
            try {
                Class<?> api = Class.forName("com.winkreyes.excelbosstrial.api.BossTrialAPI",
                    true, bossTrial.getClass().getClassLoader());
                found = api.getMethod("pollXpBandVerdict", UUID.class, long.class);
            } catch (Exception missing) {
                plugin.getLogger().info("ExcelBossTrial is present but exposes no XP band verdict feed "
                    + "(older than 0.2.4): the band governor stays inactive and governed hits pay full mcMMO XP.");
            }
        }
        this.pollMethod = found;
        this.connected = found != null;
    }

    /** True when the feed resolved at enable time. */
    public boolean connected() {
        return connected;
    }

    /**
     * Consumes the band verdict for the player's next governed hit:
     * Boolean.FALSE = the hit did not count (scale it), Boolean.TRUE
     * = it counted (full pay), null = no verdict applies (full pay).
     */
    public Boolean poll(UUID player) {
        if (!connected || dead) return null;
        try {
            return (Boolean) pollMethod.invoke(null, player, (long) Bukkit.getCurrentTick());
        } catch (Exception failure) {
            dead = true;
            plugin.getLogger().warning("BossTrial XP band verdict feed failed ("
                + failure.getClass().getSimpleName() + "); the band governor is inactive from here "
                + "and governed hits pay full mcMMO XP.");
            return null;
        }
    }
}
