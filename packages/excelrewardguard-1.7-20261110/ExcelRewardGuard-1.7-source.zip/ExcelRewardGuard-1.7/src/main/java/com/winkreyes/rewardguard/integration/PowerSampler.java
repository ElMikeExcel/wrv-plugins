package com.winkreyes.rewardguard.integration;

import com.gmail.nossr50.api.ExperienceAPI;
import com.winkreyes.rewardguard.ExcelRewardGuard;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

/**
 * Feeds the seal-step power cache (1.4). A player's power — their mcMMO
 * power level, the sum of all skill levels — is read through mcMMO's own
 * API on join and on the main class's periodic refresh of everyone online;
 * McMmoVeto additionally samples the gaining player on every mcMMO XP gain,
 * so active players' readings stay current without any of this running
 * per-event. Power moves slowly (it is a sum of levels), so this cadence
 * is plenty, exactly as the Oct 19, 2026 reward audit's implementation
 * note prescribes ("sampling on join plus a slow refresh").
 *
 * A read can fail while a profile is still loading after a join; that is
 * a normal race, not an error — the sample is skipped and the refresh
 * catches the player later. An unread player simply has no reading, and
 * the seal step treats an unknown power as "no step for that player",
 * never as a guessed one.
 *
 * This class is only loaded when the mcMMO plugin is present (the main
 * class checks before registering it), so the mcMMO classes are safe to
 * reference.
 */
public final class PowerSampler implements Listener {
    private final ExcelRewardGuard plugin;

    public PowerSampler(ExcelRewardGuard plugin) {
        this.plugin = plugin;
    }

    /** Reads one online player's power and records it; a failed read is skipped silently. */
    public static void sample(ExcelRewardGuard plugin, Player player) {
        if (player == null) return;
        try {
            plugin.observePower(player.getUniqueId(), ExperienceAPI.getPowerLevel(player));
        } catch (RuntimeException | LinkageError profileNotReady) {
            // Profile still loading (fresh join) or API hiccup: no reading
            // is recorded, which the step reads as "unknown", never as 0.
        }
    }

    /** Samples everyone currently online; called on the seal-step poll. */
    public void sampleOnline() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            sample(plugin, player);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onJoin(PlayerJoinEvent event) {
        // One tick later: mcMMO loads profiles asynchronously around the
        // join, and an immediate read can race it. The periodic refresh is
        // the backstop if even this read comes back unready.
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> sample(plugin, player), 20L);
    }
}
