// Excel signature - scoped inherited farm/band handling for Together copies.
package com.winkreyes.rewardguard.integration;

import com.gmail.nossr50.datatypes.experience.XPGainReason;
import com.gmail.nossr50.events.experience.McMMOPlayerPreXpGainEvent;
import com.gmail.nossr50.events.experience.McMMOPlayerXpGainEvent;
import com.winkreyes.rewardguard.BandScale;
import com.winkreyes.rewardguard.ExcelRewardGuard;
import com.winkreyes.rewardguard.SealStep;
import com.winkreyes.rewardguard.SharedXpProvenance;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

/**
 * mcMMO enforcement. mcMMO's XP gain events carry the player and the amount
 * but not the killed entity, so the reduction works off the suppression
 * window the main class plants when a farmed-classified mob dies (see
 * XpSuppression for the exact matching rules). Only kill-based reasons are
 * eligible: PVE (the kill itself) and SHARED_PVE (party share).
 *
 * The scaling happens exactly once, on McMMOPlayerXpGainEvent at LOWEST
 * priority, via setRawXpGained(raw * rate). That placement matters twice
 * over, both verified in the installed mcMMO build's own source:
 * McMMOPlayer.applyXpGain feeds the pre-gain amount into
 * EventUtils.handleXpGainEvent, which applies the XpGain event's raw value
 * after every listener has run — so scaling the pre-gain event as well
 * would scale twice, and scaling at LOWEST means weekend and party
 * multipliers (which listen later) multiply the already-reduced amount:
 * the farm check still runs before the multipliers, as in 1.0.
 *
 * Since 1.3 the mcMMO path has its OWN rate, config mcmmo-farm-rate
 * (default 0.33), independent of the Jobs rate. In 1.1/1.2 both paths
 * shared the single farm-reward-percent, which also made the mcMMO half
 * impossible to audit separately; the rate split plus the 1.3 audit log
 * (this handler records channel mcmmo-xp) closes that gap.
 *
 * At rate 0 the handlers reproduce 1.0 exactly: the pre-gain event is
 * cancelled and the gain event is zeroed and cancelled. At rate 1 both
 * handlers are a no-op pass-through.
 *
 * Since 1.4 the gain handler also carries the SEAL STEP on this channel
 * (Mike's hybrid, Oct 19, 2026), composed as mob-scaling SPEC §6 fixes it:
 *     final = base x (farm rate, if the gain matches a farmed kill's
 *     window; else 1) x step multiplier of the gaining player.
 * Unlike the farm factor, the step applies to EVERY mcMMO XP gain, of any
 * skill and any gain reason — the catch-up fade keys on the player (their
 * mcMMO power vs par), not on the kill. Each gaining player is stepped by
 * their OWN power: a party member receiving SHARED_PVE share is faded by
 * where THEY stand, which keeps the share proportional to the scaled
 * primary gain in the same way the farm rate already relied on. The
 * handler also feeds the power cache from the gaining player (their
 * pre-gain power — the standing they earned at), so the fade's input is
 * as fresh as the gain itself. The pre-gain handler is unchanged: it is
 * the farm rate-0 veto only, and the step (never below 1) can neither
 * cancel a gain nor resurrect one the veto blocked.
 *
 * Since 1.5 the handler also carries the BOSS BAND factor (Mike's
 * Option B, Oct 22, 2026): for PVE gains only, it consumes the
 * ExcelBossTrial verdict for the hit behind this gain (see
 * integration/BossTrialFeed for the feed contract). A FALSE verdict -
 * the hit was out-of-band or otherwise not counted toward its seal -
 * contributes the boss-band-rate factor (default 0.25); anything else
 * (counted verdict, no verdict, dead feed) contributes 1.0. The
 * composition is:
 *     final = base x farm factor x band factor x step multiplier.
 * SHARED_PVE is never polled: a party share is computed by mcMMO
 * from the primary gain AFTER this event, so the share inherits the
 * primary's band scaling exactly; polling for the share would also
 * consume a verdict that belongs to the receiver's own next hit.
 * At band rate 0 an out-of-band hit's gain is vetoed through the same
 * zero path as the farm rate's. The band factor is silent, like every
 * shaping on this channel: no player-facing text.
 *
 * This class is only loaded when the mcMMO plugin is present (the main
 * class checks before registering it), so the mcMMO classes are safe to
 * reference.
 */
public final class McMmoVeto implements Listener {
    private final ExcelRewardGuard plugin;
    private final SharedXpProvenance provenance = new SharedXpProvenance();
    private static SharedXpProvenance.Identity identity(McMMOPlayerXpGainEvent e) {
        return new SharedXpProvenance.Identity(e.getPlayer().getUniqueId(), e.getSkill().name(), e.getXpGainReason().name());
    }
    // Called only around Together's synchronous native applyXpGain. Exact original event
    // must already have passed this handler and still be positive and uncancelled.
    public boolean runObservedTogetherShare(Object original, UUID receiver, float amount,
            java.util.function.BiConsumer<java.util.function.Consumer<Object>, java.util.function.Consumer<Object>> grant) {
        if (!(original instanceof McMMOPlayerXpGainEvent e) || e.isCancelled()
                || !(e.getRawXpGained() > 0) || !Float.isFinite(e.getRawXpGained()) || receiver == null || grant == null) return false;
        var source = identity(e);
        return provenance.run(e, source, new SharedXpProvenance.Gain(
            new SharedXpProvenance.Identity(receiver, source.skill(), source.reason()), amount), plugin.currentTick(),
            () -> grant.accept(pre -> {
                if (!(pre instanceof McMMOPlayerPreXpGainEvent p)) throw new IllegalStateException("Excel expected native pre-XP event");
                provenance.bindPre(p, new SharedXpProvenance.Gain(new SharedXpProvenance.Identity(
                    p.getPlayer().getUniqueId(), p.getSkill().name(), p.getXpGainReason().name()),p.getRawXpGained()),plugin.currentTick());
            }, gain -> {
                if (!(gain instanceof McMMOPlayerXpGainEvent g)) throw new IllegalStateException("Excel expected native XP event");
                provenance.bindGain(g,new SharedXpProvenance.Gain(identity(g),g.getRawXpGained()),plugin.currentTick());
            }));
    }
    private void record(McMMOPlayerXpGainEvent e) {
        if (!e.isCancelled()) provenance.record(e, identity(e), e.getRawXpGained(), plugin.currentTick());
    }

    public McMmoVeto(ExcelRewardGuard plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onPreXpGain(McMMOPlayerPreXpGainEvent event) {
        // Only the rate-0 veto acts here (1.0 behavior). Above 0 the
        // pre-gain amount must pass through untouched: it becomes the raw
        // value the XpGain handler below scales, exactly once.
        if (plugin.mcMmoFarmRate() > 0.0) return;
        // The original has already survived the farm veto; the recipient may
        // merely stand near a different farm kill. Peek, do not consume yet.
        if (provenance.matchesPre(event, new SharedXpProvenance.Gain(
                new SharedXpProvenance.Identity(event.getPlayer().getUniqueId(), event.getSkill().name(), event.getXpGainReason().name()),
                event.getRawXpGained()), plugin.currentTick())) return;
        if (matchesDeniedKill(event.getPlayer(), event.getXpGainReason())) {
            event.setCancelled(true);
            plugin.countMcMmoIntervention();
            plugin.audit(event.getPlayer().getName(), plugin.recentFarmedOrigin(), "mcmmo-xp",
                event.getXpGained(), 0.0, 0.0);
            logIntervention(event.getPlayer(), event.getSkill().name(), event.getXpGainReason(), "blocked");
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onXpGain(McMMOPlayerXpGainEvent event) {
        Player player = event.getPlayer();
        // Freshest possible power reading: the gaining player's standing
        // before this gain lands. Feeds the cache the fade reads (and the
        // Jobs XP channel shares). Skipped entirely when the step is off.
        if (plugin.sealStepEnabled()) PowerSampler.sample(plugin, player);
        boolean inherited = provenance.consume(event, new SharedXpProvenance.Gain(identity(event), event.getRawXpGained()), plugin.currentTick());
        // A listener may mutate the exact observed event before this LOWEST handler.
        // Keep legitimate finite nonnegative edits; invalid copied amounts fail closed.
        if (inherited && (!Float.isFinite(event.getRawXpGained()) || event.getRawXpGained() < 0)) {
            event.setRawXpGained(0); event.setCancelled(true); plugin.countMcMmoIntervention(); return;
        }
        boolean window = !inherited && matchesDeniedKill(player, event.getXpGainReason());
        double farmFactor = window ? plugin.mcMmoFarmRate() : 1.0;
        // The band governor (1.5): PVE gains only - SHARED_PVE shares
        // derive from the primary gain post-event and inherit its
        // scaling; they must not consume a verdict (see class docs).
        Boolean bandVerdict = !inherited && event.getXpGainReason() == XPGainReason.PVE
            ? plugin.pollBossBand(player.getUniqueId()) : null;
        boolean banded = BandScale.isBanded(bandVerdict);
        double rate = farmFactor * BandScale.bandFactor(bandVerdict, plugin.bossBandRate())
            * plugin.sealXpMultiplier(player.getUniqueId());
        if (rate == 1.0) { record(event); return; }
        float raw = event.getRawXpGained();
        String origin = window ? plugin.recentFarmedOrigin()
            : banded ? BandScale.BAND_ORIGIN : SealStep.STEP_ORIGIN;
        String bandNote = banded ? " (boss band x" + plugin.bossBandRate() + ")" : "";
        if (rate <= 0.0) {
            event.setRawXpGained(0.0f);
            event.setCancelled(true);
            plugin.countMcMmoIntervention();
            plugin.audit(player.getName(), origin, "mcmmo-xp", raw, rate, 0.0);
            logIntervention(player, event.getSkill().name(), event.getXpGainReason(),
                "blocked" + bandNote + " (raw XP " + raw + " -> 0)");
            return;
        }
        event.setRawXpGained(SealStep.applyMultiplierFloat(raw, rate));
        record(event);
        plugin.countMcMmoIntervention();
        plugin.audit(player.getName(), origin, "mcmmo-xp", raw, rate, event.getRawXpGained());
        logIntervention(player, event.getSkill().name(), event.getXpGainReason(),
            "scaled to x" + rate + bandNote + " (raw XP " + raw + " -> " + event.getRawXpGained() + ")");
    }

    private boolean matchesDeniedKill(Player player, XPGainReason reason) {
        if (reason != XPGainReason.PVE && reason != XPGainReason.SHARED_PVE) return false;
        Location location = player.getLocation();
        if (location.getWorld() == null) return false;
        return plugin.suppression().shouldSuppress(player.getUniqueId(), location.getWorld().getName(),
            location.getX(), location.getY(), location.getZ(), plugin.currentTick(), true);
    }

    private void logIntervention(Player player, String skill, XPGainReason reason, String action) {
        if (plugin.debugLogging()) {
            plugin.getLogger().info("mcMMO XP " + action + " for " + player.getName()
                + " (" + skill + ", " + reason + ").");
        }
    }
}
