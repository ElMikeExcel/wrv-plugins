// Excel signature - WRV RewardGuard provenance bridge candidate.
package com.winkreyes.rewardguard;

import com.winkreyes.rewardguard.integration.BossTrialFeed;
import com.winkreyes.rewardguard.integration.EliteVerdictLog;
import com.winkreyes.rewardguard.integration.JobsVeto;
import com.winkreyes.rewardguard.integration.McMmoVeto;
import com.winkreyes.rewardguard.integration.PowerSampler;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import org.bukkit.Bukkit;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityRemoveEvent;
import org.bukkit.event.entity.EntityTransformEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.world.EntitiesUnloadEvent;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Farm-reward guard for Wink Reyes Valley.
 *
 * Provenance half (original Moon candidate, Oct 14): mobs born from spawners,
 * spawn eggs or Nether portals are marked in their own persistent data at
 * birth, the mark is sticky across transformations, and farmDecision() answers
 * DENY / UNKNOWN for any consumer.
 *
 * Enforcement half (completion, Oct 15): the guard reduces the rewards itself
 * through the reward plugins' own events. Since 1.1 (Mike's decision, Oct 15)
 * a marked mob earns a REDUCED share of its rewards instead of nothing;
 * since 1.3 (Mike's decisions, Oct 18, 2026) the share is a pair of decimal
 * rates — jobs-farm-rate and mcmmo-farm-rate, both defaulting to 0.33 —
 * replacing the single shared farm-reward-percent (live was 55 under 1.2):
 *   - Jobs: JobsPrePaymentEvent and JobsExpGainEvent carry the killed entity,
 *     so the reduction is exact per kill. Each channel is scaled exactly
 *     once, in exactly one handler: money and points in the pre-payment
 *     handler, XP in the XP-gain handler. 1.2 scaled XP in both, and the
 *     live Jobs database proved farmed XP landed at the percent squared
 *     (30.25% instead of 55%); see JobsVeto for the full post-mortem.
 *   - mcMMO: its XP gain events carry no entity, so a farmed death plants a
 *     short suppression window (see XpSuppression) and PVE / SHARED_PVE gains
 *     inside it are scaled at LOWEST priority, before any multiplier plugin
 *     can grow them; a reduced amount times a multiplier stays reduced. The
 *     mcMMO rate is its own knob (mcmmo-farm-rate), independent of Jobs.
 *   - EliteMobs: 10.9.8 exposes no cancellable reward event (EliteMobDeathEvent
 *     is informational; verified by javap), so the guard logs denied elite
 *     deaths for observability and claims no veto there.
 * Rate 0 on a path reproduces the 1.0 zero behavior exactly for that path,
 * and rate 1 turns that path's reduction off (full rewards). Vanilla XP
 * drops are never touched at any setting. An optional audit log
 * (audit-log: true) records every adjustment per kill — see AuditLog.
 *
 * Fall-softening half (1.2, Mike's decision, Oct 16): sky farms defeat the
 * birth marks — their mobs spawn naturally in the dark at height, fall, and
 * are finished with one hit. A FallDamageTracker therefore accumulates each
 * mob's FALL damage, and a kill whose target took at least
 * farm-fall-damage-percent (default 50) of its max health as fall damage
 * counts as farmed too, earning the same reduced share through the same two
 * enforcement paths (see FallDamageTracker for the exact rules, including
 * the cumulative-after-healing rule and the accepted ravine false
 * positive). Origin verdicts keep priority for the log label, and a kill is
 * classified — and, since the 1.3 fix, also PAID — scaled exactly once.
 * Everything 1.2 did for classification is unchanged in 1.3.
 *
 * Seal-step half (1.4, Mike's hybrid, adopted Oct 19, 2026): as each guild
 * seal falls, rewards step up in the same two listeners and at the same
 * LOWEST-priority point as the farm scale, composing as
 *     final = base x (farm rate, if the kill is farmed; else 1) x step.
 * Jobs money (and points) step FLAT at +5% per seal with no fade; Jobs XP
 * and mcMMO XP step at +10% per seal faded by the gaining player's gap to
 * par — par being the top-3 mean mcMMO power, measured live and pinned
 * per seal (see SealStep and SealStepState for the full policy, including
 * the fail-to-no-shaping posture when the seal count, the par, or a
 * player's power is unknown). The seal count is read from ExcelGuildGate's
 * public API by reflection, the same mechanism ExcelMagicGate's seal watch
 * uses. Magic SP is never stepped (audit verdict), EliteMobs currency is
 * excluded by Mike's rule, and the shaping is invisible: this plugin has
 * never contained a player-messaging call and 1.4 adds none — the only
 * records are console lines and the operator audit log.
 *
 * Console-admin half (1.7, Nov 10, 2026): the plugin's first command,
 * /rewardguard status, answers the console (and in-game holders of the
 * excelrewardguard.admin node, default op) with the guard's effective
 * config and the counters it actually keeps — see RewardGuardStatus.
 * Read-only: it builds a snapshot of existing fields and changes no
 * reward path, no state, and no file.
 */
public final class ExcelRewardGuard extends JavaPlugin implements Listener {
    // Excel: optional mcMMO integration owns provenance; no blanket party exemption.
    private McMmoVeto mcMmoVeto;
    public boolean runObservedTogetherShare(Object originalEvent, UUID receiver, float amount, java.util.function.BiConsumer<java.util.function.Consumer<Object>, java.util.function.Consumer<Object>> grant) {
        if (mcMmoVeto == null) { grant.accept(e -> {}, e -> {}); return true; } // integration disabled: retain ordinary Together behavior
        return mcMmoVeto.runObservedTogetherShare(originalEvent, receiver, amount, grant);
    }
    private ProvenanceStore provenance;
    private XpSuppression suppression;
    private FallDamageTracker fallTracker;
    private final AtomicBoolean reportedFailure = new AtomicBoolean();
    private final AtomicLong tickCounter = new AtomicLong();
    private final AtomicLong jobsInterventions = new AtomicLong();
    private final AtomicLong mcMmoInterventions = new AtomicLong();
    private final AtomicLong eliteVerdicts = new AtomicLong();
    private double jobsFarmRate = RewardScale.DEFAULT_RATE;
    private double mcMmoFarmRate = RewardScale.DEFAULT_RATE;
    // Band governor state (1.5). bossTrialFeed is null until onEnable
    // builds it; a null or unconnected feed polls as "no opinion".
    private double bossBandRate = BandScale.DEFAULT_BAND_RATE;
    private BossTrialFeed bossTrialFeed;
    private int farmFallDamagePercent = FallDamageTracker.DEFAULT_THRESHOLD_PERCENT;
    private boolean debugLogging;
    private AuditLog auditLog;
    private long suppressionWindowTicks = 2L;
    private volatile String lastFarmedReason;
    private volatile long lastFarmedTick = Long.MIN_VALUE;
    // Seal-step state (1.4). stepState is null until onEnable builds it.
    private SealStepState stepState;
    private Path stepStateFile;
    private PowerSampler powerSampler;
    private Method guildGateSealsMethod; // cached GuildGateAPI.sealsBrokenCount (mirrors ExcelMagicGate)
    private volatile boolean sealSourceLive;
    private final AtomicBoolean stepPersistWarned = new AtomicBoolean();

    @Override public void onEnable() {
        mcMmoVeto = null; // Excel: never retain a previous registration across re-enable.
        saveDefaultConfig();
        debugLogging = getConfig().getBoolean("debug-logging", false);
        Object rawJobsRate = getConfig().get("jobs-farm-rate");
        RewardScale.ParsedRate parsedJobs = RewardScale.parseRate(rawJobsRate);
        jobsFarmRate = parsedJobs.rate();
        if (parsedJobs.adjusted()) {
            getLogger().warning("jobs-farm-rate value '" + rawJobsRate + "' is not a number in 0-1; using "
                + jobsFarmRate + ". Fix config.yml to silence this warning.");
        }
        Object rawMcMmoRate = getConfig().get("mcmmo-farm-rate");
        RewardScale.ParsedRate parsedMcMmo = RewardScale.parseRate(rawMcMmoRate);
        mcMmoFarmRate = parsedMcMmo.rate();
        if (parsedMcMmo.adjusted()) {
            getLogger().warning("mcmmo-farm-rate value '" + rawMcMmoRate + "' is not a number in 0-1; using "
                + mcMmoFarmRate + ". Fix config.yml to silence this warning.");
        }
        Object rawBandRate = getConfig().get("boss-band-rate");
        RewardScale.ParsedRate parsedBand = RewardScale.parseRate(rawBandRate, BandScale.DEFAULT_BAND_RATE);
        bossBandRate = parsedBand.rate();
        if (parsedBand.adjusted()) {
            getLogger().warning("boss-band-rate value '" + rawBandRate + "' is not a number in 0-1; using "
                + bossBandRate + ". Fix config.yml to silence this warning.");
        }
        // isSet, not contains: contains() also sees the jar's bundled
        // defaults (jobs-farm-rate is always "present" through them), which
        // would suppress this warning on exactly the legacy files it is for.
        if (getConfig().isSet("farm-reward-percent") && !getConfig().isSet("jobs-farm-rate")) {
            getLogger().warning("config.yml still carries farm-reward-percent, which ExcelRewardGuard 1.3 retired: "
                + "it is IGNORED. The farm share is now jobs-farm-rate (" + jobsFarmRate + ") and mcmmo-farm-rate ("
                + mcMmoFarmRate + "); set those keys to change it.");
        }
        auditLog = new AuditLog(new java.io.File(getDataFolder(), "audit.log").toPath(),
            getConfig().getBoolean("audit-log", false), getLogger());
        Object rawFallThreshold = getConfig().get("farm-fall-damage-percent");
        RewardScale.ParsedPercent parsedFall = RewardScale.parsePercent(rawFallThreshold, FallDamageTracker.DEFAULT_THRESHOLD_PERCENT);
        farmFallDamagePercent = parsedFall.percent();
        if (parsedFall.adjusted()) {
            getLogger().warning("farm-fall-damage-percent value '" + rawFallThreshold + "' is not a whole number in 0-100; using "
                + farmFallDamagePercent + "%. Fix config.yml to silence this warning.");
        }
        provenance = new ProvenanceStore();
        fallTracker = new FallDamageTracker();
        suppressionWindowTicks = getConfig().getLong("suppression-window-ticks", 2L);
        suppression = new XpSuppression(
            getConfig().getDouble("party-share-radius-blocks", 40.0),
            suppressionWindowTicks);
        getServer().getPluginManager().registerEvents(this, this);
        getServer().getScheduler().runTaskTimer(this, tickCounter::incrementAndGet, 1L, 1L);

        getLogger().info("Provenance marking ON: spawner, spawn-egg and Nether-portal mobs are marked at birth and stay marked.");
        getLogger().info("Farm rates: Jobs " + RewardScale.percentLabel(jobsFarmRate) + " (config jobs-farm-rate: " + jobsFarmRate
            + "), mcMMO " + RewardScale.percentLabel(mcMmoFarmRate) + " (config mcmmo-farm-rate: " + mcMmoFarmRate
            + "); 0 = block that path's farm rewards like 1.0, 1 = no reduction on that path.");
        // Seal step (1.4): config parameters, persisted state, startup lines.
        // The watch task and the power sampler start after the integrations
        // register below; the state object must exist before any reward
        // handler can run, so it is built here, beside the farm rates.
        boolean stepEnabled = getConfig().getBoolean("seal-step-enabled", true);
        Object rawMoneyStep = getConfig().get("seal-money-step-per-seal");
        RewardScale.ParsedRate parsedMoneyStep = RewardScale.parseRate(rawMoneyStep, SealStep.DEFAULT_MONEY_STEP);
        if (parsedMoneyStep.adjusted()) {
            getLogger().warning("seal-money-step-per-seal value '" + rawMoneyStep + "' is not a number in 0-1; using "
                + parsedMoneyStep.rate() + ". Fix config.yml to silence this warning.");
        }
        Object rawXpStep = getConfig().get("seal-xp-step-per-seal");
        RewardScale.ParsedRate parsedXpStep = RewardScale.parseRate(rawXpStep, SealStep.DEFAULT_XP_STEP);
        if (parsedXpStep.adjusted()) {
            getLogger().warning("seal-xp-step-per-seal value '" + rawXpStep + "' is not a number in 0-1; using "
                + parsedXpStep.rate() + ". Fix config.yml to silence this warning.");
        }
        stepState = new SealStepState(stepEnabled, parsedMoneyStep.rate(), parsedXpStep.rate());
        stepStateFile = new java.io.File(getDataFolder(), "seal-step-state.txt").toPath();
        if (Files.exists(stepStateFile)) {
            try {
                int restored = stepState.deserialize(Files.readString(stepStateFile, StandardCharsets.UTF_8));
                if (restored > 0) {
                    getLogger().info("Seal-step state restored from seal-step-state.txt (" + restored + " entries).");
                }
            } catch (IOException failure) {
                getLogger().warning("Could not read seal-step-state.txt (" + failure.getClass().getSimpleName()
                    + "); starting with fresh seal-step state. Pinned pars will be re-measured live.");
            }
        }
        if (!stepEnabled) {
            getLogger().info("Seal step OFF (config seal-step-enabled: false): no seal bonus applies on any channel; "
                + "rewards pay the farm-shaped base rates only.");
        } else {
            getLogger().info("Seal step ON: Jobs money +" + RewardScale.percentLabel(parsedMoneyStep.rate())
                + " per seal flat (no fade); Jobs XP and mcMMO XP +" + RewardScale.percentLabel(parsedXpStep.rate())
                + " per seal faded by the gap to par (par = top-3 mean mcMMO power, measured live and pinned per seal). "
                + "Composition: base x farm rate (if farmed) x step. Magic SP is never stepped; the step is invisible to players.");
        }
        getLogger().info("Fall-softened kill detection ON: a mob whose cumulative fall damage reaches " + farmFallDamagePercent
            + "% of its max health counts as farmed and earns the same farm rates above (config farm-fall-damage-percent: "
            + farmFallDamagePercent + ").");
        getLogger().info(auditLog.enabled()
            ? "Audit log ON: every farm reward adjustment is appended to plugins/ExcelRewardGuard/audit.log."
            : "Audit log OFF (config audit-log: false); adjustments are counted but not recorded per kill.");
        // Band governor (1.5): connect the BossTrial verdict feed before
        // the integrations register, so the first mcMMO gain already sees
        // the settled state. An unconnected feed is a normal, supported
        // state (BossTrial absent or pre-0.2.4): gains pay full.
        bossTrialFeed = new BossTrialFeed(this);
        if (bossTrialFeed.connected()) {
            getLogger().info("Boss band governor ON: ExcelBossTrial verdict feed connected; out-of-band "
                + "governed hits pay " + RewardScale.percentLabel(bossBandRate) + " mcMMO XP in real time "
                + "(config boss-band-rate: " + bossBandRate + "), in-band hits pay full. Silent: no "
                + "player-facing text; the seal step and farm rates compose as before.");
        } else {
            getLogger().info("Boss band governor INACTIVE: no ExcelBossTrial verdict feed (plugin absent "
                + "or older than 0.2.4); governed hits pay full mcMMO XP. This is the fail-safe state, "
                + "not an error.");
        }
        registerIntegration("Jobs", getConfig().getBoolean("jobs-veto", true),
            () -> getServer().getPluginManager().registerEvents(new JobsVeto(this), this),
            jobsActiveLine(),
            "Jobs enforcement OFF by config; marked kills can still earn full Jobs rewards.");
        registerIntegration("mcMMO", getConfig().getBoolean("mcmmo-veto", true),
            () -> { mcMmoVeto = new McMmoVeto(this); getServer().getPluginManager().registerEvents(mcMmoVeto, this); },
            mcMmoActiveLine(),
            "mcMMO enforcement OFF by config; marked kills can still earn full mcMMO XP.");
        Plugin eliteMobs = getServer().getPluginManager().getPlugin("EliteMobs");
        if (eliteMobs != null && eliteMobs.isEnabled() && getConfig().getBoolean("elitemobs-verdict-logging", true)) {
            getServer().getPluginManager().registerEvents(new EliteVerdictLog(this), this);
            getLogger().info("EliteMobs found: verdict logging only. EliteMobs 10.9.8 has no cancellable reward event, so the guard cannot reduce its coin showers; its own anti-exploit caps still apply.");
        } else if (eliteMobs == null) {
            getLogger().info("EliteMobs not found: elite verdict logging inactive.");
        }
        if (stepState != null && stepState.enabled()) {
            Plugin mcMMO = getServer().getPluginManager().getPlugin("mcMMO");
            if (mcMMO != null && mcMMO.isEnabled()) {
                powerSampler = new PowerSampler(this);
                getServer().getPluginManager().registerEvents(powerSampler, this);
            } else {
                getLogger().info("Seal step: mcMMO not found, so no power readings can be taken; the XP fade stays "
                    + "unshaped (money step unaffected).");
            }
            long pollTicks = Math.max(5, getConfig().getInt("seal-watch-seconds", 60)) * 20L;
            getServer().getScheduler().runTaskTimer(this, () -> evaluateStep(true), 100L, pollTicks);
            evaluateStep(false);
            getLogger().info(sealStepStatusLine());
        }
        getLogger().info("Vanilla XP drops are never modified by this plugin.");
    }

    // ------------------------------------------------------------------
    // Console admin (1.7): /rewardguard status — read-only snapshot.
    // The console always passes; an in-game sender needs the
    // excelrewardguard.admin node (plugin.yml, default op). Formatting
    // and the gate live in RewardGuardStatus (pure, unit-tested); this
    // handler only snapshots real fields/counters and sends the lines.
    // ------------------------------------------------------------------

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!RewardGuardStatus.COMMAND_NAME.equalsIgnoreCase(command.getName())) return false;
        boolean console = sender instanceof ConsoleCommandSender;
        if (!RewardGuardStatus.canUse(console, sender.hasPermission(RewardGuardStatus.ADMIN_PERMISSION))) {
            sender.sendMessage(RewardGuardStatus.denialLine());
            return true;
        }
        if (!RewardGuardStatus.isStatusArgs(args)) {
            sender.sendMessage(RewardGuardStatus.usageLine());
            return true;
        }
        for (String line : RewardGuardStatus.format(statusSnapshot())) sender.sendMessage(line);
        return true;
    }

    private RewardGuardStatus.Snapshot statusSnapshot() {
        boolean stepOn = stepState != null && stepState.enabled();
        return new RewardGuardStatus.Snapshot(
            getDescription().getVersion(),
            jobsFarmRate, mcMmoFarmRate, bossBandRate,
            bossTrialFeed != null && bossTrialFeed.connected(),
            farmFallDamagePercent,
            fallTracker == null ? 0 : fallTracker.size(),
            jobsInterventions(), mcMmoInterventions(), eliteVerdicts(),
            stepOn,
            stepState == null ? -1 : stepState.seals(),
            SealStep.MAX_SEALS,
            sealSourceLive,
            stepState == null ? SealStep.DEFAULT_MONEY_STEP : stepState.moneyStepPerSeal(),
            stepState == null ? SealStep.DEFAULT_XP_STEP : stepState.xpStepPerSeal(),
            stepState == null ? null : stepState.pinnedPar(),
            stepState == null ? 0 : stepState.knownPowerCount(),
            auditLog != null && auditLog.enabled(),
            debugLogging,
            suppressionWindowTicks,
            recentFarmedOrigin());
    }

    @Override public void onDisable() {
        mcMmoVeto = null; // Excel: invalidate optional integration and its transient receipts.
        // The fall tracker is in-memory only; clearing it here means a
        // reload never inherits stale fall history (and frees the map).
        if (fallTracker != null) fallTracker.clear();
        // Persist the seal-step state so pinned pars and the power cache
        // survive the restart (they are re-measured live only if lost).
        if (stepState != null && stepState.dirty()) persistStepState();
    }

    // ------------------------------------------------------------------
    // Seal step (1.4): seal watch, power cache, handler accessors.
    // The seal read mirrors ExcelMagicGate's: the public GuildGateAPI is
    // consumed by reflection through ExcelGuildGate's own classloader, so
    // this plugin carries no compile dependency on the gate.
    // ------------------------------------------------------------------

    /** GuildGate's broken-seal count, or null when the source is unavailable. */
    private Integer readSeals() {
        Plugin gg = Bukkit.getPluginManager().getPlugin("ExcelGuildGate");
        if (gg == null || !gg.isEnabled()) {
            return null;
        }
        try {
            if (guildGateSealsMethod == null) {
                Class<?> api = Class.forName("com.winkreyes.guildgate.api.GuildGateAPI",
                        true, gg.getClass().getClassLoader());
                guildGateSealsMethod = api.getMethod("sealsBrokenCount");
            }
            return (Integer) guildGateSealsMethod.invoke(null);
        } catch (Exception e) {
            getLogger().warning("Could not read GuildGateAPI.sealsBrokenCount(): " + e.getMessage());
            guildGateSealsMethod = null;
            return null;
        }
    }

    /**
     * One seal-watch evaluation: read the count, follow it, refresh the
     * power readings of everyone online, persist what changed. Runs on the
     * poll timer and on joins (a join is a cheap extra tick, as in
     * ExcelMagicGate — an admin may have granted a seal between polls).
     */
    private void evaluateStep(boolean announceChanges) {
        if (stepState == null || !stepState.enabled()) return;
        Integer seals = readSeals();
        if (seals == null) {
            if (sealSourceLive) {
                getLogger().warning("Seal source lost (ExcelGuildGate stopped answering): the seal step is "
                    + "suspended — no bonus applies — until it answers again.");
            }
            sealSourceLive = false;
        } else {
            if (!sealSourceLive && announceChanges) {
                getLogger().info("Seal source answering again (ExcelGuildGate): the seal step resumes.");
            }
            sealSourceLive = true;
            int before = stepState.seals();
            Double pinned = stepState.observeSeals(seals);
            if (announceChanges && stepState.seals() != before) {
                getLogger().info("GuildGate seals observed: " + stepState.seals() + " of " + SealStep.MAX_SEALS
                    + (before >= 0 ? " (was " + before + ")" : "") + "; the reward step follows the standing count.");
            }
            if (pinned != null) logParPinned(pinned);
        }
        if (powerSampler != null) powerSampler.sampleOnline();
        if (stepState.dirty()) persistStepState();
    }

    private void logParPinned(double par) {
        getLogger().info("Seal-step par pinned for seal " + stepState.seals() + ": " + oneDecimal(par)
            + " (top-3 mean of " + stepState.knownPowerCount() + " observed player powers). "
            + "Players at or above par earn no XP step; the fade is linear below it.");
    }

    /** The boot-time status line: where the step stands right now, in operator terms. */
    private String sealStepStatusLine() {
        if (!sealSourceLive) {
            return "Seal step status: seal source UNAVAILABLE (ExcelGuildGate not answering); no step will apply until it does.";
        }
        int seals = stepState.seals();
        if (seals <= 0) {
            return "Seal step status: GuildGate seals 0 of " + SealStep.MAX_SEALS + "; no seal stands, so no step applies yet.";
        }
        Double par = stepState.pinnedPar();
        if (par == null) {
            return "Seal step status: GuildGate seals " + seals + " of " + SealStep.MAX_SEALS + "; money step x"
                + trimNumber(stepState.moneyMultiplier(true)) + " applies now. Par for seal " + seals
                + " is not yet pinned (" + stepState.knownPowerCount() + " of 3 needed player powers observed), "
                + "so the XP step waits for more readings.";
        }
        return "Seal step status: GuildGate seals " + seals + " of " + SealStep.MAX_SEALS + "; par " + oneDecimal(par)
            + "; money step x" + trimNumber(stepState.moneyMultiplier(true)) + ", XP step up to x"
            + trimNumber(SealStep.xpMultiplier(seals, stepXpStepPerSeal(), 0, par)) + " at power 0, fading to x1 at par.";
    }

    private double stepXpStepPerSeal() {
        // Kept beside the state for the status line's "up to" figure; the
        // state object owns the value used by the handlers.
        return stepState == null ? SealStep.DEFAULT_XP_STEP : stepState.xpStepPerSeal();
    }

    private void persistStepState() {
        if (stepState == null || stepStateFile == null) return;
        try {
            Path parent = stepStateFile.getParent();
            if (parent != null) Files.createDirectories(parent);
            Files.writeString(stepStateFile, stepState.serialize(), StandardCharsets.UTF_8);
            stepState.clearDirty();
        } catch (IOException failure) {
            if (stepPersistWarned.compareAndSet(false, true)) {
                getLogger().warning("Could not write seal-step-state.txt (" + failure.getClass().getSimpleName()
                    + "); pinned pars and power readings will be re-measured after a restart.");
            }
        }
    }

    /** Whether the seal step is enabled in config (1.4). */
    public boolean sealStepEnabled() {
        return stepState != null && stepState.enabled();
    }

    /** Jobs money/points step multiplier right now (flat; 1 when unknown or disabled). */
    public double sealMoneyMultiplier() {
        return stepState == null ? 1.0 : stepState.moneyMultiplier(sealSourceLive);
    }

    /** Jobs/mcMMO XP step multiplier for one gaining player (faded; 1 when unknown or disabled). */
    public double sealXpMultiplier(UUID player) {
        return stepState == null ? 1.0 : stepState.xpMultiplier(player, sealSourceLive);
    }

    /** Records one observed player power (called by the mcMMO-gated sampler and veto). */
    public void observePower(UUID player, int power) {
        if (stepState == null || !stepState.enabled()) return;
        Double pinned = stepState.observePower(player, power);
        if (pinned != null) {
            logParPinned(pinned);
            persistStepState();
        }
    }

    /** A join is a cheap extra watch tick (mirrors ExcelMagicGate). */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onJoinEvaluateStep(PlayerJoinEvent event) {
        evaluateStep(true);
    }

    private String jobsActiveLine() {
        if (jobsFarmRate <= 0.0) {
            return "Jobs vetoes ACTIVE: marked kills earn no Jobs money and no Jobs XP (payment events cancelled; jobs-farm-rate is 0).";
        }
        if (jobsFarmRate >= 1.0) {
            return "Jobs found: jobs-farm-rate is 1, so marked kills earn full Jobs money and Jobs XP (no reduction applied).";
        }
        return "Jobs reward scaling ACTIVE: marked kills earn " + RewardScale.percentLabel(jobsFarmRate)
            + " of their Jobs money, points and XP (each channel scaled exactly once; jobs-farm-rate: " + jobsFarmRate + ").";
    }

    private String mcMmoActiveLine() {
        if (mcMmoFarmRate <= 0.0) {
            return "mcMMO veto ACTIVE: marked kills earn no mcMMO XP (kill XP zeroed before multipliers and party share; mcmmo-farm-rate is 0).";
        }
        if (mcMmoFarmRate >= 1.0) {
            return "mcMMO found: mcmmo-farm-rate is 1, so marked kills earn full mcMMO XP (no reduction applied).";
        }
        return "mcMMO reward scaling ACTIVE: marked kills earn " + RewardScale.percentLabel(mcMmoFarmRate)
            + " of their mcMMO XP (kill XP scaled before multipliers and party share; mcmmo-farm-rate: " + mcMmoFarmRate + ").";
    }

    private void registerIntegration(String name, boolean wanted, Runnable register, String activeLine, String offLine) {
        Plugin plugin = getServer().getPluginManager().getPlugin(name);
        if (plugin == null || !plugin.isEnabled()) {
            getLogger().info(name + " not found: its reward enforcement is inactive; provenance marking and the farmDecision API still work.");
            return;
        }
        if (!wanted) {
            getLogger().info(offLine);
            return;
        }
        try {
            register.run();
            getLogger().info(activeLine);
        } catch (NoClassDefFoundError | RuntimeException failure) {
            getLogger().severe(name + " integration failed to register (" + failure.getClass().getSimpleName()
                + "); its reward enforcement is inactive. Provenance marking still works.");
        }
    }

    public int farmApiVersion() { return 1; }

    /** The configured Jobs farm rate (0-1): the share of Jobs money, points and XP a farmed kill still earns (1.3; config jobs-farm-rate). */
    public double jobsFarmRate() { return jobsFarmRate; }

    /** The configured mcMMO farm rate (0-1): the share of mcMMO XP a farmed kill still earns (1.3; config mcmmo-farm-rate). Independent of the Jobs rate. */
    public double mcMmoFarmRate() { return mcMmoFarmRate; }

    /** The configured boss band rate (0-1): the share of mcMMO XP an out-of-band governed hit still earns (1.5; config boss-band-rate). */
    public double bossBandRate() { return bossBandRate; }

    /**
     * Consumes the BossTrial band verdict for the player's next governed
     * hit (1.5): Boolean.FALSE = the hit did not count, Boolean.TRUE =
     * counted, null = no verdict applies. Null whenever the feed is
     * unconnected or has failed - the caller pays full (fail-safe).
     */
    public Boolean pollBossBand(UUID player) {
        BossTrialFeed feed = bossTrialFeed;
        return feed == null ? null : feed.poll(player);
    }

    /**
     * Legacy accessor kept for API compatibility: the Jobs farm rate as a
     * whole percent. 1.1/1.2 consumers read the single shared percent here;
     * since 1.3 the paths have separate rates and this returns the Jobs one.
     */
    public int farmRewardPercent() { return (int) Math.round(jobsFarmRate * 100.0); }

    /** Records one reward adjustment to the audit log when audit-log is on (see AuditLog); a no-op otherwise. */
    public void audit(String player, String origin, String channel, double base, double rate, double paid) {
        AuditLog log = auditLog;
        if (log != null) log.record(player, origin, channel, base, rate, paid);
    }

    /**
     * The classification of the most recent farmed death, while its
     * suppression window could still match a gain (window + 2 ticks of
     * margin); "window" when nothing recent is known. mcMMO XP events
     * carry no entity, so the audit log labels mcMMO adjustments with the
     * farmed death that planted the matched window — the same approximation
     * the window mechanism itself makes.
     */
    public String recentFarmedOrigin() {
        String reason = lastFarmedReason;
        if (reason == null) return "window";
        long age = currentTick() - lastFarmedTick;
        return (age >= 0 && age <= suppressionWindowTicks + 2) ? reason : "window";
    }

    /** The configured fall-softening threshold (0-100): cumulative fall damage, as a percent of max health, at which a kill counts as farmed. */
    public int farmFallDamagePercent() { return farmFallDamagePercent; }

    public FallDamageTracker fallTracker() { return fallTracker; }

    /** Snapshot while the entity object still exposes PDC, including during death callbacks. */
    public String[] farmDecision(LivingEntity entity) {
        if (!isEnabled() || provenance == null || entity == null || reportedFailure.get()) return FarmVerdict.unavailable().apiValue();
        try {
            return provenance.inspect(entity.getPersistentDataContainer()).apiValue();
        } catch (RuntimeException failure) {
            reportFailure(failure);
            return FarmVerdict.unavailable().apiValue();
        }
    }

    /** True when the entity's provenance verdict is DENY (including the fail-closed unavailable state). */
    public boolean isDenied(LivingEntity entity) {
        return "DENY".equals(farmDecision(entity)[0]);
    }

    /** True when the entity's cumulative fall damage reaches the configured threshold (see FallDamageTracker). */
    public boolean isFallSoftened(LivingEntity entity) {
        if (fallTracker == null || entity == null) return false;
        return fallTracker.isSoftened(entity.getUniqueId(), farmFallDamagePercent);
    }

    /** The entity's cumulative fall damage as a percent of its most recently observed max health; 0 when untracked. */
    public double fallDamagePercentOf(LivingEntity entity) {
        if (fallTracker == null || entity == null) return 0.0;
        return fallTracker.fallDamagePercent(entity.getUniqueId());
    }

    /**
     * The combined enforcement classification: the reason this kill counts
     * as farmed, or null when it does not. The origin verdict wins the label
     * when both signals fire, so a kill is classified (and scaled) exactly
     * once. Reasons: a provenance reason (e.g. spawn_origin_spawner) or
     * FallDamageTracker.FALL_SOFTENED_REASON.
     */
    public String farmedReason(LivingEntity entity) {
        if (entity == null) return null;
        String[] decision = farmDecision(entity);
        return FallDamageTracker.farmedReason(
            "DENY".equals(decision[0]), decision[1], isFallSoftened(entity));
    }

    /** True when the kill counts as farmed by either signal: origin DENY or fall-softened. */
    public boolean isFarmed(LivingEntity entity) {
        return farmedReason(entity) != null;
    }

    public long currentTick() { return tickCounter.get(); }

    public XpSuppression suppression() { return suppression; }

    public boolean debugLogging() { return debugLogging; }

    public void countJobsIntervention() { jobsInterventions.incrementAndGet(); }
    public void countMcMmoIntervention() { mcMmoInterventions.incrementAndGet(); }
    public void countEliteVerdict() { eliteVerdicts.incrementAndGet(); }
    public long jobsInterventions() { return jobsInterventions.get(); }
    public long mcMmoInterventions() { return mcMmoInterventions.get(); }
    public long eliteVerdicts() { return eliteVerdicts.get(); }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent event) {
        try {
            provenance.recordSpawn(event.getEntity().getPersistentDataContainer(), event.getSpawnReason().name());
        } catch (RuntimeException failure) {
            reportFailure(failure);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTransform(EntityTransformEvent event) {
        if (!(event.getEntity() instanceof LivingEntity source)) return;
        try {
            for (var entity : event.getTransformedEntities()) {
                if (entity instanceof LivingEntity target) {
                    provenance.copy(source.getPersistentDataContainer(), target.getPersistentDataContainer());
                }
            }
        } catch (RuntimeException failure) {
            reportFailure(failure);
        }
    }

    /**
     * Accumulates fall damage for the softened-kill signature. MONITOR
     * priority with ignoreCancelled, so only falls that actually happened
     * count, and the amount is the FINAL damage (after armor/enchantment
     * math — for fall damage that is what the health bar actually lost).
     * Players are not tracked: a player's death pays no kill rewards, and
     * excluding them keeps the map proportional to mobs that fell.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFallDamage(EntityDamageEvent event) {
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (!(event.getEntity() instanceof LivingEntity entity)) return;
        if (entity instanceof Player) return;
        if (fallTracker == null) return;
        AttributeInstance maxHealth = entity.getAttribute(Attribute.MAX_HEALTH);
        if (maxHealth == null) return;
        fallTracker.recordFall(entity.getUniqueId(), event.getFinalDamage(), maxHealth.getValue());
    }

    /**
     * Plants the mcMMO suppression window for a farmed death (origin-denied
     * or fall-softened). LOWEST priority so the window exists before
     * mcMMO's own NORMAL-priority death handler grants the kill XP and
     * party share synchronously inside this same dispatch. Vanilla XP drops
     * are deliberately not touched here or anywhere else.
     */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onDeathPlantWindow(EntityDeathEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim instanceof Player) return;
        String reason = farmedReason(victim);
        if (reason == null) return;
        Player killer = victim.getKiller();
        var location = victim.getLocation();
        lastFarmedReason = reason;
        lastFarmedTick = currentTick();
        suppression.plant(killer == null ? null : killer.getUniqueId(),
            location.getWorld() == null ? "" : location.getWorld().getName(),
            location.getX(), location.getY(), location.getZ(), currentTick());
        if (debugLogging) {
            if (FallDamageTracker.FALL_SOFTENED_REASON.equals(reason)) {
                getLogger().info("Suppression window planted for fall-softened death of " + victim.getType()
                    + " (fall damage " + oneDecimal(fallDamagePercentOf(victim)) + "% of max health, threshold "
                    + farmFallDamagePercent + "%).");
            } else {
                getLogger().info("Suppression window planted for denied death of " + victim.getType()
                    + " (reason " + reason + ").");
            }
        }
    }

    /**
     * Drops the victim's fall record once death processing is done.
     * MONITOR priority: every enforcement reader (the window plant above at
     * LOWEST, Jobs' own death handlers, the mcMMO window match) runs inside
     * this same dispatch before MONITOR, so the record is guaranteed to be
     * present for the whole kill and gone afterwards — for player kills and
     * non-player deaths alike.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeathCleanup(EntityDeathEvent event) {
        if (fallTracker != null) fallTracker.remove(event.getEntity().getUniqueId());
    }

    /**
     * Drops fall records for entities leaving the world without dying
     * (despawn, discard, unload, ...). DEATH is skipped on purpose: the
     * death cleanup above owns that path, with ordering guarantees this
     * event does not give.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onEntityRemove(EntityRemoveEvent event) {
        if (fallTracker == null) return;
        if (event.getCause() == EntityRemoveEvent.Cause.DEATH) return;
        fallTracker.remove(event.getEntity().getUniqueId());
    }

    /** Drops fall records for every entity in an unloading chunk. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onEntitiesUnload(EntitiesUnloadEvent event) {
        if (fallTracker == null) return;
        List<UUID> ids = new ArrayList<>();
        for (Entity entity : event.getEntities()) ids.add(entity.getUniqueId());
        fallTracker.removeAll(ids);
    }

    private static String oneDecimal(double value) {
        return String.format(java.util.Locale.ROOT, "%.1f", value);
    }

    /** Compact multiplier rendering for status lines: 1.05, 1.25, 1.5 (no trailing zeros, no float dust). */
    private static String trimNumber(double value) {
        return java.math.BigDecimal.valueOf(value).stripTrailingZeros().toPlainString();
    }

    private void reportFailure(RuntimeException failure) {
        if (reportedFailure.compareAndSet(false, true)) {
            getLogger().severe("Provenance classification failed; the API is now unavailable for this lifetime. " + failure.getClass().getSimpleName());
        }
    }
}
