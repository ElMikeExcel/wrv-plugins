package com.winkreyes.rewardguard;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

/**
 * The seal-step runtime state (ExcelRewardGuard 1.4): the last seal count
 * read from ExcelGuildGate, the par pinned for each seal, and the cache of
 * observed player powers the pars are measured from. Pure logic plus a
 * line-based serialization; the main class owns the file IO
 * (plugins/ExcelRewardGuard/seal-step-state.txt).
 *
 * Par discipline (from the Oct 19, 2026 reward audit): par is the top-3
 * mean mcMMO power, RE-PULLED FROM LIVE DATA at each seal rather than
 * taken from the audit's planning table. Concretely: the first time a seal
 * count is observed with at least three player powers on record, the
 * top-3 mean of the observed powers is pinned as that seal's par and never
 * moves again for that seal — a drifting line would quietly rewrite the
 * deal mid-seal. A later seal pins a fresh line from the then-current
 * readings. Power readings are observations of whoever has been sampled
 * (on join, on mcMMO XP gains, and on the periodic refresh the main class
 * runs), so on a family server the top 3 are the leaders by construction.
 *
 * Unknown means unshaped, throughout: until a seal count has been read at
 * all, every multiplier is 1; until par is pinned for the standing seal,
 * the XP channels pay no step (the money step, being flat, needs no par
 * and applies as soon as a seal stands).
 */
public final class SealStepState {
    private final boolean enabled;
    private final double moneyStepPerSeal;
    private final double xpStepPerSeal;
    private int seals = -1; // -1: never read
    private final Map<Integer, Double> parBySeal = new TreeMap<>();
    private final Map<UUID, Integer> powers = new HashMap<>();
    private boolean dirty;

    public SealStepState(boolean enabled, double moneyStepPerSeal, double xpStepPerSeal) {
        this.enabled = enabled;
        this.moneyStepPerSeal = moneyStepPerSeal;
        this.xpStepPerSeal = xpStepPerSeal;
    }

    public synchronized boolean enabled() { return enabled; }

    /** The configured Jobs money step per seal (a fraction: 0.05 = +5%). */
    public double moneyStepPerSeal() { return moneyStepPerSeal; }

    /** The configured Jobs/mcMMO XP step per seal before the fade (0.10 = +10%). */
    public double xpStepPerSeal() { return xpStepPerSeal; }

    /** The last observed seal count, or -1 when ExcelGuildGate has never answered. */
    public synchronized int seals() { return seals; }

    /**
     * Records a fresh seal-count reading. Returns the par value when THIS
     * call pins a par for the standing seal (so the caller can log it), or
     * null otherwise. A null reading means "source unavailable" and changes
     * nothing — the last known count stands, but see the main class: while
     * the source is unavailable it applies no step at all.
     */
    public synchronized Double observeSeals(Integer count) {
        if (count == null) return null;
        int clamped = SealStep.clampSeals(count);
        if (clamped != seals) {
            seals = clamped;
            dirty = true;
        }
        return tryPin();
    }

    /**
     * Records one player's observed mcMMO power (the sum of their skill
     * levels). Returns the par value when THIS call completes a pin for the
     * standing seal, else null.
     */
    public synchronized Double observePower(UUID player, int power) {
        if (player == null) return null;
        int p = Math.max(0, power);
        Integer previous = powers.get(player);
        if (previous == null || previous != p) {
            powers.put(player, p);
            dirty = true;
        }
        return tryPin();
    }

    /** Pins the standing seal's par from the current readings, if possible and not already pinned. */
    private Double tryPin() {
        if (seals <= 0 || parBySeal.containsKey(seals)) return null;
        double candidate = SealStep.parCandidate(new ArrayList<>(powers.values()));
        if (candidate < 0.0) return null;
        parBySeal.put(seals, candidate);
        dirty = true;
        return candidate;
    }

    /** The par pinned for the standing seal, or null while unpinned (or at seal 0). */
    public synchronized Double pinnedPar() {
        if (seals <= 0) return null;
        return parBySeal.get(seals);
    }

    /** The par pinned for a specific seal, or null. */
    public synchronized Double pinnedPar(int seal) { return parBySeal.get(seal); }

    /** How many players' powers are on record. */
    public synchronized int knownPowerCount() { return powers.size(); }

    /** One player's last observed power, or null when never sampled. */
    public synchronized Integer powerOf(UUID player) {
        return player == null ? null : powers.get(player);
    }

    /**
     * Jobs money multiplier for the standing count. The caller passes
     * whether the seal source is currently answering; while it is not, the
     * step fails to 1 (no shaping on a stale count) per the audit posture.
     */
    public synchronized double moneyMultiplier(boolean sealSourceLive) {
        if (!enabled || !sealSourceLive || seals < 0) return 1.0;
        return SealStep.moneyMultiplier(seals, moneyStepPerSeal);
    }

    /** Jobs/mcMMO XP multiplier for one gaining player; see class doc for the unknown rules. */
    public synchronized double xpMultiplier(UUID player, boolean sealSourceLive) {
        if (!enabled || !sealSourceLive || seals < 0) return 1.0;
        return SealStep.xpMultiplier(seals, xpStepPerSeal, powerOf(player), pinnedPar());
    }

    public synchronized boolean dirty() { return dirty; }
    public synchronized void clearDirty() { dirty = false; }

    // ------------------------------------------------------------------
    // Serialization: one key per line, tolerant reader (unknown or broken
    // lines are skipped, never thrown — a corrupt state file must cost the
    // server its pinned pars at worst, never its boot).
    // ------------------------------------------------------------------

    public synchronized String serialize() {
        StringBuilder out = new StringBuilder();
        out.append("# ExcelRewardGuard seal-step state (1.4). Written by the plugin; hand edits are overwritten.\n");
        out.append("v=1\n");
        out.append("seals=").append(seals).append('\n');
        for (Map.Entry<Integer, Double> e : parBySeal.entrySet()) {
            out.append("par.").append(e.getKey()).append('=').append(Double.toString(e.getValue())).append('\n');
        }
        List<Map.Entry<UUID, Integer>> sorted = new ArrayList<>(powers.entrySet());
        sorted.sort((a, b) -> a.getKey().toString().compareTo(b.getKey().toString()));
        for (Map.Entry<UUID, Integer> e : sorted) {
            out.append("power.").append(e.getKey()).append('=').append(e.getValue()).append('\n');
        }
        return out.toString();
    }

    /** Restores state from serialize() output; returns the number of entries restored. */
    public synchronized int deserialize(String text) {
        if (text == null) return 0;
        int restored = 0;
        for (String rawLine : text.split("\\R")) {
            String line = rawLine.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            int eq = line.indexOf('=');
            if (eq <= 0) continue;
            String key = line.substring(0, eq).trim();
            String value = line.substring(eq + 1).trim();
            try {
                if (key.equals("seals")) {
                    int parsed = Integer.parseInt(value);
                    seals = parsed < 0 ? -1 : SealStep.clampSeals(parsed);
                    restored++;
                } else if (key.startsWith("par.")) {
                    int seal = Integer.parseInt(key.substring(4));
                    double par = Double.parseDouble(value);
                    if (seal >= 1 && seal <= SealStep.MAX_SEALS && par > 0.0) {
                        parBySeal.put(seal, par);
                        restored++;
                    }
                } else if (key.startsWith("power.")) {
                    UUID id = UUID.fromString(key.substring(6));
                    int power = Integer.parseInt(value);
                    if (power >= 0) {
                        powers.put(id, power);
                        restored++;
                    }
                }
            } catch (RuntimeException malformed) {
                // Skip the line; tolerance is the contract (see class doc).
            }
        }
        dirty = false;
        return restored;
    }
}
