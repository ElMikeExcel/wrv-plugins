package com.winkreyes.rewardguard;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * The reduced-reward policy math (ExcelRewardGuard 1.1, Mike's decision of
 * Oct 15, 2026: farmed kills earn a reduced share instead of nothing).
 *
 * A single config value, farm-reward-percent (0-100, default 65), drives
 * every reward path: Jobs money, Jobs points, Jobs XP and mcMMO XP for a
 * DENY-classified kill are multiplied by percent/100. Two endpoints are
 * special by design:
 *   - 0 reproduces ExcelRewardGuard 1.0 exactly (full veto / zeroing);
 *   - 100 is a true no-op: values pass through untouched, with no rounding.
 * In between, scaled doubles are rounded half-up to 2 decimal places. Jobs
 * money and points are currency-like, so a scaled reward never carries
 * floating-point dust like 6.500000000000001 into a balance, and sub-cent
 * results round the way money does (65 percent of 0.01 is 0.0065, which
 * rounds to 0.01, not silently to zero).
 *
 * Pure logic on purpose: no Bukkit types, so the policy is unit-testable
 * without a server, same as XpSuppression.
 *
 * 1.3 (Mike's decisions, Oct 18, 2026): the single shared percent is retired
 * in favour of two independent decimal RATES — jobs-farm-rate and
 * mcmmo-farm-rate, both defaulting to 0.33 (the farm rate is now 33%, down
 * from the 55% live under 1.2). The percent API above is kept intact: the
 * fall-damage threshold still parses through it, and its behaviour is pinned
 * by the unchanged RewardScaleTests. The rate API below mirrors the percent
 * contract: rate 0 yields exactly 0 (handlers pair it with cancellation),
 * rate 1 is an exact pass-through with no rounding, and in between scaled
 * doubles round half-up to 2 decimal places exactly like scale().
 */
public final class RewardScale {
    public static final int DEFAULT_PERCENT = 65;
    public static final double DEFAULT_RATE = 0.33;

    private RewardScale() { }

    /** Result of parsing the raw config value: the effective percent, and whether the raw value had to be defaulted or clamped to get there. */
    public record ParsedPercent(int percent, boolean adjusted) { }

    /**
     * Parses farm-reward-percent from whatever the config held:
     *   - missing (null)          -> the shipped default, 65, not "adjusted" (it is the normal path);
     *   - an integer in [0, 100]   -> itself (a numeric string like "65" counts);
     *   - an integer out of range  -> clamped to 0 or 100, adjusted;
     *   - a fractional number      -> truncated to an integer, then clamped, adjusted;
     *   - anything unparseable     -> the default, 65, adjusted.
     */
    public static ParsedPercent parsePercent(Object raw) {
        return parsePercent(raw, DEFAULT_PERCENT);
    }

    /**
     * The same defensive parsing with a caller-chosen default, added in 1.2
     * for farm-fall-damage-percent (whose default is 50, not 65). Semantics
     * are identical to parsePercent(Object) with DEFAULT_PERCENT replaced by
     * defaultPercent throughout.
     */
    public static ParsedPercent parsePercent(Object raw, int defaultPercent) {
        if (raw == null) return new ParsedPercent(defaultPercent, false);
        Long value = null;
        if (raw instanceof Number number) {
            double d = number.doubleValue();
            if (Double.isNaN(d) || Double.isInfinite(d)) return new ParsedPercent(defaultPercent, true);
            value = (long) d;
            if (d != value) return new ParsedPercent(clamp(value), true);
        } else if (raw instanceof String text) {
            try {
                value = Long.parseLong(text.trim());
            } catch (NumberFormatException notANumber) {
                return new ParsedPercent(defaultPercent, true);
            }
        } else {
            return new ParsedPercent(defaultPercent, true);
        }
        int clamped = clamp(value);
        return new ParsedPercent(clamped, clamped != value);
    }

    private static int clamp(long value) {
        if (value < 0) return 0;
        if (value > 100) return 100;
        return (int) value;
    }

    /** Scales a double reward (Jobs money, points or XP) to the configured percent. */
    public static double scale(double value, int percent) {
        if (percent >= 100) return value;
        if (percent <= 0) return 0.0;
        return BigDecimal.valueOf(value)
            .multiply(BigDecimal.valueOf(percent))
            .movePointLeft(2)
            .setScale(2, RoundingMode.HALF_UP)
            .doubleValue();
    }

    /** Scales an mcMMO XP gain (a float) to the configured percent, same rounding as scale(). */
    public static float scaleFloat(float value, int percent) {
        if (percent >= 100) return value;
        if (percent <= 0) return 0.0f;
        return (float) scale(value, percent);
    }

    // ------------------------------------------------------------------
    // Rate API (1.3): decimal rates in [0, 1], one knob per reward path.
    // ------------------------------------------------------------------

    /** Result of parsing a raw farm-rate config value: the effective rate, and whether the raw value had to be defaulted or clamped to get there. */
    public record ParsedRate(double rate, boolean adjusted) { }

    /** Parses a farm rate with the shipped default, DEFAULT_RATE (0.33). */
    public static ParsedRate parseRate(Object raw) {
        return parseRate(raw, DEFAULT_RATE);
    }

    /**
     * Parses a farm rate from whatever the config held:
     *   - missing (null)           -> the default, not "adjusted" (the normal path);
     *   - a number in [0, 1]       -> itself (fractions are the normal form
     *     here, unlike the percent parser; a numeric string counts);
     *   - a number outside [0, 1]  -> clamped to 0 or 1, adjusted. Note a
     *     percent-style value like 33 therefore clamps to 1 (full rewards),
     *     never to 33x: rates are fractions, and the startup log prints the
     *     effective rate so a mis-typed value is visible immediately;
     *   - NaN / infinite / anything unparseable -> the default, adjusted.
     */
    public static ParsedRate parseRate(Object raw, double defaultRate) {
        if (raw == null) return new ParsedRate(defaultRate, false);
        Double value = null;
        if (raw instanceof Number number) {
            value = number.doubleValue();
        } else if (raw instanceof String text) {
            try {
                value = Double.parseDouble(text.trim());
            } catch (NumberFormatException notANumber) {
                return new ParsedRate(defaultRate, true);
            }
        } else {
            return new ParsedRate(defaultRate, true);
        }
        if (value.isNaN() || value.isInfinite()) return new ParsedRate(defaultRate, true);
        if (value < 0.0) return new ParsedRate(0.0, true);
        if (value > 1.0) return new ParsedRate(1.0, true);
        return new ParsedRate(value, false);
    }

    /** Scales a double reward (Jobs money, points or XP) to the given rate, with the same half-up cent rounding as scale(double, int). */
    public static double scaleRate(double value, double rate) {
        if (rate >= 1.0) return value;
        if (rate <= 0.0) return 0.0;
        return BigDecimal.valueOf(value)
            .multiply(BigDecimal.valueOf(rate))
            .setScale(2, RoundingMode.HALF_UP)
            .doubleValue();
    }

    /** Scales an mcMMO XP gain (a float) to the given rate, same rounding as scaleRate(). */
    public static float scaleFloatRate(float value, double rate) {
        if (rate >= 1.0) return value;
        if (rate <= 0.0) return 0.0f;
        return (float) scaleRate(value, rate);
    }

    /** Display form of a rate for log lines: 0.33 -> "33%", 0.335 -> "33.5%", 1.0 -> "100%". */
    public static String percentLabel(double rate) {
        return BigDecimal.valueOf(rate)
            .multiply(BigDecimal.valueOf(100))
            .stripTrailingZeros()
            .toPlainString() + "%";
    }
}
