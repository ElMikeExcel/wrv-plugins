package com.winkreyes.rewardguard.integration;

import com.gamingmesh.jobs.api.JobsExpGainEvent;
import com.gamingmesh.jobs.api.JobsPrePaymentEvent;
import com.winkreyes.rewardguard.ExcelRewardGuard;
import com.winkreyes.rewardguard.FallDamageTracker;
import com.winkreyes.rewardguard.RewardScale;
import com.winkreyes.rewardguard.SealStep;
import java.util.UUID;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

/**
 * Jobs enforcement. Both Jobs events carry the entity the action is about,
 * so the reduction is exact per kill: when the kill is classified farmed,
 * the reward is scaled to the Jobs farm rate (config jobs-farm-rate,
 * default 0.33 since 1.3).
 *
 * Channel ownership — the 1.3 structural fix. Each Jobs channel is scaled
 * in EXACTLY ONE handler, by construction:
 *   - onPrePayment scales MONEY and POINTS only. It deliberately never
 *     touches the event's XP.
 *   - onExpGain scales XP only.
 * 1.2 scaled XP in BOTH handlers, and Jobs fires both events for one kill,
 * feeding the pre-payment's already-scaled XP into the XP-gain event, so
 * farmed Jobs XP was paid at the farm percent SQUARED (0.55 x 0.55 =
 * 30.25% instead of 55%) while money, which only ever passes through the
 * pre-payment event, was correct. That was proven from the live Jobs
 * database (see REWARDGUARD-AUDIT-2026-10-18.md: farm batches cluster at
 * exactly x0.3025 on XP and x0.55 on money). With XP owned solely by
 * onExpGain, the double application cannot recur without deleting this
 * split, and JobsSingleScalingTests simulates the two-event pipeline and
 * pins the single-scaling result.
 *
 * "Farmed" here is the guard's combined classification (see the main
 * class): the 1.0/1.1 provenance verdict (spawner / spawn-egg /
 * Nether-portal birth) OR, since 1.2, a fall-softened kill (the target's
 * cumulative fall damage reached farm-fall-damage-percent of its max
 * health — the sky-farm signature). The origin verdict wins the log label
 * when both fire, and the classification (like the scaling) applies
 * exactly once either way. Origin-classified kills log as they did in
 * 1.1/1.2 (with the rate in place of the percent); fall-classified kills
 * log a distinct FALL_SOFTENED line so the server log shows why the
 * payout was scaled.
 *
 * Endpoints: at rate 0 the pre-payment event is cancelled (money and
 * points gone, reproducing 1.0) and the XP gain is zeroed and cancelled in
 * its own handler; at rate 1 both handlers are a no-op pass-through.
 *
 * Since 1.4 the same two handlers also carry the SEAL STEP (Mike's hybrid,
 * Oct 19, 2026), composed exactly as mob-scaling SPEC §6 fixes it:
 *     final = base x (farm rate, if the kill is farmed; else 1) x step.
 * The step applies to ALL Jobs payment and XP events — not only kills —
 * because the catch-up formula keys on the PLAYER, not the kill: money and
 * points take the flat money step (+5% per seal, from this payment
 * handler), XP takes the faded XP step (+10% per seal toward par, keyed
 * on the gaining player's observed mcMMO power). A farmed kill at farm
 * rate 0 stays cancelled — 0 x step is still 0, so the step can never
 * resurrect a blocked farm reward. The channel split above is untouched:
 * the step changes WHAT the single rate per channel is, never WHERE a
 * channel is scaled. Adjustments made by the step alone are audited with
 * origin "seal_step" (SealStep.STEP_ORIGIN), so the operator record shows
 * the multiplier that actually landed on every line.
 *
 * This class is only loaded when the Jobs plugin is present (the main
 * class checks before registering it), so the Jobs classes are safe to
 * reference.
 */
public final class JobsVeto implements Listener {
    private final ExcelRewardGuard plugin;

    public JobsVeto(ExcelRewardGuard plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onPrePayment(JobsPrePaymentEvent event) {
        LivingEntity entity = event.getLivingEntity();
        // Non-kill payments (block breaks, fishing, crafting...) carry no
        // entity: they can never be farmed, but the seal step still
        // applies to them — it keys on the player, not the kill.
        String reason = entity == null ? null : plugin.farmedReason(entity);
        boolean fallSoftened = FallDamageTracker.FALL_SOFTENED_REASON.equals(reason);
        double farmFactor = reason == null ? 1.0 : plugin.jobsFarmRate();
        double rate = farmFactor * plugin.sealMoneyMultiplier();
        if (rate == 1.0) return;
        String player = event.getPlayer() == null ? "unknown" : event.getPlayer().getName();
        String origin = reason == null ? SealStep.STEP_ORIGIN : reason;
        if (rate <= 0.0) {
            // Only reachable farmed at farm rate 0: the step is never
            // below 1, so 0 x step stays 0 and a blocked farm kill stays
            // blocked exactly as in 1.0-1.3.
            event.setCancelled(true);
            plugin.countJobsIntervention();
            plugin.audit(player, origin, "jobs-money", event.getAmount(), rate, 0.0);
            plugin.audit(player, origin, "jobs-points", event.getPoints(), rate, 0.0);
            if (plugin.debugLogging()) {
                if (fallSoftened) {
                    plugin.getLogger().info("Jobs payment blocked for FALL_SOFTENED " + entity.getType()
                        + " (job " + event.getJob().getName() + ", fall damage " + fallPercent(entity)
                        + "% of max health; jobs-farm-rate 0).");
                } else {
                    plugin.getLogger().info("Jobs payment blocked for denied " + entity.getType()
                        + " (job " + event.getJob().getName() + ", jobs-farm-rate 0).");
                }
            }
            return;
        }
        // Money and points ONLY. The event's XP component is left exactly
        // as Jobs set it: Jobs carries that same XP into JobsExpGainEvent,
        // whose handler below is the single place XP is scaled (1.3 fix —
        // scaling here as well was the 1.2 double-scale bug).
        double money = event.getAmount();
        double points = event.getPoints();
        event.setAmount(SealStep.applyMultiplier(money, rate));
        event.setPoints(SealStep.applyMultiplier(points, rate));
        plugin.countJobsIntervention();
        plugin.audit(player, origin, "jobs-money", money, rate, event.getAmount());
        plugin.audit(player, origin, "jobs-points", points, rate, event.getPoints());
        if (plugin.debugLogging()) {
            if (reason == null) {
                plugin.getLogger().info("Jobs payment stepped x" + rate + " by the seal step"
                    + " (job " + event.getJob().getName() + "): money " + money + " -> " + event.getAmount()
                    + ", points " + points + " -> " + event.getPoints()
                    + " (XP is stepped in the XP-gain event).");
            } else if (fallSoftened) {
                plugin.getLogger().info("Jobs payment scaled to " + RewardScale.percentLabel(rate) + " for FALL_SOFTENED " + entity.getType()
                    + " (job " + event.getJob().getName() + ", fall damage " + fallPercent(entity)
                    + "% of max health): money " + money + " -> " + event.getAmount()
                    + ", points " + points + " -> " + event.getPoints()
                    + " (XP is scaled in the XP-gain event).");
            } else {
                plugin.getLogger().info("Jobs payment scaled to " + RewardScale.percentLabel(rate) + " for denied " + entity.getType()
                    + " (job " + event.getJob().getName() + "): money " + money + " -> " + event.getAmount()
                    + ", points " + points + " -> " + event.getPoints()
                    + " (XP is scaled in the XP-gain event).");
            }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onExpGain(JobsExpGainEvent event) {
        LivingEntity entity = event.getLivingEntity();
        String reason = entity == null ? null : plugin.farmedReason(entity);
        boolean fallSoftened = FallDamageTracker.FALL_SOFTENED_REASON.equals(reason);
        double farmFactor = reason == null ? 1.0 : plugin.jobsFarmRate();
        UUID playerId = event.getPlayer() == null ? null : event.getPlayer().getUniqueId();
        double rate = farmFactor * plugin.sealXpMultiplier(playerId);
        if (rate == 1.0) return;
        String player = event.getPlayer() == null ? "unknown" : event.getPlayer().getName();
        String origin = reason == null ? SealStep.STEP_ORIGIN : reason;
        double exp = event.getExp();
        if (rate <= 0.0) {
            event.setExp(0.0);
            event.setCancelled(true);
            plugin.countJobsIntervention();
            plugin.audit(player, origin, "jobs-xp", exp, rate, 0.0);
            if (plugin.debugLogging()) {
                if (fallSoftened) {
                    plugin.getLogger().info("Jobs XP blocked for FALL_SOFTENED " + entity.getType()
                        + " (job " + event.getJob().getName() + ", fall damage " + fallPercent(entity)
                        + "% of max health; jobs-farm-rate 0).");
                } else {
                    plugin.getLogger().info("Jobs XP blocked for denied " + entity.getType()
                        + " (job " + event.getJob().getName() + ", jobs-farm-rate 0).");
                }
            }
            return;
        }
        // The ONE place Jobs XP is scaled (1.3). The pre-payment handler
        // above never touches XP, so this scaling lands exactly once.
        event.setExp(SealStep.applyMultiplier(exp, rate));
        plugin.countJobsIntervention();
        plugin.audit(player, origin, "jobs-xp", exp, rate, event.getExp());
        if (plugin.debugLogging()) {
            if (reason == null) {
                plugin.getLogger().info("Jobs XP stepped x" + rate + " by the seal step"
                    + " (job " + event.getJob().getName() + "): XP " + exp + " -> " + event.getExp() + ".");
            } else if (fallSoftened) {
                plugin.getLogger().info("Jobs XP scaled to " + RewardScale.percentLabel(rate) + " for FALL_SOFTENED " + entity.getType()
                    + " (job " + event.getJob().getName() + ", fall damage " + fallPercent(entity)
                    + "% of max health): XP " + exp + " -> " + event.getExp() + ".");
            } else {
                plugin.getLogger().info("Jobs XP scaled to " + RewardScale.percentLabel(rate) + " for denied " + entity.getType()
                    + " (job " + event.getJob().getName() + "): XP " + exp + " -> " + event.getExp() + ".");
            }
        }
    }

    private String fallPercent(LivingEntity entity) {
        return String.format(java.util.Locale.ROOT, "%.1f", plugin.fallDamagePercentOf(entity));
    }
}
