package com.winkreyes.rewardguard;

import java.util.ArrayList;
import java.util.List;

/**
 * The 1.7 console-admin status surface: pure formatting of a snapshot
 * of the guard's REAL runtime state, so the reply text is unit-testable
 * without a server (same pattern as the other pure-logic classes).
 *
 * Nothing here reads or mutates plugin state: the main class builds
 * the snapshot from its own fields and counters — the configured farm
 * rates (jobs-farm-rate / mcmmo-farm-rate), the boss band rate, the
 * fall-softening threshold, the seal-step state, and the three
 * intervention counters the enforcement paths have incremented since
 * enable (Jobs interventions, mcMMO interventions, elite verdicts).
 * There is no "marked kills" counter in the plugin: kills are
 * classified per event and only the interventions are counted, so the
 * status reports exactly those counters and invents no other number.
 *
 * Permission discipline lives here too, so it is testable: the console
 * can always run the status command; an in-game sender needs the
 * excelrewardguard.admin node (plugin.yml, default op).
 */
public final class RewardGuardStatus {
    public static final String ADMIN_PERMISSION = "excelrewardguard.admin";
    public static final String COMMAND_NAME = "rewardguard";

    private RewardGuardStatus() { }

    /** Immutable snapshot of the values the status reply shows. */
    public record Snapshot(
        String version,
        double jobsFarmRate,
        double mcMmoFarmRate,
        double bossBandRate,
        boolean bossBandFeedConnected,
        int farmFallDamagePercent,
        int fallRecordsTracked,
        long jobsInterventions,
        long mcMmoInterventions,
        long eliteVerdicts,
        boolean sealStepEnabled,
        int seals,
        int maxSeals,
        boolean sealSourceLive,
        double sealMoneyStepPerSeal,
        double sealXpStepPerSeal,
        Double pinnedPar,
        int knownPowerCount,
        boolean auditLogEnabled,
        boolean debugLogging,
        long suppressionWindowTicks,
        String recentFarmedOrigin) { }

    /** True when the args are exactly the status form: ["status"]. */
    public static boolean isStatusArgs(String[] args) {
        return args != null && args.length == 1 && "status".equalsIgnoreCase(args[0]);
    }

    /** The gate: console always; anyone else needs the admin node. */
    public static boolean canUse(boolean consoleSender, boolean hasAdminPermission) {
        return consoleSender || hasAdminPermission;
    }

    public static String usageLine() {
        return "Usage: /" + COMMAND_NAME + " status";
    }

    public static String denialLine() {
        return "You need the " + ADMIN_PERMISSION + " permission to use /" + COMMAND_NAME + ".";
    }

    /** The status reply, one entry per line the sender receives. */
    public static List<String> format(Snapshot s) {
        List<String> lines = new ArrayList<>();
        lines.add("ExcelRewardGuard " + s.version() + " status:");
        lines.add("Farm rates: Jobs " + RewardScale.percentLabel(s.jobsFarmRate())
            + " (config jobs-farm-rate: " + trim(s.jobsFarmRate()) + "), mcMMO "
            + RewardScale.percentLabel(s.mcMmoFarmRate())
            + " (config mcmmo-farm-rate: " + trim(s.mcMmoFarmRate()) + "); boss band "
            + RewardScale.percentLabel(s.bossBandRate())
            + " (config boss-band-rate: " + trim(s.bossBandRate()) + ", verdict feed "
            + (s.bossBandFeedConnected() ? "connected" : "inactive - hits pay full") + ").");
        lines.add("Fall-softened threshold: " + s.farmFallDamagePercent()
            + "% of max health (config farm-fall-damage-percent: " + s.farmFallDamagePercent()
            + "); fall records tracked now: " + s.fallRecordsTracked() + ".");
        lines.add("Interventions since enable: Jobs " + s.jobsInterventions()
            + ", mcMMO " + s.mcMmoInterventions() + ", elite verdicts " + s.eliteVerdicts() + ".");
        lines.add(sealLine(s));
        lines.add("Audit log " + (s.auditLogEnabled() ? "ON" : "OFF")
            + "; debug logging " + (s.debugLogging() ? "ON" : "OFF")
            + "; suppression window " + s.suppressionWindowTicks() + " ticks"
            + "; most recent farmed origin: " + (s.recentFarmedOrigin() == null ? "window" : s.recentFarmedOrigin()) + ".");
        return List.copyOf(lines);
    }

    private static String sealLine(Snapshot s) {
        if (!s.sealStepEnabled()) {
            return "Seal step: OFF (config seal-step-enabled: false); no seal bonus applies.";
        }
        StringBuilder out = new StringBuilder("Seal step: ON; money +")
            .append(RewardScale.percentLabel(s.sealMoneyStepPerSeal()))
            .append(" per seal flat, XP +")
            .append(RewardScale.percentLabel(s.sealXpStepPerSeal()))
            .append(" per seal faded to par; ");
        if (s.seals() < 0) {
            out.append("seals not yet read (ExcelGuildGate has not answered).");
        } else {
            out.append("seals ").append(s.seals()).append(" of ").append(s.maxSeals())
                .append(s.sealSourceLive() ? " (source live)" : " (source UNAVAILABLE - step suspended)")
                .append("; par ");
            if (s.pinnedPar() == null) {
                out.append("not yet pinned (").append(s.knownPowerCount()).append(" player powers observed).");
            } else {
                out.append(trim(s.pinnedPar())).append(" (").append(s.knownPowerCount())
                    .append(" player powers observed).");
            }
        }
        return out.toString();
    }

    private static String trim(double value) {
        return java.math.BigDecimal.valueOf(value).stripTrailingZeros().toPlainString();
    }
}
