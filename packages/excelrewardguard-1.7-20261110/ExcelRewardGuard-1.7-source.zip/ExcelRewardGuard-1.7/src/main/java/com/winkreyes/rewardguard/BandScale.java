package com.winkreyes.rewardguard;

/**
 * The XP band governor's factor (1.5, Mike's pick Oct 22, 2026 -
 * "Option B" of the seal-hardening XP investigation): a governed
 * seal-boss hit that ExcelBossTrial classified as out-of-band (or
 * otherwise not counted toward its seal) pays this fraction of its
 * mcMMO XP, applied IN REAL TIME as the gain fires; a counted hit
 * pays full. No clawback, no death-time window: the verdict travels
 * with the hit itself (see integration/BossTrialFeed for the feed
 * contract and McMmoVeto for where the factor composes).
 *
 * Pure value logic, unit-tested directly. The one rule that matters:
 * anything that is not an explicit FALSE verdict - a counted hit, no
 * verdict in flight, an expired verdict, a dead feed - is factor
 * 1.0, full pay. The governor can only ever scale a hit BossTrial
 * positively classified as not counted; every failure mode degrades
 * to the pre-1.5 behavior.
 */
public final class BandScale {
    /** The shipped rate: out-of-band governed hits pay 25% mcMMO XP. Config boss-band-rate. */
    public static final double DEFAULT_BAND_RATE = 0.25;

    /** The audit origin recorded when the band factor shaped a gain. */
    public static final String BAND_ORIGIN = "boss_band_excluded";

    private BandScale() {}

    /** True when the verdict positively classifies the hit as not counted. */
    public static boolean isBanded(Boolean verdict) {
        return Boolean.FALSE.equals(verdict);
    }

    /**
     * The multiplicative factor for one PVE gain: bandRate when the
     * consumed verdict says the hit did not count, 1.0 otherwise
     * (counted verdict, or null - no opinion, pay full).
     */
    public static double bandFactor(Boolean verdict, double bandRate) {
        return isBanded(verdict) ? bandRate : 1.0;
    }
}
