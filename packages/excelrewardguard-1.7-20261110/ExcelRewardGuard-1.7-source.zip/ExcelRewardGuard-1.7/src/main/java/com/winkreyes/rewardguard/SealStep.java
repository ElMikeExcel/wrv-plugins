package com.winkreyes.rewardguard;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * The seal-step reward math (ExcelRewardGuard 1.4; Mike's hybrid, adopted
 * Oct 19, 2026 from the reward audit at
 * ~/workspace/mob-scaling/REWARD-AUDIT-2026-10-19.md).
 *
 * As each guild seal falls, the world gets harder (the mob ladder steps up)
 * and rewards step with it, in three channels only:
 *   - Jobs MONEY (and the points that ride the same payment event): a FLAT
 *     step of +5% per seal, no fade — multiplier 1 + 0.05 x seals. Money is
 *     itself the catch-up tool (it buys the gear), its power is capped by
 *     the fixed shop price list, and even at Seal 5 the stacked rate stays
 *     below the rates Jobs ships with.
 *   - Jobs XP and mcMMO XP: the same step at FULL size (+10% per seal) but
 *     faded by the gap to par:
 *         multiplier = 1 + step(seal) x clamp(1 - power / par, 0, 1)
 *     where power is the gaining player's mcMMO power level (the sum of
 *     their skill levels) and par is the top-3 mean power of the server,
 *     measured live and pinned when each seal is first observed (see
 *     SealStepState). A player AT or ABOVE par gets exactly +0% — the steps
 *     structurally cannot speed the leaders or move a leader's skill-cap
 *     date — and a player at power 0 gets the full step. That asymmetry is
 *     the whole point: help flows only to players behind.
 *   - Magic SP is NEVER stepped and never shaped (audit verdict: its earn
 *     ceiling is per-spell and equal for everyone, its prices are fixed,
 *     its permissions are global — the gap the fade exists to fix does not
 *     exist there). EliteMobs currency is excluded by Mike's rule (the
 *     0.25x coin-shower tune is FINAL), and vanilla XP is never touched,
 *     as everywhere else in this plugin.
 *
 * The shaping is INVISIBLE by Mike's hard requirement: no announcements,
 * no labels, no player-facing text anywhere in this plugin (it contains no
 * player-messaging call at all). The only records are console startup and
 * state lines and the operator audit log — see SPEC §6 of
 * ~/workspace/mob-scaling/SPEC.md, which also fixes the composition point:
 * the step multiplier enters at the same LOWEST-priority handlers as the
 * farm scale, so the final rate is
 *     base x (farm rate, if the kill is farmed; else 1) x step multiplier
 * and downstream party/weekend multipliers apply after, unchanged.
 *
 * Failure posture, also by design: anything unknown means NO step, never a
 * guessed bonus. Seal count unreadable (ExcelGuildGate absent or its API
 * failing), par not yet pinned, or a player's power unobserved all yield
 * a multiplier of exactly 1 on the affected channel.
 *
 * Pure logic on purpose: no Bukkit types, so the policy is unit-testable
 * without a server, same as RewardScale and XpSuppression.
 */
public final class SealStep {
    /** The campaign has five seals; a count outside 0-5 is clamped to it. */
    public static final int MAX_SEALS = 5;
    /** Jobs money step per seal: +5% (the audit's half-step; +25% at Seal 5). */
    public static final double DEFAULT_MONEY_STEP = 0.05;
    /** Jobs/mcMMO XP step per seal before the fade: +10% (+50% at Seal 5). */
    public static final double DEFAULT_XP_STEP = 0.10;
    /** Audit-log origin label for adjustments made by the step alone (operator record only; never shown to players). */
    public static final String STEP_ORIGIN = "seal_step";

    private SealStep() { }

    /** Clamps a raw seal count into the campaign range 0..5. */
    public static int clampSeals(int seals) {
        if (seals < 0) return 0;
        return Math.min(seals, MAX_SEALS);
    }

    /**
     * Jobs money multiplier for a standing seal count: flat, no fade.
     * seals <= 0 (or an unusable step) yields exactly 1 — no step at all is
     * the pre-Seal-1 world and stays byte-for-byte the old behaviour.
     */
    public static double moneyMultiplier(int seals, double stepPerSeal) {
        int s = clampSeals(seals);
        if (s <= 0 || !(stepPerSeal > 0.0)) return 1.0;
        return 1.0 + stepPerSeal * s;
    }

    /**
     * The fade factor in [0, 1]: 1 at power 0, 0 at or above par. A null or
     * non-positive par (not measured / not pinned) yields 0 — no bonus is
     * ever computed against an unknown line.
     */
    public static double fade(Integer power, Double par) {
        if (par == null || !(par > 0.0)) return 0.0;
        int p = power == null ? 0 : Math.max(0, power);
        double f = 1.0 - p / par;
        if (f < 0.0) return 0.0;
        return Math.min(f, 1.0);
    }

    /**
     * Jobs/mcMMO XP multiplier for one gaining player. Unknown power or
     * unpinned par yields exactly 1 (no shaping), per the failure posture
     * above; at or above par the fade is 0 and the result is exactly 1.
     */
    public static double xpMultiplier(int seals, double stepPerSeal, Integer power, Double par) {
        int s = clampSeals(seals);
        if (s <= 0 || !(stepPerSeal > 0.0)) return 1.0;
        if (power == null || par == null) return 1.0;
        return 1.0 + stepPerSeal * s * fade(power, par);
    }

    /**
     * The par candidate from observed powers: the mean of the three highest.
     * Returns -1 when fewer than three players have been observed — with no
     * top 3 there is no par, and the caller must keep waiting rather than
     * pinning a line from one or two readings (the audit defines par as the
     * top-3 mean; anything smaller is a different, weaker line).
     */
    public static double parCandidate(List<Integer> observedPowers) {
        if (observedPowers == null || observedPowers.size() < 3) return -1.0;
        List<Integer> sorted = new ArrayList<>(observedPowers);
        sorted.sort((a, b) -> Integer.compare(b, a));
        double sum = 0.0;
        for (int i = 0; i < 3; i++) sum += sorted.get(i);
        return sum / 3.0;
    }

    /**
     * Applies a combined rate (farm factor x step multiplier) to a double
     * reward with the house rounding contract: half-up to 2 decimals in
     * between, exactly 0 at rate <= 0, exact pass-through at rate == 1.
     * RewardScale.scaleRate cannot serve here — by design it treats any
     * rate >= 1 as a pass-through, which is right for a reduction and
     * wrong for a bonus. For rates below 1 this computes exactly what
     * scaleRate computes, so farm-only adjustments are unchanged.
     */
    public static double applyMultiplier(double value, double rate) {
        if (rate == 1.0) return value;
        if (rate <= 0.0) return 0.0;
        return BigDecimal.valueOf(value)
            .multiply(BigDecimal.valueOf(rate))
            .setScale(2, RoundingMode.HALF_UP)
            .doubleValue();
    }

    /** The float twin of applyMultiplier, for mcMMO raw XP gains. */
    public static float applyMultiplierFloat(float value, double rate) {
        if (rate == 1.0) return value;
        if (rate <= 0.0) return 0.0f;
        return (float) applyMultiplier(value, rate);
    }
}
