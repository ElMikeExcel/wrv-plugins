package com.winkreyes.rewardguard;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;

/**
 * Per-kill audit trail (1.3, Mike's call, Oct 18, 2026). RewardGuard 1.2's
 * acceptance had to be reverse-engineered from the Jobs database because
 * the only per-kill record was a debug log line that ships OFF. When
 * audit-log: true, every reward adjustment appends one line per channel to
 * plugins/ExcelRewardGuard/audit.log:
 *
 *   2026-10-18T18:45:00Z player=Kailey origin=spawn_origin_spawner channel=jobs-money base=10.00 rate=0.33 paid=3.30
 *
 * Channels: jobs-money, jobs-points, jobs-xp, mcmmo-xp. Blocked (rate 0)
 * adjustments are recorded too, with paid=0.00, so a zero rate is just as
 * auditable as a scaled one. Default OFF: record() is then a no-op and no
 * file is created. The origin on the mcMMO channel is the reason of the
 * farmed death that planted the matched suppression window — the same
 * approximation the window mechanism itself makes (see McMmoVeto); the
 * Jobs channels always name the exact killed entity's classification.
 *
 * Writes append one line per call (no held-open handle), so a plugin
 * reload or a hand-edit of the file can never corrupt a stream; volume on
 * a family server is a few lines per farmed kill. A write failure is
 * logged once at WARNING and never thrown into a reward handler.
 */
public final class AuditLog {
    private final Path file;
    private final boolean enabled;
    private final Logger logger;
    private final AtomicBoolean writeFailureReported = new AtomicBoolean();

    public AuditLog(Path file, boolean enabled, Logger logger) {
        this.file = file;
        this.enabled = enabled;
        this.logger = logger;
    }

    public boolean enabled() { return enabled; }

    /** Formats one audit line. Pure, so the exact format is unit-testable. */
    public static String format(Instant when, String player, String origin, String channel,
                                double base, double rate, double paid) {
        return DateTimeFormatter.ISO_INSTANT.format(when)
            + " player=" + safe(player)
            + " origin=" + safe(origin)
            + " channel=" + safe(channel)
            + " base=" + money(base)
            + " rate=" + BigDecimal.valueOf(rate).stripTrailingZeros().toPlainString()
            + " paid=" + money(paid);
    }

    /** Appends one line when enabled; a disabled log writes nothing and creates no file. */
    public synchronized void record(String player, String origin, String channel,
                                    double base, double rate, double paid) {
        if (!enabled) return;
        String line = format(Instant.now(), player, origin, channel, base, rate, paid);
        try {
            Path parent = file.getParent();
            if (parent != null) Files.createDirectories(parent);
            Files.writeString(file, line + "\n", StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException failure) {
            if (writeFailureReported.compareAndSet(false, true) && logger != null) {
                logger.warning("Audit log write failed (" + failure.getClass().getSimpleName()
                    + ": " + failure.getMessage() + "); further failures this run will not be repeated.");
            }
        }
    }

    private static String money(double value) {
        return String.format(Locale.ROOT, "%.2f", value);
    }

    /** Player/origin/channel tokens never carry spaces into the log format. */
    private static String safe(String token) {
        if (token == null || token.isBlank()) return "unknown";
        return token.replaceAll("\\s+", "_");
    }
}
