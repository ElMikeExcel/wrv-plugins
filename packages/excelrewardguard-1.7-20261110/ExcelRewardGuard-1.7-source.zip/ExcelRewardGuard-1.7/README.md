# ExcelRewardGuard 1.7

Farm-reward guard for the Wink Reyes Valley family server (Paper 26.2, Java 25).

**Status: Built, automated tests passed, local test-server passed. NOT installed live.** Installation follows the standard WRV gates (Mike's approval where required, empty-server restart window). Install packet: `INSTALL-PACKET.md` in `~/workspace/rewardguard-17-build/` (1.7 packet, staged Nov 10, 2026; not installed).

Authorship: Iris / Mike. Version 1.1 (Oct 15, 2026) changes the policy from "farmed kills earn nothing" to "farmed kills earn a reduced share", per Mike's decision the same day. Version 1.2 (Oct 16, 2026) adds the sky-farm signature. Version 1.3 (Oct 18, 2026) is the rate rework. Version 1.4 (Oct 20, 2026) is the seal step below, per Mike's hybrid adopted Oct 19, 2026.

## What 1.7 changes (console admin, Nov 10, 2026)

1. **The plugin's first command: `/rewardguard status`.** Read-only; answers the server console always, and in-game senders holding the new `excelrewardguard.admin` permission node (default op). The reply shows the guard's effective config — Jobs / mcMMO farm rates, boss band rate and verdict-feed state, the fall-softening threshold — and the counters the plugin actually keeps: Jobs interventions, mcMMO interventions, and elite verdicts since enable, plus fall records currently tracked and the seal-step state. There is no per-kill "marked" counter in the plugin, so none is shown.
2. **Nothing else changes.** No reward path, classification, config key, or data file is touched; `config.yml` ships byte-identical to 1.6. Formatting and the permission gate are the pure class `RewardGuardStatus`, unit-tested without a server (`RewardGuardStatusTests`). The one messaging this adds is the operator reply to the command sender — the standing "invisible to players" rule for reward shaping is unchanged.
3. **plugin.yml:** version 1.7, the `rewardguard` command and `excelrewardguard.admin` permission registration, and the author line now matches the shipped 1.6 jar (`author: Moon (provenance candidate) and Argus (enforcement completion)`) instead of the tree's former `authors: [Iris, Mike]`.

## What 1.6 / 1.5 / 1.4 changed

1.6 (Oct 30, 2026, Shared-XP bundle) added the shared-XP identity/provenance observer (`SharedXpProvenance`, the mcMMO fork's raw-XP pre-event accessors). 1.5 (Oct 22, 2026) added the boss band governor (25% mcMMO XP for out-of-band governed seal-boss hits, via ExcelBossTrial's verdict feed). 1.4 is detailed in the next section.

## What 1.4 changes (Mike's hybrid, adopted Oct 19, 2026)

1. **The seal step.** As each guild seal falls (the seal count is read live from ExcelGuildGate's public API, by reflection — the same mechanism ExcelMagicGate's seal watch uses), rewards step up at the same LOWEST-priority handlers and in the same composition the farm scale uses: `final = base × (farm rate, if farmed; else 1) × step multiplier`. Party/weekend multipliers still apply after, in their own plugins, unchanged.
2. **Jobs money (and points): flat +5% per seal, no fade** (`seal-money-step-per-seal: 0.05`; ×1.05 at Seal 1 … ×1.25 at Seal 5). It applies to ALL Jobs payments, not only kills — the step keys on the player, not the kill.
3. **Jobs XP and mcMMO XP: +10% per seal, faded by the gap to par** (`seal-xp-step-per-seal: 0.10`): `multiplier = 1 + step × clamp(1 − power/par, 0, 1)`, where power is the gaining player's mcMMO power level and par is the top-3 mean power of the server, measured live from observed readings (join, XP gains, a 60-second refresh) and **pinned when each seal is first observed** — a pinned par never drifts mid-seal. At or above par the XP step is exactly zero: the steps cannot speed the leaders or move a leader's skill-cap date. Pins and readings persist in `plugins/ExcelRewardGuard/seal-step-state.txt`.
4. **Failure posture: unknown means unshaped.** Seal count unreadable (GuildGate down), par not yet pinned (fewer than 3 players observed), or a player's power unobserved → that channel pays no step, never a guessed bonus. A farmed kill at farm rate 0 stays blocked (0 × step = 0).
5. **Invisible, as required.** No announcements, labels, or player-facing text — the plugin contains no player-messaging call at all. The only records are console startup/state lines (the effective parameters print beside the farm rates, per mob-scaling SPEC §6) and the audit log, whose step-only lines carry origin `seal_step` and the combined multiplier actually applied.
6. **Unchanged:** everything 1.3 did — classification (birth provenance + fall-softening), PDC marking, the suppression window, per-path farm rates, the audit log, EliteMobs verdict logging. Magic SP is never stepped (the audit's verdict), EliteMobs currency stays excluded (Mike's 0.25× is final), and **vanilla XP is never touched**.

## What 1.3 changes (Mike's decisions, Oct 18, 2026)

1. **The farm rate is 33%, set per path.** The single shared `farm-reward-percent` (live 55 under 1.2) is retired. Two independent decimal knobs replace it: `jobs-farm-rate: 0.33` and `mcmmo-farm-rate: 0.33`. A legacy `farm-reward-percent` key is ignored, with a startup warning saying so. Rates are fractions in [0, 1]: 0 blocks that path's farm rewards (the 1.0 behavior), 1 is a no-op pass-through.
2. **The Jobs XP double-scale bug is fixed structurally.** A log audit of live data (Oct 18) proved farmed Jobs XP paid 30.25% instead of the intended 55%: 1.2 scaled XP in both Jobs handlers, and Jobs fires both per kill, chaining the amounts. In 1.3 each Jobs channel is scaled in exactly one handler: money and points on `JobsPrePaymentEvent`, XP only on `JobsExpGainEvent`. A regression suite (`JobsSingleScalingTests`) simulates the two-event pipeline, pins the single-scaling result, and reproduces the audited 0.3025 figure under the old composition so the model is demonstrably the real pipeline.
3. **The mcMMO adjuster is explicit.** In 1.2, mcMMO scaling rode the shared percent inside the suppression-window veto — functional, but inseparable from the Jobs rate and impossible to audit (mcMMO keeps no per-event XP record). In 1.3 the mcMMO scale is driven by its own named knob (`mcmmo-farm-rate`) in `McMmoVeto`, covered by tests, and every adjustment can be recorded (next point).
4. **Audit log (new, default OFF).** `audit-log: true` appends one line per adjusted channel to `plugins/ExcelRewardGuard/audit.log`: timestamp, player, origin class, channel (`jobs-money` / `jobs-points` / `jobs-xp` / `mcmmo-xp`), base amount, rate, paid amount. The mcMMO origin is the farmed death that planted the matched window — the same approximation the window mechanism itself makes.
5. **Unchanged:** classification (birth provenance + fall-softening), PDC marking, the suppression window, EliteMobs verdict logging (that code is byte-identical to 1.2, as are `FallDamageTracker`, `ProvenanceStore`, `XpSuppression`, `FarmVerdict`), the party/weekend stack behaviour (those multipliers belong to Jobs/ExcelTogether; the guard applies only its own single rate), and the standing rule that **vanilla Minecraft XP is never touched**.

## What it does (the guard as a whole)

Mobs born from a **spawner block**, a **spawn egg**, or through a **Nether portal** are marked in their own persistent data at birth. The mark is sticky: it survives chunk save/load and transformations/splits that Bukkit surfaces through EntityTransformEvent. Since 1.2, a kill whose target's **cumulative fall damage** reaches `farm-fall-damage-percent` of its max health (default 50) also counts as farmed (the sky-farm signature; cumulative and never forgiven by healing; entries cleaned on death/despawn/chunk unload/disable; players untracked). When a farmed mob is killed:

- **Jobs pays the reduced share**: money and points are scaled on the pre-payment event, XP on the XP-gain event — each exactly once (the 1.3 fix). Nothing is cancelled at any rate above 0.
- **mcMMO pays the reduced share of XP**: neither the killer's combat XP nor party share escapes; the reduction lands before the weekend (1.20x) and together (1.25x) multipliers can grow the amount, so a reduced gain stays reduced after multipliers.
- **Vanilla XP is never touched.** Farmed mobs still drop their normal XP orbs and loot. The guard cancels no damage or death event (except, at rate 0, the reward events of that path), removes no entity, and edits no balance or skill directly.

Rate endpoints are deliberate per path: **0** reproduces ExcelRewardGuard 1.0 exactly for that path, **1** turns that path's reduction off entirely (exact pass-through, no rounding). Out-of-range or unparseable rate values are clamped/defaulted to 0.33 with a startup warning, and the startup log always prints the effective rates.

## Dependencies (all optional, disclosed per Mike's rule)

| Plugin | What it provides | Without it |
|---|---|---|
| Jobs 5.2.6.3 | `JobsPrePaymentEvent` and `JobsExpGainEvent`, whose money/points/XP amounts are scaled for farmed kills | Jobs enforcement inactive; marking, fall tracking and the API still work |
| mcMMO 2.3.003-WRV | `McMMOPlayerXpGainEvent` / `McMMOPlayerPreXpGainEvent`, scaled (or, at rate 0, zeroed/cancelled) inside a farmed-kill window | mcMMO enforcement inactive; marking, fall tracking and the API still work |
| EliteMobs 10.9.8 | `EliteMobDeathEvent`, used for verdict logging only | No elite logging; nothing else changes |
| Vault / an economy plugin | Not used by the guard itself. Jobs needs one to pay out at all | n/a |

Every API signature above was verified with javap against the exact jars the server runs, and `LiveApiSignatureTests` re-checks them on every build (1.3 adds the `getPlayer` accessors the audit log uses).

**EliteMobs limitation, stated plainly:** EliteMobs 10.9.8 exposes no cancellable reward event (its death event is informational), and it pays coin showers through its own internal handling. The guard therefore **cannot reduce EliteMobs rewards**; it logs the deaths of marked elites so the gap is visible.

## How the mcMMO reduction works (and its one tradeoff)

mcMMO's XP events carry the player, skill and amount, but not the killed entity, so the guard cannot ask "which mob was this XP for?". Instead, when a farmed mob dies, the guard plants a short window (default: the death tick + 2 ticks, 40-block radius). mcMMO grants kill XP synchronously while processing that same death, so PVE and SHARED_PVE gains landing inside the window, in the same world, for the killer or anyone inside the radius, are scaled at LOWEST event priority — exactly once, on the XP gain event (the installed mcMMO build's own source shows the pre-gain amount feeding into the gain event, so scaling both would double-count). The tradeoff: if a second player lands an unrelated legitimate kill in the same 2-tick window within 40 blocks of a farm death, that gain is scaled too. On a small family server this is vanishingly rare, and the policy errs toward the farm side on purpose; every reduction is counted, `debug-logging: true` prints each one, and `audit-log: true` records each one to file.

Jobs needs no such window: its events name the entity, so a Jobs reduction can only ever hit the exact farmed kill. One Jobs caveat: if Jobs is configured to batch payments and no longer carries the killed entity when it pays, that payment cannot be reduced; the reduction covers every payment Jobs still attributes to the entity, which is how 5.2.6.3 fires its pre-payment event.

## Provenance notes

- Marking starts when the plugin is installed. Mobs already alive in the world at install time carry no mark and are unclassified by origin. Fall tracking likewise starts at install.
- The mark uses only this plugin's own namespaced keys (`excelrewardguard:origin_v1`, `denied_v1`, `reason_v1`). Foreign plugins' tags are never read or mutated. Fall records live only in memory (never persisted), keyed by entity UUID.
- Fail-closed: if provenance storage ever throws, classification reports unavailable, which the API contract defines as DENY, and the failure is logged once at SEVERE. Rewards fail safe (reduced/blocked), never silently open.

## Consumer API (unchanged from the candidate)

`ExcelRewardGuard.farmApiVersion()` returns `1`. `farmDecision(LivingEntity)` returns `[decision, reason, "1"]` where decision is `DENY` or `UNKNOWN` — this remains the **origin** verdict. 1.3 adds `jobsFarmRate()` and `mcMmoFarmRate()` accessors; the legacy `farmRewardPercent()` now returns the Jobs rate as a whole percent for compatibility.

## Configuration

`config.yml`: `jobs-farm-rate` (0.33) and `mcmmo-farm-rate` (0.33) — the farm share per path; `farm-fall-damage-percent` (50); `jobs-veto`, `mcmmo-veto`, `elitemobs-verdict-logging` (all default true); `party-share-radius-blocks` (40); `suppression-window-ticks` (2); `audit-log` (false); `debug-logging` (false). The retired `farm-reward-percent` is ignored with a warning. Rates parse defensively (clamped to [0, 1], invalid values defaulted to 0.33 with a startup warning) and are re-read on enable.

## Tests

Eight suites run on every build (`bash build.sh`, compiling against the exact Paper 26.2-123 API and the live Jobs/mcMMO/EliteMobs jars) — **372 assertions**:

- `ProvenanceTests`: 85 (unchanged from 1.1) — origin policy, stickiness, fail-closed, API shape.
- `XpSuppressionTests`: 22 (unchanged) — window mechanics.
- `RewardScaleTests`: 51 (unchanged) — the retained percent math and parser (fall threshold).
- `FallDamageTrackerTests`: 81 (unchanged) — the sky-farm signature and cleanup rules.
- `FarmRateTests`: 58 (new) — rate scaling at 0.33, rounding, 0/1 endpoints, rate parsing (missing → 0.33, clamps, garbage, percent-style trap), knob independence, log labels.
- `JobsSingleScalingTests`: 27 (new) — the double-fire regression: the 1.3 pipeline pays base × rate once per channel; the 1.2 composition reproduces the audited 0.3025; natural/0/1 exact.
- `AuditLogTests`: 16 (new) — exact line format, token safety, disabled writes nothing, enabled appends across reloads.
- `LiveApiSignatureTests`: 32 (29 + 3 new `getPlayer` pins) — every third-party method/cancellation property the enforcement and audit code rely on, against the installed jars.

## Still unverified (honest list)

- Live-server behavior: no install has happened. The real in-game proof after install: a spawner kill and a sky-farm kill paying 33% Jobs money/XP and 33% mcMMO XP with full vanilla XP — now directly readable from `audit.log` with `audit-log: true`, plus the three human checks the Oct 18 audit narrowed to (mcMMO before/after skill read, vanilla XP comparison, party share).
- Jobs deferred/batch payment attribution on the live Jobs config (carried caveat).
- EliteMobs reduction: impossible through its 10.9.8 API; unchanged.
- Performance on the 3 GB live server is unmeasured; the guard's footprint is unchanged from 1.2 (audit writes are one small line per adjusted channel, only when enabled).
