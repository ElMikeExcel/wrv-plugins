#!/usr/bin/env bash
# ExcelItemInsight — plain-JVM tests over the Bukkit-free core.
set -euo pipefail
cd "$(dirname "$0")"
JAVA_HOME="${JAVA_HOME:-$HOME/workspace/.jdk25}"
JAVAC="$JAVA_HOME/bin/javac"
JAVA="$JAVA_HOME/bin/java"
[ -x "$JAVAC" ] || { echo "JDK not found at $JAVA_HOME" >&2; exit 1; }
rm -rf build/test-classes
mkdir -p build/test-classes
find src/com/winkreyes/exceliteminsight/core -name '*.java' > build/test-sources.txt
find test -name '*.java' >> build/test-sources.txt
"$JAVAC" --release 21 -proc:none -nowarn -d build/test-classes @build/test-sources.txt
"$JAVA" -cp build/test-classes TestMain pinned-enchantments-26.2.txt

# ExcelItemInsight — an Excel plugin by WinkReyesValley. (Excel signature — MikeExcel)
