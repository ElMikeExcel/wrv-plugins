package com.winkreyes.exceliteminsight;

import com.winkreyes.exceliteminsight.core.EnchantDictionary;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

/**
 * ExcelItemInsight — every enchantment on an item, explained in the
 * item's lore at its exact level, in plain words with real numbers.
 * Born from Jester's question (Oct 20, 2026): his Sharpness V diamond
 * sword "only does 7 attack damage" per the vanilla tooltip, because
 * the tooltip shows base damage only. The sword really hits for 10.
 * Now the item itself says so.
 */
public final class ExcelItemInsight extends JavaPlugin {

    private InsightService service;
    private int[] coverage = new int[]{0, 0};

    @Override
    public void onEnable() {
        saveDefaultConfig();
        service = new InsightService(this);
        runRegistrySelfCheck();
        getServer().getPluginManager().registerEvents(new InsightListener(this, service), this);
        PluginCommand cmd = getCommand("iteminsight");
        if (cmd != null) {
            InsightCommand executor = new InsightCommand(this);
            cmd.setExecutor(executor);
            cmd.setTabCompleter(executor);
        }
        getLogger().info("ExcelItemInsight " + getPluginMeta().getVersion()
                + " enabled — dictionary: " + EnchantDictionary.size()
                + " enchantments, registry coverage " + coverageText() + ".");
    }

    /** Iterate the live enchantment registry and prove the dictionary
     *  explains every vanilla enchantment in it. Anything missing is a
     *  SEVERE: a silent gap is the one failure this plugin must never
     *  have quietly. */
    private void runRegistrySelfCheck() {
        List<String> missing = new ArrayList<>();
        coverage = service.registryCoverage(missing);
        for (String key : missing) {
            getLogger().severe("ExcelItemInsight has NO explanation for registry enchantment "
                    + key + " — it will be left unexplained until the dictionary is updated.");
        }
    }

    public InsightService service() {
        return service;
    }

    public String coverageText() {
        return coverage[0] + "/" + coverage[1];
    }

    public void reloadInsight() {
        reloadConfig();
        service.reload();
        runRegistrySelfCheck();
    }
}

// ExcelItemInsight — an Excel plugin by WinkReyesValley. (Excel signature — MikeExcel)
