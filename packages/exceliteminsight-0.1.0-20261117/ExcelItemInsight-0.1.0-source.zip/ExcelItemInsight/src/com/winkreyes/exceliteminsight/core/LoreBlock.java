package com.winkreyes.exceliteminsight.core;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * The lore block itself, as pure string-list logic (legacy section-sign
 * lines) so it can be unit-tested on a plain JVM. The Bukkit glue
 * converts between these strings and Adventure components, always keeping
 * foreign lore lines as their original component objects — the strings
 * here are only ever used to find, compare and rebuild OUR block.
 *
 * Ownership rule: the plugin owns exactly one contiguous block — the
 * configured header line, an optional Total-hit line, one line per
 * enchantment sorted by display name, and a small footer signature —
 * and the block always sits at the END of the lore. Refresh strips any
 * previous block (found via the header, bounded by the footer) and
 * appends the freshly computed one, so blocks never stack and stale
 * numbers never survive an enchant change.
 */
public final class LoreBlock {

    public static final String DEFAULT_HEADER = "§8— What the enchantments do —";
    public static final String FOOTER = "§8§oExcelItemInsight";
    private static final String LINE_COLOR = "§7";
    private static final String TOTAL_COLOR = "§f";

    private LoreBlock() {
    }

    /** Index range [start, end) of our block inside {@code lines}, or
     *  null when there is none. Primary match: the exact header line,
     *  bounded by the footer (a header with no footer is treated as a
     *  block running to the end of the lore, which is where our blocks
     *  always live). Fallback: if the configured header text changed
     *  since a block was written, the block is found by its footer —
     *  walk up from the footer past our own colored lines and take one
     *  more line as the old header, so a header change can never strand
     *  a stale block on an item. */
    public static int[] findBlock(List<String> lines, String header) {
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).equals(header)) {
                int end = lines.size();
                for (int j = i + 1; j < lines.size(); j++) {
                    if (lines.get(j).equals(FOOTER)) {
                        end = j + 1;
                        break;
                    }
                }
                return new int[]{i, end};
            }
        }
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).equals(FOOTER)) {
                int start = i;
                while (start > 0 && isOurContentLine(lines.get(start - 1))) {
                    start--;
                }
                if (start > 0) {
                    start--; // the old header line itself, whatever it said
                }
                return new int[]{start, i + 1};
            }
        }
        return null;
    }

    /** Our content lines: gray (§7) explanation lines and the white
     *  (§f) Total-hit line. Used only by the footer-anchored fallback. */
    private static boolean isOurContentLine(String line) {
        return line.startsWith(LINE_COLOR) || line.startsWith(TOTAL_COLOR);
    }

    public static boolean hasBlock(List<String> lines, String header) {
        return findBlock(lines, header) != null;
    }

    /** The block lines currently on the item (empty list when none). */
    public static List<String> extractBlock(List<String> lines, String header) {
        int[] range = findBlock(lines, header);
        if (range == null) {
            return List.of();
        }
        return List.copyOf(lines.subList(range[0], range[1]));
    }

    /** The lines with any existing block removed; foreign lore is kept
     *  exactly as-is, in order. */
    public static List<String> stripBlock(List<String> lines, String header) {
        int[] range = findBlock(lines, header);
        if (range == null) {
            return new ArrayList<>(lines);
        }
        List<String> out = new ArrayList<>(lines.size());
        out.addAll(lines.subList(0, range[0]));
        out.addAll(lines.subList(range[1], lines.size()));
        return out;
    }

    /**
     * Build the block for a set of enchantments.
     *
     * @param enchants       namespaced-key (path only, e.g. "sharpness")
     *                       to level; unknown keys are skipped — other
     *                       plugins' custom enchantments are not ours to
     *                       explain
     * @param header         the rendered header line (with color codes)
     * @param meleeBaseDamage the item's base melee attack damage, or null
     *                       when the item is not a priced melee weapon;
     *                       only then, and only with Sharpness present,
     *                       does the Total-hit line appear
     */
    public static List<String> buildBlock(Map<String, Integer> enchants,
                                          String header, Double meleeBaseDamage) {
        List<Map.Entry<String, Integer>> known = new ArrayList<>();
        for (Map.Entry<String, Integer> e : enchants.entrySet()) {
            if (EnchantDictionary.has(e.getKey())) {
                known.add(e);
            }
        }
        if (known.isEmpty()) {
            return List.of();
        }
        known.sort(Comparator.comparing(e -> EnchantDictionary.nameOf(e.getKey())));

        List<String> block = new ArrayList<>();
        block.add(header);
        Integer sharp = enchants.get("sharpness");
        if (sharp != null && meleeBaseDamage != null) {
            double bonus = 0.5 * sharp + 0.5;
            block.add(TOTAL_COLOR + "Total hit: " + EnchantDictionary.num(meleeBaseDamage + bonus)
                    + " (base " + EnchantDictionary.num(meleeBaseDamage) + " + "
                    + EnchantDictionary.num(bonus) + " from Sharpness)");
        }
        for (Map.Entry<String, Integer> e : known) {
            block.add(LINE_COLOR + EnchantDictionary.explain(e.getKey(), e.getValue()));
        }
        block.add(FOOTER);
        return block;
    }

    /**
     * The full refresh: foreign lore preserved line-for-line, any old
     * block removed, the fresh block appended. An empty enchantment set
     * yields the lore with our block (if any) stripped — that is the
     * grindstone path.
     */
    public static List<String> apply(List<String> existingLore,
                                     Map<String, Integer> enchants,
                                     String header, Double meleeBaseDamage) {
        List<String> out = stripBlock(existingLore, header);
        List<String> block = buildBlock(enchants, header, meleeBaseDamage);
        out.addAll(block);
        return out;
    }
}

// ExcelItemInsight — an Excel plugin by WinkReyesValley. (Excel signature — MikeExcel)
