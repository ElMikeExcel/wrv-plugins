package com.winkreyes.exceliteminsight;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.List;

/** /iteminsight — status for anyone, reload for admins. */
public final class InsightCommand implements CommandExecutor, TabCompleter {

    private static final LegacyComponentSerializer LEGACY =
            LegacyComponentSerializer.legacyAmpersand();

    private final ExcelItemInsight plugin;

    public InsightCommand(ExcelItemInsight plugin) {
        this.plugin = plugin;
    }

    private void send(CommandSender sender, String legacyText) {
        sender.sendMessage((Component) LEGACY.deserialize(legacyText));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("status")) {
            send(sender, "&8[&fExcelItemInsight&8] &7v" + plugin.getPluginMeta().getVersion()
                    + " — enabled: " + plugin.service().isEnabled()
                    + " — dictionary covers " + plugin.coverageText() + " enchantments.");
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("exceliteminsight.admin")) {
                send(sender, "&cYou need the exceliteminsight.admin permission to reload.");
                return true;
            }
            plugin.reloadInsight();
            send(sender, "&8[&fExcelItemInsight&8] &7Config reloaded. Enabled: "
                    + plugin.service().isEnabled() + ".");
            return true;
        }
        send(sender, "&7Usage: /iteminsight [status|reload]");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("status", "reload")) {
                if (s.startsWith(args[0].toLowerCase())) {
                    out.add(s);
                }
            }
        }
        return out;
    }
}

// ExcelItemInsight — an Excel plugin by WinkReyesValley. (Excel signature — MikeExcel)
