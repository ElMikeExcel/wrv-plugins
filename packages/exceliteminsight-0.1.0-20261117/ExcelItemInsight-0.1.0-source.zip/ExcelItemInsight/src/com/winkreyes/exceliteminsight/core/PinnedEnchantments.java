package com.winkreyes.exceliteminsight.core;

import java.util.List;

/**
 * The enchantment keys of the pinned vanilla registry (Minecraft 26.2,
 * Paper build 123). Generated 2026-10-20 from the bundled vanilla data
 * in the pinned server jar (data/minecraft/enchantment/*.json, 43 files,
 * extracted to ~/workspace/iteminsight-research/pinned-enchantments-26.2/).
 * The completeness test compares the dictionary against BOTH this list
 * and pinned-enchantments-26.2.txt, which came from the same extraction.
 */
public final class PinnedEnchantments {

    public static final List<String> KEYS = List.of(
        "aqua_affinity",
        "bane_of_arthropods",
        "binding_curse",
        "blast_protection",
        "breach",
        "channeling",
        "density",
        "depth_strider",
        "efficiency",
        "feather_falling",
        "fire_aspect",
        "fire_protection",
        "flame",
        "fortune",
        "frost_walker",
        "impaling",
        "infinity",
        "knockback",
        "looting",
        "loyalty",
        "luck_of_the_sea",
        "lunge",
        "lure",
        "mending",
        "multishot",
        "piercing",
        "power",
        "projectile_protection",
        "protection",
        "punch",
        "quick_charge",
        "respiration",
        "riptide",
        "sharpness",
        "silk_touch",
        "smite",
        "soul_speed",
        "sweeping_edge",
        "swift_sneak",
        "thorns",
        "unbreaking",
        "vanishing_curse",
        "wind_burst"
    );

    private PinnedEnchantments() {
    }
}

// ExcelItemInsight — an Excel plugin by WinkReyesValley. (Excel signature — MikeExcel)
