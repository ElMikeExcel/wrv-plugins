package com.winkreyes.exceliteminsight;

import com.winkreyes.exceliteminsight.core.EnchantDictionary;
import com.winkreyes.exceliteminsight.core.LoreBlock;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The Bukkit side of the refresh: reads an item's enchantments (stored
 * ones for enchanted books), computes the block with the pure core, and
 * writes it back as Adventure components — foreign lore lines keep their
 * original component objects, so custom and signature loot lore is
 * preserved exactly. Our lines get italic switched OFF (vanilla custom
 * lore is italic purple by default; the explainer should read plain).
 *
 * Base attack damage for the Total-hit line comes from the item type's
 * own default attribute modifiers (the game's data, not a table in our
 * code), with a small verified fallback table for the classic weapons in
 * case an API ever returns nothing. Only the unconditional Sharpness
 * bonus folds into the total; Smite/Bane stay conditional in their own
 * lines, by design.
 */
public final class InsightService {

    private static final LegacyComponentSerializer LEGACY =
            LegacyComponentSerializer.legacySection();

    /** Verified vanilla base melee damage (Minecraft Wiki weapon tables,
     *  cross-checked against the Sharpness damage tables 2026-10-20).
     *  Fallback only — the API value wins whenever it exists. Keyed by
     *  material NAME so newer materials (the copper tier) resolve even
     *  when an older compile-time API lacks their enum constants. */
    private static final Map<String, Double> BASE_DAMAGE_FALLBACK = new HashMap<>();

    static {
        BASE_DAMAGE_FALLBACK.put("WOODEN_SWORD", 4.0);
        BASE_DAMAGE_FALLBACK.put("GOLDEN_SWORD", 4.0);
        BASE_DAMAGE_FALLBACK.put("STONE_SWORD", 5.0);
        BASE_DAMAGE_FALLBACK.put("COPPER_SWORD", 5.0);
        BASE_DAMAGE_FALLBACK.put("IRON_SWORD", 6.0);
        BASE_DAMAGE_FALLBACK.put("DIAMOND_SWORD", 7.0);
        BASE_DAMAGE_FALLBACK.put("NETHERITE_SWORD", 8.0);
        BASE_DAMAGE_FALLBACK.put("WOODEN_AXE", 7.0);
        BASE_DAMAGE_FALLBACK.put("GOLDEN_AXE", 7.0);
        BASE_DAMAGE_FALLBACK.put("STONE_AXE", 9.0);
        BASE_DAMAGE_FALLBACK.put("COPPER_AXE", 9.0);
        BASE_DAMAGE_FALLBACK.put("IRON_AXE", 9.0);
        BASE_DAMAGE_FALLBACK.put("DIAMOND_AXE", 9.0);
        BASE_DAMAGE_FALLBACK.put("NETHERITE_AXE", 10.0);
        BASE_DAMAGE_FALLBACK.put("TRIDENT", 9.0);
        BASE_DAMAGE_FALLBACK.put("MACE", 6.0);
    }

    private final ExcelItemInsight plugin;
    private final NamespacedKey markerKey;
    private boolean enabled;
    private String header;

    public InsightService(ExcelItemInsight plugin) {
        this.plugin = plugin;
        this.markerKey = new NamespacedKey(plugin, "managed");
        reload();
    }

    public void reload() {
        this.enabled = plugin.getConfig().getBoolean("enabled", true);
        String raw = plugin.getConfig().getString("header", "&8— What the enchantments do —");
        this.header = ChatColor.translateAlternateColorCodes('&', raw);
    }

    public boolean isEnabled() {
        return enabled;
    }

    public String header() {
        return header;
    }

    /** Registry self-check: how many of the live registry's VANILLA
     *  enchantments the dictionary can explain. Returns {covered,
     *  total} over minecraft-namespace enchantments only (other
     *  plugins' custom enchantments are not ours to explain), plus the
     *  missing vanilla keys for the SEVERE log line. */
    public int[] registryCoverage(List<String> missingOut) {
        int total = 0;
        int covered = 0;
        for (Enchantment ench : Registry.ENCHANTMENT) {
            if (!"minecraft".equals(ench.getKey().getNamespace())) {
                continue;
            }
            total++;
            String key = ench.getKey().getKey();
            if (EnchantDictionary.has(key)) {
                covered++;
            } else if (missingOut != null) {
                missingOut.add(ench.getKey().toString());
            }
        }
        return new int[]{covered, total};
    }

    /**
     * Refresh one item's block in place. Returns true when the item was
     * changed. Unenchanted, unmarked items are never touched.
     */
    public boolean refresh(ItemStack item) {
        if (!enabled || item == null || item.getType().isAir()) {
            return false;
        }
        Map<String, Integer> enchants = enchantmentsOf(item);
        boolean marked = false;
        List<String> oldStrings = List.of();
        ItemMeta meta = null;
        if (item.hasItemMeta()) {
            meta = item.getItemMeta();
            if (meta != null) {
                marked = meta.getPersistentDataContainer().has(markerKey, PersistentDataType.BYTE);
                if (meta.hasLore() && meta.lore() != null) {
                    oldStrings = meta.lore().stream().map(LEGACY::serialize).toList();
                }
            }
        }
        boolean hasOurBlock = LoreBlock.hasBlock(oldStrings, header);
        if (enchants.isEmpty() && !marked && !hasOurBlock) {
            return false; // plain item, not ours — never touched
        }
        Double base = enchants.containsKey("sharpness") ? baseDamage(item.getType()) : null;
        List<String> block = LoreBlock.buildBlock(enchants, header, base);
        if (block.equals(LoreBlock.extractBlock(oldStrings, header)) && (marked || block.isEmpty())) {
            return false; // already exactly right — skip (no churn)
        }
        if (meta == null) {
            meta = item.getItemMeta();
            if (meta == null) {
                return false;
            }
        }
        // Rebuild the component list: foreign lines keep their original
        // component objects; only our block range is dropped and rebuilt.
        List<Component> oldComps = meta.lore() == null ? List.of() : meta.lore();
        int[] range = LoreBlock.findBlock(oldStrings, header);
        List<Component> out = new ArrayList<>();
        for (int i = 0; i < oldComps.size(); i++) {
            if (range != null && i >= range[0] && i < range[1]) {
                continue;
            }
            out.add(oldComps.get(i));
        }
        for (String line : block) {
            out.add(LEGACY.deserialize(line).decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(out.isEmpty() ? null : out);
        if (block.isEmpty()) {
            meta.getPersistentDataContainer().remove(markerKey);
        } else {
            meta.getPersistentDataContainer().set(markerKey, PersistentDataType.BYTE, (byte) 1);
        }
        item.setItemMeta(meta);
        return true;
    }

    /** Enchantments on the item — stored ones for enchanted books.
     *  Vanilla (minecraft-namespaced) keys only; other plugins' custom
     *  enchantments are not ours to explain. */
    private Map<String, Integer> enchantmentsOf(ItemStack item) {
        Map<Enchantment, Integer> raw;
        ItemMeta meta = item.hasItemMeta() ? item.getItemMeta() : null;
        if (meta instanceof EnchantmentStorageMeta storage) {
            raw = storage.getStoredEnchants();
        } else {
            raw = item.getEnchantments();
        }
        Map<String, Integer> out = new HashMap<>();
        for (Map.Entry<Enchantment, Integer> e : raw.entrySet()) {
            NamespacedKey key = e.getKey().getKey();
            if ("minecraft".equals(key.getNamespace())) {
                out.put(key.getKey(), e.getValue());
            }
        }
        return out;
    }

    /** Base melee attack damage for the Total-hit line, or null when the
     *  item is not a melee weapon we can price. The API's default
     *  attribute modifiers carry the weapon's bonus over the base 1;
     *  the vanilla convention is total = 1 + sum of ADD_NUMBER damage
     *  modifiers for the main hand (the rig prints the raw values so
     *  this stays verifiable). */
    private Double baseDamage(Material type) {
        String name = type.name();
        boolean melee = name.endsWith("_SWORD") || name.endsWith("_AXE")
                || name.endsWith("_SPEAR") || type == Material.TRIDENT
                || type == Material.MACE;
        if (!melee) {
            return null;
        }
        try {
            double sum = 0.0;
            boolean any = false;
            for (AttributeModifier mod : type.getDefaultAttributeModifiers(EquipmentSlot.HAND)
                    .get(Attribute.ATTACK_DAMAGE)) {
                if (mod.getOperation() == AttributeModifier.Operation.ADD_NUMBER) {
                    sum += mod.getAmount();
                    any = true;
                }
            }
            if (any) {
                return 1.0 + sum;
            }
        } catch (RuntimeException ignored) {
            // fall through to the verified table
        }
        return BASE_DAMAGE_FALLBACK.get(name);
    }
}

// ExcelItemInsight — an Excel plugin by WinkReyesValley. (Excel signature — MikeExcel)
