package com.winkreyes.exceliteminsight;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareGrindstoneEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.inventory.PrepareSmithingEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.world.LootGenerateEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

/**
 * Refresh triggers. The direct ones (enchanting table, anvil,
 * grindstone, smithing, crafting result, generated loot) fire at the
 * moment the item changes; the catch-up scans (join, inventory
 * open/close/click, pickup, held-item swap) make sure anything created
 * by any other path — commands, other plugins, old items from before
 * the install — gets its block the first time a player actually meets
 * it. Refresh itself is cheap and skips items whose block already
 * matches, so the scans cost nothing on settled inventories.
 */
public final class InsightListener implements Listener {

    private final ExcelItemInsight plugin;
    private final InsightService service;

    public InsightListener(ExcelItemInsight plugin, InsightService service) {
        this.plugin = plugin;
        this.service = service;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onEnchant(EnchantItemEvent event) {
        ItemStack item = event.getItem();
        // Enchants land as the event completes; refresh next tick.
        Bukkit.getScheduler().runTask(plugin, () -> service.refresh(item));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPrepareAnvil(PrepareAnvilEvent event) {
        refreshResult(event.getResult());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPrepareGrindstone(PrepareGrindstoneEvent event) {
        refreshResult(event.getResult());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPrepareSmithing(PrepareSmithingEvent event) {
        refreshResult(event.getResult());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        refreshResult(event.getInventory().getResult());
    }

    private void refreshResult(ItemStack result) {
        if (result != null) {
            service.refresh(result);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onLoot(LootGenerateEvent event) {
        for (ItemStack item : event.getLoot()) {
            service.refresh(item);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        scan(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onOpen(InventoryOpenEvent event) {
        if (event.getPlayer() instanceof Player player) {
            scan(event.getInventory());
            scan(player);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onClose(InventoryCloseEvent event) {
        if (event.getPlayer() instanceof Player player) {
            scan(player);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        ItemStack current = event.getCurrentItem();
        ItemStack cursor = event.getCursor();
        Bukkit.getScheduler().runTask(plugin, () -> {
            service.refresh(current);
            service.refresh(cursor);
        });
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (event.getEntity() instanceof Player) {
            service.refresh(event.getItem().getItemStack());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onHeld(PlayerItemHeldEvent event) {
        service.refresh(event.getPlayer().getInventory().getItem(event.getNewSlot()));
    }

    private void scan(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            service.refresh(item);
        }
        for (ItemStack item : player.getEnderChest().getContents()) {
            service.refresh(item);
        }
    }

    private void scan(Inventory inventory) {
        for (ItemStack item : inventory.getContents()) {
            service.refresh(item);
        }
    }
}

// ExcelItemInsight — an Excel plugin by WinkReyesValley. (Excel signature — MikeExcel)
