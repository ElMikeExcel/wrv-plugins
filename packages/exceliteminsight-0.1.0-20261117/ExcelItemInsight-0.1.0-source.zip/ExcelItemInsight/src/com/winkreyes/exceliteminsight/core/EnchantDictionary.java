package com.winkreyes.exceliteminsight.core;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.IntFunction;

/**
 * One plain-words explanation per vanilla enchantment, computed from the
 * enchantment's own level by formula wherever the game is formulaic, so
 * over-level books (Sharpness X and friends) read right too.
 *
 * Every number was verified on 2026-10-20 against the Minecraft Wiki
 * enchantment pages AND the pinned data of the server's own jar
 * (Paper 26.2 build 123; data/minecraft/enchantment/*.json — the pinned
 * definitions are the ground truth where the two disagreed). The full
 * per-number citation list lives in BUILD.md. Anything that has no clean
 * verifiable number ships as plain words, never a guessed figure.
 *
 * This class is pure Java (no Bukkit) so the test suite can exercise it
 * on a plain JVM.
 */
public final class EnchantDictionary {

    /** One dictionary entry: the display name (sort key + line prefix) and
     *  the line builder for a level. */
    public record Entry(String name, IntFunction<String> line) {
    }

    private static final Map<String, Entry> ENTRIES = new LinkedHashMap<>();

    private static void put(String key, String name, IntFunction<String> line) {
        ENTRIES.put(key, new Entry(name, line));
    }

    /** Plain number format: integers without a decimal point, everything
     *  else trimmed to at most two decimals (2.5, 0.75, 2.2, 11.3). */
    static String num(double v) {
        return new BigDecimal(String.format(java.util.Locale.ROOT, "%.2f", v))
                .stripTrailingZeros().toPlainString();
    }

    static {
        put("aqua_affinity", "Aqua Affinity", lvl ->
                "Aqua Affinity: you mine at full speed while underwater.");
        put("bane_of_arthropods", "Bane of Arthropods", lvl ->
                "Bane of Arthropods " + lvl + ": +" + num(2.5 * lvl)
                        + " damage against spiders, bees, silverfish and other bugs"
                        + " — and hits slow them down.");
        put("binding_curse", "Curse of Binding", lvl ->
                "Curse of Binding: once you put this on, you cannot take it off"
                        + " until it breaks or you die.");
        put("blast_protection", "Blast Protection", lvl ->
                "Blast Protection " + lvl + ": explosion damage hurts " + (8 * lvl)
                        + "% less, and explosions knock you back less.");
        put("breach", "Breach", lvl ->
                "Breach " + lvl + ": your hits treat the target's armor as "
                        + (15 * lvl) + "% weaker.");
        put("channeling", "Channeling", lvl ->
                "Channeling: during a thunderstorm, a thrown trident calls down"
                        + " lightning on whatever it hits (it needs open sky above).");
        put("density", "Density", lvl ->
                "Density " + lvl + ": a falling smash hit gains +" + num(0.5 * lvl)
                        + " damage for every block you fell.");
        put("depth_strider", "Depth Strider", lvl -> lvl >= 3
                ? "Depth Strider " + lvl + ": you swim through water at full walking speed."
                : "Depth Strider " + lvl + ": water slows your swimming about "
                        + Math.round(100.0 * lvl / 3.0) + "% less.");
        put("efficiency", "Efficiency", lvl ->
                "Efficiency " + lvl + ": +" + (lvl * lvl + 1)
                        + " mining speed — blocks break much faster.");
        put("feather_falling", "Feather Falling", lvl ->
                "Feather Falling " + lvl + ": falls hurt " + (12 * lvl) + "% less.");
        put("fire_aspect", "Fire Aspect", lvl ->
                "Fire Aspect " + lvl + ": everything you hit burns for " + (4 * lvl)
                        + " seconds.");
        put("fire_protection", "Fire Protection", lvl ->
                "Fire Protection " + lvl + ": fire and lava hurt " + (8 * lvl)
                        + "% less, and you stop burning " + (15 * lvl) + "% sooner.");
        put("flame", "Flame", lvl ->
                "Flame: your arrows set whatever they hit on fire for 5 seconds.");
        put("fortune", "Fortune", lvl -> {
            double avg = (1.0 + (lvl + 1.0) * (lvl + 2.0) / 2.0) / (lvl + 2.0);
            return "Fortune " + lvl + ": one ore block can drop up to " + (lvl + 1)
                    + " times as much (about " + num(avg) + " times on average).";
        });
        put("frost_walker", "Frost Walker", lvl ->
                "Frost Walker " + lvl + ": water freezes under your feet in a circle"
                        + " reaching " + (lvl + 2) + " blocks out from you, and magma"
                        + " blocks and campfires cannot hurt you.");
        put("impaling", "Impaling", lvl ->
                "Impaling " + lvl + ": +" + num(2.5 * lvl)
                        + " damage against water creatures — fish, squid, guardians,"
                        + " turtles and axolotls.");
        put("infinity", "Infinity", lvl ->
                "Infinity: your bow never uses up plain arrows — you just need one"
                        + " arrow in your bag. (Special arrows are still used up.)");
        put("knockback", "Knockback", lvl ->
                "Knockback " + lvl + ": your hits knock enemies much farther back.");
        put("looting", "Looting", lvl ->
                "Looting " + lvl + ": mobs can drop up to " + lvl
                        + (lvl == 1 ? " extra item" : " extra items")
                        + ", and rare and gear drops are +" + lvl
                        + "% more likely.");
        put("loyalty", "Loyalty", lvl ->
                "Loyalty " + lvl + ": a thrown trident flies back to you — higher"
                        + " levels come back faster.");
        put("luck_of_the_sea", "Luck of the Sea", lvl ->
                "Luck of the Sea " + lvl + ": fishing finds treasure more often"
                        + " (about " + num(5.0 + 2.1 * lvl) + "% of catches) and junk"
                        + " less often.");
        put("lunge", "Lunge", lvl ->
                "Lunge " + lvl + ": after a spear charge hit lands, you dash"
                        + " forward — farther at higher levels. Costs hunger and"
                        + " 1 extra durability.");
        put("lure", "Lure", lvl ->
                "Lure " + lvl + ": fish bite about " + (5 * lvl) + " seconds sooner.");
        put("mending", "Mending", lvl ->
                "Mending: XP you collect repairs this item instead"
                        + " (2 durability per XP point).");
        put("multishot", "Multishot", lvl ->
                "Multishot: fires 3 arrows at once in a fan, using 1 arrow"
                        + " (only the middle arrow can be picked back up).");
        put("piercing", "Piercing", lvl ->
                "Piercing " + lvl + ": arrows pass through enemies, hitting up to "
                        + (lvl + 1) + " in a line — even through shields.");
        put("power", "Power", lvl ->
                "Power " + lvl + ": arrows deal +" + (25 * (lvl + 1)) + "% damage.");
        put("projectile_protection", "Projectile Protection", lvl ->
                "Projectile Protection " + lvl + ": arrows and other shots hurt "
                        + (8 * lvl) + "% less.");
        put("protection", "Protection", lvl ->
                "Protection " + lvl + ": almost all damage hurts " + (4 * lvl)
                        + "% less. (All worn protection together caps at 80%.)");
        put("punch", "Punch", lvl ->
                "Punch " + lvl + ": your arrows knock enemies much farther back.");
        put("quick_charge", "Quick Charge", lvl -> {
            double left = Math.max(0.0, 1.25 - 0.25 * lvl);
            String tail = lvl >= 5 ? " (as fast as a crossbow can reload)."
                    : " (about " + num(left) + (left == 1.0 ? " second)." : " seconds).");
            return "Quick Charge " + lvl + ": crossbow reloads " + num(0.25 * lvl)
                    + " seconds faster" + tail;
        });
        put("respiration", "Respiration", lvl ->
                "Respiration " + lvl + ": your air lasts about " + (lvl + 1)
                        + " times as long underwater (roughly " + (16 * (lvl + 1))
                        + " seconds).");
        put("riptide", "Riptide", lvl ->
                "Riptide " + lvl + ": in water or rain, throwing the trident"
                        + " launches you through the air with it — higher levels"
                        + " throw you farther. It will not throw on dry land.");
        put("sharpness", "Sharpness", lvl ->
                "Sharpness " + lvl + ": +" + num(0.5 * lvl + 0.5)
                        + " damage on every hit.");
        put("silk_touch", "Silk Touch", lvl ->
                "Silk Touch: mined blocks drop as themselves (glass, stone, ore"
                        + " blocks and more) instead of their normal drops.");
        put("smite", "Smite", lvl ->
                "Smite " + lvl + ": +" + num(2.5 * lvl)
                        + " damage against the undead — zombies, skeletons,"
                        + " wither skeletons, the wither and more.");
        put("soul_speed", "Soul Speed", lvl ->
                "Soul Speed " + lvl + ": you run fast on soul sand and soul soil,"
                        + " faster at higher levels. The boots slowly wear out"
                        + " while you do.");
        put("sweeping_edge", "Sweeping Edge", lvl ->
                "Sweeping Edge " + lvl + ": sweep hits deal "
                        + Math.round(100.0 * lvl / (lvl + 1))
                        + "% of your full damage to every enemy around the one"
                        + " you hit.");
        put("swift_sneak", "Swift Sneak", lvl ->
                "Swift Sneak " + lvl + ": you sneak at "
                        + Math.min(100, 30 + 15 * lvl)
                        + "% of walking speed instead of the usual 30%.");
        put("thorns", "Thorns", lvl ->
                "Thorns " + lvl + ": attackers have a " + (15 * lvl)
                        + "% chance to take 1 to 5 damage back. Thorns hits wear"
                        + " the armor out faster.");
        put("unbreaking", "Unbreaking", lvl ->
                "Unbreaking " + lvl + ": on average, this lasts about " + (lvl + 1)
                        + " times longer before breaking.");
        put("vanishing_curse", "Curse of Vanishing", lvl ->
                "Curse of Vanishing: when you die, this item is destroyed instead"
                        + " of dropping.");
        put("wind_burst", "Wind Burst", lvl ->
                "Wind Burst " + lvl + ": a falling smash hit bounces you about "
                        + (8 * lvl) + " blocks into the air, ready to smash again.");
    }

    private EnchantDictionary() {
    }

    public static boolean has(String key) {
        return ENTRIES.containsKey(key);
    }

    public static Set<String> keys() {
        return ENTRIES.keySet();
    }

    public static int size() {
        return ENTRIES.size();
    }

    public static String nameOf(String key) {
        Entry e = ENTRIES.get(key);
        return e == null ? null : e.name();
    }

    /** The explanation line for one enchantment at one level, or null when
     *  the key is unknown (custom enchantments from other plugins are left
     *  completely alone by design). */
    public static String explain(String key, int level) {
        Entry e = ENTRIES.get(key);
        return e == null ? null : e.line().apply(Math.max(1, level));
    }
}

// ExcelItemInsight — an Excel plugin by WinkReyesValley. (Excel signature — MikeExcel)
