/** Tiny assertion helper for the plain-JVM suites (house pattern). */
final class Check {

    static int passed;
    static int failed;

    private Check() {
    }

    static void that(String name, boolean condition) {
        if (condition) {
            passed++;
        } else {
            failed++;
            System.out.println("FAIL: " + name);
        }
    }

    static void eq(String name, Object expected, Object actual) {
        boolean ok = expected == null ? actual == null : expected.equals(actual);
        if (ok) {
            passed++;
        } else {
            failed++;
            System.out.println("FAIL: " + name + " — expected <" + expected
                    + "> but was <" + actual + ">");
        }
    }

    static void contains(String name, String text, String needle) {
        that(name + " (looking for \"" + needle + "\" in \"" + text + "\")",
                text != null && text.contains(needle));
    }
}

// ExcelItemInsight — an Excel plugin by WinkReyesValley. (Excel signature — MikeExcel)
