import com.winkreyes.exceliteminsight.core.LoreBlock;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Block ownership behavior: replace-not-stack, foreign lore preserved
 * line-for-line, stale blocks replaced, grindstone strip, books,
 * curses, the Total-hit line rules.
 */
final class TestLoreBlock {

    private static final String H = LoreBlock.DEFAULT_HEADER;

    private TestLoreBlock() {
    }

    static void run() {
        // ---- the Jester case: Sharpness V diamond sword (base 7) ----
        List<String> sword = LoreBlock.apply(List.of(),
                Map.of("sharpness", 5), H, 7.0);
        Check.eq("sword block is header+total+line+footer", 4, sword.size());
        Check.eq("block starts with the header", H, sword.get(0));
        Check.contains("total line", sword.get(1), "Total hit: 10 (base 7 + 3 from Sharpness)");
        Check.contains("sharpness line", sword.get(2), "Sharpness 5: +3 damage");
        Check.eq("block ends with footer", LoreBlock.FOOTER, sword.get(3));

        // ---- replace, never stack ----
        List<String> twice = LoreBlock.apply(sword, Map.of("sharpness", 5), H, 7.0);
        Check.eq("double refresh is identical (no stacking)", sword, twice);
        long headers = twice.stream().filter(H::equals).count();
        Check.eq("exactly one header after double refresh", 1L, headers);

        // ---- stale block (wrong numbers) gets replaced ----
        List<String> stale = List.of(H, "§7Sharpness 5: +99 damage", LoreBlock.FOOTER);
        List<String> fixed = LoreBlock.apply(stale, Map.of("sharpness", 5), H, 7.0);
        Check.that("stale +99 is gone", fixed.stream().noneMatch(l -> l.contains("+99")));
        Check.contains("fresh line present", String.join("\n", fixed), "Sharpness 5: +3 damage");

        // ---- foreign lore preserved line-for-line (signature loot) ----
        List<String> foreign = List.of("§6Gravewhisper", "§7Forged where the deep things sleep.");
        List<String> withBlock = LoreBlock.apply(foreign,
                Map.of("sharpness", 4, "unbreaking", 3), H, 7.0);
        Check.eq("foreign line 1 untouched", foreign.get(0), withBlock.get(0));
        Check.eq("foreign line 2 untouched", foreign.get(1), withBlock.get(1));
        Check.eq("block appended BELOW foreign lore", H, withBlock.get(2));
        List<String> stripped = LoreBlock.apply(withBlock, Map.of(), H, null);
        Check.eq("grindstone strip returns exactly the foreign lore", foreign, stripped);

        // ---- unenchanted items are untouched ----
        List<String> plain = LoreBlock.apply(foreign, Map.of(), H, null);
        Check.eq("no enchants + no block = identical lore", foreign, plain);
        Check.eq("no enchants + empty lore = empty lore",
                List.of(), LoreBlock.apply(List.of(), Map.of(), H, null));

        // ---- enchanted book: stored enchants, no Total line ----
        Map<String, Integer> book = new LinkedHashMap<>();
        book.put("sharpness", 5);
        book.put("looting", 3);
        List<String> bookLore = LoreBlock.apply(List.of(), book, H, null);
        Check.eq("book block size", 4, bookLore.size());
        Check.that("book has no Total line",
                bookLore.stream().noneMatch(l -> l.contains("Total hit")));
        Check.contains("book looting line (sorted before sharpness)",
                bookLore.get(1), "Looting 3");
        Check.contains("book sharpness line", bookLore.get(2), "Sharpness 5");

        // ---- ordering is stable regardless of map order ----
        Map<String, Integer> reversed = new LinkedHashMap<>();
        reversed.put("looting", 3);
        reversed.put("sharpness", 5);
        Check.eq("insertion order does not change the block",
                bookLore, LoreBlock.apply(List.of(), reversed, H, null));

        // ---- Total line rules ----
        List<String> smiteOnly = LoreBlock.apply(List.of(), Map.of("smite", 5), H, 7.0);
        Check.that("Smite stays conditional: no Total line",
                smiteOnly.stream().noneMatch(l -> l.contains("Total hit")));
        List<String> bowSharp = LoreBlock.apply(List.of(), Map.of("sharpness", 5), H, null);
        Check.that("no base damage (bow/book): no Total line",
                bowSharp.stream().noneMatch(l -> l.contains("Total hit")));
        List<String> ironAxe = LoreBlock.apply(List.of(), Map.of("sharpness", 3), H, 9.0);
        Check.contains("iron axe total (9 + 2)", String.join("\n", ironAxe),
                "Total hit: 11 (base 9 + 2 from Sharpness)");

        // ---- curses explain like everything else ----
        List<String> cursed = LoreBlock.apply(List.of(),
                Map.of("binding_curse", 1, "vanishing_curse", 1), H, null);
        Check.contains("binding explained", String.join("\n", cursed), "Curse of Binding");
        Check.contains("vanishing explained", String.join("\n", cursed), "Curse of Vanishing");

        // ---- unknown (custom) enchantments are left alone ----
        Check.eq("unknown key alone builds no block",
                List.of(), LoreBlock.buildBlock(Map.of("some_custom_enchant", 3), H, null));
        List<String> mixed = LoreBlock.apply(List.of(),
                Map.of("sharpness", 2, "some_custom_enchant", 3), H, 6.0);
        Check.eq("mixed: only the vanilla line appears", 4, mixed.size());
        Check.contains("mixed total uses vanilla sharpness only",
                String.join("\n", mixed), "Total hit: 7.5 (base 6 + 1.5 from Sharpness)");

        // ---- custom header from config is honored and detected ----
        String custom = "§8~ Enchantments ~";
        List<String> customBlock = LoreBlock.apply(List.of(), Map.of("power", 5), custom, null);
        Check.eq("custom header used", custom, customBlock.get(0));
        Check.that("custom header block is found again",
                LoreBlock.hasBlock(customBlock, custom));
        Check.eq("custom header block refreshes cleanly",
                customBlock, LoreBlock.apply(customBlock, Map.of("power", 5), custom, null));

        // ---- block in the middle (should not happen, but strip is total) ----
        List<String> middle = List.of("§aTop", H, "§7Sharpness 1: +1 damage",
                LoreBlock.FOOTER, "§bBottom");
        List<String> cleaned = LoreBlock.stripBlock(middle, H);
        Check.eq("mid-lore block stripped, surroundings kept",
                List.of("§aTop", "§bBottom"), cleaned);

        // ---- header changed in config: old block still found + replaced ----
        List<String> oldHeader = LoreBlock.apply(foreign, Map.of("power", 5),
                "§8~ Old Header ~", null);
        List<String> reheaded = LoreBlock.apply(oldHeader, Map.of("power", 5), H, null);
        Check.that("old header text is gone after refresh with a new header",
                reheaded.stream().noneMatch(l -> l.contains("Old Header")));
        Check.eq("foreign lore still intact after re-header",
                foreign, reheaded.subList(0, 2));
        Check.eq("exactly one footer after re-header", 1L,
                reheaded.stream().filter(LoreBlock.FOOTER::equals).count());
        Check.eq("footer-anchored strip removes the whole old block",
                foreign, LoreBlock.apply(oldHeader, Map.of(), H, null));

        // ---- extractBlock matches what apply wrote ----
        Check.eq("extractBlock round-trips",
                sword, LoreBlock.extractBlock(sword, H));
        Check.eq("extractBlock on clean lore is empty",
                List.of(), LoreBlock.extractBlock(foreign, H));
    }
}

// ExcelItemInsight — an Excel plugin by WinkReyesValley. (Excel signature — MikeExcel)
