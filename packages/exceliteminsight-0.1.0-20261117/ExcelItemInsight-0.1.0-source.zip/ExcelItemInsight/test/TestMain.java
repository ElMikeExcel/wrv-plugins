/** Plain-JVM test entry point (house pattern). Args: [pinned-enchantments txt path]. */
public final class TestMain {

    private TestMain() {
    }

    public static void main(String[] args) throws Exception {
        String pinned = args.length > 0 ? args[0] : "pinned-enchantments-26.2.txt";
        TestDictionary.run(pinned);
        TestLoreBlock.run();
        System.out.println("ExcelItemInsight tests: " + Check.passed + " passed, "
                + Check.failed + " failed.");
        if (Check.failed > 0) {
            System.exit(1);
        }
    }
}

// ExcelItemInsight — an Excel plugin by WinkReyesValley. (Excel signature — MikeExcel)
