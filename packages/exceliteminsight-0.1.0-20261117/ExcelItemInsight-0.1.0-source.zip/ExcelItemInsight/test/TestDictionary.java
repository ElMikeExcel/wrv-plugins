import com.winkreyes.exceliteminsight.core.EnchantDictionary;
import com.winkreyes.exceliteminsight.core.PinnedEnchantments;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Dictionary completeness against the pinned 26.2 registry (extracted
 * from the server's own jar) plus formula spot-checks against the
 * numbers verified from the wiki and the pinned definitions.
 * The build FAILS if any pinned enchantment lacks an explanation.
 */
final class TestDictionary {

    private TestDictionary() {
    }

    static void run(String pinnedTxtPath) throws Exception {
        // ---- completeness: pinned list, generated class, dictionary ----
        List<String> fileKeys = Files.readAllLines(Path.of(pinnedTxtPath)).stream()
                .map(String::trim).filter(s -> !s.isEmpty()).toList();
        Check.eq("pinned file lists 43 enchantments", 43, fileKeys.size());
        Check.eq("pinned class lists 43 enchantments", 43, PinnedEnchantments.KEYS.size());
        Check.eq("pinned file == pinned class",
                new HashSet<>(fileKeys), new HashSet<>(PinnedEnchantments.KEYS));
        Check.eq("dictionary covers exactly the pinned set",
                new HashSet<>(PinnedEnchantments.KEYS),
                new HashSet<>(EnchantDictionary.keys()));
        Check.eq("dictionary size is 43", 43, EnchantDictionary.size());

        // ---- every entry renders sane text at levels 1..10 ----
        for (String key : PinnedEnchantments.KEYS) {
            for (int lvl = 1; lvl <= 10; lvl++) {
                String line = EnchantDictionary.explain(key, lvl);
                Check.that("explain " + key + " lvl " + lvl + " non-blank",
                        line != null && !line.isBlank());
                Check.that("explain " + key + " lvl " + lvl + " has no null/format junk",
                        line != null && !line.contains("null") && !line.contains("%s")
                                && !line.contains("NaN"));
            }
        }

        // ---- formula spot-checks (sources in BUILD.md) ----
        Check.contains("Sharpness I", ex("sharpness", 1), "+1 damage");
        Check.contains("Sharpness V", ex("sharpness", 5), "+3 damage");
        Check.contains("Sharpness X (over-level, by formula)", ex("sharpness", 10), "+5.5 damage");
        Check.contains("Smite V", ex("smite", 5), "+12.5 damage");
        Check.contains("Bane V", ex("bane_of_arthropods", 5), "+12.5 damage");
        Check.contains("Impaling V (Java, aquatic)", ex("impaling", 5), "+12.5 damage");
        Check.contains("Power I", ex("power", 1), "+50%");
        Check.contains("Power V", ex("power", 5), "+150%");
        Check.contains("Sweeping I", ex("sweeping_edge", 1), "50%");
        Check.contains("Sweeping II", ex("sweeping_edge", 2), "67%");
        Check.contains("Sweeping III", ex("sweeping_edge", 3), "75%");
        Check.contains("Unbreaking III", ex("unbreaking", 3), "about 4 times longer");
        Check.contains("Unbreaking I", ex("unbreaking", 1), "about 2 times longer");
        Check.contains("Protection IV", ex("protection", 4), "16%");
        Check.contains("Fire Protection IV damage", ex("fire_protection", 4), "32%");
        Check.contains("Fire Protection IV burn time", ex("fire_protection", 4), "60% sooner");
        Check.contains("Blast Protection IV", ex("blast_protection", 4), "32%");
        Check.contains("Projectile Protection IV", ex("projectile_protection", 4), "32%");
        Check.contains("Feather Falling IV", ex("feather_falling", 4), "48%");
        Check.contains("Thorns III", ex("thorns", 3), "45% chance");
        Check.contains("Thorns damage range (pinned data: 1-5)", ex("thorns", 1), "1 to 5 damage");
        Check.contains("Efficiency V", ex("efficiency", 5), "+26 mining speed");
        Check.contains("Efficiency I", ex("efficiency", 1), "+2 mining speed");
        Check.contains("Fortune III max", ex("fortune", 3), "up to 4 times");
        Check.contains("Fortune III average", ex("fortune", 3), "2.2 times on average");
        Check.contains("Fortune I average", ex("fortune", 1), "1.33 times on average");
        Check.contains("Frost Walker II radius", ex("frost_walker", 2), "reaching 4 blocks");
        Check.contains("Frost Walker I radius", ex("frost_walker", 1), "reaching 3 blocks");
        Check.contains("Fire Aspect II", ex("fire_aspect", 2), "burns for 8 seconds");
        Check.contains("Flame burn (pinned: 100 ticks)", ex("flame", 1), "fire for 5 seconds");
        Check.contains("Quick Charge III speed-up", ex("quick_charge", 3), "0.75 seconds faster");
        Check.contains("Quick Charge III total", ex("quick_charge", 3), "about 0.5 seconds");
        Check.contains("Quick Charge I total", ex("quick_charge", 1), "about 1 second");
        Check.contains("Lure III", ex("lure", 3), "15 seconds sooner");
        Check.contains("Luck of the Sea I", ex("luck_of_the_sea", 1), "7.1%");
        Check.contains("Luck of the Sea III", ex("luck_of_the_sea", 3), "11.3%");
        Check.contains("Respiration III air multiple", ex("respiration", 3), "about 4 times");
        Check.contains("Respiration III seconds", ex("respiration", 3), "64 seconds");
        Check.contains("Respiration I seconds", ex("respiration", 1), "32 seconds");
        Check.contains("Swift Sneak III", ex("swift_sneak", 3), "75% of walking speed");
        Check.contains("Swift Sneak V caps at 100", ex("swift_sneak", 5), "100% of walking speed");
        Check.contains("Piercing IV count", ex("piercing", 4), "up to 5 in a line");
        Check.contains("Piercing I count", ex("piercing", 1), "up to 2 in a line");
        Check.contains("Density V", ex("density", 5), "+2.5 damage for every block");
        Check.contains("Breach IV", ex("breach", 4), "60% weaker");
        Check.contains("Looting III max", ex("looting", 3), "up to 3 extra items");
        Check.contains("Looting III rare chance", ex("looting", 3), "+3% more likely");
        Check.contains("Looting I singular", ex("looting", 1), "up to 1 extra item,");
        Check.contains("Depth Strider III", ex("depth_strider", 3), "full walking speed");
        Check.contains("Depth Strider I", ex("depth_strider", 1), "33% less");
        Check.contains("Depth Strider II", ex("depth_strider", 2), "67% less");
        Check.contains("Wind Burst III", ex("wind_burst", 3), "about 24 blocks");
        Check.contains("Mending rate", ex("mending", 1), "2 durability per XP point");
        Check.contains("Multishot count", ex("multishot", 1), "3 arrows at once");
        Check.contains("Binding curse", ex("binding_curse", 1), "cannot take it off");
        Check.contains("Vanishing curse", ex("vanishing_curse", 1), "destroyed instead");
        Check.contains("Lunge (new in 26.2)", ex("lunge", 2), "dash forward");
    }

    private static String ex(String key, int lvl) {
        return EnchantDictionary.explain(key, lvl);
    }
}

// ExcelItemInsight — an Excel plugin by WinkReyesValley. (Excel signature — MikeExcel)
