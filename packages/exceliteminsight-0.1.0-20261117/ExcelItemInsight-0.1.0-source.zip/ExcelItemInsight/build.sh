#!/usr/bin/env bash
# ExcelItemInsight build — deterministic jar (fixed zip timestamps,
# sorted entries), release 21 classfiles for the Paper 26.2 / Java 25
# server. Run the tests first (run-tests.sh); a red suite means no jar.
set -euo pipefail
cd "$(dirname "$0")"
JAVA_HOME="${JAVA_HOME:-$HOME/workspace/.jdk25}"
JAVAC="$JAVA_HOME/bin/javac"
JAR="$JAVA_HOME/bin/jar"
LIBS="$HOME/workspace/excelshops/build-libs"
[ -x "$JAVAC" ] || { echo "JDK not found at $JAVA_HOME" >&2; exit 1; }
OUT="${1:-$HOME/workspace/exceliteminsight/ExcelItemInsight-0.1.0.jar}"
rm -rf build/classes
mkdir -p build/classes
CP="$LIBS/paper-api.jar"
for j in adventure-api-4.20.0 adventure-key-4.20.0 adventure-text-minimessage-4.20.0 adventure-text-serializer-gson-4.20.0 adventure-text-serializer-json-4.20.0 adventure-text-serializer-legacy-4.20.0 adventure-text-serializer-plain-4.20.0 examination-api-1.3.0 examination-string-1.3.0 option-1.0.0 gson-2.11.0 guava-33.3.1-jre snakeyaml-2.2; do CP="$CP:$LIBS/$j.jar"; done
RT="$HOME/workspace/excelbuildmode-pilot/runtime-server/libraries"
CP="$CP:$RT/org/joml/joml/1.10.8/joml-1.10.8.jar:$RT/com/googlecode/json-simple/json-simple/1.1.1/json-simple-1.1.1.jar:$RT/it/unimi/dsi/fastutil/8.5.19/fastutil-8.5.19.jar:$RT/com/mojang/brigadier/1.3.10/brigadier-1.3.10.jar:$RT/net/md-5/bungeecord-chat/1.21-R0.2-deprecated+build.21/bungeecord-chat-1.21-R0.2-deprecated+build.21.jar:$RT/org/jspecify/jspecify/1.0.0/jspecify-1.0.0.jar:$RT/org/slf4j/slf4j-api/2.0.18/slf4j-api-2.0.18.jar:$RT/com/google/guava/failureaccess/1.0.3/failureaccess-1.0.3.jar:$RT/org/apache/logging/log4j/log4j-api/2.26.0/log4j-api-2.26.0.jar"
find src -name '*.java' > build/sources.txt
"$JAVAC" --release 21 -proc:none -nowarn \
    -cp "$CP" \
    -d build/classes @build/sources.txt
cp plugin.yml config.yml build/classes/
"$JAR" --create --file "$OUT" --date=2026-10-20T00:00:00-05:00 -C build/classes .
echo "built: $OUT"
sha256sum "$OUT"

# ExcelItemInsight — an Excel plugin by WinkReyesValley. (Excel signature — MikeExcel)
