#!/bin/bash
# Plain-JVM suites (house pattern): the core is Bukkit-free, so
# every probability and verdict check runs without a server.
set -euo pipefail
cd "$(dirname "$0")"

JDK=~/workspace/.jdk25
LIBS=/home/hatch/workspace/excelshops/build-libs
RT=/home/hatch/workspace/excelbuildmode-pilot/runtime-server/libraries
CP="$LIBS/paper-api.jar"
for j in adventure-api-4.20.0 adventure-key-4.20.0 adventure-text-minimessage-4.20.0 adventure-text-serializer-gson-4.20.0 adventure-text-serializer-json-4.20.0 adventure-text-serializer-legacy-4.20.0 adventure-text-serializer-plain-4.20.0 examination-api-1.3.0 examination-string-1.3.0 option-1.0.0 gson-2.11.0 guava-33.3.1-jre snakeyaml-2.2; do CP="$CP:$LIBS/$j.jar"; done
CP="$CP:$RT/org/joml/joml/1.10.8/joml-1.10.8.jar:$RT/com/googlecode/json-simple/json-simple/1.1.1/json-simple-1.1.1.jar:$RT/it/unimi/dsi/fastutil/8.5.19/fastutil-8.5.19.jar:$RT/com/mojang/brigadier/1.3.10/brigadier-1.3.10.jar:$RT/net/md-5/bungeecord-chat/1.21-R0.2-deprecated+build.21/bungeecord-chat-1.21-R0.2-deprecated+build.21.jar:$RT/org/jspecify/jspecify/1.0.0/jspecify-1.0.0.jar:$RT/org/slf4j/slf4j-api/2.0.18/slf4j-api-2.0.18.jar:$RT/com/google/guava/failureaccess/1.0.3/failureaccess-1.0.3.jar:$RT/org/apache/logging/log4j/log4j-api/2.26.0/log4j-api-2.26.0.jar"
CP="$CP:$HOME/workspace/.m2/repository/org/jetbrains/annotations/26.0.2/annotations-26.0.2.jar"

rm -rf build/test-classes
mkdir -p build/test-classes build/classes

# Ensure the plugin classes exist (tests link the core).
if [ ! -d build/classes/com ]; then
  "$JDK/bin/javac" --release 21 -proc:none -encoding UTF-8 -nowarn \
    -cp "$CP" \
    -d build/classes $(find src -name '*.java')
fi

"$JDK/bin/javac" --release 21 -proc:none -encoding UTF-8 -nowarn \
  -cp "build/classes" \
  -d build/test-classes $(find tests -name '*.java')

"$JDK/bin/java" -cp "build/classes:build/test-classes" TestMain
