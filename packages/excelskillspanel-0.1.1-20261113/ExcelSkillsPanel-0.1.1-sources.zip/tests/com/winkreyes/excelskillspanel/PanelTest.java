package com.winkreyes.excelskillspanel;

import com.gmail.nossr50.datatypes.skills.PrimarySkillType;
import com.winkreyes.excelskillspanel.bukkit.BedrockForms;
import com.winkreyes.excelskillspanel.core.MagicLines;
import com.winkreyes.excelskillspanel.core.PanelModel;
import com.winkreyes.excelskillspanel.core.SkillMath;
import com.winkreyes.excelskillspanel.provider.mcmmo.McMMoProvider;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * ExcelSkillsPanel harness: the pure model (bars, rows, the Magic
 * header composition), the provider seam's mcMMO skill census,
 * and the Bedrock form handler proof against the REAL Cumulus
 * classes in the staged Geyser jar (the Summons 0.1.8 pattern —
 * forms must not only SEND, taps must ARRIVE).
 *
 * Excel — Wink Reyes Valley (Iris / Mike).
 */
class PanelTest {

    // ----------------- bars -----------------

    @Test
    void barMath() {
        PanelModel.BarData half = new PanelModel.BarData(1000, 2000);
        assertEquals(0.5, half.fraction());
        assertEquals(50, half.percent());
        assertEquals("\u25B0\u25B0\u25B0\u25B0\u25B0\u25B1\u25B1\u25B1\u25B1\u25B1", half.bar());
        assertEquals("\u25B0\u25B0\u25B0\u25B0\u25B0\u25B1\u25B1\u25B1\u25B1\u25B1 50% \u2014 1,000 / 2,000 XP",
                half.line());
        assertEquals("\u25B0\u25B0\u25B0\u25B0\u25B0\u25B1\u25B1\u25B1\u25B1\u25B1 50%", half.compact());
    }

    @Test
    void barClampsAndCaps() {
        PanelModel.BarData over = new PanelModel.BarData(3000, 2000);
        assertEquals(1.0, over.fraction(), "over-full clamps to 100%");
        assertEquals(100, over.percent());
        PanelModel.BarData negative = new PanelModel.BarData(-50, 2000);
        assertEquals(0.0, negative.fraction(), "negative into clamps to 0");
        PanelModel.BarData capped = new PanelModel.BarData(500, 0);
        assertTrue(capped.capped(), "span 0 is the cap");
        assertEquals(1.0, capped.fraction());
        assertTrue(capped.line().endsWith("MAX"), "capped line says MAX, no invented fraction");
        assertTrue(capped.compact().endsWith("MAX"));
        PanelModel.BarData empty = new PanelModel.BarData(0, 2000);
        assertEquals(0, empty.percent());
        assertEquals("\u25B1\u25B1\u25B1\u25B1\u25B1\u25B1\u25B1\u25B1\u25B1\u25B1", empty.bar());
    }

    @Test
    void numberFormatting() {
        assertEquals("1,240", PanelModel.fmt(1240));
        assertEquals("0", PanelModel.fmt(0));
        assertEquals("17,821", PanelModel.fmt(17821));
    }

    // ----------------- mcMMO rows (pure composition) -----------------

    @Test
    void mcmmoRowComposition() {
        PanelModel.SkillRow row = SkillMath.mcmmoRow("mining", "Mining", "IRON_PICKAXE",
                214, 1240, 2000, null);
        assertEquals("Mining 214 \u25B0\u25B0\u25B0\u25B0\u25B0\u25B0\u25B1\u25B1\u25B1\u25B1 62%",
                row.compactLine());
        assertEquals("Mining \u2014 Lv 214", row.buttonLabel());
        assertEquals(List.of(
                "Level: 214",
                "\u25B0\u25B0\u25B0\u25B0\u25B0\u25B0\u25B1\u25B1\u25B1\u25B1 62% \u2014 1,240 / 2,000 XP",
                "XP into this level: 1,240",
                "XP to next level: 760",
                SkillMath.PERK_POINTER), row.detailLines());
    }

    @Test
    void mcmmoRowRankAndCap() {
        PanelModel.SkillRow ranked = SkillMath.mcmmoRow("mining", "Mining", "IRON_PICKAXE",
                10, 5, 100, "Adept");
        assertTrue(ranked.detailLines().contains("Rank: Adept"),
                "a verified rank label shows in the detail view");
        PanelModel.SkillRow capped = SkillMath.mcmmoRow("mining", "Mining", "IRON_PICKAXE",
                1000, 0, 0, null);
        assertTrue(capped.detailLines().get(3).contains("at the cap"),
                "a capped skill's detail says so instead of a fake remainder");
        PanelModel.SkillRow blank = SkillMath.mcmmoRow("mining", "Mining", "IRON_PICKAXE",
                10, 5, 100, " ");
        assertFalse(blank.detailLines().toString().contains("Rank:"),
                "a blank rank label is treated as absent");
    }

    @Test
    void childSkillRowComposition() {
        // Salvage / Smelting: a level but no XP and no bar —
        // mcMMO's XP reads throw for child skills (rig-proven).
        PanelModel.SkillRow row = SkillMath.childRow("salvage", "Salvage", "GOLD_INGOT",
                12, null);
        assertNull(row.bar(), "a child row carries no bar");
        assertEquals("Salvage 12 (child skill)", row.compactLine());
        assertEquals("Salvage \u2014 Lv 12", row.buttonLabel());
        assertEquals("Level: 12", row.detailLines().get(0));
        assertTrue(row.detailLines().get(1).contains("parent skills"));
        assertEquals(SkillMath.PERK_POINTER,
                row.detailLines().get(row.detailLines().size() - 1));
    }

    @Test
    void powerHeaderComposition() {
        // 0.1.1 (Mike, Nov 13, 2026): ONE line — the value lives in
        // the block title; the block carries no lines, so no
        // surface can print heading + value as two lines.
        PanelModel.HeaderBlock header = SkillMath.powerHeader(579, Integer.MAX_VALUE);
        assertEquals("Power Level 579", header.title(),
                "the single Power Level line, no colon, value in the title");
        assertEquals(List.of(), header.lines(), "no separate value line remains");
        assertEquals(List.of(), header.allLines(), "no lore/body lines duplicate the title");
        PanelModel.HeaderBlock big = SkillMath.powerHeader(1234, 5000);
        assertEquals("Power Level 1,234", big.title(), "thousands formatting kept");
        // The cap line is gone ENTIRELY — even a configured cap,
        // and above all the fork's uncapped Integer.MAX_VALUE.
        for (PanelModel.HeaderBlock h : List.of(header, big, SkillMath.powerHeader(42, 0))) {
            String all = h.title() + "|" + h.allLines();
            assertFalse(all.contains("cap"), "no cap text anywhere: " + all);
            assertFalse(all.contains("2,147,483,647"),
                    "Integer.MAX_VALUE noise never renders: " + all);
        }
    }

    @Test
    void mcmmoSkillCensusIsThe19() {
        assertEquals(19, McMMoProvider.SKILLS.size(), "the panel maps all 19 primary skills");
        assertEquals(19, PrimarySkillType.values().length,
                "the fork's PrimarySkillType census the design verified");
        for (McMMoProvider.SkillDef def : McMMoProvider.SKILLS) {
            assertNotNull(def.type());
            assertFalse(def.displayName().isBlank());
            assertFalse(def.iconKey().isBlank());
        }
        // declaration order preserved end to end
        assertEquals(PrimarySkillType.ACROBATICS, McMMoProvider.SKILLS.get(0).type());
        assertEquals(PrimarySkillType.WOODCUTTING, McMMoProvider.SKILLS.get(18).type());
    }

    // ----------------- Magic header composition -----------------

    private static MagicLines.MagicData fullMagic() {
        return new MagicLines.MagicData(
                12, 1240L, 760L, 54321L,
                "Apprentice", "apprentice", "Master", "Mage",
                60.0f, 150, 25,
                "13.75", "13.75", "5.5",
                1234L, 4);
    }

    @Test
    void magicHeaderFullComposition() {
        MagicLines.MagicData d = fullMagic();
        List<String> lines = MagicLines.headerLines(d);
        assertEquals(List.of(
                "Magic Level 12 \u2014 54,321 XP total",
                "Rank: Apprentice",
                "Class: Mage",
                "Next rank: Master",
                "Mana: 60 / 150",
                "Mana regen: 25",
                "Boosts: mana pool +13.75%, mana regen +13.75%, cast cost -5.5%",
                "Total casts: 1,234",
                "Guild seals: 4 of 5"), lines);
        PanelModel.HeaderBlock block = MagicLines.headerBlock(d);
        assertNotNull(block);
        assertTrue(block.hasDetail(), "the Magic block opens the detail view");
        assertEquals(new PanelModel.BarData(1240, 2000), block.bar(),
                "the Magic bar spans into + to-next");
    }

    @Test
    void magicHeaderOmitsWhatDidNotRead() {
        MagicLines.MagicData sparse = new MagicLines.MagicData(
                null, null, null, null,
                null, null, null, null,
                null, null, null,
                null, null, null,
                null, null);
        assertNull(MagicLines.headerBlock(sparse),
                "nothing read -> no Magic block at all, never an empty or faked one");
        MagicLines.MagicData levelOnly = new MagicLines.MagicData(
                3, 10L, 90L, 250L,
                null, null, null, null,
                null, null, null,
                null, null, null,
                null, null);
        assertEquals(List.of("Magic Level 3 \u2014 250 XP total"),
                MagicLines.headerLines(levelOnly));
        // rank falls back to the KEY only when the name did not read
        MagicLines.MagicData keyOnly = new MagicLines.MagicData(
                null, null, null, null,
                null, "apprentice", null, null,
                null, null, null,
                null, null, null,
                null, null);
        assertEquals(List.of("Rank: apprentice"), MagicLines.headerLines(keyOnly));
    }

    @Test
    void magicBoostsLineLevels() {
        MagicLines.MagicData one = new MagicLines.MagicData(
                1, 0L, 100L, 0L, null, null, null, null, null, null, null,
                "0", "0", "0", null, null);
        assertEquals("Boosts: none yet \u2014 they start at Magic Level 2",
                MagicLines.boostsLine(one), "level 1 mirrors ExcelMagicLevel's own wording");
        MagicLines.MagicData poolOnly = new MagicLines.MagicData(
                5, 0L, 100L, 400L, null, null, null, null, null, null, null,
                "5", null, null, null, null);
        assertEquals("Boosts: mana pool +5%", MagicLines.boostsLine(poolOnly),
                "unread boost parts are omitted, not zero-filled");
    }

    @Test
    void magicBarAtCap() {
        MagicLines.MagicData capped = new MagicLines.MagicData(
                20, 500L, 0L, 99999L, null, null, null, null, null, null, null,
                null, null, null, null, null);
        PanelModel.BarData bar = MagicLines.magicBar(capped);
        assertNotNull(bar);
        assertTrue(bar.line().endsWith("MAX"),
                "to-next 0 with XP banked renders the capped bar (span = into)");
        assertNull(MagicLines.magicBar(new MagicLines.MagicData(
                null, null, null, null, null, null, null, null, null, null, null,
                null, null, null, null, null)), "no level surface -> no bar");
    }

    @Test
    void magicCastsNeverLabelledCredited() {
        for (String line : MagicLines.headerLines(fullMagic())) {
            assertFalse(line.toLowerCase().contains("credited"),
                    "casts are labelled casts, never credited: " + line);
        }
        for (String line : MagicLines.detailLines(fullMagic())) {
            assertFalse(line.toLowerCase().contains("credited"),
                    "the detail view keeps the same label discipline: " + line);
        }
    }

    @Test
    void magicDetailLeadsWithExplainer() {
        List<String> detail = MagicLines.detailLines(fullMagic());
        assertEquals(MagicLines.EXPLAINER, detail.get(0),
                "the detail view leads with the canonical explainer");
        assertTrue(detail.contains("Magic XP: "
                        + "\u25B0\u25B0\u25B0\u25B0\u25B0\u25B0\u25B1\u25B1\u25B1\u25B1 62% \u2014 1,240 / 2,000 XP"),
                "the detail view carries the bar numbers line");
        assertTrue(MagicLines.detailLines(new MagicLines.MagicData(
                null, null, null, null, null, null, null, null, null, null, null,
                null, null, null, null, null)).isEmpty(),
                "no reads -> no detail view");
    }

    @Test
    void percentFormattingMatchesExcelMagicLevel() {
        // ExcelMagicLevel Percents.format's own documented examples
        // (fraction -> percent number); all are exact at the panel's
        // scale-2 display rounding too, so they still agree.
        assertEquals("1.25", MagicLines.percentOf(0.0125));
        assertEquals("9.5", MagicLines.percentOf(0.095));
        assertEquals("23.75", MagicLines.percentOf(0.2375));
        assertEquals("0", MagicLines.percentOf(0.0));
        // the reward-table formula at level 12: per-level x 11
        assertEquals("13.75", MagicLines.percentOf(0.0125 * 11));
        assertEquals("5.5", MagicLines.percentOf(0.005 * 11));
    }

    @Test
    void boostsRenderRoundedToTwoDecimals() {
        // 0.1.1 (Mike, Nov 13, 2026): the values are FRACTIONS in
        // ExcelMagicLevel's Boost record; Percents.format turns
        // them into percent numbers at scale 4. On the shipped
        // 1000-level curve (per-level = cap / 999), Mike's Magic
        // Level 26 carries 25 steps: mana 25 x 0.0002377377... =
        // 0.5943%, cost 25 x 0.0000950951... = 0.2377% — his live
        // screenshot's exact numbers. The panel renders scale 2.
        double perLevelMana = 0.2375 / 999.0;
        double perLevelCost = 0.095 / 999.0;
        assertEquals("0.59", MagicLines.percentOf(perLevelMana * 25),
                "the computed (regen-style) path rounds the same way");
        assertEquals("0.24", MagicLines.percentOf(perLevelCost * 25));
        assertEquals("0.59", MagicLines.displayPct("0.5943"),
                "the PAPI-string (mana pool) path re-renders at scale 2");
        assertEquals("0.24", MagicLines.displayPct("0.2377"));
        assertEquals("3.21", MagicLines.displayPct("3.2095"),
                "the rig's level-136 value rounds up cleanly");
        assertEquals("1.28", MagicLines.displayPct("1.2838"));
        assertEquals("13.75", MagicLines.displayPct("13.75"),
                "already-clean values are untouched");
        assertEquals("0", MagicLines.displayPct("0"));
        assertEquals("n/a", MagicLines.displayPct("n/a"),
                "an unparseable provider string passes through, never hidden");
        // Whole-percent rounding was rejected on purpose: it would
        // print 0.59% as 1% and 0.24% as 0%. Scale 2 keeps the
        // smallest real boost visible (level 2: 0.02% / 0.01%).
        assertEquals("0.02", MagicLines.percentOf(perLevelMana));
        assertEquals("0.01", MagicLines.percentOf(perLevelCost));
        // Mike's exact live DTO (level 26, PAPI-formatted strings):
        MagicLines.MagicData mike = new MagicLines.MagicData(
                26, 10L, 19L, 579L,
                "Beginner", "beginner", "Student", "Mage",
                60.0f, 60, 5,
                "0.5943", "0.5943", "0.2377",
                694L, 4);
        assertEquals("Boosts: mana pool +0.59%, mana regen +0.59%, cast cost -0.24%",
                MagicLines.boostsLine(mike));
    }

    // ----------------- panel assembly -----------------

    @Test
    void panelBodyAndChatLines() {
        PanelModel.Panel panel = new PanelModel.Panel(
                List.of(SkillMath.powerHeader(100, 0),
                        MagicLines.headerBlock(fullMagic())),
                List.of(SkillMath.mcmmoRow("mining", "Mining", "IRON_PICKAXE",
                        214, 1240, 2000, null)),
                MagicLines.detailLines(fullMagic()));
        String body = panel.bedrockBody();
        assertTrue(body.startsWith("Power Level 100\n\nMagic\n"),
                "0.1.1: the Power Level header is ONE line leading the Bedrock body");
        assertEquals(1, body.split("Power Level", -1).length - 1,
                "Power Level is named exactly once in the whole body (no cap line either)");
        assertTrue(body.contains("Guild seals: 4 of 5"));
        assertTrue(body.endsWith("Mining 214 "
                        + "\u25B0\u25B0\u25B0\u25B0\u25B0\u25B0\u25B1\u25B1\u25B1\u25B1 62%"),
                "the compact skill lines close the body");
        List<String> chat = panel.chatLines();
        assertEquals("Skills", chat.get(0));
        assertTrue(chat.contains("Mining 214 "
                + "\u25B0\u25B0\u25B0\u25B0\u25B0\u25B0\u25B1\u25B1\u25B1\u25B1 62%"),
                "the chat fallback carries the same compact lines");
        assertTrue(panel.hasMagicDetail());
        assertNotNull(panel.header("magic"));
        assertNull(panel.header("nope"));
    }

    // ----------------- Bedrock form handler (real Cumulus) -----------------

    @Test
    void bedrockFormsHandlerShape() throws Exception {
        // Structural pin on the compiled BedrockForms: the NEW
        // Cumulus + Geyser-only path is what ships (the Summons
        // 0.1.8 shape); the dead 0.1.7 shape stays out.
        byte[] bytes;
        try (var in = PanelTest.class.getResourceAsStream(
                "/com/winkreyes/excelskillspanel/bukkit/BedrockForms.class")) {
            assertNotNull(in, "BedrockForms.class is on the test classpath");
            bytes = in.readAllBytes();
        }
        String pool = new String(bytes, java.nio.charset.StandardCharsets.ISO_8859_1);
        assertTrue(pool.contains("org.geysermc.cumulus.form.SimpleForm"), "the NEW Cumulus SimpleForm");
        assertTrue(pool.contains("org.geysermc.cumulus.form.util.FormBuilder"), "the new FormBuilder");
        assertTrue(pool.contains("resultHandler"), "the handler attaches via FormBuilder.resultHandler");
        assertTrue(pool.contains("clickedButtonId"), "the index unwraps via SimpleFormResponse.clickedButtonId");
        assertTrue(pool.contains("connectionByUuid"), "the connection is looked up by player uuid");
        assertFalse(pool.contains("org.geysermc.cumulus.SimpleForm"),
                "the OLD Cumulus SimpleForm is gone");
        assertFalse(pool.contains("validResultHandler"), "the 0.1.7 handler hunt is gone");
        assertFalse(pool.contains("floodgate"), "the Floodgate attempt is gone — Geyser class loader only");
    }

    @Test
    void bedrockFormsHandlerDeliversEveryIndex() throws Exception {
        // Behavioral proof against the REAL Cumulus classes in
        // the staged Geyser jar (local-build.sh passes its path):
        // for each form shape the panel sends, a synthetic
        // response is driven through the handler
        // BedrockForms.buildForm attached — via
        // FormImpl.callResultHandler AND via the raw-payload
        // entry (SimpleFormDefinition.handleFormResponse). A
        // closed form must report -1.
        String geyserJar = System.getProperty("skillspanel.test.geyserJar");
        String guavaJar = System.getProperty("skillspanel.test.guavaJar");
        String gsonJar = System.getProperty("skillspanel.test.gsonJar");
        assertNotNull(geyserJar, "local-build.sh passes -Dskillspanel.test.geyserJar");
        java.net.URLClassLoader l = new java.net.URLClassLoader(new java.net.URL[]{
                java.nio.file.Path.of(geyserJar).toUri().toURL(),
                java.nio.file.Path.of(guavaJar).toUri().toURL(),
                java.nio.file.Path.of(gsonJar).toUri().toURL()},
                PanelTest.class.getClassLoader());
        Class<?> formImpl = Class.forName("org.geysermc.cumulus.form.impl.FormImpl", true, l);
        Class<?> resultT = Class.forName("org.geysermc.cumulus.response.result.FormResponseResult", true, l);
        Class<?> validT = Class.forName("org.geysermc.cumulus.response.result.ValidFormResponseResult", true, l);
        Class<?> respImpl = Class.forName("org.geysermc.cumulus.response.impl.SimpleFormResponseImpl", true, l);
        Class<?> buttonT = Class.forName("org.geysermc.cumulus.component.ButtonComponent", true, l);
        Class<?> responseT = Class.forName("org.geysermc.cumulus.response.FormResponse", true, l);
        java.lang.reflect.Method respOf = respImpl.getMethod("of", int.class, buttonT);
        java.lang.reflect.Method validOf = validT.getMethod("of", responseT);
        java.lang.reflect.Method callHandler = formImpl.getMethod("callResultHandler", resultT);
        java.lang.reflect.Method closedOf = resultT.getMethod("closed");
        Object definition = Class.forName("org.geysermc.cumulus.form.impl.simple.SimpleFormDefinition", true, l)
                .getMethod("instance").invoke(null);
        java.lang.reflect.Method handleRaw = definition.getClass().getMethod("handleFormResponse",
                Class.forName("org.geysermc.cumulus.form.Form", true, l), String.class);
        java.util.logging.Logger log = java.util.logging.Logger.getLogger("skillspanel-test");
        java.util.Map<String, List<String>> shapes = new java.util.LinkedHashMap<>();
        shapes.put("panel", List.of("Magic \u2014 details", "Mining \u2014 Lv 214",
                "Fishing \u2014 Lv 3", "Close"));
        shapes.put("skill-detail", List.of("Back to Skills"));
        shapes.put("magic-detail", List.of("Back to Skills"));
        for (var shape : shapes.entrySet()) {
            java.util.concurrent.atomic.AtomicInteger got =
                    new java.util.concurrent.atomic.AtomicInteger(Integer.MIN_VALUE);
            Object form = BedrockForms.buildForm(l, "Skills", "body",
                    shape.getValue(), got::set, log);
            List<?> buttons = (List<?>) form.getClass().getMethod("buttons").invoke(form);
            assertEquals(shape.getValue().size(), buttons.size(),
                    shape.getKey() + " form carries its buttons");
            for (int i = 0; i < buttons.size(); i++) {
                got.set(Integer.MIN_VALUE);
                callHandler.invoke(form, validOf.invoke(null, respOf.invoke(null, i, buttons.get(i))));
                assertEquals(i, got.get(),
                        shape.getKey() + " button " + i + " reaches the callback via callResultHandler");
                got.set(Integer.MIN_VALUE);
                handleRaw.invoke(definition, form, String.valueOf(i));
                assertEquals(i, got.get(),
                        shape.getKey() + " button " + i + " reaches the callback via the raw payload path");
            }
            got.set(Integer.MIN_VALUE);
            callHandler.invoke(form, closedOf.invoke(null));
            assertEquals(-1, got.get(), shape.getKey() + ": a closed form reports -1");
            got.set(Integer.MIN_VALUE);
            handleRaw.invoke(definition, form, "null");
            assertEquals(-1, got.get(), shape.getKey() + ": the client's close payload reports -1");
        }
    }

    // ----------------- Bedrock percent sign (0.1.1) -----------------

    @Test
    void bedrockPercentSafeRendering() {
        // The MODEL keeps the ASCII sign — the Java chest lore and
        // the chat fallback render it directly and must not change.
        PanelModel.BarData bar = new PanelModel.BarData(1240, 2000);
        assertTrue(bar.compact().endsWith("62%"), "model compact keeps ASCII %: " + bar.compact());
        assertTrue(bar.line().contains("62% \u2014"), "model line keeps ASCII %: " + bar.line());
        // The form-bound rendering swaps U+0025 for U+FF05 only.
        String safe = PanelModel.bedrockSafe(bar.line());
        assertFalse(safe.contains("%"), "no ASCII % survives into a form body: " + safe);
        assertTrue(safe.contains("62\uFF05 \u2014 1,240 / 2,000 XP"),
                "the value + fullwidth sign survive: " + safe);
        assertEquals(safe, PanelModel.bedrockSafe(safe), "bedrockSafe is idempotent");
        assertNull(PanelModel.bedrockSafe(null), "null stays null");
        assertEquals("no percent here", PanelModel.bedrockSafe("no percent here"),
                "text without a percent is untouched");
    }

    @Test
    void bedrockFormContentRetainsPercentSigns() throws Exception {
        // Root-cause isolation against the REAL Cumulus classes:
        // a form built through BedrockForms.buildForm RETAINS an
        // ASCII "%" in its content exactly — the plugin -> Cumulus
        // leg does NOT eat the glyph (Mike's live loss is
        // downstream, in the Bedrock client's form rendering).
        // The 0.1.1 fullwidth sign is likewise retained exactly,
        // so the form the client receives carries a percent sign
        // its renderer passes through.
        String geyserJar = System.getProperty("skillspanel.test.geyserJar");
        String guavaJar = System.getProperty("skillspanel.test.guavaJar");
        String gsonJar = System.getProperty("skillspanel.test.gsonJar");
        assertNotNull(geyserJar, "local-build.sh passes -Dskillspanel.test.geyserJar");
        java.net.URLClassLoader l = new java.net.URLClassLoader(new java.net.URL[]{
                java.nio.file.Path.of(geyserJar).toUri().toURL(),
                java.nio.file.Path.of(guavaJar).toUri().toURL(),
                java.nio.file.Path.of(gsonJar).toUri().toURL()},
                PanelTest.class.getClassLoader());
        java.util.logging.Logger log = java.util.logging.Logger.getLogger("skillspanel-test");
        java.util.function.IntConsumer noop = i -> {};
        Object ascii = BedrockForms.buildForm(l, "Skills", "Bar 62% \u2014 done",
                List.of("Close"), noop, log);
        Object content = ascii.getClass().getMethod("content").invoke(ascii);
        assertEquals("Bar 62% \u2014 done", content,
                "Cumulus retains the ASCII % — the loss is NOT in the plugin or Cumulus");
        String safeBody = PanelModel.bedrockSafe("Bar 62% \u2014 done");
        Object safe = BedrockForms.buildForm(l, "Skills", safeBody,
                List.of("Close"), noop, log);
        assertEquals(safeBody, safe.getClass().getMethod("content").invoke(safe),
                "Cumulus retains the fullwidth sign the 0.1.1 forms actually send");
    }
}
