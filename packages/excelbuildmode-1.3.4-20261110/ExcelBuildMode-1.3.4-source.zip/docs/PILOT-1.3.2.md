# ExcelBuildMode 1.3.2 — big paste (design + root cause)

An Excel plugin note for Wink Reyes Valley. October 21, 2026.
Approved by Mike, Oct 21, 2026, ~12:42 AM CDT.

## The problem (all verified from source, Oct 20–21, 2026)

1. The live WorldEdit 7.4.5 config is the pilot fragment:
   `limits.max-blocks-changed` default 5000 / maximum 5000. Every
   WorldEdit session starts at the config default, so every edit is
   capped at 5,000 blocks changed.
2. BuildPolicy blocks `//limit` inside Build Mode by design (the pilot
   safety set Mike signed off on; CoreTests pin "//limit -1" denied).
   The `worldedit.limit.unrestricted` node does NOT raise a session's
   starting limit — it only lets `//limit` exceed the config maximum —
   so inside Build Mode there was NO way to raise the cap at all.
3. Result: a Build Mode paste can never exceed 5,000 blocks. Marvin's
   village is 70,326 blocks (//copy bounding box 433,998). On Oct 20–21
   it had to run in Play Normally under a temporary LuckPerms
   `worldedit.*` grant, with a fragile order of operations: Build Mode's
   exit probe (ExcelBuildMode.removeAttachment) re-tests every
   WORLD_EDIT_PERMISSIONS node after removing its own attachment and
   fail-closes if any still reads true — so ANY external WorldEdit
   grant (the temporary wildcard, or OP, which is what broke the
   Oct 20, 7:53 PM exit) must be gone before exit, and entry refuses a
   player holding outside WorldEdit access at all.

## The fix (this delta, and nothing else)

- New permission node `excelbuildmode.bigpaste` (registered in
  plugin.yml, default false). It is OUR node, not a WorldEdit node, so
  it can be granted permanently (LuckPerms) with zero interaction with
  the entry/exit probes: neither probe set contains it, and the session
  attachment never grants it.
- While a Build Mode session's WorldEdit grant is in effect, the plugin
  raises the player's WorldEdit LocalSession block-change limit to the
  configured cap. The decision is pure (core/BigPastePolicy); the
  mechanics live in paper/WorldEditLimitBridge — the only class that
  imports WorldEdit types, invoked only when the WorldEdit plugin is
  enabled (the existing worldEdit gate), via the SessionManager session
  for the Bukkit-adapted player. WorldEdit 7.4.5's
  LocalSession.createEditSession reads getBlockChangeLimit() into the
  edit's maxBlocks (bytecode-verified), so the raised value is the
  value //copy and //paste actually enforce.
- The hook is inside attachSession, immediately after the session
  grant is probe-verified — the single funnel used by normal entry
  (port.enterBuild) AND relog-restore (restoreBuild), so both paths
  raise it and the states cannot drift. The landing hold attaches
  without the WorldEdit grant and never raises.
- The raise is logged at INFO (player name + UUID + the value the
  session reports after applying) for audit.
- Config knob `big-paste.block-change-limit`, built-in default
  1,000,000: a large FINITE cap, chosen over -1 (unlimited) on purpose.
  The biggest job on record is the village (70,326 changed blocks;
  433,998 copy bounding box); 1,000,000 covers it ~2.3x over while
  still bounding a runaway edit before it can eat the 3 GB server.
  A configured -1 is honored (an operator's deliberate choice);
  0 or below -1 falls back to the default. The live config file needs
  no edit — an absent key uses the default.

## What deliberately does NOT change

- `//limit` stays blocked by BuildPolicy for everyone, holders too.
- Entry and exit probes are byte-for-byte untouched; an external
  WorldEdit grant still fail-closes an exit (pinned by the unchanged
  code + change-scope diff).
- Non-holders keep exactly the WorldEdit config default (live: 5000).
- WorldEdit's own config is never edited; the pilot cap Mike signed
  stays in force for everyone except node holders, in session only.

## Side finding — //schem vs //schematic (Mike's live report, Oct 21)

On the live server `//schem` does not dispatch (WorldEdit 7.4.5's schem
alias is broken locally); `//schematic` works. That is a WorldEdit-side
alias fact, NOT a BuildPolicy defect: BuildPolicy normalizes the command
root (namespace and leading slashes stripped) and gates BOTH "schem"
and "schematic" on the identical subcommand set (load/save/list/
formats allowed with session WorldEdit; delete/rename/bare/unknown
denied). 1.3.2 pins that identity with a full sweep in PilotGateTests
(every root form x subcommand x WorldEdit shape). Player-facing steps
in the install packet use `//schematic`, the form that works live.

## Verification shape

- Base proven first: the untouched 1.3.1 tree rebuilt clean-room
  byte-identical to the shipped jar (SHA-256 5f8aaa86…) before the
  delta was applied.
- PilotGateTests gains: the big-paste decision matrix (holder /
  non-holder / no-grant / configured values / sanitize fallbacks),
  node-placement pins (never attached, never probed), //limit denial
  pins, the schem/schematic identity sweep, and an API-seam proof on
  real WorldEdit 7.4.5 LocalSession objects (raise lands, per-session
  isolation, cap clears 70,326 and 433,998).
- Exit-probe behavior (test d in the brief) is pinned by the unchanged
  probe code itself — the change-scope diff vs the verified 1.3.1 tree
  shows removeAttachment and enter() untouched — plus the existing
  suites; the paper layer has never had a Bukkit client simulation.
- Rig: boot on the scratch Paper 26.2-123 + WorldEdit 7.4.5 stack for
  a clean enable + banner. The rig cannot drive a real eligible-player
  Build Mode session (same stated limitation as 1.3/1.3.1); the
  end-to-end paste proof is Marvin's post-install player proof in the
  install packet.
