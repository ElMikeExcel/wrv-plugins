# ExcelBuildMode PILOT 1.3 — logout/login desync fix + full WorldEdit while building

Status: BUILT (fleet gate) — see the verification section for final test/probe results.
Date: October 20, 2026. Supersedes 1.2 for the pilot install; 1.2 jar is the rollback.

— An Excel plugin by Argus for Wink Reyes Valley.

## The bug (reported by Mike, Oct 20, 2026, relaying Marvin, the pilot builder)

"If you're in the air and log off, when you log back in you're in survival mode.
It lets you fly, and since you're in survival mode it still gives you the Jobs
exploration [pay] and etc."

## Root cause (pinned in the 1.2 source)

`ExcelBuildMode.onQuit` ran the full recovery for every guarded player.
Recovery of an airborne player cannot restore immediately, so
`SessionCoordinator.recover()` routed to `landingHold()`, which:

1. set the phase to LANDING (in-memory only),
2. **removed the session permission attachment** — the attachment carrying
   `jobs.use=false` and the WorldEdit nodes,
3. set Survival + `setAllowFlight(true)` + `setFlying(true)`, and
4. called `p.saveData()`, persisting Survival + flight into the player's
   playerdata file.

Phases do not survive a logout. On relog, the journal session and the
playerdata recovery marker correctly kept the player guarded, and `onJoin`
re-ran recovery — airborne again → `landingHold()` again — but the session
attachment was never re-created on that path, and recovery only completed
on the landing timer's exact safe-ground test. The resting state was
therefore Survival + flight enabled + Jobs paying normally, indefinitely:
the three things Build Mode exists to keep apart, combined. A grounded
logout already worked (recovery completed at quit); only the airborne
path desynced.

## The fix (design call: Mike, Oct 20, 2026 — Option 1)

A player who logs off in Build Mode is restored INTO Build Mode on relog —
gamemode, flight and the Jobs-suppression attachment return as one state,
airborne or not. The grounding variant (teleport/strip flight at logout or
relog) was rejected: it only patched the airborne symptom and cost the
builder his working position on every relog.

Implementation:

- New core `BuildReturnStore`: one small durable record per player
  (`plugins/ExcelBuildMode/build-return/<uuid>.return`, atomic write in the
  ReviewHoldStore style) binding the player to the recovery-journal session
  they entered Build Mode with. Written at the END of build entry, once the
  build state is fully in effect; cleared by every full survival restore
  and on death in Build Mode. The directory must be provisioned by the
  install (see the packet) — the store refuses to start without it and
  entry is disabled, same fail-closed posture as the other stores.
- New core `BuildReturnPolicy`: the pure relog decision. RESTORE_BUILD
  only when a record names the journal's currently active session;
  RECOVER_SURVIVAL (the standard recovery, landing hold included) when a
  session exists but the record is missing/corrupt/stale; FAIL_CLOSED when
  a guarded player has no journal session to stand on.
- `onQuit`: a BUILD-phase logout no longer runs recovery at all — the
  session attachment is detached (it cannot survive a logout), and
  vanilla persists the Creative gamemode, flight and build inventory.
- `onJoin` / enable-resume (`resumeOrRecover`): guarded players take the
  policy decision; RESTORE_BUILD re-applies Creative + flight and a FRESH
  session attachment via the same `attachSession()` used at entry, and
  tells the player they are still in Build Mode.
- `landingHold()` now attaches a Jobs-denied, no-WorldEdit session
  attachment instead of removing the attachment — no code path can persist
  Survival + flight with Jobs unsuppressed again. The glide-down landing
  itself is unchanged, and grounding logic lives ONLY in this
  corrupt/missing-state fallback, per the design call.
- Unchanged: the frozen Moon recovery core (journal, coordinator,
  snapshots, markers, review holds), restart semantics for players online
  at shutdown (graceful-stop recovery), death handling, all guards.

Hard invariant after 1.3: a relog NEVER yields Survival + flight + Jobs pay
together — the player returns fully in Build Mode or is fully restored to
survival (flight off, safe landing if airborne).

## WorldEdit: full ability set while building (Mike, Oct 20, 2026)

Marvin's in-mode WorldEdit never persisted as working nodes, and an
always-on LuckPerms `worldedit.*` grant was added live today to unbreak
his copy/paste. 1.3 makes the plugin itself the grantor:

- The session attachment now grants the full ability set whenever
  temporary WorldEdit is on — the `worldedit.*` wildcard PLUS every node
  of the previous fixed list granted explicitly — attached on entry AND
  on relog-restore, removed on every exit. It is never an always-on
  survival grant: relog can never yield Survival + WorldEdit (the
  fallback attachment shape is Jobs-denied, no WorldEdit). The explicit
  grants are not redundant: Bukkit wildcard expansion only covers
  permission children registered with the server, WorldEdit 7.4.5
  registers none in its plugin.yml, and the 1.3 runtime probe caught
  `worldedit.brush.smooth` resolving FALSE under a wildcard-only grant
  (1.2's explicit grant had covered it). Wildcard for the registered
  long tail, explicit for the known toolset.
- The previous fixed 41-node list is retained as the VERIFICATION PROBE
  set: entry/restore still fail unless representative nodes across
  selection/region/clipboard/history/brushes actually resolve, entry
  still refuses a player who already holds WorldEdit access from another
  source, and exit still proves the probes are gone.
- Note plainly: `worldedit.*` breadth necessarily includes nodes the 1.2
  curated list left out (e.g. `worldedit.brush.butcher`,
  `worldedit.history.undo.other`). That is the directed full set; it is
  bounded by Build Mode itself (Creative, guarded, recoverable, cohort
  allowlist) rather than by node curation.
- The install packet removes the always-on LuckPerms wildcard in the
  same window, sequenced AFTER the 1.3 jar is in place and boot-verified,
  so the pilot is never left with neither grant path.

## Verification

- Unit suites (build.sh, all green): CoreTests 5,709 assertions;
  RewardTests 5,283; RecoverySafetyTests 84; PlayerDataProofTests 145;
  PilotGateTests 58 (updated only where the directed WorldEdit grant shape
  and the build-return feature changed the contract); NEW
  BuildReturnTests 18 (store round-trip/overwrite/clear/corruption +
  the full relog decision matrix). Total 11,297 assertions.
- Runtime probe (Paper 26.2 build 123, real WorldEdit 7.4.5, fixture
  cohort, temporary-worldedit: true):
  - `normal` PASS 107 — entry grants Jobs denial + full WorldEdit
    (wildcard, brush, clipboard probes); grounded logout → relog restores
    Build Mode with the "still in Build Mode" message; AIRBORNE logout →
    relog restores Build Mode (flight on, Jobs denied, WorldEdit
    granted), invariant check explicit; clean exits restore the seeded
    survival inventory byte-exact and remove the WorldEdit grant; the
    pre-1.3 scenarios (unauthorized entry, canceled Creative, save
    failure lock, death recovery, foreign mode change) all still pass.
  - `restart-seed` PASS 5 + `restart-recover` PASS 16 — two-JVM proof:
    build state persisted, new JVM discovers the journal, join restores
    Build Mode (build inventory intact, snapshot untouched), voluntary
    exit then restores the seeded survival state byte-exact.
  - `return-corrupt` PASS 34 — corrupt record → full survival recovery;
    missing record → full survival recovery; airborne + corrupt record →
    LANDING glide with Jobs STILL denied and no WorldEdit, completing to
    a byte-exact survival restore on landing.
- Clean-room rebuild: byte-identical. Jar: ExcelBuildMode-1.3.jar,
  86,987 bytes, SHA-256
  5f50d985aa9cf36c08957c8dda1d48366e89f55c1f29682d69ed8f00d792d358.
- Not provable headless: a real client's airborne relog (the probe
  replays join/quit events on a constructed player; the playerdata
  round-trip itself is covered by PlayerDataProofTests and the two-JVM
  probe), and an actual WorldEdit brush EXECUTION (permission resolution
  is probed; command execution is WorldEdit's own code). Both are the
  post-install player proofs in the packet (Marvin: enter → brush →
  exit → brush denied; one airborne logout/relog).

## Install summary

Jar swap at a server restart with nobody in Build Mode; provision
`plugins/ExcelBuildMode/build-return/` first; preserve config, cohort and
all existing recovery data; then remove the always-on LuckPerms
`worldedit.*` grant from the pilot (see INSTALL-PACKET-1.3.md for the
exact ordered steps and rollback). No config value changes: the existing
live `temporary-worldedit: true` stays as it is.
