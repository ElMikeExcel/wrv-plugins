# ExcelBuildMode 1.3.3 — console admin (design + root cause)

An Excel plugin note for Wink Reyes Valley. November 10, 2026.
Commissioned from the console-admin coverage audit (Nov 9, 2026,
AUDIT.md §4), under Mike's Nov 3, 2026 console-admin rule.

## The problem (verified from the 1.3.2 source, Nov 9–10, 2026)

1. The sole command `/buildmode [on|off|status]` opens with
   `if (!(sender instanceof Player p))` and replies "Use /buildmode
   in game. It only changes your own mode." — the console cannot run
   any form of it.
2. plugin.yml declares only `excelbuildmode.use` and
   `excelbuildmode.bigpaste` (both default false). There is no admin
   node at all.
3. Build Mode sessions are DURABLE state — a Survival snapshot in the
   recovery journal, a session index entry, a native playerdata
   marker. A session can wedge (landing hold, failed-closed recovery,
   a builder who cannot get back in), and through 1.3.2 an operator
   at the console had no way to inspect that state or force its
   restore. That is exactly the support case the Nov 3 rule exists
   for; the audit graded 1.3.2 FAIL (support-critical).

## The fix (this delta, and nothing else)

Shaped on the AutoSort 0.2.1 precedent: one minor bump, admin
subcommands on the existing command, a new op-default admin node,
console explicitly allowed, player-facing paths behavior-unchanged,
harness tests for the new subcommands.

- New permission node `excelbuildmode.admin` (plugin.yml, default
  **op** — deliberately NOT default false like the use nodes, so an
  operator holds it by the ordinary op rule and the console by the
  explicit bypass below). It is our node, never granted by a session
  attachment and not in the WorldEdit probe set, so holding it trips
  neither the entry probe nor the exit probe (harness-pinned).
- New pure core class `AdminPolicy`: routing, the gate, target
  classification, and the force-off decision — no Bukkit types, so
  every branch is harness-testable. The gate is the ExcelCosmetics /
  ExcelBrainGames shape: `console || holdsAdmin`.
- `ExcelBuildMode.onCommand` routes the admin branch BEFORE the
  player-only gate. Forms:
  - `/buildmode admin status <player>` — online: live phase, journal
    session id when active, review-hold flag. Offline: any durable
    record (active journal session / review hold) is reported as
    such. A name that is neither online nor on record is reported
    unknown — never guessed.
  - `/buildmode admin off <player>` — for an online target, decides
    via `AdminPolicy.decideOff` and then calls the SAME `recover()`
    the player paths, join path and periodic sweep call, which
    delegates to `SessionCoordinator.recover`. There is no second
    restore implementation. Outcomes are interpreted from the
    resulting phase and reported to the operator, and an INFO audit
    line names the actor (CONSOLE or operator name), the target, and
    the outcome.
  - Denial for a sender without the gate precedes all target
    handling; malformed admin calls get one usage line.
- Deliberate limits, stated plainly:
  - A review-held player is NOT force-restored: `recover()` itself
    refuses those fail-closed, and the admin surface reports the
    hold instead of kicking the player through the failure path.
    A hold clears only by the administrator verification that the
    hold mechanism exists for.
  - An offline target's live restore cannot run (the restore
    mutates a live player). The journal record is durable and the
    existing join recovery restores it at the next join; admin off
    for an offline session says exactly that and changes nothing.
  - Non-admin invocations are byte-for-byte the 1.3.2 behavior,
    including the console rejection on the player paths and tab
    completion for non-admin players (admin completions appear only
    for senders who pass the gate).
- plugin.yml: version 1.3.3, the admin permission, the usage line
  naming both admin forms, the description line. config.yml is
  untouched — the swap needs no config edit and the live config is
  preserved.

## Proof shape

- AdminTests (new seventh suite in build.sh): the gate matrix
  (console allowed, operator allowed, non-admin denied), the full
  routing matrix incl. case-insensitivity and usage errors, the
  player-path regression pins (every pre-1.3.3 shape routes to the
  player path for every sender kind), target classification incl.
  the unknown case, the off-decision matrix, the plugin.yml pins
  (admin default op; use/bigpaste still default false; admin node
  absent from the session attachment and the WorldEdit probe set) —
  and the exercised restore the audit required: a session entered
  through the real SessionCoordinator until stuck is force-restored
  through that coordinator's recover(), with the Survival bytes
  verified byte-for-byte and journal/index/marker/guard all
  completing; a redundant off is a clean no-op; a review-held and a
  storage-unready session are left untouched by their refusals.
- The six carried suites pass unmodified.
- Rig boot on Paper 26.2-123 + WorldEdit 7.4.5 with the rig's
  synthetic eligible builder: clean 1.3.3 enable + banner, zero
  SEVERE, and the console itself exercises `admin status` /
  `admin off` against an unknown name, the usage forms, the admin
  denial-free console path, and the unchanged console rejection on
  the player path. Rig limitation, stated plainly: the rig has no
  real client, so no live in-session force-restore runs there —
  that leg is the harness exercise above plus the post-install
  player proof in the install packet.
