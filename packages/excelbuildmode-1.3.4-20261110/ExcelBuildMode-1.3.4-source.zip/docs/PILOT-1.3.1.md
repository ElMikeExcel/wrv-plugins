# ExcelBuildMode 1.3.1 — PILOT hotfix record

An Excel plugin by Argus for Wink Reyes Valley. October 20–21, 2026.

## The defect (confirmed live)

Marvin, in Build Mode on the live server (Oct 20, 2026, 7:46 PM CDT,
screenshot to Mike): `//schem load medieval-village-130red` was CANCELLED
by ExcelBuildMode's command guard — "Build Mode » Switch to Play Normally
to use that command." The village paste workflow hands the builder
`//schem load` + `//schem save` to run from inside Build Mode (the safe
creative session with the survival snapshot), but 1.3's
`BuildPolicy.allowsCommand` allowlist (EDIT_COMMANDS) never included the
schematic family, so the guard treated it like an admin command. Play
Normally was a dead end by design (no WorldEdit outside the session).

## The fix (one policy function + version/banner strings)

`BuildPolicy.allowsCommand`: after the existing normalization (leading
slash root, `worldedit:` namespace strip) and only when session WorldEdit
is active (`worldEdit=true`), the bare root `schem` / `schematic` (covers
`//schem`, `//schematic`, `/schem`, `/worldedit:schem`,
`/worldedit:/schem`) is gated by SUBCOMMAND:

- ALLOW: `load`, `save`, `list`, `formats`
- DENY (falls through to the existing guard message): `delete`, `rename`,
  any other subcommand, and a bare `//schem` with no subcommand.

No other behavior changes: without session WorldEdit the family stays
denied like every edit command; jobs/gamemode/economy/shop commands stay
denied while building; permissions, snapshots, recovery, grants untouched.

## Tests

- PilotGateTests 58 → 75: 17 new literal-string checks (the exact blocked
  command `//schem load medieval-village-130red` allowed with session WE
  and denied without; save/list/formats; delete/rename/bare/unknown
  denied; `//schematic` alias; both namespaced forms; case-insensitivity;
  independence from the chat/help toggle).
- CoreTests policy list updated: `//schem load foo` left the
  denied-with-WE list; `//schem delete foo` + `//schem rename a b` added.
  CoreTests 5,709 → 5,710.
- Full suite: 11,315 assertions, six suites green (Core 5,710; Reward
  5,283; RecoverySafety 84; PlayerDataProof 145; PilotGate 75;
  BuildReturn 18).
- Base verification BEFORE the delta: a clean-room copy of the untouched
  1.3 tree rebuilt byte-identical to the shipped jar
  (5f50d985aa9cf36c08957c8dda1d48366e89f55c1f29682d69ed8f00d792d358).
- Clean-room rebuild of 1.3.1 byte-identical.
- Rig boot (Paper 26.2-123 + WorldEdit 7.4.5, live-shaped config:
  pilot-construction-only true, temporary-worldedit true, cohort replicas
  + storage provisioned): "Enabling ExcelBuildMode v1.3.1" + the 1.3.1
  PILOT banner, Done, ZERO SEVERE, clean stop.
- A rig-side live command-event probe was NOT run (needs a real eligible
  player session; the 1.3 fixture harness was not re-run for this
  one-function policy delta). The end-to-end proof is Marvin's retry
  post-install (see INSTALL-PACKET-1.3.1.md).
