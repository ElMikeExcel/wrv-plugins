package com.winkreyes.excelnophantoms;

import org.bukkit.entity.EntityType;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.junit.jupiter.api.Test;

import java.time.ZonedDateTime;
import java.util.List;

import static org.mockito.Mockito.*;

/**
 * Listener contract. The two 1.1.0 tests are kept (adapted: with no
 * config loaded the gate fails soft to suppress, exactly like 1.1.0's
 * blanket cancel); the rest prove the listener truly delegates to the
 * PhantomGate in event mode.
 */
class ExcelNoPhantomsTest {

    private static ZonedDateTime chicago(int dayOfOctober2026, int hour) {
        return ZonedDateTime.of(2026, 10, dayOfOctober2026, hour, 0, 0, 0, PhantomGate.CHICAGO);
    }

    private static CreatureSpawnEvent spawnOf(EntityType type) {
        CreatureSpawnEvent event = mock(CreatureSpawnEvent.class);
        when(event.getEntityType()).thenReturn(type);
        return event;
    }

    private static GateConfig eventConfig() {
        return GateConfig.of(PhantomGate.Mode.EVENT, true,
                List.of("line one", "line two"), 25, "wards", true);
    }

    @Test
    void phantomSpawnsAreCancelled() {
        // No config at all (the mock never ran onEnable): fail-soft == 1.1.0.
        ExcelNoPhantoms plugin = mock(ExcelNoPhantoms.class, CALLS_REAL_METHODS);
        CreatureSpawnEvent event = spawnOf(EntityType.PHANTOM);
        plugin.onCreatureSpawn(event);
        verify(event).setCancelled(true);
    }

    @Test
    void otherCreaturesAreUnaffected() {
        ExcelNoPhantoms plugin = mock(ExcelNoPhantoms.class, CALLS_REAL_METHODS);
        CreatureSpawnEvent event = spawnOf(EntityType.COW);
        plugin.onCreatureSpawn(event);
        verify(event, never()).setCancelled(anyBoolean());
    }

    @Test
    void eventModeHauntedTuesdayAllowsPhantom() {
        ExcelNoPhantoms plugin = mock(ExcelNoPhantoms.class, CALLS_REAL_METHODS);
        plugin.gateConfig = eventConfig();
        plugin.clock = () -> chicago(20, 21); // Tuesday Oct 20, 2026
        plugin.dragonSealReader = () -> Boolean.FALSE;
        CreatureSpawnEvent event = spawnOf(EntityType.PHANTOM);
        plugin.onCreatureSpawn(event);
        verify(event, never()).setCancelled(anyBoolean());
    }

    @Test
    void eventModeWardFridaySuppressesPhantom() {
        ExcelNoPhantoms plugin = mock(ExcelNoPhantoms.class, CALLS_REAL_METHODS);
        plugin.gateConfig = eventConfig();
        plugin.clock = () -> chicago(23, 21); // Friday Oct 23, 2026
        plugin.dragonSealReader = () -> Boolean.FALSE;
        CreatureSpawnEvent event = spawnOf(EntityType.PHANTOM);
        plugin.onCreatureSpawn(event);
        verify(event).setCancelled(true);
    }

    @Test
    void eventModeBrokenSealSuppressesEvenOnTuesday() {
        ExcelNoPhantoms plugin = mock(ExcelNoPhantoms.class, CALLS_REAL_METHODS);
        plugin.gateConfig = eventConfig();
        plugin.clock = () -> chicago(20, 21); // Tuesday
        plugin.dragonSealReader = () -> Boolean.TRUE;
        CreatureSpawnEvent event = spawnOf(EntityType.PHANTOM);
        plugin.onCreatureSpawn(event);
        verify(event).setCancelled(true);
    }

    @Test
    void eventModeNeverCancelsNonPhantoms() {
        ExcelNoPhantoms plugin = mock(ExcelNoPhantoms.class, CALLS_REAL_METHODS);
        plugin.gateConfig = eventConfig();
        plugin.clock = () -> chicago(23, 21); // Friday: phantoms suppressed...
        plugin.dragonSealReader = () -> Boolean.FALSE;
        CreatureSpawnEvent event = spawnOf(EntityType.ZOMBIE); // ...but nothing else is touched
        plugin.onCreatureSpawn(event);
        verify(event, never()).setCancelled(anyBoolean());
    }
}
