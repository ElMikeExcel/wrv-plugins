package com.winkreyes.excelnophantoms;

import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Broadcast contract: the haunted-night story rotation (StoryRotator)
 * and the once-per-evening ward line (WardLineTracker). Chicago dates:
 * Tue Oct 20 and Fri Oct 23, 2026. Night window = world time 13000-23000.
 */
class BroadcastTest {

    private static final long NIGHT = 15000L;
    private static final long DAY = 6000L;
    private static final Instant T0 = Instant.parse("2026-10-21T01:00:00Z");

    private static ZonedDateTime chicago(int day, int hour) {
        return ZonedDateTime.of(2026, 10, day, hour, 0, 0, 0, PhantomGate.CHICAGO);
    }

    private static ZonedDateTime tueNight() {
        return chicago(20, 20);
    }

    private static ZonedDateTime friNight() {
        return chicago(23, 20);
    }

    private static GateConfig eventWith(List<String> lines, int interval, boolean wardsEnabled) {
        return GateConfig.of(PhantomGate.Mode.EVENT, true, lines, interval, "wards hold", wardsEnabled);
    }

    // ---------------- Story rotation ----------------

    @Test
    void rotationAdvancesThroughAllLinesAndWraps() {
        GateConfig cfg = eventWith(List.of("L1", "L2", "L3"), 25, true);
        StoryRotator rotator = new StoryRotator(0);
        assertEquals(Optional.of("L1"), rotator.tryFire(cfg, Boolean.FALSE, tueNight(), NIGHT, 2, T0));
        assertEquals(Optional.of("L2"), rotator.tryFire(cfg, Boolean.FALSE, tueNight(), NIGHT, 2, T0.plusSeconds(25 * 60)));
        assertEquals(Optional.of("L3"), rotator.tryFire(cfg, Boolean.FALSE, tueNight(), NIGHT, 2, T0.plusSeconds(50 * 60)));
        assertEquals(Optional.of("L1"), rotator.tryFire(cfg, Boolean.FALSE, tueNight(), NIGHT, 2, T0.plusSeconds(75 * 60)), "wraps to first");
        assertEquals(1, rotator.nextIndex());
    }

    @Test
    void rotationRespectsTheInterval() {
        GateConfig cfg = eventWith(List.of("L1", "L2"), 25, true);
        StoryRotator rotator = new StoryRotator(0);
        assertTrue(rotator.tryFire(cfg, Boolean.FALSE, tueNight(), NIGHT, 1, T0).isPresent());
        assertTrue(rotator.tryFire(cfg, Boolean.FALSE, tueNight(), NIGHT, 1, T0.plusSeconds(24 * 60)).isEmpty(), "24 min < interval");
        assertTrue(rotator.tryFire(cfg, Boolean.FALSE, tueNight(), NIGHT, 1, T0.plusSeconds(25 * 60)).isPresent(), "25 min = interval");
    }

    @Test
    void restartResumesPersistedIndexAndFiresPromptly() {
        GateConfig cfg = eventWith(List.of("L1", "L2", "L3"), 25, true);
        StoryRotator before = new StoryRotator(0);
        assertEquals(Optional.of("L1"), before.tryFire(cfg, Boolean.FALSE, tueNight(), NIGHT, 1, T0));
        // Simulated restart: a fresh rotator rebuilt from the persisted
        // index. The last-fired instant is in-memory only, so the next
        // line is due on the first eligible check after boot.
        StoryRotator after = new StoryRotator(before.nextIndex());
        assertEquals(Optional.of("L2"), after.tryFire(cfg, Boolean.FALSE, tueNight(), NIGHT, 1, T0.plusSeconds(5 * 60)));
    }

    @Test
    void rotationSilentInDaytime() {
        GateConfig cfg = eventWith(List.of("L1"), 25, true);
        StoryRotator rotator = new StoryRotator(0);
        assertTrue(rotator.tryFire(cfg, Boolean.FALSE, tueNight(), DAY, 2, T0).isEmpty());
        assertTrue(rotator.tryFire(cfg, Boolean.FALSE, tueNight(), 12999L, 2, T0).isEmpty(), "just before nightfall");
        assertTrue(rotator.tryFire(cfg, Boolean.FALSE, tueNight(), 23001L, 2, T0).isEmpty(), "just after the window");
        assertTrue(rotator.tryFire(cfg, Boolean.FALSE, tueNight(), 13000L, 2, T0).isPresent(), "window start fires");
    }

    @Test
    void rotationSilentWithNobodyOnline() {
        GateConfig cfg = eventWith(List.of("L1"), 25, true);
        assertTrue(new StoryRotator(0).tryFire(cfg, Boolean.FALSE, tueNight(), NIGHT, 0, T0).isEmpty());
    }

    @Test
    void rotationSilentOnWardNight() {
        GateConfig cfg = eventWith(List.of("L1"), 25, true);
        assertTrue(new StoryRotator(0).tryFire(cfg, Boolean.FALSE, friNight(), NIGHT, 2, T0).isEmpty(), "Friday is wards, not story");
    }

    @Test
    void rotationSilentWhenEventInactiveAlwaysOffOrSealBroken() {
        GateConfig inactive = GateConfig.of(PhantomGate.Mode.EVENT, false, List.of("L1"), 25, "w", true);
        GateConfig alwaysOff = GateConfig.of(PhantomGate.Mode.ALWAYS_OFF, true, List.of("L1"), 25, "w", true);
        GateConfig live = eventWith(List.of("L1"), 25, true);
        assertTrue(new StoryRotator(0).tryFire(inactive, Boolean.FALSE, tueNight(), NIGHT, 2, T0).isEmpty(), "event-active=false");
        assertTrue(new StoryRotator(0).tryFire(alwaysOff, Boolean.FALSE, tueNight(), NIGHT, 2, T0).isEmpty(), "always-off");
        assertTrue(new StoryRotator(0).tryFire(live, Boolean.TRUE, tueNight(), NIGHT, 2, T0).isEmpty(), "seal broken");
    }

    @Test
    void customIntervalAndLinesFromConfigAreUsed() {
        GateConfig cfg = eventWith(List.of("X", "Y"), 5, true);
        StoryRotator rotator = new StoryRotator(0);
        assertEquals(Optional.of("X"), rotator.tryFire(cfg, Boolean.FALSE, tueNight(), NIGHT, 1, T0));
        assertTrue(rotator.tryFire(cfg, Boolean.FALSE, tueNight(), NIGHT, 1, T0.plusSeconds(4 * 60)).isEmpty());
        assertEquals(Optional.of("Y"), rotator.tryFire(cfg, Boolean.FALSE, tueNight(), NIGHT, 1, T0.plusSeconds(5 * 60)));
    }

    @Test
    void malformedStoryLinesMeanNoBroadcastsButTheGateStillWorks() {
        List<String> warnings = new ArrayList<>();
        GateConfig cfg = GateConfig.fromRaw("event", true, "not-a-list", 25, "wards", true, warnings::add);
        assertTrue(cfg.storyMalformed());
        assertTrue(cfg.storyLines().isEmpty());
        assertTrue(new StoryRotator(0).tryFire(cfg, Boolean.FALSE, tueNight(), NIGHT, 2, T0).isEmpty(),
                "no broadcasts from a malformed story config");
        assertEquals(PhantomGate.Decision.ALLOW,
                PhantomGate.decide(cfg, Boolean.FALSE, tueNight()), "the gate itself is unaffected");
    }

    @Test
    void emptyStoryLinesMeanNoBroadcasts() {
        List<String> warnings = new ArrayList<>();
        GateConfig cfg = GateConfig.fromRaw("event", true, List.of(), 25, "wards", true, warnings::add);
        assertTrue(cfg.storyMalformed());
        assertTrue(new StoryRotator(0).tryFire(cfg, Boolean.FALSE, tueNight(), NIGHT, 2, T0).isEmpty());
    }

    // ---------------- Ward line ----------------

    @Test
    void wardLineFiresOncePerWardEveningAcrossRestarts() {
        GateConfig cfg = eventWith(List.of("L1"), 25, true);
        WardLineTracker tracker = new WardLineTracker(null);
        assertTrue(tracker.tryFire(cfg, Boolean.FALSE, friNight(), NIGHT, 1), "first nightfall check");
        assertFalse(tracker.tryFire(cfg, Boolean.FALSE, friNight(), NIGHT, 1), "same evening again");
        // Simulated restart with the persisted date: still no refire.
        WardLineTracker restarted = new WardLineTracker(tracker.lastFiredDate());
        assertFalse(restarted.tryFire(cfg, Boolean.FALSE, friNight(), NIGHT, 3), "after restart, same evening");
        // The next ward evening (Saturday) fires again.
        assertTrue(restarted.tryFire(cfg, Boolean.FALSE, chicago(24, 20), NIGHT, 1), "Saturday evening");
    }

    @Test
    void wardLineSilentOnHauntedNightsAndWhenEnded() {
        GateConfig cfg = eventWith(List.of("L1"), 25, true);
        assertFalse(new WardLineTracker(null).tryFire(cfg, Boolean.FALSE, tueNight(), NIGHT, 1), "Tuesday is story, not wards");
        assertFalse(new WardLineTracker(null).tryFire(cfg, Boolean.TRUE, friNight(), NIGHT, 1), "seal broken = ended");
        GateConfig inactive = GateConfig.of(PhantomGate.Mode.EVENT, false, List.of("L1"), 25, "w", true);
        assertFalse(new WardLineTracker(null).tryFire(inactive, Boolean.FALSE, friNight(), NIGHT, 1), "event-active=false");
        GateConfig alwaysOff = GateConfig.of(PhantomGate.Mode.ALWAYS_OFF, true, List.of("L1"), 25, "w", true);
        assertFalse(new WardLineTracker(null).tryFire(alwaysOff, Boolean.FALSE, friNight(), NIGHT, 1), "always-off");
    }

    @Test
    void wardLineNeedsNightPlayersAndTheEnabledFlag() {
        GateConfig cfg = eventWith(List.of("L1"), 25, true);
        assertFalse(new WardLineTracker(null).tryFire(cfg, Boolean.FALSE, friNight(), DAY, 1), "daytime");
        assertFalse(new WardLineTracker(null).tryFire(cfg, Boolean.FALSE, friNight(), NIGHT, 0), "nobody online");
        GateConfig disabled = eventWith(List.of("L1"), 25, false);
        assertFalse(new WardLineTracker(null).tryFire(disabled, Boolean.FALSE, friNight(), NIGHT, 1), "wards-line-enabled: false");
    }
}
