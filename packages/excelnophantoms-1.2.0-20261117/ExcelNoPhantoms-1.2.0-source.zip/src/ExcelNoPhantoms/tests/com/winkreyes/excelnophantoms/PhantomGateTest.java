package com.winkreyes.excelnophantoms;

import org.junit.jupiter.api.Test;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * The PhantomGate truth table (Oct 2026 Chicago dates: Mon 19, Tue 20,
 * Wed 21, Thu 22, Fri 23, Sat 24, Sun 25) plus the fail-soft config rules.
 */
class PhantomGateTest {

    private static ZonedDateTime at(int day, int hour, int minute, int second) {
        return ZonedDateTime.of(2026, 10, day, hour, minute, second, 0, PhantomGate.CHICAGO);
    }

    private static GateConfig event(boolean active) {
        return GateConfig.of(PhantomGate.Mode.EVENT, active,
                List.of("l1", "l2"), 25, "wards", true);
    }

    private static GateConfig parsed(Object mode, Object active, Object story,
                                     List<String> warnings) {
        return GateConfig.fromRaw(mode, active, story, 25, "wards", true, warnings::add);
    }

    @Test
    void weekdayTruthTableEventMode() {
        GateConfig cfg = event(true);
        // Mon-Thu ALLOW, Fri-Sun SUPPRESS, seal not broken.
        assertEquals(PhantomGate.Decision.ALLOW, PhantomGate.decide(cfg, Boolean.FALSE, at(19, 12, 0, 0)), "Mon");
        assertEquals(PhantomGate.Decision.ALLOW, PhantomGate.decide(cfg, Boolean.FALSE, at(20, 12, 0, 0)), "Tue");
        assertEquals(PhantomGate.Decision.ALLOW, PhantomGate.decide(cfg, Boolean.FALSE, at(21, 12, 0, 0)), "Wed");
        assertEquals(PhantomGate.Decision.ALLOW, PhantomGate.decide(cfg, Boolean.FALSE, at(22, 12, 0, 0)), "Thu");
        assertEquals(PhantomGate.Decision.SUPPRESS, PhantomGate.decide(cfg, Boolean.FALSE, at(23, 12, 0, 0)), "Fri");
        assertEquals(PhantomGate.Decision.SUPPRESS, PhantomGate.decide(cfg, Boolean.FALSE, at(24, 12, 0, 0)), "Sat");
        assertEquals(PhantomGate.Decision.SUPPRESS, PhantomGate.decide(cfg, Boolean.FALSE, at(25, 12, 0, 0)), "Sun");
    }

    @Test
    void midnightBoundaries() {
        GateConfig cfg = event(true);
        assertEquals(PhantomGate.Decision.ALLOW, PhantomGate.decide(cfg, Boolean.FALSE, at(22, 23, 59, 59)), "Thu 23:59:59");
        assertEquals(PhantomGate.Decision.SUPPRESS, PhantomGate.decide(cfg, Boolean.FALSE, at(23, 0, 0, 0)), "Fri 00:00:00");
        assertEquals(PhantomGate.Decision.SUPPRESS, PhantomGate.decide(cfg, Boolean.FALSE, at(25, 23, 59, 59)), "Sun 23:59:59");
        assertEquals(PhantomGate.Decision.ALLOW, PhantomGate.decide(cfg, Boolean.FALSE, at(26, 0, 0, 0)), "Mon 00:00:00");
    }

    @Test
    void eventInactiveSuppressesAllWeek() {
        GateConfig cfg = event(false);
        for (int day = 19; day <= 25; day++) {
            assertEquals(PhantomGate.Decision.SUPPRESS,
                    PhantomGate.decide(cfg, Boolean.FALSE, at(day, 12, 0, 0)), "day " + day);
        }
    }

    @Test
    void alwaysOffSuppressesAllWeek() {
        GateConfig cfg = GateConfig.of(PhantomGate.Mode.ALWAYS_OFF, true,
                List.of("l1"), 25, "wards", true);
        for (int day = 19; day <= 25; day++) {
            assertEquals(PhantomGate.Decision.SUPPRESS,
                    PhantomGate.decide(cfg, Boolean.FALSE, at(day, 12, 0, 0)), "day " + day);
            assertEquals(PhantomGate.Decision.SUPPRESS,
                    PhantomGate.decide(cfg, null, at(day, 12, 0, 0)), "day " + day + " seal unknown");
        }
    }

    @Test
    void brokenDragonSealSuppressesEvenOnTuesday() {
        assertEquals(PhantomGate.Decision.SUPPRESS,
                PhantomGate.decide(event(true), Boolean.TRUE, at(20, 12, 0, 0)));
    }

    @Test
    void unreadableSealLetsFlagAndWeekdayGovern() {
        assertEquals(PhantomGate.Decision.ALLOW,
                PhantomGate.decide(event(true), null, at(20, 12, 0, 0)), "Tue, seal unknown");
        assertEquals(PhantomGate.Decision.SUPPRESS,
                PhantomGate.decide(event(true), null, at(23, 12, 0, 0)), "Fri, seal unknown");
        assertEquals(PhantomGate.Decision.SUPPRESS,
                PhantomGate.decide(event(false), null, at(20, 12, 0, 0)), "flag off, seal unknown");
    }

    @Test
    void badModeStringFailsSoftToAlwaysSuppress() {
        List<String> warnings = new ArrayList<>();
        GateConfig cfg = parsed("haunted", true, List.of("l1"), warnings);
        assertTrue(cfg.malformed());
        assertEquals(PhantomGate.Mode.ALWAYS_OFF, cfg.effectiveMode());
        assertFalse(warnings.isEmpty());
        for (int day = 19; day <= 25; day++) {
            assertEquals(PhantomGate.Decision.SUPPRESS,
                    PhantomGate.decide(cfg, Boolean.FALSE, at(day, 12, 0, 0)), "day " + day);
        }
    }

    @Test
    void missingGateKeysFailSoftToAlwaysSuppress() {
        List<String> warnings = new ArrayList<>();
        GateConfig cfg = parsed(null, null, List.of("l1"), warnings);
        assertTrue(cfg.malformed());
        assertEquals(PhantomGate.Decision.SUPPRESS,
                PhantomGate.decide(cfg, Boolean.FALSE, at(20, 12, 0, 0)), "Tue with missing keys");
    }

    @Test
    void wrongGateValueTypesFailSoftToAlwaysSuppress() {
        List<String> warnings = new ArrayList<>();
        GateConfig cfg = parsed(42, "yes", List.of("l1"), warnings);
        assertTrue(cfg.malformed());
        assertEquals(PhantomGate.Mode.ALWAYS_OFF, cfg.effectiveMode());
        assertEquals(PhantomGate.Decision.SUPPRESS,
                PhantomGate.decide(cfg, Boolean.FALSE, at(20, 12, 0, 0)), "Tue with wrong types");
    }

    @Test
    void nullConfigAndNullTimeFailSoft() {
        assertEquals(PhantomGate.Decision.SUPPRESS,
                PhantomGate.decide(null, Boolean.FALSE, at(20, 12, 0, 0)));
        assertEquals(PhantomGate.Decision.SUPPRESS,
                PhantomGate.decide(event(true), Boolean.FALSE, null));
    }

    @Test
    void tonightLabels() {
        assertTrue(PhantomGate.tonightLabel(event(true), Boolean.FALSE, at(20, 12, 0, 0))
                .contains("HAUNTED tonight (Tuesday)"));
        assertTrue(PhantomGate.tonightLabel(event(true), Boolean.FALSE, at(23, 12, 0, 0))
                .contains("WARDS HOLD tonight (Friday)"));
        assertTrue(PhantomGate.tonightLabel(event(false), Boolean.FALSE, at(20, 12, 0, 0))
                .contains("ENDED"));
        assertTrue(PhantomGate.tonightLabel(event(true), Boolean.TRUE, at(20, 12, 0, 0))
                .contains("ENDED"));
        assertTrue(PhantomGate.tonightLabel(GateConfig.safeDefault(), null, at(20, 12, 0, 0))
                .contains("always-off"));
    }
}
