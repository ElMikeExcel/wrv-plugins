package com.winkreyes.excelnophantoms;

import java.time.DayOfWeek;
import java.time.ZoneId;
import java.time.ZonedDateTime;

/**
 * Pure Phantom Debt gate: decides whether a phantom spawn is SUPPRESSed
 * (cancelled) or ALLOWed (vanilla insomnia rules take it from there).
 *
 * No Bukkit dependencies, so the whole truth table is unit-testable on a
 * plain JVM. The plugin's listener delegates here for every phantom
 * CreatureSpawnEvent, of any spawn reason (parity with 1.1.0's blanket
 * cancel, narrowed only by this gate).
 *
 * Semantics (Mike's design, approved Oct 18, 2026):
 * - mode always-off: SUPPRESS always. A bare install reproduces 1.1.0.
 * - mode event + eventActive + dragon seal not broken:
 *     Chicago Mon/Tue/Wed/Thu -> ALLOW (haunted nights)
 *     Chicago Fri/Sat/Sun     -> SUPPRESS (the guild's wards hold)
 * - mode event but eventActive=false, or the dragon seal is broken:
 *     SUPPRESS always (the event has ENDED).
 * - dragonSealBroken == null means "unreadable" (GuildGate absent or its
 *   state not yet bound): the operator flag and the weekday govern alone.
 * - A malformed gate config is carried as GateConfig.malformed and this
 *   class is only ever consulted with the config's EFFECTIVE mode, which
 *   is always-off when malformed: fail soft to always-suppress, the
 *   kids'-server safe default.
 */
public final class PhantomGate {

    public enum Mode { ALWAYS_OFF, EVENT }

    public enum Decision { SUPPRESS, ALLOW }

    /** The one timezone the valley runs on. */
    public static final ZoneId CHICAGO = ZoneId.of("America/Chicago");

    /** Overworld night range used by both broadcast paths (vanilla
     *  phantom-spawn hours are world time ~12300-23850; the story/ward
     *  checks use the round 13000-23000 nightfall-to-late-night window). */
    public static final long NIGHT_START_TICKS = 13000L;
    public static final long NIGHT_END_TICKS = 23000L;

    private PhantomGate() {
    }

    /** True on a haunted weekday (Chicago Mon-Thu). */
    public static boolean isHauntedWeekday(DayOfWeek day) {
        return day == DayOfWeek.MONDAY || day == DayOfWeek.TUESDAY
                || day == DayOfWeek.WEDNESDAY || day == DayOfWeek.THURSDAY;
    }

    /** True when the event is live tonight apart from the weekday:
     *  event mode, operator flag on, dragon seal not known-broken. */
    public static boolean eventLive(GateConfig config, Boolean dragonSealBroken) {
        return config != null
                && config.effectiveMode() == Mode.EVENT
                && config.eventActive()
                && !Boolean.TRUE.equals(dragonSealBroken);
    }

    /** True when tonight is a haunted night (event live + Mon-Thu). */
    public static boolean isHauntedNight(GateConfig config, Boolean dragonSealBroken,
                                           ZonedDateTime nowChicago) {
        return eventLive(config, dragonSealBroken)
                && nowChicago != null
                && isHauntedWeekday(nowChicago.getDayOfWeek());
    }

    /** True when tonight is a ward night (event live + Fri/Sat/Sun). */
    public static boolean isWardNight(GateConfig config, Boolean dragonSealBroken,
                                      ZonedDateTime nowChicago) {
        return eventLive(config, dragonSealBroken)
                && nowChicago != null
                && !isHauntedWeekday(nowChicago.getDayOfWeek());
    }

    /** The gate itself. Null config / null time fail soft to SUPPRESS. */
    public static Decision decide(GateConfig config, Boolean dragonSealBroken,
                                  ZonedDateTime nowChicago) {
        if (config == null || nowChicago == null) {
            return Decision.SUPPRESS;
        }
        if (isHauntedNight(config, dragonSealBroken, nowChicago)) {
            return Decision.ALLOW;
        }
        return Decision.SUPPRESS;
    }

    /** True when a world time (ticks, 0-23999) is inside the night window. */
    public static boolean isNightTime(long worldTimeTicks) {
        return worldTimeTicks >= NIGHT_START_TICKS && worldTimeTicks <= NIGHT_END_TICKS;
    }

    /** Short human label for tonight's state, shared by the boot line and
     *  /nophantoms status so the two can never disagree. */
    public static String tonightLabel(GateConfig config, Boolean dragonSealBroken,
                                      ZonedDateTime nowChicago) {
        if (config == null || config.effectiveMode() != Mode.EVENT) {
            return "phantoms suppressed (mode always-off)";
        }
        if (!config.eventActive() || Boolean.TRUE.equals(dragonSealBroken)) {
            return "Phantom Debt: ENDED — wards hold for good";
        }
        String day = dayName(nowChicago);
        if (nowChicago != null && isHauntedWeekday(nowChicago.getDayOfWeek())) {
            return "Phantom Debt: HAUNTED tonight (" + day + "); wards hold Fri–Sun";
        }
        return "Phantom Debt: WARDS HOLD tonight (" + day + ")";
    }

    static String dayName(ZonedDateTime nowChicago) {
        if (nowChicago == null) {
            return "unknown day";
        }
        String n = nowChicago.getDayOfWeek().name();
        return n.charAt(0) + n.substring(1).toLowerCase(java.util.Locale.ROOT);
    }
}
