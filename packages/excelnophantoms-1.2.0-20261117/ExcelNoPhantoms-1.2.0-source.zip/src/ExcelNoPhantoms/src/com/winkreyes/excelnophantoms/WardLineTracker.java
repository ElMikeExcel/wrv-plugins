package com.winkreyes.excelnophantoms;

import java.time.LocalDate;
import java.time.ZonedDateTime;

/**
 * The ward-evening line: ONE chat line per ward evening (Chicago
 * Fri/Sat/Sun, event live), fired at first nightfall - the first check
 * that finds the primary world inside the night window (13000-23000
 * ticks) with at least one player online.
 *
 * The last-fired Chicago date persists (the plugin keeps it in
 * state.yml), so restarts and reloads never double-fire the line on the
 * same evening. Pure and unit-testable.
 */
public final class WardLineTracker {

    private LocalDate lastFiredDate;

    public WardLineTracker(LocalDate persistedLastFiredDate) {
        this.lastFiredDate = persistedLastFiredDate;
    }

    public LocalDate lastFiredDate() {
        return lastFiredDate;
    }

    /** Conditions half: ward line enabled and present, ward night, night
     *  window, someone online, not already fired on this Chicago date. */
    public static boolean conditionsHold(GateConfig config, Boolean dragonSealBroken,
                                         ZonedDateTime nowChicago, long worldTimeTicks,
                                         int playersOnline, LocalDate lastFiredDate) {
        return config != null
                && config.wardsLineEnabled()
                && !config.wardsLine().isBlank()
                && playersOnline >= 1
                && nowChicago != null
                && PhantomGate.isNightTime(worldTimeTicks)
                && PhantomGate.isWardNight(config, dragonSealBroken, nowChicago)
                && !nowChicago.toLocalDate().equals(lastFiredDate);
    }

    /**
     * Try to fire for this check. On success the tracker records today's
     * Chicago date (the caller persists it) and returns true exactly once
     * per ward evening.
     */
    public boolean tryFire(GateConfig config, Boolean dragonSealBroken,
                           ZonedDateTime nowChicago, long worldTimeTicks, int playersOnline) {
        if (!conditionsHold(config, dragonSealBroken, nowChicago, worldTimeTicks,
                playersOnline, lastFiredDate)) {
            return false;
        }
        lastFiredDate = nowChicago.toLocalDate();
        return true;
    }
}
