package com.winkreyes.excelnophantoms;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.function.Supplier;

/**
 * ExcelNoPhantoms 1.2.0 - the Phantom Debt event mode.
 *
 * 1.1.0 cancelled every phantom spawn, unconditionally. 1.2.0 keeps that
 * as the bundled default (mode: always-off) and adds Mike's event mode
 * (approved Oct 18, 2026): while the event is active and Seal 1 (the
 * Ender Dragon) still stands, phantoms hunt on Chicago Mon-Thu nights
 * and the guild's wards suppress them Fri-Sun. When the dragon seal
 * breaks - or an operator flips event-active to false - suppression is
 * permanent again. On haunted nights a rotating story explains the debt
 * in chat; on ward evenings a single ward line fires at first nightfall.
 *
 * The gate itself is pure (PhantomGate / GateConfig); this class is the
 * Bukkit glue: spawn listener, config load, the GuildGate seal read by
 * reflection, the broadcast checks, persistence, and /nophantoms.
 */
public class ExcelNoPhantoms extends JavaPlugin implements Listener, CommandExecutor {

    // Injectable seams (package-private for tests). Any of them may be
    // null on a Mockito CALLS_REAL_METHODS instance; every use is guarded
    // and falls back to the fail-soft behaviour (suppress / no broadcast).
    Supplier<ZonedDateTime> clock = () -> ZonedDateTime.now(PhantomGate.CHICAGO);
    Supplier<Boolean> dragonSealReader = this::readDragonSealBroken;
    Supplier<Long> worldTimeReader = this::readPrimaryWorldTime;
    GateConfig gateConfig;
    StoryRotator storyRotator;
    WardLineTracker wardLineTracker;

    // Cached GuildGate reflection handles (resolved lazily, retried until
    // the first success so plugin load order cannot break the seal read).
    private Class<?> guildGateApiClass;
    private Field guildGateStateField;
    private Method sealIsBrokenMethod;
    private boolean sealReadWarned;

    // ------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------

    @Override
    public void onEnable() {
        migrateLegacyDataFolder();
        saveDefaultConfig();
        gateConfig = loadGateConfig();

        loadBroadcastState();
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("nophantoms") != null) {
            getCommand("nophantoms").setExecutor(this);
        }
        // Broadcast checks run every minute; the story interval is enforced
        // inside StoryRotator, so the task period never needs to change
        // when an operator edits story-interval-minutes and restarts.
        getServer().getScheduler().runTaskTimer(this, this::checkBroadcasts, 1200L, 1200L);

        Boolean seal = dragonSealBroken();
        getLogger().info(bootLine(gateConfig, seal, nowChicago()));
        if (gateConfig.malformed()) {
            getLogger().warning("ExcelNoPhantoms config is malformed (see warnings above):"
                    + " the phantom gate is failing soft to always-suppress.");
        }
    }

    private String bootLine(GateConfig config, Boolean seal, ZonedDateTime now) {
        String label = PhantomGate.tonightLabel(config, seal, now);
        if (config.malformed()) {
            return "ExcelNoPhantoms " + version() + " enabled: mode=" + modeName(config.mode())
                    + " (MALFORMED - effective always-off) — " + label + ".";
        }
        if (config.effectiveMode() == PhantomGate.Mode.EVENT) {
            boolean ended = !config.eventActive() || Boolean.TRUE.equals(seal);
            return "ExcelNoPhantoms " + version() + " enabled: mode=event, event "
                    + (ended ? "ENDED" : "ACTIVE") + " — " + label + ".";
        }
        return "ExcelNoPhantoms " + version() + " enabled: mode=always-off — " + label + ".";
    }

    private GateConfig loadGateConfig() {
        var cfg = getConfig();
        return GateConfig.fromRaw(
                cfg.get("mode"),
                cfg.get("event-active"),
                cfg.get("story-lines"),
                cfg.get("story-interval-minutes"),
                cfg.get("wards-line"),
                cfg.get("wards-line-enabled"),
                message -> getLogger().warning("ExcelNoPhantoms: " + message));
    }

    // ------------------------------------------------------------------
    // The gate
    // ------------------------------------------------------------------

    @EventHandler(ignoreCancelled = true)
    public void onCreatureSpawn(CreatureSpawnEvent event) {
        if (event.getEntityType() != EntityType.PHANTOM) {
            return;
        }
        PhantomGate.Decision decision = PhantomGate.decide(
                gateConfig, dragonSealBroken(), nowChicago());
        if (decision == PhantomGate.Decision.SUPPRESS) {
            event.setCancelled(true);
        }
    }

    /** Seal state for the gate: TRUE broken, FALSE not broken, null unreadable. */
    Boolean dragonSealBroken() {
        try {
            Supplier<Boolean> reader = dragonSealReader;
            if (reader == null) {
                return null;
            }
            return reader.get();
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * The house reflection pattern (mirrors ExcelMagicGate): find
     * ExcelGuildGate, load GuildGateAPI from ITS classloader, read the
     * private static `state` field, and invoke SealState.isBroken(
     * "ender_dragon") on it. Any failure - plugin absent, class or field
     * missing, state not yet bound, invocation error - returns null
     * (unknown) and the operator flag governs alone. Reflection problems
     * warn at most once and never break the listener.
     */
    private Boolean readDragonSealBroken() {
        try {
            Plugin gg = getServer().getPluginManager().getPlugin("ExcelGuildGate");
            if (gg == null || !gg.isEnabled()) {
                return null;
            }
            if (guildGateApiClass == null || guildGateStateField == null) {
                guildGateApiClass = Class.forName("com.winkreyes.guildgate.api.GuildGateAPI",
                        true, gg.getClass().getClassLoader());
                guildGateStateField = guildGateApiClass.getDeclaredField("state");
                guildGateStateField.setAccessible(true);
            }
            Object state = guildGateStateField.get(null);
            if (state == null) {
                return null; // GuildGate loaded but its state is not bound yet
            }
            if (sealIsBrokenMethod == null
                    || sealIsBrokenMethod.getDeclaringClass() != state.getClass()) {
                sealIsBrokenMethod = state.getClass().getMethod("isBroken", String.class);
            }
            Object result = sealIsBrokenMethod.invoke(state, "ender_dragon");
            return result instanceof Boolean b ? b : null;
        } catch (Throwable t) {
            if (!sealReadWarned) {
                sealReadWarned = true;
                try {
                    getLogger().warning("ExcelNoPhantoms: could not read the ExcelGuildGate"
                            + " dragon seal (" + t.getClass().getSimpleName() + ": "
                            + t.getMessage() + ") - the operator flag governs alone."
                            + " This warning fires once.");
                } catch (Throwable ignored) {
                    // A dead logger must never break the seal read.
                }
            }
            return null;
        }
    }

    // ------------------------------------------------------------------
    // Broadcasts: story rotation (haunted nights) + ward line (ward evenings)
    // ------------------------------------------------------------------

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        checkBroadcasts();
    }

    /** One broadcast check: story rotation first, then the ward line. */
    public void checkBroadcasts() {
        try {
            checkStory();
            checkWardLine();
        } catch (Throwable t) {
            try {
                getLogger().warning("ExcelNoPhantoms broadcast check failed: " + t.getMessage());
            } catch (Throwable ignored) {
                // Never let a broadcast failure escape into the scheduler.
            }
        }
    }

    private void checkStory() {
        if (gateConfig == null || storyRotator == null) {
            return;
        }
        storyRotator.tryFire(gateConfig, dragonSealBroken(), nowChicago(),
                        worldTimeTicks(), playersOnline(), Instant.now())
                .ifPresent(line -> {
                    getServer().broadcastMessage(color(line));
                    getLogger().info("Phantom Debt story line broadcast (next index now "
                            + storyRotator.nextIndex() + ").");
                    saveBroadcastState();
                });
    }

    private void checkWardLine() {
        if (gateConfig == null || wardLineTracker == null) {
            return;
        }
        if (wardLineTracker.tryFire(gateConfig, dragonSealBroken(), nowChicago(),
                worldTimeTicks(), playersOnline())) {
            getServer().broadcastMessage(color(gateConfig.wardsLine()));
            getLogger().info("Phantom Debt ward line broadcast for "
                    + wardLineTracker.lastFiredDate() + ".");
            saveBroadcastState();
        }
    }

    // ------------------------------------------------------------------
    // Broadcast state persistence (state.yml in the data folder)
    // ------------------------------------------------------------------

    private File broadcastStateFile() {
        return new File(getDataFolder(), "state.yml");
    }

    private void loadBroadcastState() {
        int index = 0;
        LocalDate wardsDate = null;
        try {
            File file = broadcastStateFile();
            if (file.isFile()) {
                YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
                index = y.getInt("story-next-index", 0);
                String stored = y.getString("last-wards-line-date");
                if (stored != null && !stored.isBlank()) {
                    wardsDate = LocalDate.parse(stored.trim());
                }
            }
        } catch (Exception e) {
            getLogger().warning("ExcelNoPhantoms: state.yml could not be read (" + e.getMessage()
                    + ") - story rotation restarts at line 1 and the ward line may refire once.");
            index = 0;
            wardsDate = null;
        }
        storyRotator = new StoryRotator(index);
        wardLineTracker = new WardLineTracker(wardsDate);
    }

    private void saveBroadcastState() {
        try {
            YamlConfiguration y = new YamlConfiguration();
            if (storyRotator != null) {
                y.set("story-next-index", storyRotator.nextIndex());
            }
            if (wardLineTracker != null && wardLineTracker.lastFiredDate() != null) {
                y.set("last-wards-line-date", wardLineTracker.lastFiredDate().toString());
            }
            y.save(broadcastStateFile());
        } catch (IOException | RuntimeException e) {
            try {
                getLogger().warning("ExcelNoPhantoms: could not save state.yml: " + e.getMessage());
            } catch (Throwable ignored) {
                // Persistence is best-effort; the in-memory trackers still
                // prevent double-fires until the next restart.
            }
        }
    }

    // ------------------------------------------------------------------
    // /nophantoms status
    // ------------------------------------------------------------------

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!cmd.getName().equalsIgnoreCase("nophantoms")) {
            return false;
        }
        if (!sender.hasPermission("excelnophantoms.admin")) {
            sender.sendMessage(color("&cYou do not have permission to use /nophantoms."));
            return true;
        }
        if (args.length > 0 && !args[0].equalsIgnoreCase("status")) {
            sender.sendMessage(color("&6/nophantoms &7- Phantom Debt admin"));
            sender.sendMessage(color("&e/nophantoms status &7- mode, flag, seal, tonight"));
            return true;
        }
        sendStatus(sender);
        return true;
    }

    private void sendStatus(CommandSender sender) {
        GateConfig config = gateConfig != null ? gateConfig : GateConfig.safeDefault();
        Boolean seal = dragonSealBroken();
        ZonedDateTime now = nowChicago();
        sender.sendMessage(color("&5— ExcelNoPhantoms " + version() + ": status —"));
        sender.sendMessage(color("&7Mode: &f" + modeName(config.mode())
                + (config.malformed() ? " &c(malformed - effective always-off)" : "")));
        sender.sendMessage(color("&7Event active: &f" + config.eventActive()));
        sender.sendMessage(color("&7Dragon seal (ender_dragon): &f"
                + (seal == null ? "unreadable" : seal ? "broken" : "not broken")));
        sender.sendMessage(color("&7Tonight (" + PhantomGate.dayName(now)
                + ", America/Chicago): &f" + PhantomGate.tonightLabel(config, seal, now)));
        if (config.effectiveMode() == PhantomGate.Mode.EVENT && !config.storyLines().isEmpty()
                && storyRotator != null) {
            sender.sendMessage(color("&7Story rotation: &fnext line "
                    + (storyRotator.nextIndex() + 1) + " of " + config.storyLines().size()
                    + ", every " + config.storyIntervalMinutes()
                    + " min on haunted nights (world time 13000-23000)"));
        }
        sender.sendMessage(color("&7Ward line: &f" + (config.wardsLineEnabled() ? "enabled" : "disabled")
                + (wardLineTracker != null && wardLineTracker.lastFiredDate() != null
                        ? ", last fired " + wardLineTracker.lastFiredDate() : ", not fired yet")));
    }

    // ------------------------------------------------------------------
    // Small guarded helpers
    // ------------------------------------------------------------------

    ZonedDateTime nowChicago() {
        try {
            Supplier<ZonedDateTime> c = clock;
            ZonedDateTime now = c != null ? c.get() : null;
            return now != null ? now : ZonedDateTime.now(PhantomGate.CHICAGO);
        } catch (Throwable t) {
            return null; // the gate treats a null time as SUPPRESS (fail soft)
        }
    }

    private int playersOnline() {
        try {
            return getServer().getOnlinePlayers().size();
        } catch (Throwable t) {
            return 0;
        }
    }

    private long worldTimeTicks() {
        try {
            Supplier<Long> reader = worldTimeReader;
            Long t = reader != null ? reader.get() : null;
            return t != null ? t : -1L;
        } catch (Throwable t) {
            return -1L;
        }
    }

    /** Primary (first) world's time; -1 when no world is loaded. */
    private Long readPrimaryWorldTime() {
        try {
            var worlds = getServer().getWorlds();
            if (worlds == null || worlds.isEmpty()) {
                return -1L;
            }
            return worlds.get(0).getTime();
        } catch (Throwable t) {
            return -1L;
        }
    }

    private String version() {
        try {
            return getDescription().getVersion();
        } catch (Throwable t) {
            return "1.2.0";
        }
    }

    private static String modeName(PhantomGate.Mode mode) {
        return mode == PhantomGate.Mode.EVENT ? "event" : "always-off";
    }

    private static String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    private void migrateLegacyDataFolder() {
        java.io.File dataFolder = getDataFolder();
        if (dataFolder == null || dataFolder.getParentFile() == null) {
            return;
        }
        java.io.File legacy = new java.io.File(dataFolder.getParentFile(), "NoPhantoms");
        LegacyDataMigration.migrate(legacy, dataFolder, message -> getLogger().info(message));
    }
}
