package com.winkreyes.excelnophantoms;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Parsed plugin config, split into two independent fail-soft halves:
 *
 * GATE half (mode / event-active): any malformed, missing or wrongly-typed
 * value marks the config malformed, and effectiveMode() then reports
 * ALWAYS_OFF - the gate always-suppresses, the kids'-server safe default.
 *
 * STORY half (story-lines / story-interval-minutes / wards-line /
 * wards-line-enabled): malformed story-lines (empty list, not a list, a
 * non-string entry) fail soft to NO broadcasts - storyLines() comes back
 * empty - while the phantom gate itself keeps working from its own half.
 * A bad interval falls back to the 25-minute default with a warning. A
 * wrongly-typed wards-line-enabled disables the ward line with a warning.
 *
 * Pure: built from raw config values (whatever Bukkit's get() returned),
 * never from Bukkit types, so every failure mode is unit-testable.
 */
public final class GateConfig {

    public static final int DEFAULT_STORY_INTERVAL_MINUTES = 25;

    private final PhantomGate.Mode mode;
    private final boolean eventActive;
    private final boolean malformed;
    private final List<String> storyLines;
    private final boolean storyMalformed;
    private final int storyIntervalMinutes;
    private final String wardsLine;
    private final boolean wardsLineEnabled;

    private GateConfig(PhantomGate.Mode mode, boolean eventActive, boolean malformed,
                       List<String> storyLines, boolean storyMalformed,
                       int storyIntervalMinutes, String wardsLine, boolean wardsLineEnabled) {
        this.mode = mode;
        this.eventActive = eventActive;
        this.malformed = malformed;
        this.storyLines = storyLines;
        this.storyMalformed = storyMalformed;
        this.storyIntervalMinutes = storyIntervalMinutes;
        this.wardsLine = wardsLine;
        this.wardsLineEnabled = wardsLineEnabled;
    }

    /** The safe default: always-off, no broadcasts. A bare 1.2.0 install. */
    public static GateConfig safeDefault() {
        return new GateConfig(PhantomGate.Mode.ALWAYS_OFF, true, false,
                List.of(), false, DEFAULT_STORY_INTERVAL_MINUTES, "", false);
    }

    /** Direct construction for tests and for the plugin's own defaults. */
    public static GateConfig of(PhantomGate.Mode mode, boolean eventActive,
                                List<String> storyLines, int storyIntervalMinutes,
                                String wardsLine, boolean wardsLineEnabled) {
        return new GateConfig(mode, eventActive, false,
                storyLines == null ? List.of() : List.copyOf(storyLines),
                storyLines == null || storyLines.isEmpty(),
                storyIntervalMinutes > 0 ? storyIntervalMinutes : DEFAULT_STORY_INTERVAL_MINUTES,
                wardsLine == null ? "" : wardsLine, wardsLineEnabled);
    }

    /**
     * Parse raw config values. Every problem is reported through warn and
     * degrades only its own half (see class docs).
     */
    public static GateConfig fromRaw(Object modeRaw, Object eventActiveRaw,
                                     Object storyLinesRaw, Object storyIntervalRaw,
                                     Object wardsLineRaw, Object wardsLineEnabledRaw,
                                     Consumer<String> warn) {
        boolean malformed = false;

        PhantomGate.Mode mode = PhantomGate.Mode.ALWAYS_OFF;
        if (modeRaw instanceof String s) {
            switch (s.trim().toLowerCase(java.util.Locale.ROOT)) {
                case "always-off" -> mode = PhantomGate.Mode.ALWAYS_OFF;
                case "event" -> mode = PhantomGate.Mode.EVENT;
                default -> {
                    malformed = true;
                    warn.accept("config 'mode' has unknown value '" + s
                            + "' (expected always-off or event) - failing soft to always-suppress.");
                }
            }
        } else {
            malformed = true;
            warn.accept("config 'mode' is missing or not a string - failing soft to always-suppress.");
        }

        boolean eventActive = true;
        if (eventActiveRaw instanceof Boolean b) {
            eventActive = b;
        } else {
            malformed = true;
            warn.accept("config 'event-active' is missing or not a boolean"
                    + " - failing soft to always-suppress.");
        }

        List<String> lines = new ArrayList<>();
        boolean storyMalformed = false;
        if (storyLinesRaw instanceof List<?> rawList) {
            if (rawList.isEmpty()) {
                storyMalformed = true;
                warn.accept("config 'story-lines' is an empty list - story broadcasts disabled"
                        + " (the phantom gate is unaffected).");
            } else {
                for (Object o : rawList) {
                    if (o instanceof String s && !s.isBlank()) {
                        lines.add(s);
                    } else {
                        storyMalformed = true;
                        lines.clear();
                        warn.accept("config 'story-lines' contains a non-string or blank entry"
                                + " - story broadcasts disabled (the phantom gate is unaffected).");
                        break;
                    }
                }
            }
        } else {
            storyMalformed = true;
            warn.accept("config 'story-lines' is missing or not a list - story broadcasts disabled"
                    + " (the phantom gate is unaffected).");
        }

        int interval = DEFAULT_STORY_INTERVAL_MINUTES;
        if (storyIntervalRaw instanceof Number n) {
            if (n.intValue() > 0) {
                interval = n.intValue();
            } else {
                warn.accept("config 'story-interval-minutes' must be positive (got " + n
                        + ") - using the " + DEFAULT_STORY_INTERVAL_MINUTES + "-minute default.");
            }
        } else if (storyIntervalRaw != null) {
            warn.accept("config 'story-interval-minutes' is not a number - using the "
                    + DEFAULT_STORY_INTERVAL_MINUTES + "-minute default.");
        }

        String wardsLine = "";
        if (wardsLineRaw instanceof String s) {
            wardsLine = s;
        } else if (wardsLineRaw != null) {
            warn.accept("config 'wards-line' is not a string - ward line disabled.");
        }

        boolean wardsEnabled = true;
        if (wardsLineEnabledRaw instanceof Boolean b) {
            wardsEnabled = b;
        } else if (wardsLineEnabledRaw != null) {
            wardsEnabled = false;
            warn.accept("config 'wards-line-enabled' is not a boolean - ward line disabled.");
        }

        return new GateConfig(mode, eventActive, malformed,
                List.copyOf(lines), storyMalformed, interval, wardsLine, wardsEnabled);
    }

    /** The configured mode (before the malformed fail-soft). */
    public PhantomGate.Mode mode() {
        return mode;
    }

    /** The mode the gate must actually use: always-off when malformed. */
    public PhantomGate.Mode effectiveMode() {
        return malformed ? PhantomGate.Mode.ALWAYS_OFF : mode;
    }

    public boolean eventActive() {
        return eventActive;
    }

    public boolean malformed() {
        return malformed;
    }

    /** Story lines to rotate; empty means the rotation never fires. */
    public List<String> storyLines() {
        return storyLines;
    }

    public boolean storyMalformed() {
        return storyMalformed;
    }

    public int storyIntervalMinutes() {
        return storyIntervalMinutes;
    }

    public String wardsLine() {
        return wardsLine;
    }

    public boolean wardsLineEnabled() {
        return wardsLineEnabled;
    }
}
