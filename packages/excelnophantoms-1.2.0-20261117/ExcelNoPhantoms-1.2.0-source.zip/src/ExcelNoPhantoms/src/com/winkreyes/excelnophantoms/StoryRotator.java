package com.winkreyes.excelnophantoms;

import java.time.Duration;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.Optional;

/**
 * The Phantom Debt story rotation for haunted nights.
 *
 * On a haunted night (PhantomGate.isHauntedNight), with the primary world
 * inside the night window (world time 13000-23000 ticks) and at least one
 * player online, one story line is broadcast every story-interval-minutes,
 * cycling through the configured lines in order and wrapping to the first.
 *
 * State discipline (documented choice):
 * - The rotation INDEX persists (the plugin keeps it in state.yml): a
 *   restart resumes the story where it left off instead of replaying
 *   line 1 all night.
 * - The last-fired INSTANT is in-memory only: after a restart (or a
 *   config reload, which rebuilds this object from the persisted index)
 *   the next line is due on the first eligible check, then the interval
 *   runs from there. Reload therefore never double-fires a line within
 *   its interval after the first post-reload line, and never stalls the
 *   story for a full interval after a restart.
 *
 * Pure and unit-testable: the plugin feeds it config, seal state, Chicago
 * time, world time, player count and "now"; it answers the line to send.
 */
public final class StoryRotator {

    private int nextIndex;
    private Instant lastFiredAt;

    public StoryRotator(int persistedNextIndex) {
        this.nextIndex = Math.max(0, persistedNextIndex);
    }

    /** Index (0-based) of the line that will fire next. */
    public int nextIndex() {
        return nextIndex;
    }

    /** Last time a story line fired (in-memory only; null after boot). */
    public Instant lastFiredAt() {
        return lastFiredAt;
    }

    /**
     * Conditions half of the fire decision, without the interval: haunted
     * night, story lines present, night window, someone online.
     */
    public static boolean conditionsHold(GateConfig config, Boolean dragonSealBroken,
                                         ZonedDateTime nowChicago, long worldTimeTicks,
                                         int playersOnline) {
        return config != null
                && !config.storyLines().isEmpty()
                && playersOnline >= 1
                && PhantomGate.isNightTime(worldTimeTicks)
                && PhantomGate.isHauntedNight(config, dragonSealBroken, nowChicago);
    }

    /**
     * Try to fire. Returns the line to broadcast and advances the rotation
     * when every condition holds and the configured interval has elapsed
     * since the last fire (or nothing has fired since boot). Returns empty
     * - and changes nothing - otherwise.
     */
    public Optional<String> tryFire(GateConfig config, Boolean dragonSealBroken,
                                    ZonedDateTime nowChicago, long worldTimeTicks,
                                    int playersOnline, Instant now) {
        if (now == null || !conditionsHold(config, dragonSealBroken, nowChicago,
                worldTimeTicks, playersOnline)) {
            return Optional.empty();
        }
        if (lastFiredAt != null) {
            Duration interval = Duration.ofMinutes(config.storyIntervalMinutes());
            if (now.isBefore(lastFiredAt.plus(interval))) {
                return Optional.empty();
            }
        }
        var lines = config.storyLines();
        int idx = Math.floorMod(nextIndex, lines.size());
        String line = lines.get(idx);
        nextIndex = idx + 1;
        if (nextIndex >= lines.size()) {
            nextIndex = 0;
        }
        lastFiredAt = now;
        return Optional.of(line);
    }
}
