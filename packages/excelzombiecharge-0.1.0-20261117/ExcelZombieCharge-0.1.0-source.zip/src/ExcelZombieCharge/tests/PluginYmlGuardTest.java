import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * plugin.yml guards: ExcelZombieCharge must carry NO dependency on
 * Magic or EliteMobs at all - detection is by damage-event
 * signature (FINDINGS) and the effect is a vanilla attribute
 * modifier, so the plugin boots identically on a server with
 * neither installed. Also pins the identity fields.
 */
public final class PluginYmlGuardTest {

    public static void run() throws Exception {
        System.out.println("PluginYmlGuardTest");
        Path yml = Path.of("plugin.yml");
        Check.ok(Files.exists(yml), "plugin.yml present in project root");
        String text = Files.readString(yml, StandardCharsets.UTF_8);

        boolean anyDepend = text.lines().anyMatch(l ->
                l.startsWith("depend:") || l.startsWith("softdepend:") || l.startsWith("loadbefore:"));
        Check.ok(!anyDepend, "no depend/softdepend/loadbefore lines at all");
        Check.ok(text.contains("name: ExcelZombieCharge"), "plugin name pinned");
        Check.ok(text.contains("main: com.winkreyes.excelzombiecharge.ExcelZombieCharge"),
                "main class pinned to the renamed package");
        Check.ok(text.contains("version: 0.1.0"), "version 0.1.0 pinned");
        Check.ok(text.contains("excelzombiecharge.admin"), "admin permission declared");
        Check.ok(text.contains("provoke:"), "/provoke command declared");
        Check.ok(text.contains("Renamed from ExcelProvoke"),
                "description carries the rename note (supersedes ExcelProvoke 0.1.0)");
        Check.ok(!text.contains("name: ExcelProvoke") && !text.contains("excelprovoke.admin"),
                "no live ExcelProvoke identity remains in plugin.yml");
    }
}
