import com.winkreyes.excelzombiecharge.core.HitClassifier;
import com.winkreyes.excelzombiecharge.core.ZombieChargeSettings;

import java.util.Set;

/**
 * The classification table, row by row: every cause/damager
 * combination the listener can extract, including every
 * exclusion FINDINGS names. The order pins matter as much as the
 * verdicts: victim membership is checked before any shape, and a
 * ThrownPotion damager always takes the Magic-signature branch
 * (a ThrownPotion IS a Projectile in Bukkit's type tree - reading
 * it as a projectile first would misclassify both a witch's
 * potion and Magic's scratch potion).
 */
public final class HitClassifierTest {

    private static final Set<String> SET = ZombieChargeSettings.defaults().entityTypes();

    private static HitClassifier.Input in(String victim, String cause, boolean proj,
                                          boolean shooterPlayer, boolean potion,
                                          boolean potionDmg, boolean typeMagic,
                                          boolean causingPlayer) {
        return new HitClassifier.Input(victim, cause, proj, shooterPlayer, potion,
                potionDmg, typeMagic, causingPlayer);
    }

    private static void row(HitClassifier.Input input, HitClassifier.Verdict expected, String name) {
        Check.eq(expected, HitClassifier.classify(input, SET), name);
    }

    public static void run() {
        System.out.println("HitClassifierTest");
        // --- qualifying projectiles, across the victim set ---
        row(in("ZOMBIE", "PROJECTILE", true, true, false, false, false, false),
                HitClassifier.Verdict.QUALIFY_PROJECTILE, "zombie + player arrow qualifies");
        row(in("HUSK", "PROJECTILE", true, true, false, false, false, false),
                HitClassifier.Verdict.QUALIFY_PROJECTILE, "husk + player arrow qualifies");
        row(in("DROWNED", "PROJECTILE", true, true, false, false, false, false),
                HitClassifier.Verdict.QUALIFY_PROJECTILE, "drowned + player trident qualifies");
        row(in("PIGLIN_BRUTE", "PROJECTILE", true, true, false, false, false, false),
                HitClassifier.Verdict.QUALIFY_PROJECTILE, "piglin brute + player bolt qualifies");
        row(in("ZOMBIFIED_PIGLIN", "PROJECTILE", true, true, false, false, false, false),
                HitClassifier.Verdict.QUALIFY_PROJECTILE, "zombified piglin + player arrow qualifies");

        // --- projectiles without a player behind them ---
        row(in("ZOMBIE", "PROJECTILE", true, false, false, false, false, false),
                HitClassifier.Verdict.PROJECTILE_NOT_PLAYER, "skeleton arrow does not qualify");
        row(in("ZOMBIE", "PROJECTILE", true, false, false, false, false, false),
                HitClassifier.Verdict.PROJECTILE_NOT_PLAYER, "dispenser arrow does not qualify");

        // --- the Magic signature ---
        // (a ThrownPotion is a Projectile too; proj=true in these
        // rows on purpose - the potion branch must win the order)
        row(in("ZOMBIE", "MAGIC", true, true, true, false, true, true),
                HitClassifier.Verdict.QUALIFY_MAGIC, "Magic signature on zombie qualifies");
        row(in("ZOMBIE_VILLAGER", "MAGIC", true, true, true, false, true, true),
                HitClassifier.Verdict.QUALIFY_MAGIC, "Magic signature on zombie villager qualifies");
        row(in("ZOMBIE", "MAGIC", true, false, true, true, true, false),
                HitClassifier.Verdict.MAGIC_POTION_NOT_BLANK, "witch harming potion excluded (not blank)");
        row(in("PIGLIN", "MAGIC", true, true, true, true, true, true),
                HitClassifier.Verdict.MAGIC_POTION_NOT_BLANK, "player's own harming potion excluded (not blank)");
        row(in("ZOMBIE", "MAGIC", true, true, true, false, true, false),
                HitClassifier.Verdict.MAGIC_NO_PLAYER_CASTER, "blank potion with no player caster excluded");
        row(in("ZOMBIE", "MAGIC", false, false, false, false, true, true),
                HitClassifier.Verdict.MAGIC_NOT_POTION_DAMAGER, "AreaEffectCloud magic excluded (damager not a potion)");
        row(in("ZOMBIE", "MAGIC", false, false, false, false, true, false),
                HitClassifier.Verdict.MAGIC_NOT_POTION_DAMAGER, "EvokerFangs-style magic excluded (damager not a potion)");
        row(in("ZOMBIE", "PROJECTILE", true, true, true, false, true, true),
                HitClassifier.Verdict.MAGIC_SIGNATURE_MISMATCH, "potion damager without MAGIC cause is not the signature");
        row(in("ZOMBIE", "MAGIC", true, true, true, false, false, true),
                HitClassifier.Verdict.MAGIC_SIGNATURE_MISMATCH, "potion damager without MAGIC damage type is not the signature");

        // --- melee and everything else ---
        row(in("ZOMBIE", "ENTITY_ATTACK", false, false, false, false, false, true),
                HitClassifier.Verdict.NOT_RANGED, "sword hit never qualifies (magic_damage:false spells land here too)");
        row(in("ZOMBIE", "ENTITY_SWEEP_ATTACK", false, false, false, false, false, true),
                HitClassifier.Verdict.NOT_RANGED, "sweep hit never qualifies");
        row(in("PIGLIN", "ENTITY_EXPLOSION", false, false, false, false, false, false),
                HitClassifier.Verdict.NOT_RANGED, "creeper explosion never qualifies");
        row(in("ZOMBIE", "FALL", false, false, false, false, false, false),
                HitClassifier.Verdict.NOT_RANGED, "fall damage never qualifies");

        // --- victim membership, checked before any shape ---
        row(in("CREEPER", "PROJECTILE", true, true, false, false, false, false),
                HitClassifier.Verdict.NOT_VICTIM_TYPE, "creeper + player arrow: not a victim type");
        row(in("SKELETON", "PROJECTILE", true, true, false, false, false, false),
                HitClassifier.Verdict.NOT_VICTIM_TYPE, "skeleton + player arrow: not a victim type");
        row(in("HOGLIN", "PROJECTILE", true, true, false, false, false, false),
                HitClassifier.Verdict.NOT_VICTIM_TYPE, "hoglin is deliberately NOT in the set");
        row(in("CREEPER", "MAGIC", true, true, true, false, true, true),
                HitClassifier.Verdict.NOT_VICTIM_TYPE, "victim check beats the full Magic signature");

        // --- the qualifies() convenience ---
        Check.ok(HitClassifier.qualifies(HitClassifier.Verdict.QUALIFY_PROJECTILE), "qualifies(PROJECTILE)");
        Check.ok(HitClassifier.qualifies(HitClassifier.Verdict.QUALIFY_MAGIC), "qualifies(MAGIC)");
        Check.ok(!HitClassifier.qualifies(HitClassifier.Verdict.NOT_RANGED), "!qualifies(NOT_RANGED)");
        Check.ok(!HitClassifier.qualifies(HitClassifier.Verdict.MAGIC_POTION_NOT_BLANK), "!qualifies(NOT_BLANK)");
    }
}
