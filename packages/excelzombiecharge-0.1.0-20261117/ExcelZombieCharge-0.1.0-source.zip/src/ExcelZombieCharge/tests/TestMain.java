public class TestMain {
    public static void main(String[] args) throws Exception {
        HitClassifierTest.run();
        ChargeTrackerTest.run();
        ZombieChargeSettingsTest.run();
        ChargeKeysTest.run();
        PluginYmlGuardTest.run();
        System.out.println("TOTAL: " + Check.passed + " passed, " + Check.failed + " failed");
        if (Check.failed > 0) System.exit(1);
    }
}
