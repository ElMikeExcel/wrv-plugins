import com.winkreyes.excelzombiecharge.core.ChargeKeys;

import java.util.HashSet;

/**
 * The rename-migration pin: ExcelZombieCharge is ExcelProvoke
 * renamed, and attribute modifiers serialize with entity data -
 * so the stale-strip MUST cover the legacy excelprovoke:speed
 * key alongside the current excelzombiecharge:speed, or a mob
 * saved mid-charge by the old plugin would keep +50% speed
 * forever after the jar swap (the old plugin is gone and cannot
 * strip its own modifier). These checks pin the strip set.
 */
public final class ChargeKeysTest {

    public static void run() {
        System.out.println("ChargeKeysTest");
        Check.ok("excelzombiecharge:speed".equals(ChargeKeys.MODIFIER_KEY_STRING),
                "current modifier key is excelzombiecharge:speed");
        Check.ok("excelprovoke:speed".equals(ChargeKeys.LEGACY_KEY_STRING),
                "legacy modifier key is excelprovoke:speed");
        Check.ok("excelzombiecharge".equals(ChargeKeys.NAMESPACE)
                        && "excelprovoke".equals(ChargeKeys.LEGACY_NAMESPACE)
                        && "speed".equals(ChargeKeys.KEY_PATH),
                "key parts: namespaces excelzombiecharge / excelprovoke, path speed");
        Check.ok(ChargeKeys.STRIP_KEY_STRINGS.contains(ChargeKeys.LEGACY_KEY_STRING),
                "LEGACY KEY IS IN THE STRIP SET (the migration pin)");
        Check.ok(ChargeKeys.STRIP_KEY_STRINGS.contains(ChargeKeys.MODIFIER_KEY_STRING),
                "current key is in the strip set");
        Check.eq(2, ChargeKeys.STRIP_KEY_STRINGS.size(),
                "strip set is exactly the two keys, no more");
        Check.eq(ChargeKeys.STRIP_KEY_STRINGS.size(),
                new HashSet<>(ChargeKeys.STRIP_KEY_STRINGS).size(),
                "strip set has no duplicates");
        Check.ok(ChargeKeys.isStripKey("excelprovoke:speed"),
                "isStripKey accepts the legacy key");
        Check.ok(ChargeKeys.isStripKey("excelzombiecharge:speed"),
                "isStripKey accepts the current key");
        Check.ok(!ChargeKeys.isStripKey("excelprovoke:other"),
                "isStripKey rejects an unrelated key in the legacy namespace");
        Check.ok(!ChargeKeys.isStripKey("excelzombiecharge:other"),
                "isStripKey rejects an unrelated key in the current namespace");
        Check.ok(!ChargeKeys.isStripKey("minecraft:generic.movement_speed"),
                "isStripKey rejects vanilla keys");
        Check.ok(!ChargeKeys.isStripKey(null), "isStripKey is null-safe");
        Check.ok(!ChargeKeys.isStripKey(""), "isStripKey rejects the empty string");
    }
}
