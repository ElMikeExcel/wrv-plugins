import com.winkreyes.excelzombiecharge.core.ZombieChargeSettings;

import java.util.List;
import java.util.Set;

/**
 * Settings snapshot semantics: the approved defaults, overrides,
 * clamps (a typo degrades to the nearest sane value, never
 * throws), type-list normalization, and the two deliberate
 * shapes: an ABSENT list means the default set; an explicitly
 * EMPTY list is honored as "nothing charges".
 */
public final class ZombieChargeSettingsTest {

    public static void run() {
        System.out.println("ZombieChargeSettingsTest");
        ZombieChargeSettings d = ZombieChargeSettings.defaults();
        Check.ok(d.enabled(), "default enabled");
        Check.close(0.5, d.speedMultiplier(), "default multiplier 0.5 (the approved +50%)");
        Check.eq(60L, d.durationTicks(), "default duration 60 ticks (the approved 3s)");
        Check.ok(!d.debugLog(), "default debug off");
        Check.eq(Set.of("ZOMBIE", "HUSK", "DROWNED", "ZOMBIE_VILLAGER",
                        "ZOMBIFIED_PIGLIN", "PIGLIN", "PIGLIN_BRUTE"), d.entityTypes(),
                "default victim set is the approved seven");
        Check.ok(!d.entityTypes().contains("HOGLIN"), "hoglin is NOT in the default set");

        ZombieChargeSettings fromNulls = ZombieChargeSettings.of(null, null, null, null, null);
        Check.eq(d, fromNulls, "all-absent config reproduces the defaults");

        ZombieChargeSettings custom = ZombieChargeSettings.of(false, 1.0, 100,
                List.of("zombie", " husk ", "ZOMBIE"), true);
        Check.ok(!custom.enabled(), "override: disabled honored");
        Check.close(1.0, custom.speedMultiplier(), "override: multiplier 1.0");
        Check.eq(100L, custom.durationTicks(), "override: duration 100");
        Check.eq(Set.of("ZOMBIE", "HUSK"), custom.entityTypes(),
                "override: types normalized (trim, uppercase, dedupe)");
        Check.ok(custom.debugLog(), "override: debug on");

        Check.close(0.0, ZombieChargeSettings.of(null, -1.0, null, null, null).speedMultiplier(),
                "negative multiplier clamps to 0 (this plugin never slows)");
        Check.close(4.0, ZombieChargeSettings.of(null, 99.0, null, null, null).speedMultiplier(),
                "huge multiplier clamps to 4");
        Check.close(0.5, ZombieChargeSettings.of(null, Double.NaN, null, null, null).speedMultiplier(),
                "NaN multiplier falls back to the default");
        Check.close(0.5, ZombieChargeSettings.of(null, Double.POSITIVE_INFINITY, null, null, null)
                .speedMultiplier(), "infinite multiplier falls back to the default");

        Check.eq(1L, ZombieChargeSettings.of(null, null, 0, null, null).durationTicks(),
                "duration 0 clamps up to 1 tick");
        Check.eq(7200L, ZombieChargeSettings.of(null, null, 999999, null, null).durationTicks(),
                "huge duration clamps to 7200 ticks");

        Check.ok(ZombieChargeSettings.of(null, null, null, List.of(), null).entityTypes().isEmpty(),
                "explicitly empty type list is honored (nothing charges)");
        Check.eq(Set.of("ZOMBIE"), ZombieChargeSettings.of(null, null, null,
                List.of("", "  ", "zombie"), null).entityTypes(),
                "blank type tokens are dropped");
    }
}
