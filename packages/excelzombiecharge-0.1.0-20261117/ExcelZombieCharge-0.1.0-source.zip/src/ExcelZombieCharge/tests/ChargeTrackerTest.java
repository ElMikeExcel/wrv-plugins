import com.winkreyes.excelzombiecharge.core.ChargeTracker;

import java.util.Set;
import java.util.UUID;

/**
 * Refresh/expiry semantics of the charge book, driven by a
 * scripted tick sequence - no wall clock anywhere, so these
 * checks are exact: a charge is live while now &lt; expiry, a
 * refresh REPLACES the expiry with now + duration (which, with
 * ticks only moving forward, is what keeps a repeatedly-hit mob
 * charged continuously), and the sweep set is exactly the ids
 * with now &gt;= expiry.
 */
public final class ChargeTrackerTest {

    private static final UUID A = UUID.fromString("00000000-0000-0000-0000-00000000000a");
    private static final UUID B = UUID.fromString("00000000-0000-0000-0000-00000000000b");

    public static void run() {
        System.out.println("ChargeTrackerTest");
        ChargeTracker t = new ChargeTracker();

        Check.ok(!t.isCharged(A, 0), "untracked id is not charged");
        Check.eq(-1L, t.expiryOf(A), "untracked id has expiry -1");
        Check.eq(0, t.size(), "empty tracker size 0");

        // Basic window: applied at 100 for 60 ticks.
        t.apply(A, 100, 60);
        Check.eq(160L, t.expiryOf(A), "expiry is now + duration");
        Check.ok(t.isCharged(A, 100), "charged at the apply tick");
        Check.ok(t.isCharged(A, 159), "charged one tick before expiry");
        Check.ok(!t.isCharged(A, 160), "expired exactly at the expiry tick");
        Check.ok(t.expired(159).isEmpty(), "nothing expired at 159");
        Check.eq(Set.of(A), t.expired(160), "A is the expired set at 160");

        // Refresh: a second hit at 140 restarts the clock.
        t.apply(A, 140, 60);
        Check.eq(200L, t.expiryOf(A), "refresh replaces the expiry (140 + 60)");
        Check.ok(t.isCharged(A, 170), "still charged past the ORIGINAL expiry after refresh");
        Check.eq(1, t.size(), "refresh never stacks: still one entry");

        // Independence: B runs on its own clock.
        t.apply(B, 190, 60);
        Check.eq(2, t.size(), "two entities tracked independently");
        Check.eq(Set.of(A), t.expired(210), "at 210 only A has expired");
        Check.ok(t.isCharged(B, 210), "B still charged at 210");

        // Removal is idempotent and total.
        Check.ok(t.remove(A), "remove(A) reports true when tracked");
        Check.ok(!t.remove(A), "remove(A) again reports false");
        Check.ok(!t.isTracked(A), "A untracked after remove");
        Check.eq(1, t.size(), "size drops after remove");

        // tracked() is a snapshot, not a view.
        Set<UUID> snap = t.tracked();
        snap.clear();
        Check.eq(1, t.size(), "mutating the tracked() snapshot does not touch the book");

        // Clear empties everything.
        t.clear();
        Check.eq(0, t.size(), "clear empties the book");
        Check.ok(!t.isCharged(B, 200), "nothing charged after clear");
    }
}
