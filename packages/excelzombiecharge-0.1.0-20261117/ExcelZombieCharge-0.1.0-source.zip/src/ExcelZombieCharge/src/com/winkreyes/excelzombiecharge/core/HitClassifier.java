package com.winkreyes.excelzombiecharge.core;

import java.util.Set;

/**
 * The hit classifier: given the extracted shape of one
 * EntityDamageByEntityEvent, decide whether the hit is a
 * qualifying ranged hit (player projectile, or a Magic spell hit
 * carrying the verified signature) or exactly why it is not.
 * Pure JVM - the listener extracts Bukkit fields into an
 * {@link Input}; every row of the classification table is pinned
 * by the plain-JVM suite.
 *
 * <p>The signature comes from ~/workspace/provoke-speed/
 * FINDINGS.md (verified against the Magic 11.2.5 jar on Paper
 * 26.2): a Magic damage spell with default parameters calls
 * CompatibilityUtils.magicDamage, which hurts the target through
 * NMS DamageSources.indirectMagic(scratchPotion, caster). The
 * Bukkit event therefore shows: cause MAGIC, damage type in the
 * magic family (INDIRECT_MAGIC for the indirectMagic source -
 * the build rig's live Missile hit proved this where FINDINGS
 * had said MAGIC), damager = Magic's reusable per-world
 * ThrownPotion whose item is BLANK (a plain splash potion, no
 * potion effect), and DamageSource.getCausingEntity() = the
 * caster. A real harming
 * potion - a witch's, or a player's own - carries an
 * instant-damage effect in its item meta, which is what separates
 * the two.
 *
 * <p>Branch order matters and is deliberate:
 * <ol>
 *   <li>Victim membership first: a type outside the configured
 *       set is never classified further.</li>
 *   <li>ThrownPotion damagers go down the MAGIC-signature branch,
 *       never the projectile branch - a ThrownPotion IS a
 *       Projectile in Bukkit's type tree, and both a witch's
 *       harming potion (non-player shooter) and Magic's scratch
 *       potion (player shooter) would otherwise be misread as
 *       ordinary projectile hits. A thrown potion that deals
 *       damage at all arrives as MAGIC-cause damage, so the
 *       signature branch is its only honest home.</li>
 *   <li>Other MAGIC-cause sources (AreaEffectCloud, EvokerFangs,
 *       Guardian, dragon breath) present non-potion damagers and
 *       are excluded by the potion check.</li>
 *   <li>Remaining projectiles qualify only with a player
 *       shooter. Magic's own arrow spells are real arrows and
 *       land here by design (FINDINGS Q1c).</li>
 *   <li>Everything else - melee, sweep, falls, fire, entity
 *       attacks of any kind - never qualifies. Spells configured
 *       magic_damage:false present as ENTITY_ATTACK from the
 *       caster and intentionally land here too (FINDINGS: in the
 *       stock set those are dash, powerstone, sweep - no primary
 *       damage spells).</li>
 * </ol>
 */
public final class HitClassifier {

    public enum Verdict {
        QUALIFY_PROJECTILE,
        QUALIFY_MAGIC,
        NOT_VICTIM_TYPE,
        PROJECTILE_NOT_PLAYER,
        MAGIC_SIGNATURE_MISMATCH,
        MAGIC_NOT_POTION_DAMAGER,
        MAGIC_POTION_NOT_BLANK,
        MAGIC_NO_PLAYER_CASTER,
        NOT_RANGED
    }

    /**
     * The extracted shape of one damage event. Strings are enum
     * names (EntityType, DamageCause) so the core stays
     * Bukkit-free; booleans are pre-extracted facts.
     *
     * @param victimType               EntityType.name() of the victim
     * @param cause                    DamageCause.name() of the event
     * @param damagerIsProjectile      damager instanceof Projectile
     * @param projectileShooterIsPlayer the projectile's shooter is a Player
     * @param damagerIsThrownPotion    damager instanceof ThrownPotion
     * @param potionHasDamagingEffect  the potion item carries an
     *                                 instant-damage effect (base
     *                                 potion type or custom effect)
     * @param damageTypeMagicFamily    the DamageSource damage type
     *                                 is in the magic family: MAGIC
     *                                 or INDIRECT_MAGIC (Magic's
     *                                 spells hurt through NMS
     *                                 indirectMagic, which reports
     *                                 INDIRECT_MAGIC - proven by
     *                                 the build rig's live Missile
     *                                 hit; FINDINGS said MAGIC and
     *                                 the rig corrected it)
     * @param causingEntityIsPlayer    DamageSource.getCausingEntity() is a Player
     */
    public record Input(
            String victimType,
            String cause,
            boolean damagerIsProjectile,
            boolean projectileShooterIsPlayer,
            boolean damagerIsThrownPotion,
            boolean potionHasDamagingEffect,
            boolean damageTypeMagicFamily,
            boolean causingEntityIsPlayer) {
    }

    private HitClassifier() {
    }

    public static Verdict classify(Input in, Set<String> victimTypes) {
        if (in.victimType() == null || !victimTypes.contains(in.victimType())) {
            return Verdict.NOT_VICTIM_TYPE;
        }
        // Potion branch first: a ThrownPotion is a Projectile in
        // Bukkit's type tree, and its only qualifying shape is the
        // Magic signature.
        if (in.damagerIsThrownPotion()) {
            if (!"MAGIC".equals(in.cause()) || !in.damageTypeMagicFamily()) {
                return Verdict.MAGIC_SIGNATURE_MISMATCH;
            }
            if (in.potionHasDamagingEffect()) {
                return Verdict.MAGIC_POTION_NOT_BLANK;
            }
            if (!in.causingEntityIsPlayer()) {
                return Verdict.MAGIC_NO_PLAYER_CASTER;
            }
            return Verdict.QUALIFY_MAGIC;
        }
        // MAGIC cause with any other damager (cloud, fangs,
        // guardian, a plugin's direct magic source): never the
        // signature.
        if ("MAGIC".equals(in.cause())) {
            return Verdict.MAGIC_NOT_POTION_DAMAGER;
        }
        if ("PROJECTILE".equals(in.cause()) || in.damagerIsProjectile()) {
            return in.damagerIsProjectile() && in.projectileShooterIsPlayer()
                    ? Verdict.QUALIFY_PROJECTILE
                    : Verdict.PROJECTILE_NOT_PLAYER;
        }
        return Verdict.NOT_RANGED;
    }

    public static boolean qualifies(Verdict verdict) {
        return verdict == Verdict.QUALIFY_PROJECTILE || verdict == Verdict.QUALIFY_MAGIC;
    }
}
