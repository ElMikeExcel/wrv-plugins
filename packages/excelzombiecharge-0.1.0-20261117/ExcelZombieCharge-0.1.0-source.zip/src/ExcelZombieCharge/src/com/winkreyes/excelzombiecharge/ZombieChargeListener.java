package com.winkreyes.excelzombiecharge;

import com.winkreyes.excelzombiecharge.core.HitClassifier;
import com.winkreyes.excelzombiecharge.core.ZombieChargeSettings;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityRemoveEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.event.world.EntitiesUnloadEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * The whole listener surface:
 *
 * <p><b>The charge hook</b> - EntityDamageByEntityEvent at
 * MONITOR, cancelled events skipped (ignoreCancelled): the event
 * has fully resolved by MONITOR, so the fields read here are the
 * truth of the hit. The listener only EXTRACTS - cause, damager
 * shape, the potion's damaging-effect fact, the damage type, the
 * causing entity - and hands the shape to the pure-JVM
 * HitClassifier; a qualifying verdict is the only path to a
 * charge. It never cancels, never modifies damage, never touches
 * targeting: vanilla/EliteMobs AI already turns the mob toward
 * its attacker on damage, and the charge only makes it arrive
 * faster.
 *
 * <p><b>The cleanup hooks</b> - death and removal drop the charge
 * with the entity; unload strips the modifier BEFORE the chunk
 * saves (Bukkit modifiers persist in entity data, and a 3-second
 * charge must never be found alive on a reloaded entity); load
 * strips any untracked leftover under our key as the backstop for
 * a crash or a missed unload.
 */
final class ZombieChargeListener implements Listener {

    private final ExcelZombieCharge plugin;
    private final ChargeManager charges;

    ZombieChargeListener(ExcelZombieCharge plugin, ChargeManager charges) {
        this.plugin = plugin;
        this.charges = charges;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof LivingEntity victim)) return;
        ZombieChargeSettings settings = plugin.settings();
        if (!settings.enabled()) return;
        if (!settings.entityTypes().contains(victim.getType().name())) return;

        Entity damager = event.getDamager();
        boolean isProjectile = damager instanceof Projectile;
        boolean shooterIsPlayer = isProjectile
                && ((Projectile) damager).getShooter() instanceof Player;
        boolean isPotion = damager instanceof ThrownPotion;
        boolean potionDamaging = isPotion
                && potionHasDamagingEffect(((ThrownPotion) damager).getItem());
        // The magic family: Magic's spells hurt through NMS
        // DamageSources.indirectMagic, whose Bukkit damage type
        // is INDIRECT_MAGIC; plain MAGIC covers direct magic
        // sources. (FINDINGS said MAGIC; the build rig's live
        // Missile hit proved INDIRECT_MAGIC - see BUILD-RECORD.)
        org.bukkit.damage.DamageType dt = event.getDamageSource().getDamageType();
        boolean typeIsMagicFamily = dt == org.bukkit.damage.DamageType.MAGIC
                || dt == org.bukkit.damage.DamageType.INDIRECT_MAGIC;
        boolean causingIsPlayer = event.getDamageSource().getCausingEntity()
                instanceof Player;

        HitClassifier.Input in = new HitClassifier.Input(
                victim.getType().name(),
                event.getCause().name(),
                isProjectile,
                shooterIsPlayer,
                isPotion,
                potionDamaging,
                typeIsMagicFamily,
                causingIsPlayer);
        HitClassifier.Verdict verdict = HitClassifier.classify(in, settings.entityTypes());

        if (settings.debugLog()) {
            plugin.getLogger().info(String.format(
                    "ExcelZombieCharge: hit on %s (%s): cause=%s damager=%s projectile=%s "
                            + "shooterPlayer=%s potion=%s potionDamaging=%s "
                            + "damageType=%s causingPlayer=%s -> %s",
                    victim.getName(), victim.getType(), event.getCause(),
                    damager == null ? "null" : damager.getType().name(),
                    isProjectile, shooterIsPlayer, isPotion, potionDamaging,
                    event.getDamageSource().getDamageType().getKey(),
                    causingIsPlayer, verdict));
        }
        if (HitClassifier.qualifies(verdict)) {
            charges.applyCharge(victim);
        }
    }

    /**
     * True when the potion item carries an instant-damage effect,
     * in its base potion type or as a custom effect: the mark of a
     * REAL harming potion (a witch's, a player's). Magic's
     * scratch potion is a plain splash potion with no effect at
     * all, and a meta-less item is blank by the same reading.
     */
    static boolean potionHasDamagingEffect(ItemStack item) {
        if (item == null) return false;
        if (!(item.getItemMeta() instanceof PotionMeta meta)) return false;
        if (meta.getBasePotionType() != null) {
            for (PotionEffect effect : meta.getBasePotionType().getPotionEffects()) {
                if (effect.getType() == PotionEffectType.INSTANT_DAMAGE) return true;
            }
        }
        for (PotionEffect effect : meta.getCustomEffects()) {
            if (effect.getType() == PotionEffectType.INSTANT_DAMAGE) return true;
        }
        return false;
    }

    // ---------- cleanup hooks ----------

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(EntityDeathEvent event) {
        charges.stripCharge(event.getEntity());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRemove(EntityRemoveEvent event) {
        if (event.getEntity() instanceof LivingEntity living) {
            charges.stripCharge(living);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onEntitiesUnload(EntitiesUnloadEvent event) {
        for (Entity e : event.getEntities()) {
            if (e instanceof LivingEntity living
                    && charges.tracker().isTracked(e.getUniqueId())) {
                charges.stripCharge(living);
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onEntitiesLoad(EntitiesLoadEvent event) {
        for (Entity e : event.getEntities()) {
            charges.stripStale(e);
        }
    }
}
