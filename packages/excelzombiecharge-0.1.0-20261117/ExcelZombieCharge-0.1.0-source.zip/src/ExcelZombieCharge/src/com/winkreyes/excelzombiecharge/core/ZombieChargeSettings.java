package com.winkreyes.excelzombiecharge.core;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * The immutable settings snapshot: read from config at enable and
 * at /provoke reload, then swapped atomically (a reload can never
 * leave a half-read config live). Every value is clamped, never
 * thrown - a typo in the file degrades to the nearest sane value,
 * in the house SkullSettings/RaidBuffConfig style. (The loader
 * separately warns about entity-type tokens that match no
 * EntityType - the core stays Bukkit-free, so unknown tokens are
 * kept here and simply never match a victim; the warning makes
 * the typo visible instead of silent.)
 */
public record ZombieChargeSettings(
        boolean enabled,
        double speedMultiplier,
        long durationTicks,
        Set<String> entityTypes,
        boolean debugLog) {

    public static final boolean DEFAULT_ENABLED = true;
    public static final double DEFAULT_SPEED_MULTIPLIER = 0.5;
    public static final long DEFAULT_DURATION_TICKS = 60L;
    public static final boolean DEFAULT_DEBUG_LOG = false;

    /** The approved victim set: the zombie family + piglins. Hoglin is NOT in it. */
    public static final List<String> DEFAULT_ENTITY_TYPES = List.of(
            "ZOMBIE", "HUSK", "DROWNED", "ZOMBIE_VILLAGER",
            "ZOMBIFIED_PIGLIN", "PIGLIN", "PIGLIN_BRUTE");

    public static ZombieChargeSettings defaults() {
        return new ZombieChargeSettings(DEFAULT_ENABLED, DEFAULT_SPEED_MULTIPLIER,
                DEFAULT_DURATION_TICKS, new LinkedHashSet<>(DEFAULT_ENTITY_TYPES),
                DEFAULT_DEBUG_LOG);
    }

    /**
     * Build a snapshot from raw config values (nulls = keys
     * absent). The multiplier is clamped into [0, 4] (a negative
     * "charge" would be a slow, which this plugin never deals;
     * 4x is beyond any sane tuning), a non-finite value falls
     * back to the default, and the duration is clamped into
     * [1, 7200] ticks. A provided type list is normalized (trim,
     * uppercase, blanks dropped, duplicates collapsed) and used
     * as given - an explicitly empty list means NO type charges,
     * honored rather than second-guessed.
     */
    public static ZombieChargeSettings of(Boolean enabled, Double speedMultiplier,
                                     Integer durationTicks, List<String> entityTypes,
                                     Boolean debugLog) {
        boolean e = enabled != null ? enabled : DEFAULT_ENABLED;
        double m = DEFAULT_SPEED_MULTIPLIER;
        if (speedMultiplier != null && Double.isFinite(speedMultiplier)) {
            m = Math.max(0.0, Math.min(4.0, speedMultiplier));
        }
        long d = DEFAULT_DURATION_TICKS;
        if (durationTicks != null) {
            d = Math.max(1L, Math.min(7200L, durationTicks.longValue()));
        }
        Set<String> types = new LinkedHashSet<>();
        if (entityTypes == null) {
            types.addAll(DEFAULT_ENTITY_TYPES);
        } else {
            for (String raw : entityTypes) {
                if (raw == null) continue;
                String t = raw.trim().toUpperCase(java.util.Locale.ROOT);
                if (!t.isEmpty()) types.add(t);
            }
        }
        boolean dbg = debugLog != null ? debugLog : DEFAULT_DEBUG_LOG;
        return new ZombieChargeSettings(e, m, d, Set.copyOf(types), dbg);
    }
}
