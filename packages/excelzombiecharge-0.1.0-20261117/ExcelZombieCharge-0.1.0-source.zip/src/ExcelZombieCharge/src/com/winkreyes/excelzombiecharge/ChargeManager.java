package com.winkreyes.excelzombiecharge;

import com.winkreyes.excelzombiecharge.core.ChargeTracker;
import com.winkreyes.excelzombiecharge.core.ZombieChargeSettings;
import org.bukkit.Bukkit;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;

import java.util.UUID;

/**
 * Owns every attribute write and the charge bookkeeping that
 * pairs with it. The rule of the house: a tracker entry and the
 * attribute modifier are born together (applyCharge) and die
 * together (stripCharge / sweep / clearAll); the one sanctioned
 * exception is {@link #stripStale}, which removes a modifier that
 * has NO tracker entry - by definition a leftover (see below).
 *
 * <p>Why stale cleanup exists: Bukkit attribute modifiers are
 * part of the entity's persistent attribute map - they survive
 * chunk unload and server restart in the entity's data. The
 * charge is a 3-second transient and must never outlive its
 * window, so: the unload listener strips the modifier before the
 * chunk goes away, the sweep drops tracking for entities it can
 * no longer reach, and the load listener + a boot pass strip any
 * modifier carrying our key - or the legacy ExcelProvoke key -
 * that has no live tracker entry (reachable after a crash
 * mid-charge, a missed unload, or the rename swap). A
 * live charge always has a tracker entry, so an untracked
 * modifier under either key is stale by definition.
 *
 * <p>The modifier is added with addModifier under one fixed
 * namespaced key, Operation MULTIPLY_SCALAR_1: it multiplies the
 * total (base + other modifiers), coexists with EliteMobs' own
 * movement_speed handling (EM's lua power grants a Speed potion
 * EFFECT, a different channel entirely) and never writes the
 * base value. Apply is remove-then-add, so a refresh can neither
 * stack nor throw on the duplicate key.
 *
 * <p>RENAME MIGRATION (ExcelProvoke -> ExcelZombieCharge):
 * every removal in this class takes BOTH keys - our own
 * excelzombiecharge:speed and the legacy excelprovoke:speed.
 * Charges are only ever APPLIED under our own key, but a mob
 * saved while charged by the old plugin carries the legacy
 * modifier in its data, and the old plugin is not there to
 * remove it after the swap. A legacy modifier can never be a
 * live charge of ours, so removing it wherever we remove our
 * own is always safe. (core/ChargeKeys holds the key strings and
 * the pinned strip set.)
 */
final class ChargeManager {

    private final ExcelZombieCharge plugin;
    private final ChargeTracker tracker = new ChargeTracker();

    ChargeManager(ExcelZombieCharge plugin) {
        this.plugin = plugin;
    }

    ChargeTracker tracker() {
        return tracker;
    }

    /** Remove every charge modifier from the attribute: ours AND the legacy key. */
    private static void removeChargeModifiers(AttributeInstance attr) {
        attr.removeModifier(ExcelZombieCharge.MODIFIER_KEY);
        attr.removeModifier(ExcelZombieCharge.LEGACY_MODIFIER_KEY);
    }

    /** Start or refresh the charge on a victim. Main thread only. */
    void applyCharge(LivingEntity entity) {
        AttributeInstance attr = entity.getAttribute(Attribute.MOVEMENT_SPEED);
        if (attr == null) return;
        ZombieChargeSettings s = plugin.settings();
        removeChargeModifiers(attr);
        attr.addModifier(new AttributeModifier(ExcelZombieCharge.MODIFIER_KEY,
                s.speedMultiplier(), AttributeModifier.Operation.MULTIPLY_SCALAR_1));
        tracker.apply(entity.getUniqueId(), Bukkit.getCurrentTick(), s.durationTicks());
        if (s.debugLog()) {
            plugin.getLogger().info(String.format(
                    "ExcelZombieCharge: CHARGED %s (%s) speed x%.2f for %d ticks (value now %.4f)",
                    entity.getName(), entity.getType(), 1.0 + s.speedMultiplier(),
                    s.durationTicks(), attr.getValue()));
        }
    }

    /** Remove the charge (modifier + tracking) from an entity. */
    void stripCharge(LivingEntity entity) {
        AttributeInstance attr = entity.getAttribute(Attribute.MOVEMENT_SPEED);
        if (attr != null) removeChargeModifiers(attr);
        tracker.remove(entity.getUniqueId());
    }

    /**
     * Remove a charge modifier from an entity that has one but no
     * live tracker entry: a leftover from a crash, a missed
     * unload, or - under the LEGACY excelprovoke:speed key - a
     * charge applied by ExcelProvoke before the rename (the old
     * plugin is gone after the swap and cannot strip its own).
     * Live charges are untouched - they are tracked by
     * definition. Returns true when a stale modifier was removed.
     */
    boolean stripStale(Entity entity) {
        if (!(entity instanceof LivingEntity living)) return false;
        if (tracker.isTracked(entity.getUniqueId())) return false;
        AttributeInstance attr = living.getAttribute(Attribute.MOVEMENT_SPEED);
        if (attr == null) return false;
        boolean ours = attr.getModifier(ExcelZombieCharge.MODIFIER_KEY) != null;
        boolean legacy = attr.getModifier(ExcelZombieCharge.LEGACY_MODIFIER_KEY) != null;
        if (!ours && !legacy) return false;
        removeChargeModifiers(attr);
        if (legacy) {
            plugin.getLogger().info("ExcelZombieCharge: stripped a LEGACY ExcelProvoke "
                    + "charge modifier (excelprovoke:speed) from "
                    + living.getName() + " (" + living.getType()
                    + ") - leftover from before the rename");
        }
        if (ours) {
            plugin.getLogger().info("ExcelZombieCharge: stripped a stale charge modifier from "
                    + living.getName() + " (" + living.getType()
                    + ") - it had outlived its charge window");
        }
        return true;
    }

    boolean isModifierPresent(LivingEntity entity) {
        AttributeInstance attr = entity.getAttribute(Attribute.MOVEMENT_SPEED);
        return attr != null && attr.getModifier(ExcelZombieCharge.MODIFIER_KEY) != null;
    }

    /**
     * The 10-tick sweep: expire finished charges (modifier off,
     * tracking dropped) and drop tracking for entities that are
     * gone, dead or unloaded (their modifier is either gone with
     * them or already stripped at unload; if a modifier somehow
     * persists in saved data, the load-time stale strip is the
     * backstop). Runs on the main thread via the scheduler.
     */
    void sweep() {
        long now = Bukkit.getCurrentTick();
        for (UUID id : tracker.tracked()) {
            Entity e = Bukkit.getEntity(id);
            if (!(e instanceof LivingEntity living) || !living.isValid() || living.isDead()) {
                tracker.remove(id);
                continue;
            }
            if (!tracker.isCharged(id, now)) {
                AttributeInstance attr = living.getAttribute(Attribute.MOVEMENT_SPEED);
                if (attr != null) removeChargeModifiers(attr);
                tracker.remove(id);
                if (plugin.settings().debugLog()) {
                    plugin.getLogger().info("ExcelZombieCharge: charge expired on "
                            + living.getName() + " (" + living.getType() + ")");
                }
            }
        }
    }

    /** Plugin disable: every reachable modifier off, book cleared. */
    void clearAll() {
        for (UUID id : tracker.tracked()) {
            Entity e = Bukkit.getEntity(id);
            if (e instanceof LivingEntity living) {
                AttributeInstance attr = living.getAttribute(Attribute.MOVEMENT_SPEED);
                if (attr != null) removeChargeModifiers(attr);
            }
        }
        tracker.clear();
    }
}
