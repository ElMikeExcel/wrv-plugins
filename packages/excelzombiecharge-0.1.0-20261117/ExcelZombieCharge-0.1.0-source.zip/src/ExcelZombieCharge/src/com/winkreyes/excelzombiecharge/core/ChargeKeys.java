package com.winkreyes.excelzombiecharge.core;

import java.util.List;

/**
 * The attribute-modifier key strings, as pure data so the plain
 * JVM suites can pin them (the core stays Bukkit-free; the plugin
 * class builds the real NamespacedKeys from these parts).
 *
 * <p>ExcelZombieCharge is ExcelProvoke 0.1.0 renamed (Mike's
 * naming rule, Oct 21, 2026: a plugin's name must describe what
 * it does - "hit it from range, it charges you"). Charges applied
 * by THIS plugin live under {@link #MODIFIER_KEY_STRING}. The
 * predecessor's key, {@link #LEGACY_KEY_STRING}, is never applied
 * here, but it IS in the strip set: Bukkit attribute modifiers
 * serialize with the entity's saved data, and after the jar swap
 * the old plugin is no longer there to clean up its own
 * leftovers - so this plugin's stale-strip (boot pass and
 * EntitiesLoad) removes BOTH keys from any entity that carries
 * one without a live tracker entry.
 */
public final class ChargeKeys {

    /** Namespace of the current plugin's modifier key. */
    public static final String NAMESPACE = "excelzombiecharge";
    /** Namespace of the predecessor plugin's (ExcelProvoke) key. */
    public static final String LEGACY_NAMESPACE = "excelprovoke";
    /** The key path shared by both namespaces. */
    public static final String KEY_PATH = "speed";

    /** The key every charge applied by this plugin lives under. */
    public static final String MODIFIER_KEY_STRING = NAMESPACE + ":" + KEY_PATH;
    /** ExcelProvoke's key: never applied here, always stripped when stale. */
    public static final String LEGACY_KEY_STRING = LEGACY_NAMESPACE + ":" + KEY_PATH;

    /** Every modifier key the stale-strip removes (current + legacy). */
    public static final List<String> STRIP_KEY_STRINGS =
            List.of(MODIFIER_KEY_STRING, LEGACY_KEY_STRING);

    private ChargeKeys() {
    }

    /** True when keyString (NamespacedKey.asString()) is one we strip when stale. */
    public static boolean isStripKey(String keyString) {
        return keyString != null && STRIP_KEY_STRINGS.contains(keyString);
    }
}
