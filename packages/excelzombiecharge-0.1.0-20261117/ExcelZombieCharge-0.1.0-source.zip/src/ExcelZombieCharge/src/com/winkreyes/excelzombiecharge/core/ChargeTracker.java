package com.winkreyes.excelzombiecharge.core;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * The charge book: which entities are currently charged, and the
 * tick at which each charge expires. Pure JVM with the tick
 * supplied by the caller (the plugin passes Bukkit's current
 * tick; the tests pass a scripted tick source), so refresh and
 * expiry semantics are pinned deterministically with no
 * wall-clock anywhere.
 *
 * <p>Semantics: apply(id, now, duration) sets the expiry to
 * now + duration, replacing any previous entry - a second
 * qualifying hit REFRESHES, it never stacks and never shortens a
 * longer remaining charge unless the new expiry is itself the
 * later one (it always is when hits arrive in tick order: now
 * only moves forward). A charge is live while now &lt; expiry and
 * expired when now &gt;= expiry; the plugin's sweep removes the
 * expired. The tracker knows nothing about attributes - the
 * plugin pairs every tracker transition with the matching
 * attribute operation.
 */
public final class ChargeTracker {

    private final java.util.Map<UUID, Long> expiryByUuid = new java.util.HashMap<>();

    /** Start or refresh a charge: expiry becomes nowTick + durationTicks. */
    public void apply(UUID id, long nowTick, long durationTicks) {
        expiryByUuid.put(id, nowTick + durationTicks);
    }

    /** True while the charge is live at nowTick (nowTick &lt; expiry). */
    public boolean isCharged(UUID id, long nowTick) {
        Long expiry = expiryByUuid.get(id);
        return expiry != null && nowTick < expiry;
    }

    /** True if the id is tracked at all, live or expired-unswept. */
    public boolean isTracked(UUID id) {
        return expiryByUuid.containsKey(id);
    }

    /** The expiry tick for id, or -1 when untracked. */
    public long expiryOf(UUID id) {
        return expiryByUuid.getOrDefault(id, -1L);
    }

    /** Every tracked id whose charge has expired at nowTick. */
    public Set<UUID> expired(long nowTick) {
        Set<UUID> out = new HashSet<>();
        for (var e : expiryByUuid.entrySet()) {
            if (nowTick >= e.getValue()) out.add(e.getKey());
        }
        return out;
    }

    /** A snapshot of every tracked id (live and expired-unswept). */
    public Set<UUID> tracked() {
        return new HashSet<>(expiryByUuid.keySet());
    }

    /** Drop one id. Returns true when it was tracked. Idempotent. */
    public boolean remove(UUID id) {
        return expiryByUuid.remove(id) != null;
    }

    public void clear() {
        expiryByUuid.clear();
    }

    public int size() {
        return expiryByUuid.size();
    }
}
