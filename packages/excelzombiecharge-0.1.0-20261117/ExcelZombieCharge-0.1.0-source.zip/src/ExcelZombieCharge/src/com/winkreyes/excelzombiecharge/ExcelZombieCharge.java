package com.winkreyes.excelzombiecharge;

import com.winkreyes.excelzombiecharge.core.ZombieChargeSettings;
import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.List;

/**
 * ExcelZombieCharge - Wink Reyes Valley (Excel signature).
 *
 * <p>The anti-kiting charge (Mike's approval, Oct 21, 2026):
 * when a mob of the zombie family or a piglin takes a RANGED hit
 * from a player - an arrow, a bolt, a thrown trident, or a Magic
 * spell carrying the verified signature (design source:
 * ~/workspace/provoke-speed/FINDINGS.md) - it CHARGES: +50%
 * movement speed for 3 seconds, refreshed by every further
 * qualifying hit, never stacking. Melee hits never trigger it, so
 * standing your ground stays the calm option and sniping is what
 * provokes the charge. The mechanic exists because the bow lane
 * could plink a 0.23-speed zombie from 30 blocks while it merely
 * waded closer; the charge closes that gap without touching any
 * damage number, any targeting rule, or any other mob.
 *
 * <p>Everything here is signature- and attribute-based: no
 * dependency on Magic or EliteMobs (both are read about in
 * FINDINGS, neither is linked), no particles, no sounds, no
 * writes to any base value, and no state outside a fixed-key
 * attribute modifier plus its in-memory expiry entry - a pair
 * born together and cleaned up together on expiry, death,
 * removal, chunk unload, and disable, with a load-time stale
 * strip as the crash backstop.
 *
 * <p>This plugin is ExcelProvoke 0.1.0 RENAMED (Mike picked
 * "ExcelZombieCharge" Oct 21, 2026, under his naming rule: the
 * name must describe the mechanic). Identity only - the behavior
 * is the predecessor's, untouched. The one migration duty the
 * rename creates is in the stale-strip: charges the old plugin
 * applied live under excelprovoke:speed and persist in entity
 * data, so the strip removes the LEGACY key alongside our own
 * (see {@link #LEGACY_MODIFIER_KEY} and core/ChargeKeys).
 */
public final class ExcelZombieCharge extends JavaPlugin {

    public static final String PERM_ADMIN = "excelzombiecharge.admin";

    /** The one modifier key every charge lives under: excelzombiecharge:speed. */
    public static final NamespacedKey MODIFIER_KEY =
            new NamespacedKey(com.winkreyes.excelzombiecharge.core.ChargeKeys.NAMESPACE,
                    com.winkreyes.excelzombiecharge.core.ChargeKeys.KEY_PATH);

    /**
     * The predecessor's key: excelprovoke:speed (ExcelProvoke
     * 0.1.0, renamed to this plugin). Never applied here, but the
     * stale-strip removes it alongside our own key - attribute
     * modifiers serialize with entity data, and after the jar
     * swap the old plugin is gone and cannot clean up after
     * itself. See core/ChargeKeys.
     */
    public static final NamespacedKey LEGACY_MODIFIER_KEY =
            new NamespacedKey(com.winkreyes.excelzombiecharge.core.ChargeKeys.LEGACY_NAMESPACE,
                    com.winkreyes.excelzombiecharge.core.ChargeKeys.KEY_PATH);

    private volatile ZombieChargeSettings settings = ZombieChargeSettings.defaults();
    private ChargeManager charges;
    private BukkitTask sweepTask;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        settings = loadSettings();
        charges = new ChargeManager(this);
        getServer().getPluginManager().registerEvents(new ZombieChargeListener(this, charges), this);
        ZombieChargeCommand cmd = new ZombieChargeCommand(this);
        if (getCommand("provoke") != null) {
            getCommand("provoke").setExecutor(cmd);
            getCommand("provoke").setTabCompleter(cmd);
        }
        // The sweep: every 10 ticks, expire finished charges and
        // drop tracking for entities that left the world.
        sweepTask = getServer().getScheduler().runTaskTimer(this, charges::sweep, 10L, 10L);
        // Boot pass: any modifier under our key - or the legacy
        // ExcelProvoke key - on an already loaded entity is a
        // leftover from a crash mid-charge or the rename swap
        // (the tracker starts empty by definition). Deferred one
        // tick so world entities are fully live.
        getServer().getScheduler().runTask(this, () -> {
            int stripped = 0;
            for (org.bukkit.World world : getServer().getWorlds()) {
                for (org.bukkit.entity.LivingEntity living : world.getLivingEntities()) {
                    if (charges.stripStale(living)) stripped++;
                }
            }
            if (stripped > 0) {
                getLogger().info("ExcelZombieCharge: boot pass stripped " + stripped
                        + " stale charge modifier(s) left by an earlier run");
            }
        });
        getLogger().info("ExcelZombieCharge enabled: "
                + (settings.enabled() ? "charge ON" : "charge DISABLED by config")
                + ", speed x" + String.format("%.2f", 1.0 + settings.speedMultiplier())
                + " (+" + settings.speedMultiplier() + ") for " + settings.durationTicks()
                + " ticks, refreshed per qualifying hit, victim types "
                + settings.entityTypes());
    }

    @Override
    public void onDisable() {
        if (sweepTask != null) sweepTask.cancel();
        if (charges != null) charges.clearAll();
    }

    /** The live settings snapshot (swapped whole on reload). */
    public ZombieChargeSettings settings() {
        return settings;
    }

    ChargeManager charges() {
        return charges;
    }

    /**
     * Re-read config.yml and swap the snapshot. A broken file
     * keeps the previous snapshot - a reload can never wedge the
     * plugin or throw into the command. Live charges keep the
     * terms they were applied under; the new settings govern the
     * next qualifying hit, and durations already in the book run
     * out on the sweep as before.
     */
    public synchronized boolean reloadAll() {
        try {
            reloadConfig();
            settings = loadSettings();
            return true;
        } catch (Throwable t) {
            getLogger().warning("ExcelZombieCharge: config reload failed (" + t
                    + ") - keeping the previous settings");
            return false;
        }
    }

    private ZombieChargeSettings loadSettings() {
        Boolean enabled = getConfig().contains("enabled")
                ? getConfig().getBoolean("enabled") : null;
        Double mult = getConfig().contains("speed-multiplier")
                ? getConfig().getDouble("speed-multiplier") : null;
        Integer duration = getConfig().contains("duration-ticks")
                ? getConfig().getInt("duration-ticks") : null;
        List<String> types = getConfig().contains("entity-types")
                ? getConfig().getStringList("entity-types") : null;
        Boolean debug = getConfig().contains("debug-log")
                ? getConfig().getBoolean("debug-log") : null;
        ZombieChargeSettings s = ZombieChargeSettings.of(enabled, mult, duration,
                types == null ? null : new ArrayList<>(types), debug);
        // Surface typos: an entity-type token that matches no
        // EntityType can never match a victim, so say so loudly
        // instead of letting it sit silent.
        for (String token : s.entityTypes()) {
            try {
                org.bukkit.entity.EntityType.valueOf(token);
            } catch (IllegalArgumentException ex) {
                getLogger().warning("ExcelZombieCharge: entity-types entry '" + token
                        + "' matches no EntityType and will never charge anything");
            }
        }
        return s;
    }
}
