package com.winkreyes.excelzombiecharge;

import com.winkreyes.excelzombiecharge.core.ZombieChargeSettings;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.List;

/** /provoke status|reload - the whole admin surface. */
final class ZombieChargeCommand implements CommandExecutor, TabCompleter {

    private final ExcelZombieCharge plugin;

    ZombieChargeCommand(ExcelZombieCharge plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission(ExcelZombieCharge.PERM_ADMIN)) {
            sender.sendMessage("ExcelZombieCharge: you need the excelzombiecharge.admin permission.");
            return true;
        }
        String sub = args.length > 0 ? args[0].toLowerCase() : "status";
        switch (sub) {
            case "status" -> {
                ZombieChargeSettings s = plugin.settings();
                sender.sendMessage("ExcelZombieCharge: "
                        + (s.enabled() ? "charge ON" : "charge DISABLED by config")
                        + ", speed x" + String.format("%.2f", 1.0 + s.speedMultiplier())
                        + " for " + s.durationTicks() + " ticks"
                        + ", victim types " + s.entityTypes()
                        + ", debug log " + (s.debugLog() ? "on" : "off")
                        + ", charges live now: " + plugin.charges().tracker().size());
            }
            case "reload" -> {
                boolean ok = plugin.reloadAll();
                ZombieChargeSettings s = plugin.settings();
                sender.sendMessage(ok
                        ? "ExcelZombieCharge: reloaded - charge "
                                + (s.enabled() ? "ON" : "DISABLED") + ", speed x"
                                + String.format("%.2f", 1.0 + s.speedMultiplier())
                                + " for " + s.durationTicks() + " ticks."
                        : "ExcelZombieCharge: reload FAILED - previous settings kept.");
            }
            default -> sender.sendMessage("ExcelZombieCharge: usage /provoke <status|reload>");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1 && sender.hasPermission(ExcelZombieCharge.PERM_ADMIN)) {
            return List.of("status", "reload").stream()
                    .filter(x -> x.startsWith(args[0].toLowerCase()))
                    .toList();
        }
        return List.of();
    }
}
