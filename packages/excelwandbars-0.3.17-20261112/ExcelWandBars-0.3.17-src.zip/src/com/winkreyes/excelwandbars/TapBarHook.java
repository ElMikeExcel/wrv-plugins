package com.winkreyes.excelwandbars;

import com.elmakers.mine.bukkit.api.event.CastEvent;
import com.elmakers.mine.bukkit.api.event.SpellInventoryEvent;
import com.elmakers.mine.bukkit.api.event.WandActivatedEvent;
import com.elmakers.mine.bukkit.api.magic.Mage;
import com.elmakers.mine.bukkit.api.magic.MagicAPI;
import com.elmakers.mine.bukkit.api.wand.Wand;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.inventory.meta.ItemMeta;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import com.winkreyes.excelwandbars.core.BookHoldPlan;
import com.winkreyes.excelwandbars.core.SpellFacts;
import com.winkreyes.excelwandbars.core.SpellInfoText;
import com.winkreyes.excelwandbars.core.WandStyle;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * 0.2.4: the touch opener for the two hotbar-icon styles (Tap bar and Tap to
 * cycle (original)). Magic (elmakers) already does the hard part: in inventory
 * mode it stores the player's real hotbar, fills it with spell icons, casts
 * (quick cast) or picks (no quick cast) on a slot change and cancels that
 * change so the wand stays selected, and puts the real items back on close,
 * death, quit and world change. On Bedrock touch nothing reaches the server
 * for a tap on air, so Magic's "right click opens the bar" never fires.
 * This hook adds:
 *  - picking the wand in the hotbar opens the bar (the wand becomes active),
 *  - tapping an EMPTY slot while the bar is open puts the items back and
 *    selects that slot (so a phone player is never stuck on the wand),
 *  - the bar closes by itself after close-after-idle-seconds with no spell,
 *  - the bar closes before another inventory (chest, furnace...) opens and
 *    when this plugin stops (belt and braces: Magic also closes it).
 * Closing always uses Magic's own Wand.closeInventory(), which restores the
 * stored items. This class never creates, moves or deletes an item itself.
 *
 * 0.2.4 hold to read (Tap bar only):
 *  - On touch, Geyser turns a press and hold into an arm swing (left click).
 *    In Tap bar that swing no longer casts (casting is the one tap on an icon):
 *    with the bar down it opens the bar, with the bar up it shows the Spell
 *    Book detail page (the same text as /spellinfo: what it does, cost,
 *    cooldown, range, rank and the live "Next rank: N of M casts") for the
 *    last spell icon tapped, or the whole Spell Book when none was tapped yet.
 *    A held finger sends several swings; they count as one hold (hold-gap-ms).
 *  - The icons' name and lore get the same lines (icon-lore), refreshed when
 *    the bar opens and after each cast. Only the display name and lore of an
 *    item Magic itself marks as a spell icon change; nothing is created or
 *    moved, and Magic's own tags stay, so Magic still restores the real items.
 */
final class TapBarHook implements Listener {
    private final ExcelWandBars plugin;
    private final MagicAPI api;
    private boolean openOnHold = true;
    private boolean emptySlotCloses = true;
    private long idleCloseMs = 15_000;
    private boolean closeOnOtherInventory = true;
    private boolean holdShowsInfo = true;
    private long holdGapMs = 700;
    private long rememberTapMs = 30_000;
    private boolean iconLore = true;
    /** spellbook = name + lore are the Spell Book lines; magic = Magic's own name/lore kept, the next-rank line added. */
    private boolean loreMagicStyle = false;
    /** 0.3.12: when each player's bar was first seen open (slot-guard settle gate). */
    private final Map<UUID, Long> barOpenSince = new HashMap<>();
    private final Map<UUID, Long> lastSwing = new HashMap<>();
    private final Map<UUID, Long> lastSlotPick = new HashMap<>();
    private final Map<UUID, String> lastTapKey = new HashMap<>();
    private final Map<UUID, Long> lastTapAt = new HashMap<>();
    private final Map<UUID, String> lastHold = new HashMap<>();
    private long holdsInfo, holdsOpen, holdsMerged, holdsSkipped, loreSet;
    /** 0.2.5 counters: cancelled slot changes ignored (bar down), holds read from a drop, casts blocked during a hold. */
    private long heldCancelledIgnored, dropReads, dropCloses, holdCastsBlocked, pageLines;
    /** 0.2.5: right clicks with the Tap bar wand (Magic's right_click is "none" there): Bedrock reads, Java opens or puts items back. */
    private long rightReads, rightOpens, rightCloses, rightRepeats;
    private final Map<UUID, Long> lastRight = new HashMap<>();
    /** 0.2.6 Tap to pick (original): right clicks are ours (Magic's right_click is "none" there). */
    private long origRightOpens, origRightCloses, origHoldCasts, origHoldSwingCast, origRightRepeats;
    /** 0.2.6: when this player's last cast started (PreCastEvent), so one press and hold casts once. */
    private final Map<UUID, Long> lastCastStart = new HashMap<>();
    /** 0.2.5: a press and hold within this long after tapping an icon reads THAT spell (the finger is still on it). */
    private long holdReadsTapMs = 1500;
    /** 0.2.5: Tap bar stays up while the wand is held (no idle close); items back = the empty slot, Q or the wand slot hold. */
    private boolean tapBarStaysOpen = true;
    private final Map<UUID, Long> lastHoldSignal = new HashMap<>();
    private final Map<UUID, Long> lastUse = new HashMap<>();
    private final Map<UUID, String> lastCast = new HashMap<>();
    private final Map<UUID, Integer> casts = new HashMap<>();
    private long opened, closedIdle, closedEmpty, closedOther;
    private BukkitTask ticker;
    /** 0.2.7: tapping the wand itself (the slot already selected). toggle = items back when the bar is up, bar up when it is down. */
    private String tapWand = "toggle";
    private long tapWandGuardMs = 700;
    private final Map<UUID, Long> lastServerChange = new HashMap<>();
    private long wandTapCloses, wandTapOpens, wandTapGuarded, wandTapIgnored, wandTapSeen;
    private String wandTapSource = "off";
    /** Fake-tap fix: a wand packet outside an input burst is a client sync echo, not a tap (WandSlotPlan.isDeliberateTap). */
    private long tapWandFreshMs = 1000;
    private static final long TAP_PRIME_MS = 2000;
    private final Map<UUID, Long> lastWandTapPrime = new HashMap<>();
    private long wandTapEcho;
    /**
     * 0.3.5: crouch + hold opens the Spell Book, qualified on Bukkit signals (BookHoldPlan).
     * The protocol gate (CrouchHoldGate via GeyserHoldHook) starves on real clients: Geyser
     * never synthesizes the SIMULATION_TICK feed it needs (investigation, Oct 30 2026). It
     * stays installed as a fast path into the same dispatch (dispatchBook).
     */
    private final BookHoldPlan bookHold = new BookHoldPlan();
    private boolean bookHoldEnabled = true;
    private long bookHoldMs = BookHoldPlan.DEFAULT_HOLD_MS;
    private boolean bookHoldJava = false;
    private final Map<UUID, Long> sneakDownAt = new HashMap<>();
    /** The current press burst's start and last signal (gap-chained exactly like the world hold). */
    private final Map<UUID, Long> bookPressStart = new HashMap<>();
    private final Map<UUID, Long> bookLastSignal = new HashMap<>();
    private final Map<UUID, Long> lastBookFire = new HashMap<>();
    private long bookBukkit, bookProtocol, bookFallbacks, bookClaims, worldReads;
    /** 0.3.6: the exit-slot relocation sweep runs in tryOpen's tap-bar branch (ExitSweep). */
    private boolean exitSweepEnabled = true;
    private long exitSweeps, exitMoved, exitLeft;
    /** 0.3.12: the slot guard's counts (core.SlotGuardPlan + PresentedSweep). */
    private long slotGuardBlocks, slotSweeps, slotMoved, slotLeft;
    /**
     * 0.3.8: the login wand-mode trap fix (JoinGuardPlan). A bar found open inside
     * the join grace window with no deliberate engagement since the join is a bar
     * Magic restored from the last session, not one the player chose: close it so
     * the join lands on the normal hotbar. The page is never slot-dependent, so a
     * compass (or anything else) sitting in the exit slot cannot block it.
     */
    private boolean joinStartsOnItems = true;
    private long joinGraceMs = 8000;
    private final Map<UUID, Long> joinedAt = new HashMap<>();
    private final Map<UUID, Long> openedSinceJoin = new HashMap<>();
    private long joinGuardCloses, joinGuardBlocked;
    // 0.3.11: the join sweep runs at most once per join (final guard check),
    // and the quit close counts its own closes / blocked closes.
    private final Set<UUID> joinSwept = new HashSet<>();
    private long joinSweeps, joinSweepMoved, joinSweepLeft;
    private long quitCloses, quitCloseBlocked;

    TapBarHook(ExcelWandBars plugin, MagicAPI api) { this.plugin = plugin; this.api = api; }

    void loadSettings(ConfigurationSection c) {
        openOnHold = c == null || c.getBoolean("open-on-hold", true);
        emptySlotCloses = c == null || c.getBoolean("empty-slot-closes", true);
        idleCloseMs = Math.max(0, (c == null ? 15 : c.getLong("close-after-idle-seconds", 15)) * 1000L);
        closeOnOtherInventory = c == null || c.getBoolean("close-before-other-inventory", true);
        holdShowsInfo = c == null || c.getBoolean("hold-shows-info", true);
        holdGapMs = Math.max(0, c == null ? 700 : c.getLong("hold-gap-ms", 700));
        rememberTapMs = Math.max(0, (c == null ? 30 : c.getLong("info-remembers-tap-seconds", 30)) * 1000L);
        Object il = c == null ? null : c.get("icon-lore");
        String ils = il == null ? "spellbook" : String.valueOf(il).trim().toLowerCase(java.util.Locale.ROOT);
        iconLore = !(ils.equals("false") || ils.equals("off") || ils.equals("none"));
        loreMagicStyle = ils.equals("magic") || ils.equals("magic-plus-rank");
        holdReadsTapMs = Math.max(0, c == null ? 1500 : c.getLong("hold-reads-tap-ms", 1500));
        tapBarStaysOpen = c == null || c.getBoolean("tap-bar-stays-open", true);
        Object tw = c == null ? null : c.get("tap-wand");
        String tws = tw == null ? "toggle" : String.valueOf(tw).trim().toLowerCase(java.util.Locale.ROOT);
        tapWand = tws.equals("false") || tws.equals("off") || tws.equals("none") ? "off" : tws.equals("close") ? "close" : "toggle";
        tapWandGuardMs = Math.max(0, c == null ? 700 : c.getLong("tap-wand-guard-ms", 700));
        tapWandFreshMs = Math.max(0, c == null ? 1000 : c.getLong("tap-wand-fresh-input-ms", 1000));
        bookHoldEnabled = c == null || c.getBoolean("book-hold", true);
        bookHoldMs = Math.max(100, c == null ? BookHoldPlan.DEFAULT_HOLD_MS : c.getLong("book-hold-ms", BookHoldPlan.DEFAULT_HOLD_MS));
        bookHoldJava = c != null && c.getBoolean("book-hold-java", false);
        exitSweepEnabled = c == null || c.getBoolean("exit-sweep", true);
        joinStartsOnItems = c == null || c.getBoolean("join-starts-on-items", true);
        joinGraceMs = Math.max(2000, Math.min(30000, c == null ? 8000 : c.getLong("join-grace-ms", 8000)));
    }

    boolean tapWandWanted() { return !"off".equals(tapWand); }
    void setTapWandSource(String s) { wandTapSource = s; }

    /** 0.2.7: WandSlotHook moved the wand and selected it: count it as the player's pick (the Tap bar opener needs one). */
    void notePick(Player p) { lastSlotPick.put(p.getUniqueId(), System.currentTimeMillis()); noteServerChange(p); }

    /** 0.2.7: the server just changed this player's hotbar or selection; a re-sent slot right after is not a tap. */
    void noteServerChange(Player p) { lastServerChange.put(p.getUniqueId(), System.currentTimeMillis()); }

    /**
     * 0.2.7 Tap bar: a Bedrock tap on the slot that is already selected, read from Geyser
     * (Geyser does not forward it; Java sends nothing at all for it). Main thread.
     */
    String onWandTap(Player p, int slot) {
        wandTapSeen++;
        if (p == null || !p.isOnline()) return "offline";
        if ("off".equals(tapWand)) { wandTapIgnored++; return "off"; }
        Wand w = tapWand(p);
        long now = System.currentTimeMillis();
        Long last = lastServerChange.get(p.getUniqueId());
        boolean wandHeld = w != null && w.canUse(p) && p.getInventory().getHeldItemSlot() == slot;
        if (!wandHeld) { wandTapIgnored++; return "not the wand"; }
        if (!com.winkreyes.excelwandbars.core.WandSlotPlan.isWandTap(true, true, slot, p.getInventory().getHeldItemSlot(), now, last == null ? 0L : last, tapWandGuardMs)) {
            wandTapGuarded++; return "guard";
        }
        // Fake-tap fix: the guard only covers re-sends right after a change WE stamped. A
        // server hotbar refresh we cannot see (Magic's cooldown icons ticking) makes the
        // client re-send the selected slot seconds later, and that echo closed the bar on
        // its own (live counter test, Oct 30 2026: hands-off, wand-tap closes 9 -> 10 while
        // idle/empty/drop/other stayed 0). A deliberate tap rides on fresh player input:
        // a hotbar pick, a swing/hold signal or a right click within tapWandFreshMs. (A
        // cast is not counted on its own: the icon tap that started it stamps the pick,
        // and the cast itself is what provokes refreshes.) A cold first packet only primes:
        // if the player really meant it, the re-tap lands within TAP_PRIME_MS and toggles.
        UUID id = p.getUniqueId();
        long lastInput = Math.max(Math.max(lastSlotPick.getOrDefault(id, 0L), lastHoldSignal.getOrDefault(id, 0L)), lastRight.getOrDefault(id, 0L));
        Long primed = lastWandTapPrime.get(id);
        if (!com.winkreyes.excelwandbars.core.WandSlotPlan.isDeliberateTap(now, lastInput, tapWandFreshMs, primed == null ? 0L : primed, TAP_PRIME_MS)) {
            wandTapEcho++;
            lastWandTapPrime.put(id, now);
            lastHold.put(id, "wand tap echo (no fresh input)");
            return "echo";
        }
        lastWandTapPrime.remove(id);
        cancelCrouchHold(p); // explicit icon intent supersedes any queued world hold
        noteServerChange(p);
        lastUse.put(p.getUniqueId(), now);
        if (w.isInventoryOpen()) {
            w.closeInventory();
            if (w.isInventoryOpen()) { lastHold.put(p.getUniqueId(), "wand tap close blocked"); return "close blocked"; }
            wandTapCloses++;
            lastHold.put(p.getUniqueId(), "wand tap close");
            return "closed";
        }
        if (!"toggle".equals(tapWand)) { wandTapIgnored++; return "bar down"; }
        String r = tryOpen(p, "wand tap");
        wandTapOpens++;
        lastHold.put(p.getUniqueId(), "wand tap open " + r);
        if ("opened".equals(r)) sendPageLine(p, 3L);
        return "open " + r;
    }

    void cancelCrouchHold(Player p) {
        if (p != null) bookHold.cancel(p.getUniqueId());
        try { Class.forName("com.winkreyes.excelwandbars.GeyserHoldHook").getMethod("reset", UUID.class).invoke(null,p.getUniqueId()); } catch (Throwable ignored) { }
    }

    /** Called only after protocol-qualified crouched held air-use, on the server thread. */
    String onCrouchHold(Player p, int slot) {
        if (p == null || !p.isOnline() || !p.isSneaking() || !plugin.isBedrock(p)) return "not crouched Bedrock";
        try {
            boolean current=(Boolean)Class.forName("com.winkreyes.excelwandbars.GeyserHoldHook").getMethod("consume",UUID.class,int.class).invoke(null,p.getUniqueId(),slot);
            if(!current)return "stale/cancelled hold";
        } catch(Throwable unavailable){return "hold hook unavailable";}
        Wand w=tapWand(p);
        if(w==null || !w.canUse(p) || p.getInventory().getHeldItemSlot()!=slot) return "not held rank wand";
        // The protocol path keeps its transaction-typed air semantics (no raytrace).
        return dispatchBook(p, "protocol", false);
    }

    // ------------------------------------------------------------------ 0.3.5 crouch + hold book (Bukkit signals)

    /** Sneak edges for the book gate. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onSneakBookTrack(org.bukkit.event.player.PlayerToggleSneakEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        if (event.isSneaking()) sneakDownAt.put(id, System.currentTimeMillis());
        else { sneakDownAt.remove(id); bookHold.sneakUp(id); bookPressStart.remove(id); bookLastSignal.remove(id); }
    }

    /** Observe only: a swing is a use signal for the book gate. Never cancels or alters anything. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onSwingBookFeed(PlayerAnimationEvent event) {
        if (event.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
        bookSignal(event.getPlayer(), BookHoldPlan.USE_AIR);
    }

    /** Observe only: right click air continues a hold; right click block latches it disqualified. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onInteractBookFeed(PlayerInteractEvent event) {
        if (event.getHand() != null && event.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        if (event.getAction() == Action.RIGHT_CLICK_AIR) bookSignal(event.getPlayer(), BookHoldPlan.USE_AIR);
        else if (event.getAction() == Action.RIGHT_CLICK_BLOCK) bookSignal(event.getPlayer(), BookHoldPlan.USE_BLOCK);
    }

    private void bookSignal(Player p, int kind) {
        if (!bookHoldEnabled || p == null) return;
        if (!plugin.isBedrock(p) && !bookHoldJava) return;
        if (!tapBarStyle(p)) return;
        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis();
        boolean sneaking = p.isSneaking();
        // Sneak-first is judged against the PRESS, not the signal: a press that began
        // before the crouch belongs to hold-to-read for its whole life (design 6.1, 6.3e).
        // The press chain uses the world hold's own gap window, so both features agree
        // on where one press ends and the next begins.
        Long lastSig = bookLastSignal.get(id);
        long pressStart;
        if (lastSig == null || now - lastSig > holdGapMs) { pressStart = now; bookPressStart.put(id, now); }
        else pressStart = bookPressStart.getOrDefault(id, now);
        bookLastSignal.put(id, now);
        Long down = sneakDownAt.get(id);
        boolean sneakFirst = sneaking && down != null && down < pressStart;
        long startBefore = bookHold.burstStart(id);
        boolean fire = bookHold.signal(id, now, kind, sneaking, sneakFirst, bookHoldMs);
        if (fire) { dispatchBook(p, "bukkit", true); return; }
        long startAfter = bookHold.burstStart(id);
        if (startAfter > 0 && startAfter != startBefore) scheduleBookCheck(p, startAfter);
    }

    /** The scheduled threshold check: carries a sparse-cadence hold across the line (design 6.1). */
    private void scheduleBookCheck(Player p, long burstStart) {
        long ticks = Math.max(1L, (bookHoldMs + 49) / 50);
        Bukkit.getScheduler().runTaskLater(plugin, () -> runBookCheck(p, burstStart), ticks);
    }

    /**
     * The threshold check itself. Ticks are a scheduling hint, not a clock: after a
     * server stall the scheduler can run several ticks inside a fraction of the
     * wall-clock hold window, so a check that arrives before the threshold has
     * actually elapsed waits out the remainder instead of judging the burst early.
     */
    private void runBookCheck(Player p, long burstStart) {
        UUID id = p.getUniqueId();
        if (!p.isOnline() || bookHold.burstStart(id) != burstStart) return;
        long now = System.currentTimeMillis();
        if (now - burstStart < bookHoldMs) {
            long restTicks = Math.max(1L, (bookHoldMs - (now - burstStart) + 49) / 50);
            Bukkit.getScheduler().runTaskLater(plugin, () -> runBookCheck(p, burstStart), restTicks);
            return;
        }
        BookHoldPlan.Check c = bookHold.scheduledCheck(id, now, p.isSneaking(), bookHoldMs);
        if (c == BookHoldPlan.Check.FIRE) { dispatchBook(p, "bukkit", true); return; }
        if (c == BookHoldPlan.Check.GRACE) {
            long graceTicks = Math.max(1L, (BookHoldPlan.GRACE_MS + 49) / 50);
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!p.isOnline() || bookHold.burstStart(id) != burstStart) return;
                if (bookHold.scheduledCheck(id, System.currentTimeMillis(), p.isSneaking(), bookHoldMs) == BookHoldPlan.Check.FIRE)
                    dispatchBook(p, "bukkit", true);
            }, graceTicks);
        }
    }

    /**
     * 0.3.5: the one book dispatch for both qualification paths (protocol fast path and the
     * Bukkit signal gate). Failure semantics (design 6.2): non-qualifications stay silent
     * (result strings go to the debug log as before); a QUALIFIED hold whose form open fails
     * falls back to the menu path's chat book, and if even that cannot run the player gets
     * one visible line and the console a warning. A second dispatch within 1500 ms of a
     * successful fire is dropped (a client feeding both paths must not open the book twice).
     */
    private String dispatchBook(Player p, String source, boolean raytraceAim) {
        if (p == null || !p.isOnline()) return "offline";
        UUID id = p.getUniqueId();
        if (!p.isSneaking()) return "not crouched";
        if (!plugin.isBedrock(p) && !bookHoldJava) return "not Bedrock";
        Wand w = tapWand(p);
        if (w == null || !w.canUse(p)) return "not held rank wand";
        if (raytraceAim && p.getTargetBlockExact(6) != null) return "aimed at block";
        long now = System.currentTimeMillis();
        Long firedAt = lastBookFire.get(id);
        if (firedAt != null && now - firedAt <= 1500) return "already fired";
        MagicHook mh = plugin.magicHook();
        if (mh == null) { bookOpenFailed(p, "no Magic"); return "no Magic"; }
        // This is an intentional form request. Guard its slot resyncs, not ordinary world taps.
        noteServerChange(p);
        boolean shown = mh.openSpellBook(p, null, true);
        if (shown) {
            lastBookFire.put(id, now);
            holdsInfo++;
            if ("bukkit".equals(source)) bookBukkit++; else bookProtocol++;
            lastHold.put(id, "crouch hold book");
            return "book";
        }
        // Qualified hold, form open failed: retry the way the menu path does (chat book).
        boolean chat = mh.openSpellBook(p, null, false);
        if (chat) {
            lastBookFire.put(id, now);
            holdsInfo++;
            bookFallbacks++;
            if ("bukkit".equals(source)) bookBukkit++; else bookProtocol++;
            lastHold.put(id, "crouch hold book (chat)");
            return "book (chat)";
        }
        bookOpenFailed(p, "not shown");
        return "not shown";
    }

    private void bookOpenFailed(Player p, String result) {
        p.sendMessage(Component.text("The Spell Book did not open. Type /spellbook to try again.", NamedTextColor.GRAY));
        plugin.getLogger().warning("Crouch hold book failed for " + p.getName() + ": " + result);
    }

    /** Book gate state for the arrange/screen hooks and admin: is a sneak-first burst claiming this player's holds? */
    boolean bookClaimed(Player p) { return p != null && bookHold.claimed(p.getUniqueId()); }

    void start() {
        if (ticker != null) ticker.cancel();
        ticker = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 10L);
    }

    /** Plugin stop: put every open hotbar-icon bar back (Magic's own close, real items restored). */
    void stop() {
        if (ticker != null) { ticker.cancel(); ticker = null; }
        for (Player p : Bukkit.getOnlinePlayers()) {
            try { Wand w = openWand(p); if (w != null && uses(p)) w.closeInventory(); } catch (Throwable ignored) { }
        }
    }

    String summary() {
        return "open on hold " + (openOnHold ? "ON" : "OFF") + ", empty slot closes " + (emptySlotCloses ? "ON" : "OFF")
                + ", idle close " + (idleCloseMs == 0 ? "OFF" : (idleCloseMs / 1000) + "s" + (tapBarStaysOpen ? " (original only, Tap bar stays up)" : ""))
                + ", close before other inventory " + (closeOnOtherInventory ? "ON" : "OFF")
                + ", Tap bar slot-hold shows spell info " + (holdShowsInfo ? "ON (world taps never open Book; slot hold after a tap reads within " + holdReadsTapMs + " ms)" : "OFF") + ", icon lore " + (!iconLore ? "OFF" : loreMagicStyle ? "Magic's text + next rank" : "Spell Book text")
                + ", Tap to pick: tap picks (quick_cast manual), right click handled (Java open / items back, Bedrock hold casts once)"
                + ", Tap bar tap the wand: " + tapWand + " (guard " + tapWandGuardMs + " ms, source " + wandTapSource + ")"
                + ", tap echo guard: fresh input within " + tapWandFreshMs + " ms or a confirming re-tap"
                + ", crouch + hold book: " + (bookHoldEnabled ? "ON (" + bookHoldMs + " ms on Bukkit signals; protocol fast path kept" + (bookHoldJava ? "; Java armed" : "") + ")" : "OFF")
                + ", exit sweep " + (exitSweepEnabled ? "ON" : "OFF");
    }
    String counters() { return "opened " + opened + " idle-closed " + closedIdle + " empty-closed " + closedEmpty + " other-closed " + closedOther
            + " hold-info " + holdsInfo + " hold-open " + holdsOpen + " hold-merged " + holdsMerged + " hold-skipped " + holdsSkipped + " lore " + loreSet
            + " held-cancelled-ignored " + heldCancelledIgnored + " drop-reads " + dropReads + " drop-closes " + dropCloses
            + " hold-casts-blocked " + holdCastsBlocked + " page-lines " + pageLines
            + " right-uses " + rightReads + " right-opens " + rightOpens + " right-closes " + rightCloses + " right-repeats " + rightRepeats
            + " pick-right-opens " + origRightOpens + " pick-right-closes " + origRightCloses + " pick-hold-casts " + origHoldCasts
            + " pick-hold-swing-cast " + origHoldSwingCast + " pick-right-repeats " + origRightRepeats
            + " wand-tap seen " + wandTapSeen + " closes " + wandTapCloses + " opens " + wandTapOpens + " guarded " + wandTapGuarded + " ignored " + wandTapIgnored + " echo " + wandTapEcho
            + " book-hold bukkit " + bookBukkit + " protocol " + bookProtocol + " fallbacks " + bookFallbacks + " claims " + bookClaims + " world-reads " + worldReads
            + " exit-sweeps " + exitSweeps + " exit-moved " + exitMoved + " exit-left " + exitLeft
            + " join-guard closes " + joinGuardCloses + " blocked " + joinGuardBlocked
            + " join-sweeps " + joinSweeps + " moved " + joinSweepMoved + " left " + joinSweepLeft
            + " quit-closes " + quitCloses + " blocked " + quitCloseBlocked
            + " slot-guard blocks " + slotGuardBlocks + " sweeps " + slotSweeps + " moved " + slotMoved + " left " + slotLeft; }
    String lastHold(Player p) { return lastHold.getOrDefault(p.getUniqueId(), "-"); }
    String lastCast(Player p) { return lastCast.getOrDefault(p.getUniqueId(), "-") + " x" + casts.getOrDefault(p.getUniqueId(), 0); }

    private boolean uses(Player p) {
        StyleHook s = plugin.styleHook();
        return s != null && s.enabled() && s.styleOf(p).opensOnHold();
    }

    private Wand activeWand(Player p) {
        Mage m = api.getMage(p);
        return m == null ? null : m.getActiveWand();
    }

    private Wand openWand(Player p) {
        Wand w = activeWand(p);
        return w != null && w.isInventoryOpen() ? w : null;
    }

    private static boolean empty(ItemStack it) { return it == null || it.getType().isAir(); }

    /**
     * Final read-only guard for every Magic opening path, not just tryOpen().
     * Magic fires this before storing/replacing the real inventory. Never repair
     * or configure a wand from this callback: doing so can recurse into opening.
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTapBarInventoryOpening(SpellInventoryEvent event) {
        if (!event.isOpening()) return;
        Mage mage = event.getMage();
        Player p = mage == null ? null : mage.getPlayer();
        if (p == null || plugin.skipWorld(p.getWorld()) || !tapBarStyle(p)) return;
        Wand active = mage.getActiveWand();
        if (active == null || !plugin.styleHook().isRankWand(active)) return;

        boolean safe = active instanceof com.elmakers.mine.bukkit.wand.Wand wand
            && RenderedExitGuard.safe(wand.getHotbars());
        if (!safe) {
            event.setCancelled(true);
            p.sendMessage("Keep one empty space on each spell hotbar so you can tap it to return to your items.");
            // 0.3.16 (F3): every guard cancel is visible at INFO with the bar that failed.
            String detail = "no hotbars";
            if (active instanceof com.elmakers.mine.bukkit.wand.Wand wand) detail = exitGuardDetail(wand.getHotbars());
            plugin.getLogger().info("Tap bar opening cancelled for " + p.getName() + ": exit guard failed (" + detail + "); every page needs an empty exit");
        }
    }

    /** 0.3.16 (F3): the first rendered bar that fails RenderedExitGuard's rule, as "bar <i> size=<n> empty=<e>". */
    private static String exitGuardDetail(java.util.List<com.elmakers.mine.bukkit.wand.WandInventory> bars) {
        if (bars == null || bars.isEmpty()) return "no hotbars";
        for (int i = 0; i < bars.size(); i++) {
            com.elmakers.mine.bukkit.wand.WandInventory bar = bars.get(i);
            if (bar == null) return "bar " + i + " size=0 empty=0";
            int empty = 0;
            for (int s = 0; s < bar.getSize(); s++) if (FlexibleInventoryGuard.empty(bar.getItem(s))) empty++;
            if (bar.getSize() != 8 || empty == 0) return "bar " + i + " size=" + bar.getSize() + " empty=" + empty;
        }
        return "all bars pass";
    }

    /** 0.3.16: newest deliberate player-input stamp (hotbar pick or icon tap), wall-clock ms. StyleHook's self-echo check reads it. */
    long lastInputAt(Player p) {
        UUID id = p.getUniqueId();
        return Math.max(lastSlotPick.getOrDefault(id, 0L), lastTapAt.getOrDefault(id, 0L));
    }

    /**
     * 0.3.16 (F3): every refusal is logged at INFO with the layout state,
     * so a silent "bar never opened" is diagnosable from the log alone.
     * Successful opens keep their existing debug line.
     */
    String tryOpen(Player p, String why) {
        String r = tryOpenInner(p, why);
        if (!"opened".equals(r)) logTryOpenRefusal(p, why, r);
        return r;
    }

    private void logTryOpenRefusal(Player p, String why, String word) {
        String layoutOk = "false", pages = "-/-";
        try {
            StyleHook s = plugin.styleHook();
            Wand w = p == null ? null : activeWand(p);
            if (s != null && w != null && tapBarStyle(p)) {
                StyleHook.Layout l = s.layoutFor(p, w, WandStyle.TAPBAR);
                if (l != null) { layoutOk = String.valueOf(l.ok); pages = l.curPages + "/" + l.pages; }
            }
        } catch (Throwable ignored) { }
        plugin.getLogger().info("Tap bar tryOpen(" + why + ") for " + (p == null ? "?" : p.getName()) + " -> " + word + " layoutOk=" + layoutOk + " pages=" + pages);
    }

    /** Open the held rank wand's spell bar if this player's style wants it and nothing blocks it. */
    String tryOpenInner(Player p, String why) {
        if (p == null || !p.isOnline()) return "offline";
        if (!uses(p)) return "style";
        StyleHook s = plugin.styleHook();
        Wand w = activeWand(p);
        if (w == null) return "no wand";
        if (w.isInventoryOpen()) return "already open";
        if (!s.isRankWand(w) || !w.canUse(p)) return "not rank wand";
        Object mode = w.getProperty("mode");
        if (mode == null || !String.valueOf(mode).equalsIgnoreCase("inventory")) return "not inventory mode";
        if (plugin.skipWorld(p.getWorld())) return "skip world";
        if (p.getGameMode() == GameMode.SPECTATOR || p.isDead()) return "spectator/dead";
        InventoryType top = p.getOpenInventory().getTopInventory().getType();
        if (top != InventoryType.CRAFTING && top != InventoryType.PLAYER) return "other inventory open (" + top + ")";
        if (tapBarStyle(p)) {
            StyleHook.Result repaired = s.apply(p, true, "bar open");
            if (repaired == StyleHook.Result.FAILED) return "exit layout repair failed";
            w = activeWand(p);
            if (w == null || !w.canUse(p)) return "wand changed during layout repair";
            StyleHook.Layout layout = s.layoutFor(p, w, WandStyle.TAPBAR);
            if (layout == null || !layout.ok) return "exit layout not ready";
            // 0.3.6: the exit-slot relocation sweep. The exit guards police
            // click/drag events only, so a programmatic give (another plugin's
            // addItem, a pickup, a merchant result) can park a foreign item in
            // the rendered pages — deadening the empty-tap exit and, on a full
            // page, making the opening guard below refuse this very open. Move
            // foreign items out now, while the pages are authoritative and
            // before Magic presents them. Never deletes (ExitSweep).
            if (exitSweepEnabled) {
                try {
                    ExitSweep.Result swept = ExitSweep.run(plugin, p, w, plugin.magicHook());
                    if (swept.ran) { exitSweeps++; exitMoved += swept.movedStacks; exitLeft += swept.leftBehind; }
                } catch (Throwable t) {
                    plugin.getLogger().warning("Exit sweep failed for " + p.getName() + ": " + t);
                }
                w = activeWand(p);
                if (w == null || !w.canUse(p)) return "wand changed during exit sweep";
            }
        }
        w.openInventory();
        if (!w.isInventoryOpen()) return "open failed";
        opened++;
        openedSinceJoin.put(p.getUniqueId(), System.currentTimeMillis());
        noteServerChange(p);
        scheduleLore(p, 2L);
        lastUse.put(p.getUniqueId(), System.currentTimeMillis());
        if (plugin.debug()) plugin.getLogger().info("Tap bar opened for " + p.getName() + " (" + why + ")");
        return "opened";
    }

    /** Whether this player's spell bar is open right now (PagerHook's render gate). */
    boolean barOpen(Player p) { return p != null && openWand(p) != null; }

    // ------------------------------------------------------------------ 0.3.11 quit close

    /**
     * Close this player's open spell bar as they leave, using the same
     * closeInventory() call stop() uses (Magic's own close; real items
     * restored). Called from QuitCloseHook on Paper's connection-close event
     * — which fires BEFORE PlayerQuitEvent, while Magic's mage is still
     * active — and again from onQuit as a belt for logout_delay &gt; 0 setups,
     * where Magic defers its own quit handling past the quit event.
     *
     * Why it must be early: Magic decides at its quit handling whether the
     * next join restores the wand open, reading the wand's open state at
     * that moment — and Magic's quit handler runs before any
     * PlayerQuitEvent handler WandBars can register (Magic enables first;
     * its default logout_delay is 0, so by the time a quit handler runs the
     * mage is already deactivated and the wand unreachable). Closing at
     * connection close makes the restore decision read a closed bar on
     * every logout: no join ever starts on the wand bar, so the menu
     * compass handed out at join is checked against the player's real
     * inventory and never duplicated into the bar. The policy switch is the
     * existing join-starts-on-items switch (see core.QuitClosePlan).
     * Returns a result word for the log/probe.
     */
    String closeBarAtExit(Player p, String why) {
        if (p == null) return "no player";
        Wand w = activeWand(p);
        boolean open = w != null && w.isInventoryOpen();
        if (!open) return "leave (bar down)";
        if (com.winkreyes.excelwandbars.core.QuitClosePlan.decide(
                joinStartsOnItems, uses(p), true, true)
                != com.winkreyes.excelwandbars.core.QuitClosePlan.Decision.CLOSE) {
            return "leave (policy off)";
        }
        w.closeInventory();
        if (w.isInventoryOpen()) { quitCloseBlocked++; return "close blocked"; }
        quitCloses++;
        plugin.getLogger().info("Quit close: " + p.getName() + " logged out with the spell bar open (" + why + "); items restored (joins start on your items).");
        return "closed";
    }

    // ------------------------------------------------------------------ 0.3.8 join guard

    /** Stamp a join for the guard (also the rig probe's entry point). */
    void stampJoin(Player p, long when) { if (p != null) joinedAt.put(p.getUniqueId(), when); }

    @EventHandler
    public void onJoin(org.bukkit.event.player.PlayerJoinEvent event) {
        Player p = event.getPlayer();
        stampJoin(p, System.currentTimeMillis());
        if (!joinStartsOnItems) return;
        // Magic restores the wand's open state as the session settles, so judge
        // more than once inside the grace window; any one CLOSE ends the matter.
        // The last check is the final one: if it leaves the bar up, the 0.3.11
        // join sweep runs there (see joinGuardCheck).
        for (long ticks : new long[]{30L, 80L}) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> joinGuardCheck(p), ticks);
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> joinGuardCheck(p, true), 160L);
    }

    /**
     * One join-guard judgement for a player. Package-private: the rig probe
     * drives it directly against a staged "restored" bar. Returns a result word
     * for the log/probe; the CLOSE path logs at info and tells the player once.
     */
    String joinGuardCheck(Player p) { return joinGuardCheck(p, false); }

    /**
     * @param finalCheck true only for the last scheduled check of a join
     *                   (160 ticks). 0.3.11: when that check LEAVEs a bar open,
     *                   the exit sweep runs once for the join — pages baked
     *                   before the quit close existed can already hold a menu
     *                   compass, and the restored-at-join path never reaches
     *                   tryOpen's sweep (it returns "already open" first).
     *                   See core.JoinSweepPlan.
     */
    String joinGuardCheck(Player p, boolean finalCheck) {
        if (p == null || !p.isOnline()) return "offline";
        UUID id = p.getUniqueId();
        Long joined = joinedAt.get(id);
        Wand w = openWand(p);
        long activity = Math.max(lastSlotPick.getOrDefault(id, 0L), openedSinceJoin.getOrDefault(id, 0L));
        com.winkreyes.excelwandbars.core.JoinGuardPlan.Decision d =
                com.winkreyes.excelwandbars.core.JoinGuardPlan.decide(
                        joinStartsOnItems, uses(p), w != null,
                        joined == null ? 0L : joined, System.currentTimeMillis(), activity, joinGraceMs);
        if (d != com.winkreyes.excelwandbars.core.JoinGuardPlan.Decision.CLOSE) {
            if (com.winkreyes.excelwandbars.core.JoinSweepPlan.shouldSweep(
                    joinStartsOnItems, exitSweepEnabled, finalCheck, true, w != null, joinSwept.contains(id))) {
                joinSwept.add(id);
                try {
                    ExitSweep.Result swept = ExitSweep.run(plugin, p, w, plugin.magicHook());
                    if (swept.ran) { joinSweeps++; joinSweepMoved += swept.movedStacks; joinSweepLeft += swept.leftBehind; }
                } catch (Throwable t) {
                    plugin.getLogger().warning("Join sweep failed for " + p.getName() + ": " + t);
                }
                return "leave (bar open; join sweep ran)";
            }
            return w == null ? "leave (bar down)" : "leave (engaged or window over)";
        }
        w.closeInventory();
        if (w.isInventoryOpen()) { joinGuardBlocked++; return "close blocked"; }
        joinGuardCloses++;
        joinedAt.remove(id);
        // 0.3.16 (F3): every join-grace close is logged with how long after join it landed.
        long ticksSinceJoin = joined == null ? -1 : (System.currentTimeMillis() - joined) / 50L;
        plugin.getLogger().info("Join guard: " + p.getName() + " logged in with the spell bar open; items restored (joins start on your items); closed " + ticksSinceJoin + " ticks after join.");
        p.sendMessage(Component.text("Your items are back — joining starts on your items, not the spell bar.", NamedTextColor.GRAY));
        // A compass handed out at join may have landed in the stored inventory
        // while the bar was up; with the bar closed the tidy can see it now.
        CompassGuard cg = plugin.compassGuard();
        if (cg != null) cg.checkLater(p, 5L);
        return "closed";
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onWandActivated(WandActivatedEvent event) {
        if (!openOnHold) return;
        Mage mage = event.getMage();
        Player p = mage == null || !mage.isPlayer() ? null : mage.getPlayer();
        if (p == null || !uses(p)) return;
        // Only a real pick of the wand slot opens the bar (not a respawn, join, world change or /give).
        Long picked = lastSlotPick.get(p.getUniqueId());
        if (picked == null || System.currentTimeMillis() - picked > 2000) return;
        // After StyleHook's next-tick apply (which re-activates the wand once when it changes controls).
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            try { if ("opened".equals(tryOpen(p, "hold"))) sendPageLine(p, 3L); } catch (Throwable t) { plugin.getLogger().warning("Tap bar open error for " + p.getName() + ": " + t); }
        }, 4L);
    }

    /**
     * 0.2.5: MONITOR (was LOWEST), after ExcelAttunement (LOW) and Magic (NORMAL) have decided.
     * Bar down: a switch someone cancelled (ExcelAttunement's stance lock refusing the wand)
     * is ignored completely, so it can never count as "picked the wand" and open the bar.
     * Bar up: Magic itself cancels every slot change (quick cast / pick keeps the wand
     * selected), so a cancelled event is normal there; note the tapped icon, and an empty
     * slot means "give me my items back".
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onHeld(PlayerItemHeldEvent event) {
        Player p = event.getPlayer();
        cancelCrouchHold(p);
        if (!uses(p)) return;
        noteServerChange(p);
        Wand w = openWand(p);
        if (w == null) {
            if (event.isCancelled()) { heldCancelledIgnored++; return; }
            lastSlotPick.put(p.getUniqueId(), System.currentTimeMillis());
            return;
        }
        lastSlotPick.put(p.getUniqueId(), System.currentTimeMillis());
        lastUse.put(p.getUniqueId(), System.currentTimeMillis());
        int slot = event.getNewSlot();
        MagicHook mh = plugin.magicHook();
        String key = mh == null ? null : mh.spellKeyOf(p.getInventory().getItem(slot));
        if (key != null) { lastTapKey.put(p.getUniqueId(), key); lastTapAt.put(p.getUniqueId(), System.currentTimeMillis()); }
        if (!emptySlotCloses && !tapBarStyle(p)) return;
        if (!empty(p.getInventory().getItem(slot))) return;
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!p.isOnline()) return;
            Wand now = openWand(p);
            if (now == null) return;
            now.closeInventory();
            closedEmpty++;
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!p.isOnline()) return;
                Wand again = openWand(p);
                if (again != null) return; // something re-opened it; leave the selection alone
                p.getInventory().setHeldItemSlot(slot);
                Mage m = api.getMage(p);
                if (m != null) m.checkWand();
            });
        });
    }


    /** Restrict only the temporary managed spell bar, never the real inventory. */
    private boolean reservesExit(Player p) {
        Wand w = openWand(p);
        return tapBarStyle(p) && w != null && plugin.styleHook().isRankWand(w) && w.canUse(p);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void protectExitClick(org.bukkit.event.inventory.InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p) || !reservesExit(p)) return;
        // 0.3.12 (slot guard): a click that would place a FOREIGN item
        // into the presented inventory is cancelled outright — the exit
        // invariant below only ever counted empty slots, so a foreign
        // place / cursor swap / number-key swap / shift-click into the
        // bar row or the list grid sailed through whenever a second
        // empty slot existed (audit in BUILD-RECORD.md). Spell-icon
        // gestures are untouched: an icon is never "foreign", so the
        // interpreters' verdicts stand exactly as before.
        if (slotGuardBlocksClick(p, e)) { e.setCancelled(true); slotGuardBlocks++; return; }
        if (FlexibleInventoryGuard.blockClick(e, p.getInventory())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void protectExitDrag(org.bukkit.event.inventory.InventoryDragEvent e) {
        if (!(e.getWhoClicked() instanceof Player p) || !reservesExit(p)) return;
        // 0.3.12 (slot guard): a drag carrying a foreign stack across
        // any presented slot is cancelled whole, same reasoning as the
        // click guard. Icon drags are the interpreters' (an icon cursor
        // is never foreign here). The Geyser occupied-slot swap (H1)
        // does not travel as a foreign-cursor Bukkit drag and is a
        // separate gated item — untouched.
        if (slotGuardBlocksDrag(p, e)) { e.setCancelled(true); slotGuardBlocks++; return; }
        if (FlexibleInventoryGuard.blockDrag(e, p.getInventory())) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ 0.3.12 slot guard

    /** Is this stack a foreign item in the presentation's terms? (SlotGuardPlan.foreign, hook side.) */
    private boolean foreignItem(Player p, ItemStack it) {
        if (it == null || it.getType().isAir()) return false;
        MagicHook mh = plugin.magicHook();
        if (mh != null && mh.spellKeyOf(it) != null) return false;
        if (mh != null && mh.isWandItem(it)) return false;
        PagerHook pg = plugin.pager();
        if (pg != null && pg.isPagerButton(it)) return false;
        return true;
    }

    private boolean slotGuardBlocksClick(Player p, org.bukkit.event.inventory.InventoryClickEvent e) {
        org.bukkit.event.inventory.InventoryAction a = e.getAction();
        com.winkreyes.excelwandbars.core.SlotGuardPlan.ClickKind kind;
        switch (a) {
            case PLACE_ALL, PLACE_ONE, PLACE_SOME -> kind = com.winkreyes.excelwandbars.core.SlotGuardPlan.ClickKind.PLACE;
            case SWAP_WITH_CURSOR -> kind = com.winkreyes.excelwandbars.core.SlotGuardPlan.ClickKind.SWAP_CURSOR;
            case HOTBAR_SWAP, HOTBAR_MOVE_AND_READD -> kind = com.winkreyes.excelwandbars.core.SlotGuardPlan.ClickKind.HOTBAR_SWAP;
            case MOVE_TO_OTHER_INVENTORY -> kind = com.winkreyes.excelwandbars.core.SlotGuardPlan.ClickKind.SHIFT_MOVE;
            default -> kind = com.winkreyes.excelwandbars.core.SlotGuardPlan.ClickKind.OTHER;
        }
        if (kind == com.winkreyes.excelwandbars.core.SlotGuardPlan.ClickKind.OTHER) return false;
        boolean clickedPresented = e.getClickedInventory() != null && e.getClickedInventory().equals(p.getInventory());
        boolean clickedForeign = foreignItem(p, e.getCurrentItem());
        boolean otherForeign, otherPresented = false;
        if (kind == com.winkreyes.excelwandbars.core.SlotGuardPlan.ClickKind.HOTBAR_SWAP) {
            int hb = e.getHotbarButton();
            otherForeign = hb >= 0 && hb < 9 && foreignItem(p, p.getInventory().getItem(hb));
            // The hotbar-button side is always one of the player's own
            // hotbar slots — presented whenever the bar is open (the
            // guard's context), whichever side was clicked.
            otherPresented = hb >= 0 && hb < 9;
        } else if (kind == com.winkreyes.excelwandbars.core.SlotGuardPlan.ClickKind.SHIFT_MOVE) {
            otherForeign = false; // the clicked stack itself is the mover; judged via clickedForeign
        } else {
            otherForeign = foreignItem(p, e.getCursor());
        }
        return com.winkreyes.excelwandbars.core.SlotGuardPlan.blocksClick(true, kind,
                clickedPresented, clickedForeign, otherForeign, otherPresented);
    }

    private boolean slotGuardBlocksDrag(Player p, org.bukkit.event.inventory.InventoryDragEvent e) {
        if (!foreignItem(p, e.getOldCursor())) return false;
        boolean touches = false;
        int topSize = e.getView().getTopInventory().getSize();
        for (int raw : e.getRawSlots()) {
            if (raw < topSize) continue;
            touches = true; // a bottom-inventory slot of the player's own view = presented
            break;
        }
        // Raw slots below the top inventory are the player's own
        // inventory in this view; while the bar is open in the player's
        // own screen that IS the presentation. (A drag in some other
        // view cannot coincide with reservesExit: the bar closes
        // before another inventory opens.)
        return com.winkreyes.excelwandbars.core.SlotGuardPlan.blocksDrag(true, true, touches);
    }

    /**
     * 0.3.12: a ground pickup while the bar is open (Mike's Nov 7 fight
     * intake: arrows, mid-combat). The pickup is NEVER cancelled — the
     * player keeps the loot — but Bukkit lands it hotbar-first in the
     * presented inventory, whose first empty slot is the exit slot, so
     * a presented sweep is scheduled to relocate the stack into the
     * wand's stored inventory (where the real items wait). Two passes:
     * the stack lands over the pickup's own tick or two.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPickup(org.bukkit.event.entity.EntityPickupItemEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (!com.winkreyes.excelwandbars.core.SlotGuardPlan.pickupSweeps(reservesExit(p))) return;
        Bukkit.getScheduler().runTask(plugin, () -> presentedSweep(p));
        Bukkit.getScheduler().runTaskLater(plugin, () -> presentedSweep(p), 3L);
    }

    /**
     * 0.3.12: relocate foreign items out of the LIVE presented
     * inventory (slots 0–35) into the wand's stored inventory (PresentedSweep;
     * moved, never deleted). The event-driven entry — a ground pickup
     * calls this one (verbose). Rides the exit-sweep switch: an admin
     * who turned the sweep off gets no relocations (the click/drag
     * blocks above are guards, not sweeps, and stay). Package-private:
     * MagicHook's pre-save sweep and the rig probe drive it directly.
     * Returns a result word for the log/probe.
     *
     * SETTLE GATE (rig-caught, 0.3.12): for the first second after a
     * bar opens, the live hotbar row still shows the player's real
     * items — Magic's store-and-paint lands a tick or more after
     * isInventoryOpen first reads true — so a sweep in that window
     * cannot tell real items from foreign ones and must not run. The
     * poll and pickup entries pass through the gate (the poll keeps
     * retrying and sweeps once the bar is a second old); the pre-flip
     * entry (presentedSweepNow) skips it, because a flip is a
     * deliberate act well after the open and its whole job is keeping
     * foreign stacks out of the save that follows.
     */
    String presentedSweep(Player p) { return presentedSweep(p, true, true); }

    /** The pre-flip entry: no settle gate (see presentedSweep). */
    String presentedSweepNow(Player p) { return presentedSweep(p, true, false); }

    private String presentedSweep(Player p, boolean verbose) { return presentedSweep(p, verbose, true); }

    private String presentedSweep(Player p, boolean verbose, boolean settleGated) {
        if (p == null || !exitSweepEnabled) return "off";
        if (!reservesExit(p)) return "not guarded";
        if (settleGated) {
            long now = System.currentTimeMillis();
            Long since = barOpenSince.get(p.getUniqueId());
            if (since == null) { barOpenSince.put(p.getUniqueId(), now); return "settling"; }
            if (now - since < 1000L) return "settling";
        }
        try {
            PresentedSweep.Result r = PresentedSweep.run(plugin, p, activeWand(p), plugin.magicHook(), verbose);
            if (r.unpainted) return "unpainted";
            if (!r.ran) return "no stored inventory";
            // A sweep counts when it had work (the 10-tick poll runs
            // constantly; counting empty passes would drown the signal).
            if (r.foreign > 0) slotSweeps++;
            slotMoved += r.movedStacks; slotLeft += r.leftBehind;
            return "swept " + r.movedStacks + " left " + r.leftBehind;
        } catch (Throwable t) {
            plugin.getLogger().warning("Slot guard sweep failed for " + p.getName() + ": " + t);
            return "failed";
        }
    }

    /** A cast starts (Magic fires CastEvent only when a spell with a duration ends, so count here). */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPreCast(com.elmakers.mine.bukkit.api.event.PreCastEvent event) {
        Mage m = event.getMage();
        Player p = m == null || !m.isPlayer() ? null : m.getPlayer();
        if (p == null) return;
        UUID id = p.getUniqueId();
        lastCastStart.put(id, System.currentTimeMillis());
        noteServerChange(p);
        lastCast.put(id, event.getSpell() == null ? "?" : event.getSpell().getKey() + " STARTED");
        casts.merge(id, 1, Integer::sum);
        if (openWand(p) != null) {
            lastUse.put(id, System.currentTimeMillis()); scheduleLore(p, 3L);
            // 0.2.5: a tap shows what you cast (name, mana, cooldown, rank) on the action bar.
            if (tapBarStyle(p) && event.getSpell() != null) {
                final String key = event.getSpell().getKey();
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (!p.isOnline() || openWand(p) == null) return;
                    MagicHook mh = plugin.magicHook();
                    SpellFacts f = mh == null ? null : mh.factsFor(p, key);
                    if (f != null) p.sendActionBar(Component.text(SpellInfoText.summary(f) + " | " + SpellInfoText.rankText(f), NamedTextColor.AQUA));
                }, 2L);
            }
        }
    }

    /**
     * 0.2.5 belt and braces: in Tap bar, pressing and holding never casts. left_click is
     * "none" on the wand, but if anything still starts a cast within 300 ms of a hold
     * (swing / left click / Q) and NOT right after a slot tap, it is stopped here, before
     * Magic spends mana or starts the cooldown.
     */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onPreCastGuard(com.elmakers.mine.bukkit.api.event.PreCastEvent event) {
        Mage m = event.getMage();
        Player p = m == null || !m.isPlayer() ? null : m.getPlayer();
        if (p == null || !tapBarStyle(p)) return;
        long now = System.currentTimeMillis();
        Long hold = lastHoldSignal.get(p.getUniqueId());
        if (hold == null || now - hold > 300) return;
        Long tap = lastSlotPick.get(p.getUniqueId());
        if (tap != null && now - tap <= 300) return;
        event.setCancelled(true);
        holdCastsBlocked++;
        if (plugin.debug()) plugin.getLogger().info("Tap bar: blocked a cast during press and hold for " + p.getName());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onCast(CastEvent event) {
        Mage m = event.getMage();
        Player p = m == null || !m.isPlayer() ? null : m.getPlayer();
        if (p == null) return;
        UUID id = p.getUniqueId();
        lastCast.put(id, event.getSpell() == null ? "?" : event.getSpell().getKey() + " " + event.getSpellResult());
        if (openWand(p) != null) { lastUse.put(id, System.currentTimeMillis()); scheduleLore(p, 3L); }
    }

    // ------------------------------------------------------------------ hold to read (Tap bar)

    private boolean tapBarStyle(Player p) {
        StyleHook s = plugin.styleHook();
        return s != null && s.enabled() && s.styleOf(p) == WandStyle.TAPBAR;
    }

    /** The held wand when this swing belongs to Tap bar's hold-to-read, else null. */
    private Wand holdWand(Player p) {
        return holdShowsInfo ? tapWand(p) : null;
    }

    /** 0.2.5: the held Tap bar wand (any use, not only hold-to-read), else null. */
    private Wand tapWand(Player p) {
        if (!tapBarStyle(p)) return null;
        return inventoryRankWand(p);
    }

    /** 0.2.6: the held Tap to pick (original) wand, else null. */
    private Wand pickWand(Player p) {
        StyleHook s = plugin.styleHook();
        if (s == null || !s.enabled() || s.styleOf(p) != WandStyle.ORIGINAL) return null;
        return inventoryRankWand(p);
    }

    /** The held rank wand in inventory mode, in a normal world, no other screen open; else null. */
    private Wand inventoryRankWand(Player p) {
        if (plugin.skipWorld(p.getWorld()) || p.getGameMode() == GameMode.SPECTATOR || p.isDead()) return null;
        InventoryType top = p.getOpenInventory().getType();
        if (top != InventoryType.CRAFTING && top != InventoryType.CREATIVE) return null;
        Wand w = activeWand(p);
        if (w == null || !plugin.styleHook().isRankWand(w)) return null;
        Object mode = w.getProperty("mode");
        if (mode == null || !String.valueOf(mode).equalsIgnoreCase("inventory")) return null;
        return w;
    }

    /** Before Magic (NORMAL, ignoreCancelled): in Tap bar a swing is "press and hold", never a cast. */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onSwing(PlayerAnimationEvent event) {
        if (event.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
        Player p = event.getPlayer();
        Wand w = holdWand(p);
        if (w == null) return;
        lastHoldSignal.put(p.getUniqueId(), System.currentTimeMillis());
        event.setCancelled(true);
        hold(p, w);
    }

    /** Magic only casts from this event when animation events are off; cancel the left click in Tap bar too. */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onLeftClick(PlayerInteractEvent event) {
        Action a = event.getAction();
        if (a != Action.LEFT_CLICK_AIR && a != Action.LEFT_CLICK_BLOCK) return;
        if (event.getHand() != null && event.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        Player p = event.getPlayer();
        Wand w = holdWand(p);
        if (w == null) return;
        lastHoldSignal.put(p.getUniqueId(), System.currentTimeMillis());
        if (a == Action.LEFT_CLICK_AIR) event.setCancelled(true);
        hold(p, w);
    }

    /**
     * 0.2.5: Q, or on a phone pressing and holding a hotbar slot, is a drop. Tap bar sets the
     * wand's drop action to "none" (Magic keeps the wand: it is undroppable, and spell icons
     * are never dropped either), and this decides what it means:
     *  - right after tapping a spell icon (the finger is still on it): read THAT spell,
     *  - a spell icon itself: read it,
     *  - otherwise with the bar up: put the items back (what drop did in 0.2.4),
     *  - bar down: open it.
     * Never casts. Observes only (Magic cancels the drop itself).
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onDrop(org.bukkit.event.player.PlayerDropItemEvent event) {
        Player p = event.getPlayer();
        if (!holdShowsInfo || !tapBarStyle(p) || p.isSneaking()) return;
        Wand w = holdWand(p);
        if (w == null) return;
        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis();
        lastHoldSignal.put(id, now);
        MagicHook mh = plugin.magicHook();
        ItemStack dropped = event.getItemDrop() == null ? null : event.getItemDrop().getItemStack();
        String iconKey = mh == null ? null : mh.spellKeyOf(dropped);
        String tapKey = lastTapKey.get(id);
        Long at = lastTapAt.get(id);
        final String key = iconKey != null ? iconKey : (tapKey != null && at != null && now - at <= holdReadsTapMs ? tapKey : null);
        final boolean wasOpen = w.isInventoryOpen();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!p.isOnline() || p.isSneaking()) return;
            Wand now2 = holdWand(p);
            if (now2 == null) return;
            if (key != null && mh != null) {
                lastSwing.put(id, System.currentTimeMillis()); // the swings of the same held finger merge into this read
                String r = mh.showSpellInfo(p, key);
                dropReads++; holdsInfo++;
                lastHold.put(id, "drop " + r);
                lastUse.put(id, System.currentTimeMillis());
                return;
            }
            if (wasOpen && now2.isInventoryOpen()) { now2.closeInventory(); noteServerChange(p); dropCloses++; lastHold.put(id, "drop close"); return; }
            if (!now2.isInventoryOpen()) { String r = tryOpen(p, "drop"); holdsOpen++; lastHold.put(id, "drop open " + r); }
        });
    }

    private final Map<UUID, Long> lastUseClick = new HashMap<>();

    /** A right click / tap on a block or entity also swings the arm: that swing is not a hold. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onRightClick(PlayerInteractEvent event) {
        Action a = event.getAction();
        // 0.2.5: only a click that really uses something (chest, door, button, villager) makes the
        // swing that comes with it "not a hold". A right click on air or a plain block does not:
        // a phone's press and hold could otherwise be skipped and show nothing.
        if (a == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock() != null && event.getClickedBlock().getType().isInteractable())
            lastUseClick.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
    }

    /**
     * 0.2.5: right click with the Tap bar wand. A phone's press and hold on the screen arrives as a
     * right click (item use), and Magic's own right_click (toggle) cannot be cancelled by a plugin,
     * so 0.2.4 closed the bar and showed nothing. Tap bar now sets Magic's right_click to "none" and
     * handles it here. Bedrock world-use signals never open Book because tap and hold are ambiguous. Java: right click opens the
     * bar or puts your items back (what Magic's toggle did). Crouch + right click stays Magic's page
     * flip (right_click_sneak). A click that uses a block (chest, door) is left alone.
     */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onRightClickWand(PlayerInteractEvent event) {
        Action a = event.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() != null && event.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        Player p = event.getPlayer();
        if (p.isSneaking()) return;
        if (a == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock() != null && event.getClickedBlock().getType().isInteractable()) return;
        Wand w = tapWand(p);
        if (w == null) return;
        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis();
        Long prevRight = lastRight.put(id, now);
        boolean repeat = prevRight != null && now - prevRight < 350; // a held mouse button / finger repeats every 4 ticks
        if (plugin.isBedrock(p) && holdShowsInfo) {
            lastHoldSignal.put(id, now);
            rightReads++;
            hold(p, w); // merges with the swing of the same finger
            return;
        }
        if (repeat) { rightRepeats++; return; }
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!p.isOnline()) return;
            Wand n = tapWand(p);
            if (n == null) return;
            if (n.isInventoryOpen()) { n.closeInventory(); noteServerChange(p); rightCloses++; lastHold.put(id, "right close"); }
            else { String r = tryOpen(p, "right click"); rightOpens++; lastHold.put(id, "right open " + r); if ("opened".equals(r)) sendPageLine(p, 3L); }
        });
    }

    /**
     * 0.2.6: right click with the Tap to pick (original) wand. Magic's right_click is "none" for this
     * style (its toggle closed the bar when a phone's press and hold arrived as a right click, so the
     * picked spell never cast). Here:
     *  - bar down (Java and Bedrock): open the bar, as Magic's toggle did,
     *  - Java, bar up: put the items back, as Magic's toggle did,
     *  - Bedrock, bar up: press and hold casts the picked spell ONCE. If the swing of the same hold
     *    already started a cast (Magic's left_click cast), nothing more happens.
     * A held finger or mouse button repeats every 4 ticks; repeats are ignored. Crouch + right click
     * stays Magic's page flip (right_click_sneak). A click that uses a block (chest, door) is left alone.
     */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onRightClickPick(PlayerInteractEvent event) {
        Action a = event.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() != null && event.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        Player p = event.getPlayer();
        if (p.isSneaking()) return;
        if (a == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock() != null && event.getClickedBlock().getType().isInteractable()) return;
        Wand w = pickWand(p);
        if (w == null) return;
        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis();
        Long prevRight = lastRight.put(id, now);
        if (prevRight != null && now - prevRight < 350) { origRightRepeats++; return; }
        final boolean bedrock = plugin.isBedrock(p);
        final boolean wasOpen = w.isInventoryOpen();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline()) return;
            Wand n = pickWand(p);
            if (n == null) return;
            if (!n.isInventoryOpen()) {
                if (wasOpen) return; // something else closed it in between (empty slot, Q): leave it
                String r = tryOpen(p, "right click");
                origRightOpens++;
                lastHold.put(id, "pick right open " + r);
                if ("opened".equals(r)) sendPageLine(p, 3L);
                return;
            }
            if (!wasOpen) return; // opened in between by the hotbar opener: leave it up
            if (!bedrock) { n.closeInventory(); origRightCloses++; lastHold.put(id, "pick right close"); return; }
            Long c = lastCastStart.get(id);
            if (c != null && c >= now - 400) { origHoldSwingCast++; lastHold.put(id, "pick hold (swing cast)"); return; }
            boolean ok = n.cast();
            origHoldCasts++;
            lastHold.put(id, "pick hold cast " + n.getActiveSpellKey() + (ok ? "" : " (not cast)"));
        }, bedrock ? 3L : 1L);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRightClickEntity(org.bukkit.event.player.PlayerInteractEntityEvent event) {
        lastUseClick.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
    }

    private boolean nearUseClick(UUID id) {
        Long t = lastUseClick.get(id);
        return t != null && Math.abs(System.currentTimeMillis() - t) < 350;
    }

    private void hold(Player p, Wand w0) {
        // Crouch belongs to bar navigation, never hold-to-read. Capture it now
        // as well as at dispatch, so a quick release cannot turn the gesture into Book.
        if (p.isSneaking()) { holdsSkipped++; return; }
        UUID id = p.getUniqueId();
        // Decide 3 ticks later: the right click that came with this swing (chest, door, villager) arrives
        // in the same burst, before or after it. Then it was a use, not a hold.
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline()) return;
            // 0.3.5: a sneak-first burst belongs to the crouch + hold book gate, never to a read.
            if (bookHold.claimed(id)) { bookClaims++; holdsSkipped++; return; }
            if (p.isSneaking() || nearUseClick(id)) { holdsSkipped++; return; }
            Wand w = holdWand(p);
            if (w == null) { holdsSkipped++; return; }
            holdNow(p, w);
        }, 3L);
    }

    private void holdNow(Player p, Wand w) {
        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis();
        Long prev = lastSwing.put(id, now);
        if (prev != null && now - prev < holdGapMs) { holdsMerged++; return; } // the same finger still down
        worldReads++;
        lastUse.put(id, now);
        if (!w.isInventoryOpen()) {
            String r = tryOpen(p, "press and hold");
            holdsOpen++;
            lastHold.put(id, "open " + r);
            if ("opened".equals(r)) sendPageLine(p, 3L);
            return;
        }
        // Bukkit world-use signals do not distinguish a short tap from a long hold.
        // Never open a form here: on Bedrock even a normal air/block tap can arrive
        // as a swing + right click, and form transitions can resend the selected slot.
        // Deliberate hotbar slot-hold/drop reads remain in onDrop; the menu has Book.
        lastHold.put(id, "world use (no book)");
    }

    /** 0.2.5: "Page 1/2: Heal, Boon, ..." once when the bar opens with more than one page. */
    private void sendPageLine(Player p, long ticks) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline()) return;
            MagicHook mh = plugin.magicHook();
            String line = mh == null ? null : mh.pageLine(p);
            if (line == null) return;
            p.sendActionBar(Component.text(line, NamedTextColor.AQUA));
            pageLines++;
        }, ticks);
    }

    // ------------------------------------------------------------------ icon name / lore = the Spell Book lines

    private void scheduleLore(Player p, long ticks) {
        if (!iconLore || !tapBarStyle(p)) return;
        Bukkit.getScheduler().runTaskLater(plugin, () -> { try { applyLore(p); } catch (Throwable t) {
            if (plugin.debug()) plugin.getLogger().warning("Tap bar lore for " + p.getName() + ": " + t); } }, ticks);
    }

    /** Hotbar spell icons only, bar open only: set name + lore to the Spell Book lines. Returns icons changed. */
    int applyLore(Player p) {
        if (!p.isOnline() || openWand(p) == null) return 0;
        MagicHook mh = plugin.magicHook();
        if (mh == null) return 0;
        int n = 0;
        for (int slot = 0; slot < 9; slot++) {
            ItemStack it = p.getInventory().getItem(slot);
            String key = mh.spellKeyOf(it);
            if (key == null) continue;
            SpellFacts f = mh.factsFor(p, key);
            if (f == null) continue;
            List<String> lines = SpellInfoText.lines(f);
            ItemMeta meta = it.getItemMeta();
            if (meta == null) continue;
            if (loreMagicStyle) {
                // Keep Magic's own lore; replace only our rank line at the end.
                List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
                while (!lore.isEmpty()) {
                    String last = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(lore.get(lore.size() - 1));
                    if (last.startsWith("Next rank") || last.startsWith("Top rank")) lore.remove(lore.size() - 1); else break;
                }
                String rankLine = null;
                for (String l : lines) if (l.startsWith("Next rank") || l.startsWith("Top rank")) rankLine = l;
                if (rankLine != null) lore.add(Component.text(rankLine, NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false));
                if (lore.equals(meta.lore())) continue;
                meta.lore(lore);
                it.setItemMeta(meta);
                n++;
                continue;
            }
            Component name = Component.text(lines.get(0), NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false);
            List<Component> lore = new ArrayList<>();
            for (String l : lines.subList(1, lines.size())) lore.add(Component.text(l, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
            if (name.equals(meta.displayName()) && lore.equals(meta.lore())) continue;
            meta.displayName(name);
            meta.lore(lore);
            it.setItemMeta(meta);
            // Still Magic's spell icon after the edit? If not, it is a bug: say so (the bar still closes and restores).
            if (mh.spellKeyOf(it) == null) plugin.getLogger().warning("Tap bar lore: icon in slot " + slot + " no longer reads as a spell");
            n++;
        }
        loreSet += n;
        if (n > 0) noteServerChange(p);
        return n;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onOtherInventory(InventoryOpenEvent event) {
        if (!closeOnOtherInventory || !(event.getPlayer() instanceof Player p) || !uses(p)) return;
        InventoryType t = event.getInventory().getType();
        if (t == InventoryType.CRAFTING || t == InventoryType.PLAYER) return;
        cancelCrouchHold(p);
        Wand w = openWand(p);
        if (w == null) return;
        w.closeInventory();
        closedOther++;
    }

    /** 0.2.7: a crouch can flip the page (the hotbar icons change): not a wand tap right after. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onSneakStamp(org.bukkit.event.player.PlayerToggleSneakEvent event) {
        if (event.isSneaking() && uses(event.getPlayer())) noteServerChange(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        // 0.3.11 belt: the connection-close hook normally closes the bar
        // before this event exists. If it could not (no Paper connection
        // event) or Magic's quit handling is deferred (logout_delay > 0, so
        // the mage is still active here), close the bar now instead.
        closeBarAtExit(event.getPlayer(), "quit");
        cancelCrouchHold(event.getPlayer());
        UUID id = event.getPlayer().getUniqueId();
        lastHoldSignal.remove(id); lastRight.remove(id); lastUse.remove(id); lastSwing.remove(id); lastTapKey.remove(id); lastTapAt.remove(id); lastHold.remove(id); lastUseClick.remove(id); lastSlotPick.remove(id); lastCastStart.remove(id); lastServerChange.remove(id); lastWandTapPrime.remove(id);
        joinedAt.remove(id); openedSinceJoin.remove(id); joinSwept.remove(id); barOpenSince.remove(id);
        sneakDownAt.remove(id); bookPressStart.remove(id); bookLastSignal.remove(id); lastBookFire.remove(id); bookHold.cancel(id);
    }

    private void tick() {
        // 0.3.12: the slot guard's poll pass. A programmatic give
        // (another plugin's addItem, a merchant result) fires no event
        // the guard can judge, so while a bar is open the presentation
        // is swept on the ticker's own cadence (10 ticks) — quiet
        // (counters only); the pickup and pre-flip passes report.
        if (exitSweepEnabled) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                try {
                    if (!reservesExit(p)) barOpenSince.remove(p.getUniqueId());
                    presentedSweep(p, false);
                } catch (Throwable ignored) { }
            }
        }
        if (idleCloseMs <= 0) return;
        long now = System.currentTimeMillis();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!uses(p)) continue;
            if (tapBarStaysOpen && tapBarStyle(p)) continue; // 0.2.5: Tap bar stays up while the wand is held
            Wand w = openWand(p);
            if (w == null) continue;
            Long last = lastUse.get(p.getUniqueId());
            if (last == null) { lastUse.put(p.getUniqueId(), now); continue; }
            if (now - last >= idleCloseMs) {
                w.closeInventory();
                closedIdle++;
                lastUse.remove(p.getUniqueId());
            }
        }
    }
}

