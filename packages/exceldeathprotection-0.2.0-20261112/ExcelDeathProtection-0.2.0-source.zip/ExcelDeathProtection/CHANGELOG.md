# ExcelDeathProtection changelog

## 0.2.0 — banked premium-credit API, November 12, 2026

**Built on the recovered 0.1.3 source (wrv-plugins PR #13, commit 18dd40ae; 13/13 manifest hashes verified before editing). Desk build only — installation is a separate gate.**

- Add `ExcelDeathProtectionAPI` with public static `creditPremium(Player)` and `creditPremium(Player, int)` — the exact reflective seam ExcelBossTrial's repeat / first-break war-chest adapter probes for. Never throws; returns false on any failure.
- Banked premium credits (decision D9): one credit is one premium protection, stored as a count in the player's persistent data (`premium-credits`). A credit arriving with no protection active activates a premium protection immediately and banks any remainder; a credit arriving while any tier is active banks in full — an active basic protection is never overwritten. Banked credits re-arm premium protection automatically at respawn after a death uses the active protection. A credit is a service balance, never an inventory item: it cannot be lost, dropped, or traded.
- Console-admin surface: `/dp status <player>` (console/admin read of tier + banked credits), `/dp credit <player> [amount]` (grant through the same API code path), `/dp uncredit <player> [amount|all]` (revoke), `/dp version` (build line). Player `/dp status` gains a banked-credits line when the bank is non-zero.
- New optional config block `premium:` (`enabled` true, `auto-rearm` true, `max-per-call` 5, `max-banked` 0 = uncapped); a config carried over from 0.1.x runs the seam ON. Prices unchanged: basic $15,000 / premium $30,000.
- Preserved from 0.1.3: two-tier purchase flow with the one-item review menu, the purchase journal and its reconciliation rules, legacy PDC migration (legacy active byte resolves to premium), XP behaviour, and the Curse of Vanishing keep-inventory behaviour.
- Tests: 118 run, 118 passed (99 carried from 0.1.3 — one version pin updated — plus 19 new: banked-credit semantics and the BossTrial probe replica).

## 0.1.3 — one-item review source candidate, October 13, 2026

**Candidate source; installation is a separate gate. 0.1.2 remains the last verified installed version at 23:40:51 UTC. PR #13 remains draft and unmerged. All 0.1.3 Java, Bedrock-phone, live-purchase, and gameplay acceptance checks are pending.**

- Every shop tap/buy command opens a quantity-1 native review with price, balance, projected remainder or exact shortfall, Confirm and Back.
- No purchase on opening, repeated buy commands, refresh, Back or close. Insufficient/invalid/expired reviews cannot charge; they can be refreshed.
- Refresh balance without arming or extending the quote. Recheck economy, eligibility, product, price and expiry on Confirm through the existing journaled coordinator.
- Bind interactions to exact inventory/player/session; cancel movement, drag, shifted/hotbar/creative/double-click actions and stale scheduled callbacks.
- Preserve tier prices, legacy entitlements/potions, journal/refund safeguards, gameplay and XP behavior.
- Keep installed 0.1.2 deployment/limited phone-appearance evidence below as history, not verification of this new UI.
- Record 99 passing candidate tests, 107 including eight independent reviewer additions, and 196 isolated Paper assertions for the exact 58,521-byte artifact. [Candidate evidence](docs/VERIFICATION-RESULTS-0.1.3.md) distinguishes synthetic results from client/provider acceptance and records a later provider-completed backup separately from the earlier failed attempt.

## 0.1.2 — two-tier update, installed October 13, 2026

**Installed and startup-verified; the owner reports both entries look good on his phone. Java, remaining phone UI, real purchases, and gameplay acceptance are pending.** The exact tested JAR was installed from source commit `a2586bf17d2322f5e3b313b7e45bc0fe32fc56ac`; PR #13 remains draft and unmerged. [Installation evidence](docs/INSTALLATION-0.1.2.md) separates deployment checks from acceptance.

- Recorded a limited phone visual check of both shop entries. The owner accepts the single-item flow without a quantity window; exact-shortfall feedback remains a reported usability concern. This is not a completed purchase or gameplay test.
- Split the product into **Death Protection**, $15,000, activated immediately after a confirmed purchase with no extra abilities, and **+Death Protection Potion**, $30,000, stored and activated by drinking.
- Keep the premium Conduit Power benefits, including faster mining on land, and disclose them consistently.
- Use a shared one-death active slot. Reject duplicate basic purchases before charging; cancel a second potion drink while either tier is active without consuming the potion.
- Add the basic boss bar **Inventory protected: 1 death**, without boss fog, sky darkening, or music.
- Add explicit `buy basic` / `buy premium` command forms. Preserve the old buy alias as premium intent with confirmation of the new $30,000 price.
- Add `basic-price` / `premium-price`; ignore the old single `price` setting.
- Preserve legacy active protection and recognized old bottles as premium at no extra charge. Refresh known original bottle names/lore lazily while preserving custom names and persistent item data.
- Avoid blanket Conduit/Luck removal because legacy effect ownership cannot be proven. Basic adds no effects; premium only fills a missing Conduit effect.
- Add transaction-journal handling for ambiguous purchases. Vault and player/plugin persistence are separate, so crash-atomic charging and delivery are not guaranteed; unresolved transactions require operator review rather than automatic recharge/refund. Player-save calls also lack a durable-write acknowledgment, so silent save failures can require manual reconciliation even after a completed journal entry.
- Install the two tier-aware Spawn Shop choices at slot 31 (basic) and slot 34 (premium), preserving 20 unrelated items and all non-item settings. The separate unassigned template is still for review only. The historical repository menu/generator remains unchanged and can overwrite the live integration on regeneration; this maintenance gap remains open.
- Keep real death, one-use inventory retention, and unchanged XP handling. Correct the earlier Curse of Vanishing assumption: an isolated native Paper 26.2 test retained a cursed sword during a protected death using keep-inventory. No gameplay change was made to force cursed items to vanish. The live server/plugin combination still needs protected and unprotected checks.

## 0.1.1 — historical revision, October 13, 2026

These notes describe the earlier single-product version, not the two-tier candidate.

- Switched the indicator from Luck to Conduit Power after the 0.1.0 Bedrock-mobile test showed no Luck indicator.
- Disclosed Conduit Power's underwater breathing, clearer underwater vision, and faster mining, including mining on land.
- Added on-screen titles for purchase confirmation, insufficient funds, and successful purchase because chat can sit behind the shop window on Bedrock.
- Raised the single potion price from $10,000 to $15,000.
- The baseline notes did not establish a completed Java player check. Historical build or player results do not validate 0.1.2.

## 0.1.0 — historical first build, October 13, 2026

- Introduced the single Death Protection Potion: drinking activated one-death inventory protection. Death was not prevented and XP was not saved.
- Stored active protection per player across relogs/restarts and initially used Luck as its indicator.
- Added two-step `/deathprotection buy`, status, and admin give commands; the original price was $10,000.
- The historical Bedrock-mobile test passed purchase messaging, drinking, status, item retention on death, XP behavior, and consuming protection. The Luck indicator failed to appear on Bedrock; the original expectation that it would display there was incorrect.
