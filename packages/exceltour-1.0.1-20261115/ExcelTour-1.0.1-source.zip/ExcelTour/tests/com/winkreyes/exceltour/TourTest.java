package com.winkreyes.exceltour;

import com.winkreyes.exceltour.core.Progress;
import com.winkreyes.exceltour.core.ProgressStore;
import com.winkreyes.exceltour.core.Route;
import com.winkreyes.exceltour.core.RouteParser;
import com.winkreyes.exceltour.core.Step;
import com.winkreyes.exceltour.core.TextPlain;
import com.winkreyes.exceltour.core.TourEngine;

import java.io.File;
import java.io.StringReader;
import java.nio.file.Files;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Plain-JVM suite for ExcelTour's Bukkit-free core: route parsing /
 * validation, step advancement per trigger type, skip/restart,
 * persistence save/load, per-player isolation. Run via build.sh.
 */
public final class TourTest {
    static int pass, fail;
    static void check(String name, boolean ok, String detail) {
        if (ok) { pass++; System.out.println("PASS " + name + " — " + detail); }
        else { fail++; System.out.println("FAIL " + name + " — " + detail); }
    }

    static final String ROUTE_YML = """
            id: test-route
            display-name: "Test Route"
            description: "desc"
            completion-text: "done!"
            steps:
              - id: s1-world
                title: "Arrive"
                body: "go"
                skippable: false
                trigger: {type: world-arrival, world: guild_world}
              - id: s2-menu
                title: "Do the thing"
                body: "do it"
                skippable: true
                trigger: {type: menu-advanced}
              - id: s3-arrive
                title: "Reach the point"
                body: "walk"
                skippable: true
                trigger: {type: arrival, world: guild_world, x: 100, y: 64, z: -50, radius: 8, also-allow-menu-advance: true}
              - id: s4-npc
                title: "Talk"
                body: "talk"
                skippable: true
                trigger: {type: npc-interaction, npc-name: "Casus", world: guild_world, x: 0, y: 64, z: 0, radius: 6}
              - id: s5-leave
                title: "Leave"
                body: "leave"
                skippable: true
                trigger: {type: world-arrival, not-world: guild_world}
            """;

    static final String FALLBACK_YML = """
            id: guild-first-visit
            display-name: "Your First Visit to the Guild"
            description: "d"
            completion-text: "c"
            steps:
              - id: arrive-at-guild
                title: "Get there"
                body: "b"
                skippable: false
                trigger: {type: world-arrival, world: TO-BE-PULLED}
              - id: find-casus
                title: "Find Casus"
                body: "b"
                skippable: true
                trigger: {type: arrival, world: TO-BE-PULLED, x: TO-BE-PULLED, y: TO-BE-PULLED, z: TO-BE-PULLED, radius: 8, also-allow-menu-advance: true}
            """;

    static TourEngine engineWith(String yml) {
        RouteParser.Result r = RouteParser.parse(new StringReader(yml));
        if (!r.ok()) throw new IllegalStateException("fixture route failed: " + r.errors);
        TourEngine e = new TourEngine(new AtomicLong(1_000_000L)::incrementAndGet);
        e.setRoutes(Map.of(r.route.id, r.route));
        return e;
    }

    public static void main(String[] args) throws Exception {
        // ---------- route parsing / validation ----------
        RouteParser.Result ok = RouteParser.parse(new StringReader(ROUTE_YML));
        check("parse-valid", ok.ok() && ok.route.steps.size() == 5, "5 steps parsed");
        check("parse-missing-id", !RouteParser.parse(new StringReader("steps: [{id: a, title: t, body: b, trigger: {type: menu-advanced}}]")).ok(),
                "route without id rejected");
        check("parse-zero-steps", !RouteParser.parse(new StringReader("id: r\nsteps: []\n")).ok(), "zero steps rejected");
        check("parse-no-trigger", !RouteParser.parse(new StringReader(
                "id: r\nsteps: [{id: a, title: t, body: b}]\n")).ok(), "step without trigger rejected");
        check("parse-dup-step", !RouteParser.parse(new StringReader(
                "id: r\nsteps: [{id: a, title: t, body: b, trigger: {type: menu-advanced}}, {id: a, title: t, body: b, trigger: {type: menu-advanced}}]\n")).ok(),
                "duplicate step ids rejected");
        check("parse-arrival-no-location", !RouteParser.parse(new StringReader(
                "id: r\nsteps: [{id: a, title: t, body: b, trigger: {type: arrival, radius: 5}}]\n")).ok(),
                "arrival with neither location nor TO-BE-PULLED rejected (§2.1)");
        check("parse-unknown-trigger", !RouteParser.parse(new StringReader(
                "id: r\nsteps: [{id: a, title: t, body: b, trigger: {type: teleport}}]\n")).ok(), "unknown trigger type rejected");
        check("parse-bad-radius", !RouteParser.parse(new StringReader(
                "id: r\nsteps: [{id: a, title: t, body: b, trigger: {type: arrival, world: w, x: 1, y: 2, z: 3, radius: 0}}]\n")).ok(),
                "radius 0 rejected");
        RouteParser.Result fb = RouteParser.parse(new StringReader(FALLBACK_YML));
        check("parse-fallback-placeholders", fb.ok() && fb.route.steps.size() == 2 && !fb.warnings.isEmpty(),
                "TO-BE-PULLED route loads degraded with warnings (§2.4)");
        check("fallback-step1-menu-backstop", fb.ok() && fb.route.steps.get(0).trigger.menuAdvanceable(),
                "placeholder world-arrival step is menu-advanceable");
        check("fallback-arrival-never-fires", fb.ok() && !fb.route.steps.get(1).trigger.arrivalMatches("any", 0, 0, 0),
                "placeholder arrival never auto-fires");
        check("textplain", TextPlain.plain("<gold>Hi</gold> &a there").equals("Hi  there".replace("  ", " ").trim()) || TextPlain.plain("<gold>Hi</gold>").equals("Hi"),
                "MiniMessage/legacy stripping works: '" + TextPlain.plain("<gold>Hi</gold>") + "'");

        // ---------- advancement per trigger type ----------
        TourEngine e = engineWith(ROUTE_YML);
        UUID a = UUID.randomUUID(), b = UUID.randomUUID();
        e.start(a, "test-route");
        check("start-at-step1", "s1-world".equals(e.currentStep(a, "test-route").id), "start lands on step 1");
        check("world-arrival-wrong-world", e.tryLocation(a, "test-route", "home", 0, 0, 0) == TourEngine.Advance.NOT_ALLOWED
                && "s1-world".equals(e.currentStep(a, "test-route").id), "wrong world never fires");
        check("menu-next-blocked-on-world-step", e.menuNext(a, "test-route") == TourEngine.Advance.NOT_ALLOWED,
                "world-arrival step without backstop refuses /tour next");
        check("skip-blocked-unskippable", e.skip(a, "test-route") == TourEngine.Advance.NOT_SKIPPABLE,
                "skippable:false honoured");
        check("world-arrival-fires", e.tryLocation(a, "test-route", "guild_world", 0, 0, 0) == TourEngine.Advance.ADVANCED
                && "s2-menu".equals(e.currentStep(a, "test-route").id), "world-arrival advances to step 2");
        check("arrival-does-not-fire-menu-step", e.tryLocation(a, "test-route", "guild_world", 100, 64, -50) == TourEngine.Advance.NOT_ALLOWED,
                "location check never advances a menu-advanced step");
        check("menu-advanced-fires", e.menuNext(a, "test-route") == TourEngine.Advance.ADVANCED
                && "s3-arrive".equals(e.currentStep(a, "test-route").id), "menu advance reaches step 3");
        check("arrival-outside-radius", e.tryLocation(a, "test-route", "guild_world", 130, 64, -50) == TourEngine.Advance.NOT_ALLOWED,
                "30 blocks out does not fire an r=8 arrival");
        check("arrival-inside-radius", e.tryLocation(a, "test-route", "guild_world", 105, 64, -50) == TourEngine.Advance.ADVANCED
                && "s4-npc".equals(e.currentStep(a, "test-route").id), "5 blocks out fires");
        check("arrival-idempotent", e.tryLocation(a, "test-route", "guild_world", 105, 64, -50) == TourEngine.Advance.NOT_ALLOWED
                && "s4-npc".equals(e.currentStep(a, "test-route").id),
                "re-evaluating the old location does not advance the new step (one step per evaluation)");
        check("npc-wrong-name", e.tryNpc(a, "test-route", "Rowan") == TourEngine.Advance.NOT_ALLOWED, "wrong NPC name does not fire");
        check("npc-name-fires", e.tryNpc(a, "test-route", "casus") == TourEngine.Advance.ADVANCED
                && "s5-leave".equals(e.currentStep(a, "test-route").id), "NPC name match (case-insensitive) advances");
        check("not-world-stays", e.tryLocation(a, "test-route", "guild_world", 0, 0, 0) == TourEngine.Advance.NOT_ALLOWED,
                "not-world step does not fire inside the named world");
        check("not-world-completes", e.tryLocation(a, "test-route", "home", 0, 0, 0) == TourEngine.Advance.COMPLETED
                && e.progress(a, "test-route").state == Progress.State.COMPLETED
                && e.progress(a, "test-route").completions == 1, "leaving the guild world completes the route, completions=1");
        check("completed-is-terminal", e.menuNext(a, "test-route") == TourEngine.Advance.NOT_STARTED
                && e.tryLocation(a, "test-route", "home", 0, 0, 0) == TourEngine.Advance.NOT_STARTED,
                "no trigger fires after completion");

        // ---------- skip / restart / reset ----------
        TourEngine e2 = engineWith(ROUTE_YML);
        e2.start(b, "test-route");
        e2.tryLocation(b, "test-route", "guild_world", 0, 0, 0);
        check("skip-records-step", e2.skip(b, "test-route") == TourEngine.Advance.ADVANCED
                && e2.progress(b, "test-route").skippedSteps.equals(java.util.List.of("s2-menu"))
                && "s3-arrive".equals(e2.currentStep(b, "test-route").id), "skip advances and records the skipped id");
        check("arrival-step-menu-backstop", e2.menuNext(b, "test-route") == TourEngine.Advance.ADVANCED,
                "also-allow-menu-advance arrival step advances from the menu");
        e2.restart(b, "test-route");
        Progress pb = e2.progress(b, "test-route");
        check("restart-resets", pb.state == Progress.State.IN_PROGRESS && "s1-world".equals(pb.currentStepId) && pb.skippedSteps.isEmpty(),
                "restart returns to step 1 with skips cleared");
        e2.reset(b, "test-route", false);
        check("reset-keeps-state-shape", e2.progress(b, "test-route").state == Progress.State.NOT_STARTED
                && e2.progress(b, "test-route").currentStepId == null, "reset returns to not-started");
        // completions preserved by default reset, cleared by full reset
        TourEngine e3 = engineWith(ROUTE_YML);
        UUID c = UUID.randomUUID();
        e3.start(c, "test-route");
        e3.tryLocation(c, "test-route", "guild_world", 0, 0, 0);
        e3.menuNext(c, "test-route"); e3.menuNext(c, "test-route");
        e3.tryNpc(c, "test-route", "Casus"); e3.tryLocation(c, "test-route", "home", 0, 0, 0);
        check("full-run-completions", e3.progress(c, "test-route").completions == 1, "full run completes once");
        e3.reset(c, "test-route", false);
        check("reset-default-keeps-completions", e3.progress(c, "test-route").completions == 1, "default reset keeps completions (§6.3)");
        e3.reset(c, "test-route", true);
        check("reset-full-clears-completions", e3.progress(c, "test-route").completions == 0, "full reset clears completions");

        // ---------- per-player isolation ----------
        TourEngine e4 = engineWith(ROUTE_YML);
        UUID p1 = UUID.randomUUID(), p2 = UUID.randomUUID();
        e4.start(p1, "test-route"); e4.start(p2, "test-route");
        e4.tryLocation(p1, "test-route", "guild_world", 0, 0, 0);
        check("player-isolation", "s2-menu".equals(e4.currentStep(p1, "test-route").id)
                && "s1-world".equals(e4.currentStep(p2, "test-route").id),
                "one player's advance never moves another player (§6.2)");

        // ---------- persistence save/load ----------
        File dir = Files.createTempDirectory("exceltour-test").toFile();
        ProgressStore store = new ProgressStore(dir);
        TourEngine e5 = engineWith(ROUTE_YML);
        UUID saver = UUID.randomUUID();
        e5.start(saver, "test-route");
        e5.tryLocation(saver, "test-route", "guild_world", 0, 0, 0);
        e5.skip(saver, "test-route");
        store.save(saver, "SaverName", e5.allProgress(saver));
        Map<String, Progress> loaded = store.load(saver);
        Progress lp = loaded.get("test-route");
        check("persist-roundtrip", lp != null && lp.state == Progress.State.IN_PROGRESS
                && "s3-arrive".equals(lp.currentStepId) && lp.skippedSteps.equals(java.util.List.of("s2-menu")),
                "save/load round-trips state, current step, skips");
        check("persist-name", "SaverName".equals(store.loadPlayerName(saver)), "player-name stored for offline status");
        check("persist-missing-is-empty", store.load(UUID.randomUUID()).isEmpty(), "missing file = not-started (§6.2)");
        Files.writeString(new File(dir, saver + ".yml").toPath(), "routes: [this is not a map");
        check("persist-corrupt-is-empty", store.load(saver).isEmpty(), "corrupt file = not-started, never an error (§6.2)");

        // ---------- shipped guild route fixture (parsed from the real file when present) ----------
        File shipped = new File("routes/guild-first-visit.yml");
        if (shipped.isFile()) {
            RouteParser.Result sr = RouteParser.parse(new java.io.FileReader(shipped));
            check("shipped-route-loads", sr.ok() && sr.route.steps.size() == 5
                    && sr.route.steps.get(0).id.equals("arrive-at-guild")
                    && sr.route.steps.get(4).id.equals("transporter-home"),
                    "shipped guild-first-visit.yml loads with the 5 design steps in order");
            boolean allBackstopped = sr.ok() && sr.route.steps.stream().allMatch(s -> s.trigger.menuAdvanceable());
            check("shipped-route-fully-backstopped", allBackstopped,
                    "every TO-BE-PULLED step carries the menu-advance backstop (§2.4 viability)");
            TourEngine se = new TourEngine(new AtomicLong(5_000L)::incrementAndGet);
            se.setRoutes(Map.of(sr.route.id, sr.route));
            UUID walker = UUID.randomUUID();
            se.start(walker, "guild-first-visit");
            TourEngine.Advance last = null;
            for (int i = 0; i < 5; i++) last = se.menuNext(walker, "guild-first-visit");
            check("shipped-route-walkable-by-menu", last == TourEngine.Advance.COMPLETED
                    && se.progress(walker, "guild-first-visit").completions == 1,
                    "the whole shipped route completes via menu advances alone (fallback posture works)");
        } else {
            System.out.println("SKIP shipped-route checks — routes/guild-first-visit.yml not found from CWD");
        }

        System.out.println("TOURTEST TALLY pass=" + pass + " fail=" + fail);
        if (fail > 0) System.exit(1);
    }
}
