package com.winkreyes.exceltour;

import com.winkreyes.exceltour.core.Progress;
import com.winkreyes.exceltour.core.ProgressStore;
import com.winkreyes.exceltour.core.RouteParser;
import com.winkreyes.exceltour.core.TourEngine;

import java.io.File;
import java.io.StringReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

/**
 * BB-09 (1.0.1) Back-navigation contract for ExcelTour's three
 * FIX-2 rows: Guide view Java, Guide view Bedrock fallback (the
 * same TourMenu inventory), and the Bedrock tour step form.
 *
 * The Bukkit screens cannot be instantiated off-server, so the
 * wiring is pinned where it lives (source contract, the BrainGames
 * BackNavTest pattern), and the mid-tour progress-survival walk is
 * run behaviorally on the Bukkit-free core: Back's handler branch
 * is asserted to contain no engine call and no save, so a Back tap
 * performs zero progress operations; the walk then proves the
 * progress record a Back leaves behind is bit-for-bit the record
 * the player had, in memory and across a save/load round-trip,
 * and that the tour still advances normally afterwards.
 */
public final class BackNavTest {
    static int pass, fail;
    static void check(String name, boolean ok, String detail) {
        if (ok) { pass++; System.out.println("PASS " + name + " - " + detail); }
        else { fail++; System.out.println("FAIL " + name + " - " + detail); }
    }

    static int count(String haystack, String needle) {
        int n = 0, i = 0;
        while ((i = haystack.indexOf(needle, i)) >= 0) { n++; i += needle.length(); }
        return n;
    }

    /** Source from a marker to the next marker (or end). */
    static String branch(String src, String from, String to) {
        int a = src.indexOf(from);
        if (a < 0) return "";
        int b = to == null ? -1 : src.indexOf(to, a + from.length());
        return b < 0 ? src.substring(a) : src.substring(a, b);
    }

    static final String ROUTE_YML = TourTest.ROUTE_YML;

    static TourEngine engineWith() {
        RouteParser.Result r = RouteParser.parse(new StringReader(ROUTE_YML));
        if (!r.ok()) throw new IllegalStateException("fixture route failed: " + r.errors);
        TourEngine e = new TourEngine(new AtomicLong(2_000_000L)::incrementAndGet);
        e.setRoutes(Map.of(r.route.id, r.route));
        return e;
    }

    static boolean sameProgress(Progress a, Progress b) {
        return a != null && b != null && a.state == b.state
                && java.util.Objects.equals(a.currentStepId, b.currentStepId)
                && a.skippedSteps.equals(b.skippedSteps)
                && a.completions == b.completions
                && a.startedAtMillis == b.startedAtMillis
                && a.updatedAtMillis == b.updatedAtMillis;
    }

    public static void main(String[] args) throws Exception {
        Path base = Path.of("src", "com", "winkreyes", "exceltour");
        String menu = Files.readString(base.resolve("TourMenu.java"));
        String main = Files.readString(base.resolve("ExcelTour.java"));
        String pres = Files.readString(base.resolve("Presentation.java"));

        // ---- Guide view (TourMenu): slot 26 Back in all three states
        check("menu-back-all-states", count(menu, "setItem(26, backItem())") == 3,
                "slot 26 Back placed in not-started, completed and in-progress states");
        check("menu-back-label", menu.contains("\"Back to Server Menu\"") && menu.contains("Material.ARROW"),
                "Back is an ARROW labelled Back to Server Menu (house style)");
        check("menu-close-gone", !menu.contains("Material.BARRIER") && !menu.contains("\"Close\""),
                "the old slot-26 Close barrier is gone from TourMenu");
        check("menu-controls-survive", menu.contains("\"Repeat\"") && menu.contains("\"Skip\"")
                && menu.contains("\"Stop tour\"") && menu.contains("\"Restart\"")
                && menu.contains("Done \u2014 next step"),
                "Repeat / Done / Skip / Restart / Stop controls all survive");

        // ---- Guide view click wiring: slot 26 opens the Server Menu
        check("menu-click-wiring", count(main, "openServerMenu(player)") == 4,
                "slot 26 wired to openServerMenu in all 3 states + the backmenu action");
        String opener = branch(main, "public void openServerMenu", "\n    }");
        check("opener-is-menu-command", opener.contains("performCommand(\"menu\")")
                && opener.contains("closeInventory()"),
                "openServerMenu closes the view and runs the ExcelMenu /menu opener");
        check("opener-touches-no-progress", !opener.contains("engine.") && !opener.contains("savePlayer"),
                "openServerMenu makes no engine call and no save");

        // ---- Step form (Bedrock): Back button, last, action backmenu
        check("form-back-button", pres.contains("buttons.add(\"Back to Server Menu\")")
                && pres.contains("actions.add(\"backmenu\")"),
                "step form gains a Back to Server Menu button with action backmenu");
        check("form-back-last", pres.indexOf("buttons.add(\"Back to Server Menu\")")
                > pres.indexOf("buttons.add(\"Close\")"),
                "Back is last on the form (house Back-last convention), after Close");
        check("form-controls-survive", pres.contains("Done \u2014 next step")
                && pres.contains("\"Skip this step\"") && pres.contains("\"Repeat\"")
                && pres.contains("\"Restart tour\"") && pres.contains("\"Close\""),
                "Done / Skip / Repeat / Restart / Close buttons all survive");
        String backBranch = branch(main, "case \"backmenu\"", "case \"close\"");
        check("backmenu-branch-pure", backBranch.contains("openServerMenu(player)")
                && !backBranch.contains("engine.") && !backBranch.contains("savePlayer(")
                && !backBranch.contains("startRoute(") && !backBranch.contains("menuNext("),
                "the backmenu handler is pure navigation: no engine call, no save, no start");

        // ---- Behavioral walk: mid-tour Back leaves progress intact
        TourEngine e = engineWith();
        UUID mid = UUID.randomUUID();
        e.start(mid, "test-route");
        e.tryLocation(mid, "test-route", "guild_world", 0, 0, 0);   // -> s2-menu
        e.skip(mid, "test-route");                                   // -> s3-arrive, skipped [s2-menu]
        Progress before = e.progress(mid, "test-route").copy();
        check("walk-mid-state", before.state == Progress.State.IN_PROGRESS
                && "s3-arrive".equals(before.currentStepId)
                && before.skippedSteps.equals(java.util.List.of("s2-menu")),
                "walk reaches the mid-tour state the Back tap happens in (step 3, one skip)");
        // A Back tap performs zero progress operations (pinned by
        // backmenu-branch-pure / opener-touches-no-progress above);
        // the player then re-opens the Guide from the Server Menu.
        Progress after = e.progress(mid, "test-route");
        check("walk-back-survives", sameProgress(before, after)
                && "test-route".equals(e.activeRouteId(mid)),
                "after Back the tour is still in progress on the same step, skips intact");
        File dir = Files.createTempDirectory("exceltour-backnav").toFile();
        ProgressStore store = new ProgressStore(dir);
        store.save(mid, "MidTour", e.allProgress(mid));
        Progress loaded = store.load(mid).get("test-route");
        check("walk-back-survives-relog", sameProgress(before, loaded),
                "the Back-surviving state round-trips save/load (relog resumes the same step)");
        check("walk-tour-still-advances", e.menuNext(mid, "test-route") == TourEngine.Advance.ADVANCED
                && "s4-npc".equals(e.currentStep(mid, "test-route").id),
                "after Back the tour still advances normally (not stopped, not reset)");

        // ---- Back in the other two states changes nothing either
        TourEngine e2 = engineWith();
        UUID fresh = UUID.randomUUID();
        check("walk-notstarted-unchanged", e2.progress(fresh, "test-route") == null
                && e2.activeRouteId(fresh) == null,
                "a player who never started still has no tour after a Back (no phantom start)");
        UUID done = UUID.randomUUID();
        e2.start(done, "test-route");
        e2.tryLocation(done, "test-route", "guild_world", 0, 0, 0);
        e2.menuNext(done, "test-route"); e2.menuNext(done, "test-route");
        e2.tryNpc(done, "test-route", "Casus"); e2.tryLocation(done, "test-route", "home", 0, 0, 0);
        Progress doneBefore = e2.progress(done, "test-route").copy();
        check("walk-completed-unchanged", doneBefore.state == Progress.State.COMPLETED
                && doneBefore.completions == 1
                && sameProgress(doneBefore, e2.progress(done, "test-route")),
                "a completed tour (1x) is unchanged by a Back from the Guide view");

        System.out.println("BACKNAVTEST TALLY pass=" + pass + " fail=" + fail);
        if (fail > 0) System.exit(1);
    }
}
