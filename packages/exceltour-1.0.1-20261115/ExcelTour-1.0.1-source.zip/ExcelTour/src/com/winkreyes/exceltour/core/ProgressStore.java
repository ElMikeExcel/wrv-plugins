package com.winkreyes.exceltour.core;

import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Per-player YAML persistence (DESIGN §6.1): one file per player,
 * plugins/ExcelTour/players/&lt;uuid&gt;.yml, keyed by the real UUID.
 * Bukkit-free (SnakeYAML only). A corrupt/missing file loads as
 * empty (= not-started) — §6.2.
 */
public final class ProgressStore {
    private static final DateTimeFormatter ISO =
            DateTimeFormatter.ISO_OFFSET_DATE_TIME.withZone(ZoneId.systemDefault());

    private final File dir;
    public ProgressStore(File dir) { this.dir = dir; }

    public File fileFor(UUID uuid) { return new File(dir, uuid.toString() + ".yml"); }
    public File dir() { return dir; }

    public static String iso(long millis) {
        return millis <= 0 ? null : ISO.format(Instant.ofEpochMilli(millis));
    }
    public static long parseIso(String s) {
        if (s == null) return 0L;
        try { return Instant.from(ISO.parse(s)).toEpochMilli(); }
        catch (Exception e) {
            try { return Instant.parse(s).toEpochMilli(); } catch (Exception e2) { return 0L; }
        }
    }

    /** All route progress for a player; empty map on missing/corrupt file. */
    public Map<String, Progress> load(UUID uuid) {
        Map<String, Progress> out = new LinkedHashMap<>();
        File f = fileFor(uuid);
        if (!f.isFile()) return out;
        try (InputStream in = new FileInputStream(f)) {
            Object rootObj = new Yaml().load(in);
            if (!(rootObj instanceof Map)) return out;
            Object routesObj = ((Map<?, ?>) rootObj).get("routes");
            if (!(routesObj instanceof Map)) return out;
            for (Map.Entry<?, ?> e : ((Map<?, ?>) routesObj).entrySet()) {
                if (!(e.getValue() instanceof Map)) continue;
                Map<?, ?> rm = (Map<?, ?>) e.getValue();
                Progress p = new Progress();
                String state = String.valueOf(rm.get("state"));
                try { p.state = Progress.State.valueOf(state.trim().toUpperCase().replace('-', '_')); }
                catch (Exception ex) { p.state = Progress.State.NOT_STARTED; }
                Object cur = rm.get("current-step");
                p.currentStepId = cur == null ? null : String.valueOf(cur);
                Object sk = rm.get("skipped-steps");
                if (sk instanceof List) for (Object s : (List<?>) sk) p.skippedSteps.add(String.valueOf(s));
                p.startedAtMillis = parseIso(str(rm.get("started-at")));
                p.updatedAtMillis = parseIso(str(rm.get("updated-at")));
                Object comp = rm.get("completions");
                p.completions = comp instanceof Number ? ((Number) comp).intValue() : 0;
                String lc = str(rm.get("last-completed-at"));
                p.lastCompletedAtMillis = lc == null ? null : parseIso(lc);
                out.put(String.valueOf(e.getKey()), p);
            }
        } catch (Exception e) {
            return new LinkedHashMap<>(); // corrupt = not-started (§6.2), caller logs once
        }
        return out;
    }

    public String loadPlayerName(UUID uuid) {
        File f = fileFor(uuid);
        if (!f.isFile()) return null;
        try (InputStream in = new FileInputStream(f)) {
            Object rootObj = new Yaml().load(in);
            if (rootObj instanceof Map) {
                Object n = ((Map<?, ?>) rootObj).get("player-name");
                return n == null ? null : String.valueOf(n);
            }
        } catch (Exception ignored) { }
        return null;
    }

    public void save(UUID uuid, String playerName, Map<String, Progress> routes) throws IOException {
        dir.mkdirs();
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("player-name", playerName);
        Map<String, Object> routesMap = new LinkedHashMap<>();
        for (Map.Entry<String, Progress> e : routes.entrySet()) {
            Progress p = e.getValue();
            Map<String, Object> rm = new LinkedHashMap<>();
            rm.put("state", p.state.name().toLowerCase().replace('_', '-'));
            rm.put("current-step", p.currentStepId);
            rm.put("skipped-steps", new ArrayList<>(p.skippedSteps));
            rm.put("started-at", iso(p.startedAtMillis));
            rm.put("updated-at", iso(p.updatedAtMillis));
            rm.put("completions", p.completions);
            rm.put("last-completed-at", p.lastCompletedAtMillis == null ? null : iso(p.lastCompletedAtMillis));
            routesMap.put(e.getKey(), rm);
        }
        root.put("routes", routesMap);
        DumperOptions opts = new DumperOptions();
        opts.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
        try (FileWriter w = new FileWriter(fileFor(uuid))) {
            new Yaml(opts).dump(root, w);
        }
    }

    /** Every saved player UUID (for offline status lookups by name). */
    public List<UUID> knownPlayers() {
        List<UUID> out = new ArrayList<>();
        File[] files = dir.listFiles((d, n) -> n.endsWith(".yml"));
        if (files == null) return out;
        for (File f : files) {
            try { out.add(UUID.fromString(f.getName().substring(0, f.getName().length() - 4))); }
            catch (Exception ignored) { }
        }
        return out;
    }

    private static String str(Object o) { return o == null ? null : String.valueOf(o); }
}
