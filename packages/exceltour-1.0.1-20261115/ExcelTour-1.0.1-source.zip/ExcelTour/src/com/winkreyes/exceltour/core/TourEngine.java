package com.winkreyes.exceltour.core;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.LongSupplier;

/**
 * The tour state machine (DESIGN §§3, 5, 6.2). Bukkit-free: the
 * Bukkit glue feeds it locations / world changes / NPC names and
 * renders the results. Advancement is idempotent — one evaluation
 * advances at most one step (§3).
 */
public final class TourEngine {
    public enum Advance { ADVANCED, COMPLETED, NOT_STARTED, NOT_ALLOWED, NOT_SKIPPABLE, UNKNOWN_ROUTE }

    private final Map<String, Route> routes = new LinkedHashMap<>();
    private final Map<UUID, Map<String, Progress>> byPlayer = new HashMap<>();
    private final LongSupplier clock;

    public TourEngine(LongSupplier clock) { this.clock = clock; }
    public TourEngine() { this(System::currentTimeMillis); }

    public void setRoutes(Map<String, Route> newRoutes) { routes.clear(); routes.putAll(newRoutes); }
    public Map<String, Route> routes() { return routes; }
    public Route route(String id) { return routes.get(id); }

    public Progress progress(UUID player, String routeId) {
        Map<String, Progress> m = byPlayer.get(player);
        if (m == null) return null;
        return m.get(routeId);
    }

    public Map<String, Progress> allProgress(UUID player) {
        Map<String, Progress> m = byPlayer.get(player);
        return m == null ? Map.of() : m;
    }

    /** Install loaded progress (from ProgressStore); validated by the caller against routes. */
    public void putProgress(UUID player, String routeId, Progress p) {
        byPlayer.computeIfAbsent(player, k -> new HashMap<>()).put(routeId, p);
    }

    public void forgetPlayer(UUID player) { byPlayer.remove(player); }

    private Progress ensure(UUID player, String routeId) {
        return byPlayer.computeIfAbsent(player, k -> new HashMap<>())
                .computeIfAbsent(routeId, k -> new Progress());
    }

    /** Start (or, on a completed route, restart) a route. Returns the progress. */
    public Progress start(UUID player, String routeId) {
        Route r = routes.get(routeId);
        if (r == null) return null;
        Progress p = ensure(player, routeId);
        long now = clock.getAsLong();
        p.state = Progress.State.IN_PROGRESS;
        p.currentStepId = r.firstStep().id;
        p.skippedSteps.clear();
        p.startedAtMillis = now; p.updatedAtMillis = now;
        return p;
    }

    /** The player's current step on a route, or null. */
    public Step currentStep(UUID player, String routeId) {
        Progress p = progress(player, routeId);
        if (p == null || p.state != Progress.State.IN_PROGRESS) return null;
        Route r = routes.get(routeId);
        return r == null ? null : r.stepById(p.currentStepId);
    }

    /** The route id of the player's (single) in-progress route, or null. */
    public String activeRouteId(UUID player) {
        for (Map.Entry<String, Progress> e : allProgress(player).entrySet())
            if (e.getValue().state == Progress.State.IN_PROGRESS) return e.getKey();
        return null;
    }

    private Advance advanceInternal(UUID player, String routeId, boolean skipped) {
        Route r = routes.get(routeId);
        if (r == null) return Advance.UNKNOWN_ROUTE;
        Progress p = progress(player, routeId);
        if (p == null || p.state != Progress.State.IN_PROGRESS) return Advance.NOT_STARTED;
        Step cur = r.stepById(p.currentStepId);
        if (cur == null) return Advance.NOT_STARTED;
        if (skipped && !p.skippedSteps.contains(cur.id)) p.skippedSteps.add(cur.id);
        long now = clock.getAsLong();
        p.updatedAtMillis = now;
        Step next = r.stepAfter(cur.id);
        if (next == null) {
            p.state = Progress.State.COMPLETED;
            p.currentStepId = null;
            p.completions++;
            p.lastCompletedAtMillis = now;
            return Advance.COMPLETED;
        }
        p.currentStepId = next.id;
        return Advance.ADVANCED;
    }

    /** Periodic location evaluation (arrival + world-arrival + npc-arrival fallback). */
    public Advance tryLocation(UUID player, String routeId, String world, double x, double y, double z) {
        Step cur = currentStep(player, routeId);
        if (cur == null) return Advance.NOT_STARTED;
        Trigger t = cur.trigger;
        switch (t.type) {
            case ARRIVAL:
                return t.arrivalMatches(world, x, y, z) ? advanceInternal(player, routeId, false) : Advance.NOT_ALLOWED;
            case WORLD_ARRIVAL:
                return t.worldMatches(world) ? advanceInternal(player, routeId, false) : Advance.NOT_ALLOWED;
            case NPC_INTERACTION:
                return t.arrivalMatches(world, x, y, z) ? advanceInternal(player, routeId, false) : Advance.NOT_ALLOWED;
            default:
                return Advance.NOT_ALLOWED;
        }
    }

    /** NPC interaction evaluation (§3.4 — name match on the step's npc-name). */
    public Advance tryNpc(UUID player, String routeId, String npcNamePlain) {
        Step cur = currentStep(player, routeId);
        if (cur == null) return Advance.NOT_STARTED;
        Trigger t = cur.trigger;
        if (t.type != Trigger.Type.NPC_INTERACTION || t.npcName == null || npcNamePlain == null) return Advance.NOT_ALLOWED;
        return t.npcName.equalsIgnoreCase(npcNamePlain.trim()) ? advanceInternal(player, routeId, false) : Advance.NOT_ALLOWED;
    }

    /** Guide-entry Done / /tour next (§3.3 + backstops). */
    public Advance menuNext(UUID player, String routeId) {
        Step cur = currentStep(player, routeId);
        if (cur == null) return Advance.NOT_STARTED;
        if (!cur.trigger.menuAdvanceable()) return Advance.NOT_ALLOWED;
        return advanceInternal(player, routeId, false);
    }

    /** Skip (§5) — honours the step's skippable flag. */
    public Advance skip(UUID player, String routeId) {
        Step cur = currentStep(player, routeId);
        if (cur == null) return Advance.NOT_STARTED;
        if (!cur.skippable) return Advance.NOT_SKIPPABLE;
        return advanceInternal(player, routeId, true);
    }

    /** Restart own route from step 1; completions preserved (§6.2). */
    public Progress restart(UUID player, String routeId) { return start(player, routeId); }

    /**
     * Reset to not-started (§6.3). Default keeps the completions
     * count; includeCompletions=true is the explicit full form.
     */
    public void reset(UUID player, String routeId, boolean includeCompletions) {
        Progress p = ensure(player, routeId);
        int keep = includeCompletions ? 0 : p.completions;
        Long keepLast = includeCompletions ? null : p.lastCompletedAtMillis;
        p.state = Progress.State.NOT_STARTED;
        p.currentStepId = null;
        p.skippedSteps.clear();
        p.startedAtMillis = 0L;
        p.updatedAtMillis = clock.getAsLong();
        p.completions = keep;
        p.lastCompletedAtMillis = keepLast;
    }
}
