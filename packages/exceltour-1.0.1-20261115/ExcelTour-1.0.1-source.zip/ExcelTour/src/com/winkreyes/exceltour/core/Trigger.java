package com.winkreyes.exceltour.core;

/** One step's trigger (DESIGN §3). Bukkit-free. */
public final class Trigger {
    public enum Type { ARRIVAL, WORLD_ARRIVAL, MENU_ADVANCED, NPC_INTERACTION }

    public final Type type;
    /** World name, or null when the YAML value is the TO-BE-PULLED placeholder. */
    public final String world;
    /** Negative world test (world-arrival variant, §3.1 step-5 form), or null. */
    public final String notWorld;
    public final Double x, y, z;
    public final double radius;
    public final String npcName;
    public final boolean alsoAllowMenuAdvance;
    /** True when any location/world value is still TO-BE-PULLED (degraded step). */
    public final boolean placeholder;

    public Trigger(Type type, String world, String notWorld, Double x, Double y, Double z,
                   double radius, String npcName, boolean alsoAllowMenuAdvance, boolean placeholder) {
        this.type = type; this.world = world; this.notWorld = notWorld;
        this.x = x; this.y = y; this.z = z; this.radius = radius;
        this.npcName = npcName; this.alsoAllowMenuAdvance = alsoAllowMenuAdvance;
        this.placeholder = placeholder;
    }

    /** Whether the Guide entry / /tour next may advance this step (§3.1/§3.3 + §2.4 backstop). */
    public boolean menuAdvanceable() {
        return type == Type.MENU_ADVANCED || alsoAllowMenuAdvance || placeholder;
    }

    /** Distance test for arrival-style triggers; false when data is missing/placeholder. */
    public boolean arrivalMatches(String playerWorld, double px, double py, double pz) {
        if (world == null || x == null || y == null || z == null || playerWorld == null) return false;
        if (!world.equals(playerWorld)) return false;
        double dx = px - x, dy = py - y, dz = pz - z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz) <= radius;
    }

    /** World test for world-arrival triggers (positive or negative form). */
    public boolean worldMatches(String playerWorld) {
        if (playerWorld == null) return false;
        if (notWorld != null) return !notWorld.equals(playerWorld);
        return world != null && world.equals(playerWorld);
    }
}
