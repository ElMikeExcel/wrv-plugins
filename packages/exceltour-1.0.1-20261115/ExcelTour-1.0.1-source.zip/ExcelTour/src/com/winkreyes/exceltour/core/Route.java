package com.winkreyes.exceltour.core;

import java.util.List;

/** One route definition (DESIGN §2). Bukkit-free. */
public final class Route {
    public final String id, displayName, description, completionText;
    public final List<Step> steps;

    public Route(String id, String displayName, String description, String completionText, List<Step> steps) {
        this.id = id; this.displayName = displayName; this.description = description;
        this.completionText = completionText; this.steps = List.copyOf(steps);
    }

    public Step stepById(String stepId) {
        if (stepId == null) return null;
        for (Step s : steps) if (s.id.equals(stepId)) return s;
        return null;
    }

    /** 1-based position of a step id, or -1. */
    public int indexOf(String stepId) {
        for (int i = 0; i < steps.size(); i++) if (steps.get(i).id.equals(stepId)) return i + 1;
        return -1;
    }

    public Step firstStep() { return steps.get(0); }

    /** The step after the given id, or null when it is the last. */
    public Step stepAfter(String stepId) {
        int idx = indexOf(stepId);
        if (idx < 1 || idx >= steps.size()) return null;
        return steps.get(idx); // idx is 1-based; steps.get(idx) is the next element
    }
}
