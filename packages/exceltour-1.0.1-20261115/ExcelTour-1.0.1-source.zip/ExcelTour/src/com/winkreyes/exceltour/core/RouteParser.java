package com.winkreyes.exceltour.core;

import org.yaml.snakeyaml.Yaml;

import java.io.Reader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Parses + validates one route YAML (DESIGN §2.1/§2.2). Bukkit-free
 * (SnakeYAML only). A route that fails validation does not load; the
 * caller logs the errors by route id. TO-BE-PULLED values are NOT a
 * validation failure: they mark the trigger placeholder/degraded so
 * the §2.4 fallback posture applies (the step stays loadable and
 * menu-advanceable, it just never auto-fires).
 */
public final class RouteParser {
    public static final String PLACEHOLDER = "TO-BE-PULLED";

    public static final class Result {
        public final Route route; public final List<String> errors; public final List<String> warnings;
        Result(Route r, List<String> e, List<String> w) { route = r; errors = e; warnings = w; }
        public boolean ok() { return route != null; }
    }

    public static Result parse(Reader reader) {
        List<String> errors = new ArrayList<>(), warnings = new ArrayList<>();
        Object rootObj;
        try { rootObj = new Yaml().load(reader); }
        catch (Exception e) { errors.add("YAML parse failure: " + e.getMessage()); return new Result(null, errors, warnings); }
        if (!(rootObj instanceof Map)) { errors.add("route file is not a YAML map"); return new Result(null, errors, warnings); }
        Map<?, ?> root = (Map<?, ?>) rootObj;
        String id = str(root.get("id"));
        if (id == null || id.isBlank()) { errors.add("missing route id"); return new Result(null, errors, warnings); }
        Object stepsObj = root.get("steps");
        if (!(stepsObj instanceof List) || ((List<?>) stepsObj).isEmpty()) {
            errors.add("route '" + id + "' has zero steps"); return new Result(null, errors, warnings);
        }
        List<Step> steps = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (Object so : (List<?>) stepsObj) {
            if (!(so instanceof Map)) { errors.add("route '" + id + "': a step is not a map"); continue; }
            Map<?, ?> sm = (Map<?, ?>) so;
            String sid = str(sm.get("id"));
            if (sid == null || sid.isBlank()) { errors.add("route '" + id + "': a step has no id"); continue; }
            if (!seen.add(sid)) { errors.add("route '" + id + "': duplicate step id '" + sid + "'"); continue; }
            Object trigObj = sm.get("trigger");
            if (!(trigObj instanceof Map)) { errors.add("route '" + id + "' step '" + sid + "': no trigger"); continue; }
            Trigger trig = parseTrigger(id, sid, (Map<?, ?>) trigObj, errors, warnings);
            if (trig == null) continue;
            steps.add(new Step(sid,
                    orEmpty(str(sm.get("title"))), orEmpty(str(sm.get("body"))), str(sm.get("hint")),
                    trig, bool(sm.get("skippable"), true)));
        }
        if (!errors.isEmpty() || steps.isEmpty()) {
            if (steps.isEmpty() && errors.isEmpty()) errors.add("route '" + id + "' has zero valid steps");
            return new Result(null, errors, warnings);
        }
        return new Result(new Route(id, orEmpty(str(root.get("display-name"))),
                orEmpty(str(root.get("description"))), orEmpty(str(root.get("completion-text"))), steps),
                errors, warnings);
    }

    private static Trigger parseTrigger(String routeId, String stepId, Map<?, ?> tm,
                                        List<String> errors, List<String> warnings) {
        String typeRaw = str(tm.get("type"));
        if (typeRaw == null) { errors.add("route '" + routeId + "' step '" + stepId + "': trigger has no type"); return null; }
        Trigger.Type type;
        try { type = Trigger.Type.valueOf(typeRaw.trim().toUpperCase().replace('-', '_')); }
        catch (IllegalArgumentException e) {
            errors.add("route '" + routeId + "' step '" + stepId + "': unknown trigger type '" + typeRaw + "'"); return null;
        }
        boolean also = bool(tm.get("also-allow-menu-advance"), false);
        switch (type) {
            case MENU_ADVANCED:
                return new Trigger(type, null, null, null, null, null, 0, null, also, false);
            case WORLD_ARRIVAL: {
                String notWorld = value(tm.get("not-world"));
                String world = value(tm.get("world"));
                if (notWorld != null && notWorld != PLACEHOLDER) {
                    boolean ph = world == PLACEHOLDER;
                    return new Trigger(type, null, notWorld, null, null, null, 0, null, also, ph);
                }
                if (world == null && notWorld == null) {
                    errors.add("route '" + routeId + "' step '" + stepId
                            + "': world-arrival needs 'world' (or TO-BE-PULLED) or 'not-world'"); return null;
                }
                boolean ph = world == PLACEHOLDER || notWorld == PLACEHOLDER;
                if (ph) warnings.add("route '" + routeId + "' step '" + stepId
                        + "': world is TO-BE-PULLED — step degraded to menu-advance backstop (§2.4)");
                return new Trigger(type, ph ? null : world, null, null, null, null, 0, null, also, ph);
            }
            case ARRIVAL:
            case NPC_INTERACTION: {
                String npc = type == Trigger.Type.NPC_INTERACTION ? str(tm.get("npc-name")) : null;
                if (type == Trigger.Type.NPC_INTERACTION && (npc == null || npc.isBlank())) {
                    errors.add("route '" + routeId + "' step '" + stepId + "': npc-interaction needs 'npc-name'"); return null;
                }
                // §2.1: an arrival step with neither a location nor a
                // TO-BE-PULLED acknowledgement does not load.
                boolean anyLocKey = tm.containsKey("world") || tm.containsKey("x")
                        || tm.containsKey("y") || tm.containsKey("z");
                if (!anyLocKey) {
                    errors.add("route '" + routeId + "' step '" + stepId
                            + "': arrival step has neither a location nor TO-BE-PULLED placeholders"); return null;
                }
                String world = value(tm.get("world"));
                Coord cx = coord(tm.get("x")), cy = coord(tm.get("y")), cz = coord(tm.get("z"));
                boolean ph = world == PLACEHOLDER || cx.placeholder || cy.placeholder || cz.placeholder;
                boolean complete = world != null && world != PLACEHOLDER
                        && cx.value != null && cy.value != null && cz.value != null;
                if (!complete && !ph) {
                    errors.add("route '" + routeId + "' step '" + stepId
                            + "': arrival location is incomplete and not marked TO-BE-PULLED"); return null;
                }
                double radius = num(tm.get("radius"), 8.0);
                if (radius <= 0) { errors.add("route '" + routeId + "' step '" + stepId + "': radius must be > 0"); return null; }
                if (ph) warnings.add("route '" + routeId + "' step '" + stepId
                        + "': location is TO-BE-PULLED — arrival will not auto-fire; menu-advance backstop applies (§2.4)");
                return new Trigger(type, complete ? world : null, null,
                        complete ? cx.value : null, complete ? cy.value : null, complete ? cz.value : null,
                        radius, npc, also, ph);
            }
        }
        return null; // unreachable
    }

    private static final class Coord { Double value; boolean placeholder; }
    private static Coord coord(Object o) {
        Coord c = new Coord();
        if (o == null) return c;
        if (o instanceof Number) { c.value = ((Number) o).doubleValue(); return c; }
        if (PLACEHOLDER.equals(String.valueOf(o).trim())) { c.placeholder = true; return c; }
        try { c.value = Double.parseDouble(String.valueOf(o).trim()); } catch (Exception ignored) { }
        return c;
    }
    /** Returns the string, the PLACEHOLDER sentinel, or null. */
    private static String value(Object o) {
        if (o == null) return null;
        String s = String.valueOf(o).trim();
        if (s.isEmpty()) return null;
        return PLACEHOLDER.equals(s) ? PLACEHOLDER : s;
    }
    private static String str(Object o) { return o == null ? null : String.valueOf(o); }
    private static String orEmpty(String s) { return s == null ? "" : s; }
    private static boolean bool(Object o, boolean def) {
        if (o instanceof Boolean) return (Boolean) o;
        if (o != null) return Boolean.parseBoolean(String.valueOf(o));
        return def;
    }
    private static double num(Object o, double def) {
        if (o instanceof Number) return ((Number) o).doubleValue();
        if (o != null) try { return Double.parseDouble(String.valueOf(o).trim()); } catch (Exception ignored) { }
        return def;
    }
}
