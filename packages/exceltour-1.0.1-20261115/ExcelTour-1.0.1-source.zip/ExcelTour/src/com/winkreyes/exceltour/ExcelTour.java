package com.winkreyes.exceltour;

import com.winkreyes.exceltour.core.Progress;
import com.winkreyes.exceltour.core.ProgressStore;
import com.winkreyes.exceltour.core.Route;
import com.winkreyes.exceltour.core.RouteParser;
import com.winkreyes.exceltour.core.Step;
import com.winkreyes.exceltour.core.TourEngine;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.FileReader;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * ExcelTour 1.0.0 — in-game guided tours for Wink Reyes Valley
 * (DESIGN: ~/workspace/exceltour-design-20261111/DESIGN.md).
 * Presentation + progression only: no teleports, no rewards, no
 * gating, no EM internals. Paper only as a hard dependency;
 * Geyser/Floodgate are soft, reflection-detected integrations.
 */
public final class ExcelTour extends JavaPlugin implements Listener {
    private final TourEngine engine = new TourEngine();
    private ProgressStore store;
    private Presentation presentation;
    private String defaultRouteId = "guild-first-visit";

    public TourEngine engine() { return engine; }
    public Presentation presentation() { return presentation; }
    public ProgressStore store() { return store; }
    public Route defaultRoute() {
        Route r = engine.route(defaultRouteId);
        if (r != null) return r;
        return engine.routes().values().stream().findFirst().orElse(null);
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        defaultRouteId = getConfig().getString("default-route", "guild-first-visit");
        store = new ProgressStore(new File(getDataFolder(), "players"));
        presentation = new Presentation(this);
        File routesDir = new File(getDataFolder(), "routes");
        if (!routesDir.isDirectory() || routesDir.listFiles((d, n) -> n.endsWith(".yml")) == null
                || routesDir.listFiles((d, n) -> n.endsWith(".yml")).length == 0) {
            saveResource("routes/guild-first-visit.yml", false);
        }
        int loaded = reloadRoutes();
        TourCommands cmds = new TourCommands(this);
        if (getCommand("tour") != null) {
            getCommand("tour").setExecutor(cmds);
            getCommand("tour").setTabCompleter(cmds);
        }
        Bukkit.getPluginManager().registerEvents(this, this);
        long checkTicks = Math.max(2L, getConfig().getLong("arrival-check-ticks", 10L));
        Bukkit.getScheduler().runTaskTimer(this, this::tickLocations, checkTicks, checkTicks);
        long refreshTicks = Math.max(20L, getConfig().getLong("actionbar-refresh-ticks", 100L));
        Bukkit.getScheduler().runTaskTimer(this, this::tickActionBars, refreshTicks, refreshTicks);
        getLogger().info("ExcelTour v" + BuildInfo.VERSION + " enabled: " + loaded
                + " route(s) loaded " + engine.routes().keySet() + " (build " + BuildInfo.BUILD_ID + ")");
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) savePlayer(p.getUniqueId(), p.getName());
        getLogger().info("ExcelTour disabled.");
    }

    /** (Re)load every route YAML; a bad route never blocks the others (§2.1). Returns count loaded. */
    public int reloadRoutes() {
        File routesDir = new File(getDataFolder(), "routes");
        Map<String, Route> loaded = new LinkedHashMap<>();
        File[] files = routesDir.listFiles((d, n) -> n.endsWith(".yml"));
        if (files != null) {
            for (File f : files) {
                try (FileReader r = new FileReader(f)) {
                    RouteParser.Result res = RouteParser.parse(r);
                    for (String w : res.warnings) getLogger().warning("ExcelTour route " + f.getName() + ": " + w);
                    if (!res.ok()) {
                        for (String e : res.errors) getLogger().warning("ExcelTour route " + f.getName() + " NOT loaded: " + e);
                        continue;
                    }
                    loaded.put(res.route.id, res.route);
                } catch (Exception e) {
                    getLogger().warning("ExcelTour route " + f.getName() + " NOT loaded: " + e.getMessage());
                }
            }
        }
        engine.setRoutes(loaded);
        return loaded.size();
    }

    // ---------- per-player load/save (§6) ----------
    public void loadPlayer(UUID uuid) {
        Map<String, Progress> saved = store.load(uuid);
        for (Map.Entry<String, Progress> e : saved.entrySet()) {
            Progress p = e.getValue();
            Route r = engine.route(e.getKey());
            if (r != null && p.state == Progress.State.IN_PROGRESS && p.currentStepId != null
                    && r.stepById(p.currentStepId) == null) {
                // §6.2: a saved step id that no longer exists resets that route to step 1.
                getLogger().warning("ExcelTour: player " + uuid + " route '" + e.getKey()
                        + "' saved step '" + p.currentStepId + "' no longer exists — reset to step 1");
                p.currentStepId = r.firstStep().id;
            }
            engine.putProgress(uuid, e.getKey(), p);
        }
    }

    public void savePlayer(UUID uuid, String lastKnownName) {
        try { store.save(uuid, lastKnownName, engine.allProgress(uuid)); }
        catch (Exception e) { getLogger().warning("ExcelTour: could not save progress for " + uuid + ": " + e.getMessage()); }
    }

    /** Shared action handler for the Java menu, the Bedrock form, and commands (§5.2). */
    public void handleTourAction(Player player, String action) {
        UUID uuid = player.getUniqueId();
        String routeId = engine.activeRouteId(uuid);
        if (routeId == null) {
            Route def = defaultRoute();
            if (def != null && "start".equals(action)) { startRoute(player, def.id); }
            return;
        }
        Route route = engine.route(routeId);
        switch (action) {
            case "next": {
                TourEngine.Advance a = engine.menuNext(uuid, routeId);
                afterAdvance(player, route, a, "This step doesn't advance from the menu — it finishes when you get there. (Skip is in the Guide if you need to pass it.)");
                break;
            }
            case "skip": {
                TourEngine.Advance a = engine.skip(uuid, routeId);
                afterAdvance(player, route, a, "This step can't be skipped.");
                break;
            }
            case "repeat": {
                Step s = engine.currentStep(uuid, routeId);
                if (s != null) presentation.showStep(player, route, s);
                break;
            }
            case "restart": {
                engine.restart(uuid, routeId);
                savePlayer(uuid, player.getName());
                Step s = engine.currentStep(uuid, routeId);
                player.sendMessage(Component.text("Tour restarted from Step 1.", NamedTextColor.GOLD));
                if (s != null) presentation.showStep(player, route, s);
                break;
            }
            case "stop": {
                engine.reset(uuid, routeId, false);
                savePlayer(uuid, player.getName());
                presentation.clearDisplay(player);
                player.sendMessage(Component.text("Tour stopped. You can start again any time from the compass Guide.", NamedTextColor.GOLD));
                break;
            }
            case "backmenu": {
                // BB-09: Back from the Bedrock step form. Pure
                // navigation only - no engine call, no save - so a
                // mid-tour Back cannot advance, restart, reset or
                // complete anything; progress survives untouched.
                openServerMenu(player);
                break;
            }
            case "close": break;
            default: break;
        }
    }

    /**
     * Back to Server Menu (BB-09, FIX-2): pure navigation via the
     * ExcelMenu /menu opener (the same opener this view is reached
     * by). It never calls the tour engine and never saves, so tour
     * progress - mid-tour included - is exactly as the player left
     * it. If ExcelMenu is absent the command simply fails and the
     * player stays where they are (the view is already closed).
     */
    public void openServerMenu(Player player) {
        player.closeInventory();
        player.performCommand("menu");
    }

    public void startRoute(Player player, String routeId) {
        Progress p = engine.start(player.getUniqueId(), routeId);
        if (p == null) {
            player.sendMessage(Component.text("That tour doesn't exist. Try /tour for the list.", NamedTextColor.RED));
            return;
        }
        savePlayer(player.getUniqueId(), player.getName());
        Route route = engine.route(routeId);
        Step s = engine.currentStep(player.getUniqueId(), routeId);
        player.sendMessage(Component.text("Started: " + com.winkreyes.exceltour.core.TextPlain.plain(route.displayName), NamedTextColor.GOLD));
        if (s != null) presentation.showStep(player, route, s);
    }

    public void afterAdvance(Player player, Route route, TourEngine.Advance a, String notAllowedText) {
        UUID uuid = player.getUniqueId();
        switch (a) {
            case ADVANCED: {
                savePlayer(uuid, player.getName());
                Step s = engine.currentStep(uuid, route.id);
                if (s != null) presentation.showStep(player, route, s);
                break;
            }
            case COMPLETED: {
                savePlayer(uuid, player.getName()); // completion saved in the same call that announces it (§6.1)
                presentation.showCompleted(player, route);
                break;
            }
            case NOT_ALLOWED:
            case NOT_SKIPPABLE:
                player.sendMessage(Component.text(notAllowedText, NamedTextColor.YELLOW));
                break;
            case NOT_STARTED:
                player.sendMessage(Component.text("You haven't started a tour yet — open the compass Guide to start one.", NamedTextColor.YELLOW));
                break;
            default: break;
        }
    }

    // ---------- listeners / tickers (§3) ----------
    private void tickLocations() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            String routeId = engine.activeRouteId(p.getUniqueId());
            if (routeId == null) continue;
            Route route = engine.route(routeId);
            if (route == null) continue;
            org.bukkit.Location loc = p.getLocation();
            TourEngine.Advance a = engine.tryLocation(p.getUniqueId(), routeId,
                    loc.getWorld() == null ? "" : loc.getWorld().getName(), loc.getX(), loc.getY(), loc.getZ());
            if (a == TourEngine.Advance.ADVANCED || a == TourEngine.Advance.COMPLETED)
                afterAdvance(p, route, a, "");
        }
    }

    private void tickActionBars() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            String routeId = engine.activeRouteId(p.getUniqueId());
            if (routeId == null) continue;
            Route route = engine.route(routeId);
            Step s = engine.currentStep(p.getUniqueId(), routeId);
            if (route != null && s != null) presentation.refreshActionBar(p, route, s);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        loadPlayer(p.getUniqueId());
        String routeId = engine.activeRouteId(p.getUniqueId());
        if (routeId != null) {
            Route route = engine.route(routeId);
            Step s = engine.currentStep(p.getUniqueId(), routeId);
            if (route != null && s != null) {
                // Resume presentation a moment after join so it lands after other join text.
                Bukkit.getScheduler().runTaskLater(this, () -> {
                    if (p.isOnline()) presentation.showStep(p, route, s);
                }, 40L);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        savePlayer(e.getPlayer().getUniqueId(), e.getPlayer().getName());
        engine.forgetPlayer(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        Player p = e.getPlayer();
        String routeId = engine.activeRouteId(p.getUniqueId());
        if (routeId == null) return;
        Route route = engine.route(routeId);
        if (route == null) return;
        org.bukkit.Location loc = p.getLocation();
        TourEngine.Advance a = engine.tryLocation(p.getUniqueId(), routeId,
                loc.getWorld() == null ? "" : loc.getWorld().getName(), loc.getX(), loc.getY(), loc.getZ());
        if (a == TourEngine.Advance.ADVANCED || a == TourEngine.Advance.COMPLETED)
            afterAdvance(p, route, a, "");
    }

    @EventHandler
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        // §3.4 optional trigger: name-match only, on Paper state — no EM internals read.
        Player p = e.getPlayer();
        String routeId = engine.activeRouteId(p.getUniqueId());
        if (routeId == null) return;
        Step cur = engine.currentStep(p.getUniqueId(), routeId);
        if (cur == null || cur.trigger.type != com.winkreyes.exceltour.core.Trigger.Type.NPC_INTERACTION) return;
        String name = e.getRightClicked().customName() != null
                ? com.winkreyes.exceltour.core.TextPlain.plain(
                    net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText()
                            .serialize(e.getRightClicked().customName()))
                : (e.getRightClicked().getCustomName() != null
                    ? com.winkreyes.exceltour.core.TextPlain.plain(e.getRightClicked().getCustomName()) : null);
        if (name == null) return;
        Route route = engine.route(routeId);
        TourEngine.Advance a = engine.tryNpc(p.getUniqueId(), routeId, name);
        if (a == TourEngine.Advance.ADVANCED || a == TourEngine.Advance.COMPLETED)
            afterAdvance(p, route, a, "");
    }

    @EventHandler
    public void onMenuClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof TourMenu menu)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player player)) return;
        int slot = e.getRawSlot();
        String routeId = engine.activeRouteId(player.getUniqueId());
        Progress p = routeId == null ? null
                : engine.progress(player.getUniqueId(), routeId);
        if (p == null || p.state == Progress.State.NOT_STARTED) {
            if (slot == 13) { Route def = defaultRoute(); if (def != null) { player.closeInventory(); startRoute(player, def.id); } }
            else if (slot == 26) openServerMenu(player);
            return;
        }
        if (p.state == Progress.State.COMPLETED) {
            if (slot == 22) {
                if (menu.isConfirmRestart()) { player.closeInventory(); handleTourAction(player, "restart"); }
                else new TourMenu(this, player, true).open();
            } else if (slot == 26) openServerMenu(player);
            return;
        }
        switch (slot) {
            case 10: player.closeInventory(); handleTourAction(player, "repeat"); break;
            case 12: player.closeInventory(); handleTourAction(player, "next"); break;
            case 14: player.closeInventory(); handleTourAction(player, "skip"); break;
            case 16:
                if (menu.isConfirmRestart()) { player.closeInventory(); handleTourAction(player, "restart"); }
                else new TourMenu(this, player, true).open();
                break;
            case 22: player.closeInventory(); handleTourAction(player, "stop"); break;
            case 26: openServerMenu(player); break;
            default: break;
        }
    }
}
