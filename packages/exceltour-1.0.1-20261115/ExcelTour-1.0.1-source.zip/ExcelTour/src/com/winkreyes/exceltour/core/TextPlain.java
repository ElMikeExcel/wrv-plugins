package com.winkreyes.exceltour.core;

/** Strips MiniMessage tags + legacy colour codes to plain text (DESIGN §2.1/§4.2). Bukkit-free. */
public final class TextPlain {
    private TextPlain() {}

    public static String plain(String s) {
        if (s == null) return "";
        String out = s.replaceAll("<[^>]*>", "");
        out = out.replaceAll("[&§][0-9a-fk-orA-FK-OR]", "");
        return out.trim();
    }
}
