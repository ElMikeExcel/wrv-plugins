package com.winkreyes.exceltour.core;

import java.util.ArrayList;
import java.util.List;

/** One player's progress on one route (DESIGN §6.1). Bukkit-free. */
public final class Progress {
    public enum State { NOT_STARTED, IN_PROGRESS, COMPLETED }

    public State state = State.NOT_STARTED;
    public String currentStepId = null;
    public final List<String> skippedSteps = new ArrayList<>();
    public long startedAtMillis = 0L;
    public long updatedAtMillis = 0L;
    public int completions = 0;
    public Long lastCompletedAtMillis = null;

    public Progress copy() {
        Progress p = new Progress();
        p.state = state; p.currentStepId = currentStepId;
        p.skippedSteps.addAll(skippedSteps);
        p.startedAtMillis = startedAtMillis; p.updatedAtMillis = updatedAtMillis;
        p.completions = completions; p.lastCompletedAtMillis = lastCompletedAtMillis;
        return p;
    }
}
