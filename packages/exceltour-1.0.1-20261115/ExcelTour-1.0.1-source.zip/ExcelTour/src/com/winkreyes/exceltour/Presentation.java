package com.winkreyes.exceltour;

import com.winkreyes.exceltour.core.Progress;
import com.winkreyes.exceltour.core.Route;
import com.winkreyes.exceltour.core.Step;
import com.winkreyes.exceltour.core.TextPlain;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;

/**
 * Per-platform step presentation (DESIGN §4). One step, three
 * renderings: Java = action bar (title + progress) + body in chat on
 * step change (§4.1 option (b) — chosen at build time to avoid
 * scoreboard-ownership conflicts with WRV's scoreboard-adjacent
 * plugins; see BUILD-RECORD §8.7). Bedrock = chat body + Cumulus
 * form popup when the form API answers, chat-only otherwise (§4.2).
 */
public final class Presentation {
    private final ExcelTour plugin;
    public Presentation(ExcelTour plugin) { this.plugin = plugin; }

    public boolean isBedrock(Player p) { return PlatformDetect.isBedrock(p, plugin.getLogger()); }

    /** Full step-change presentation. */
    public void showStep(Player player, Route route, Step step) {
        int n = route.indexOf(step.id), m = route.steps.size();
        String titleLine = "Step " + n + " of " + m + " — " + TextPlain.plain(step.title);
        if (isBedrock(player)) {
            player.sendMessage(Component.text("[" + TextPlain.plain(route.displayName) + "] " + titleLine, NamedTextColor.GOLD));
            player.sendMessage(Component.text(TextPlain.plain(step.body), NamedTextColor.WHITE));
            if (step.hint != null) player.sendMessage(Component.text("Hint: " + TextPlain.plain(step.hint), NamedTextColor.GRAY));
            sendStepForm(player, route, step);
        } else {
            player.sendActionBar(Component.text(titleLine, NamedTextColor.GOLD));
            player.sendMessage(Component.text("[" + TextPlain.plain(route.displayName) + "] " + titleLine, NamedTextColor.GOLD));
            player.sendMessage(Component.text(TextPlain.plain(step.body), NamedTextColor.WHITE));
            if (step.hint != null) player.sendMessage(Component.text("Hint: " + TextPlain.plain(step.hint), NamedTextColor.GRAY));
            player.sendMessage(Component.text("Open the compass Guide (or /tour) for Repeat / Skip / Restart.", NamedTextColor.GRAY));
        }
    }

    /** Slow action-bar refresh for Java players (§4.1 — re-send, never per-tick). */
    public void refreshActionBar(Player player, Route route, Step step) {
        if (isBedrock(player)) return;
        int n = route.indexOf(step.id), m = route.steps.size();
        player.sendActionBar(Component.text(
                "Step " + n + " of " + m + " — " + TextPlain.plain(step.title), NamedTextColor.GOLD));
    }

    public void showCompleted(Player player, Route route) {
        player.sendActionBar(Component.text(TextPlain.plain(route.completionText), NamedTextColor.GREEN));
        player.sendMessage(Component.text(TextPlain.plain(route.completionText), NamedTextColor.GREEN));
    }

    public void clearDisplay(Player player) {
        player.sendActionBar(Component.empty());
    }

    /**
     * The Bedrock step form (§4.2/§5.2): buttons in a fixed order —
     * [Done — next step (if menu-advanceable)], [Skip (if skippable)],
     * [Repeat], [Restart], [Close], [Back to Server Menu] (BB-09,
     * FIX-2; Back-last, the house form convention). Close/no-choice
     * changes nothing. Back is pure navigation to the Server Menu:
     * it runs no tour action on progress, so a mid-tour Back leaves
     * the player's step, skips and completions exactly as they were.
     * Returns false when no form API answered (chat rendering stands).
     */
    public boolean sendStepForm(Player player, Route route, Step step) {
        List<String> buttons = new ArrayList<>();
        List<String> actions = new ArrayList<>();
        if (step.trigger.menuAdvanceable()) { buttons.add("Done — next step"); actions.add("next"); }
        if (step.skippable) { buttons.add("Skip this step"); actions.add("skip"); }
        buttons.add("Repeat"); actions.add("repeat");
        buttons.add("Restart tour"); actions.add("restart");
        buttons.add("Close"); actions.add("close");
        buttons.add("Back to Server Menu"); actions.add("backmenu");
        String body = TextPlain.plain(step.title) + "\n\n" + TextPlain.plain(step.body)
                + (step.hint != null ? "\n\nHint: " + TextPlain.plain(step.hint) : "");
        IntConsumer onButton = idx -> {
            if (!player.isOnline() || idx < 0 || idx >= actions.size()) return;
            plugin.handleTourAction(player, actions.get(idx));
        };
        return BedrockForms.sendSimpleForm(player,
                TextPlain.plain(route.displayName) + " — Step " + route.indexOf(step.id) + " of " + route.steps.size(),
                body, buttons, onButton, plugin.getLogger());
    }

    public static String progressLine(Route route, Progress p) {
        switch (p.state) {
            case NOT_STARTED: return TextPlain.plain(route.displayName) + ": not started";
            case COMPLETED: return TextPlain.plain(route.displayName) + ": finished"
                    + (p.completions > 0 ? " (" + p.completions + "x)" : "");
            default:
                Step s = route.stepById(p.currentStepId);
                return TextPlain.plain(route.displayName) + ": Step " + route.indexOf(p.currentStepId)
                        + " of " + route.steps.size() + (s != null ? " — " + TextPlain.plain(s.title) : "");
        }
    }
}
