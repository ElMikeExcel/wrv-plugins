package com.winkreyes.exceltour.core;

/** One route step (DESIGN §2.2). Bukkit-free. */
public final class Step {
    public final String id, title, body, hint;
    public final Trigger trigger;
    public final boolean skippable;

    public Step(String id, String title, String body, String hint, Trigger trigger, boolean skippable) {
        this.id = id; this.title = title; this.body = body; this.hint = hint;
        this.trigger = trigger; this.skippable = skippable;
    }
}
