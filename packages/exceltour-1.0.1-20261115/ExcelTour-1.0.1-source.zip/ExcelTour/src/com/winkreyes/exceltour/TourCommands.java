package com.winkreyes.exceltour;

import com.winkreyes.exceltour.core.Progress;
import com.winkreyes.exceltour.core.ProgressStore;
import com.winkreyes.exceltour.core.Route;
import com.winkreyes.exceltour.core.TextPlain;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** /tour command family (DESIGN §7). */
public final class TourCommands implements CommandExecutor, TabCompleter {
    public static final String USE = "exceltour.use";
    public static final String ADMIN = "exceltour.admin";

    private final ExcelTour plugin;
    public TourCommands(ExcelTour plugin) { this.plugin = plugin; }

    private boolean isAdmin(CommandSender s) {
        return !(s instanceof Player) || s.hasPermission(ADMIN);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player p) openView(p); else usage(sender);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "menu": if (sender instanceof Player p) openView(p); else sender.sendMessage("Console: use /tour status <player>, /tour reset <player>, /tour reload, /tour version."); return true;
            case "version":
                sender.sendMessage("ExcelTour v" + BuildInfo.VERSION + " (build " + BuildInfo.BUILD_ID + ") — routes loaded: "
                        + plugin.engine().routes().keySet());
                return true;
            case "reload": {
                if (!isAdmin(sender)) { deny(sender); return true; }
                plugin.reloadConfig();
                int n = plugin.reloadRoutes();
                sender.sendMessage("ExcelTour reloaded: " + n + " route(s) " + plugin.engine().routes().keySet());
                return true;
            }
            case "start": {
                if (!(sender instanceof Player p)) { sender.sendMessage("Only players can start a tour."); return true; }
                String routeId = args.length >= 2 ? args[1] : (plugin.defaultRoute() == null ? null : plugin.defaultRoute().id);
                if (routeId == null || plugin.engine().route(routeId) == null) {
                    p.sendMessage(Component.text("That tour doesn't exist. Routes: " + plugin.engine().routes().keySet(), NamedTextColor.RED));
                    return true;
                }
                plugin.startRoute(p, routeId);
                return true;
            }
            case "next": if (sender instanceof Player p) plugin.handleTourAction(p, "next"); else sender.sendMessage("Players only."); return true;
            case "skip": if (sender instanceof Player p) plugin.handleTourAction(p, "skip"); else sender.sendMessage("Players only."); return true;
            case "repeat": if (sender instanceof Player p) plugin.handleTourAction(p, "repeat"); else sender.sendMessage("Players only."); return true;
            case "restart": {
                if (!(sender instanceof Player p)) { sender.sendMessage("Players only — use /tour reset <player> from console."); return true; }
                if (args.length < 2 || !"confirm".equalsIgnoreCase(args[1])) {
                    p.sendMessage(Component.text("Restart your tour from Step 1? Run /tour restart confirm to be sure.", NamedTextColor.YELLOW));
                    return true;
                }
                plugin.handleTourAction(p, "restart");
                return true;
            }
            case "status": {
                if (args.length < 2) {
                    if (sender instanceof Player p) sendStatus(sender, p.getUniqueId(), p.getName());
                    else sender.sendMessage("Usage: /tour status <player>");
                    return true;
                }
                if (!isAdmin(sender)) { deny(sender); return true; }
                UUID target = resolvePlayer(args[1]);
                if (target == null) { sender.sendMessage("No saved tour progress found for '" + args[1] + "'."); return true; }
                sendStatus(sender, target, args[1]);
                return true;
            }
            case "reset": {
                if (args.length < 2) {
                    if (!(sender instanceof Player p)) { sender.sendMessage("Usage: /tour reset <player> [route] [full]"); return true; }
                    // Self reset under exceltour.use (§7): all own routes to not-started, completions kept.
                    for (String rid : plugin.engine().routes().keySet()) plugin.engine().reset(p.getUniqueId(), rid, false);
                    plugin.savePlayer(p.getUniqueId(), p.getName());
                    plugin.presentation().clearDisplay(p);
                    p.sendMessage(Component.text("Your tour progress was reset.", NamedTextColor.GOLD));
                    return true;
                }
                if (!isAdmin(sender)) { deny(sender); return true; }
                UUID target = resolvePlayer(args[1]);
                if (target == null) { sender.sendMessage("No saved tour progress found for '" + args[1] + "'."); return true; }
                boolean full = args.length >= 3 && "full".equalsIgnoreCase(args[args.length - 1]);
                String routeArg = args.length >= 3 && !full ? args[2] : (args.length >= 4 ? args[2] : null);
                Player online = Bukkit.getPlayer(target);
                if (online == null) plugin.loadPlayer(target); // make the record editable offline
                if (routeArg != null) {
                    if (plugin.engine().route(routeArg) == null) { sender.sendMessage("Unknown route '" + routeArg + "'. Routes: " + plugin.engine().routes().keySet()); return true; }
                    plugin.engine().reset(target, routeArg, full);
                } else {
                    for (String rid : plugin.engine().routes().keySet()) plugin.engine().reset(target, rid, full);
                }
                String name = online != null ? online.getName() : args[1];
                plugin.savePlayer(target, name);
                if (online != null) {
                    plugin.presentation().clearDisplay(online);
                    online.sendMessage(Component.text("A parent reset your tour progress.", NamedTextColor.GOLD));
                } else {
                    plugin.engine().forgetPlayer(target);
                }
                sender.sendMessage("Reset tour progress for " + name + (routeArg != null ? " (route " + routeArg + ")" : " (all routes)")
                        + (full ? ", including completion counts." : ", completion counts kept."));
                return true;
            }
            default: usage(sender); return true;
        }
    }

    private void openView(Player p) {
        String routeId = plugin.engine().activeRouteId(p.getUniqueId());
        if (routeId != null && plugin.presentation().isBedrock(p)) {
            Route route = plugin.engine().route(routeId);
            com.winkreyes.exceltour.core.Step s = plugin.engine().currentStep(p.getUniqueId(), routeId);
            if (route != null && s != null && plugin.presentation().sendStepForm(p, route, s)) return;
        }
        new TourMenu(plugin, p, false).open();
    }

    private void sendStatus(CommandSender sender, UUID uuid, String displayName) {
        Player online = Bukkit.getPlayer(uuid);
        Map<String, Progress> all;
        if (online != null) {
            all = plugin.engine().allProgress(uuid);
        } else {
            all = plugin.store().load(uuid);
        }
        if (all.isEmpty()) { sender.sendMessage(displayName + " has no tour progress yet."); return; }
        sender.sendMessage("Tour progress for " + displayName + ":");
        for (Route route : plugin.engine().routes().values()) {
            Progress p = all.get(route.id);
            if (p == null) { sender.sendMessage("  " + TextPlain.plain(route.displayName) + ": not started"); continue; }
            StringBuilder sb = new StringBuilder("  ").append(Presentation.progressLine(route, p));
            if (!p.skippedSteps.isEmpty()) sb.append(" — skipped: ").append(p.skippedSteps);
            if (p.updatedAtMillis > 0) sb.append(" — updated ").append(ProgressStore.iso(p.updatedAtMillis));
            sender.sendMessage(sb.toString());
        }
    }

    /** Resolve an online player, a known offline player, or a saved progress file by name. */
    private UUID resolvePlayer(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return online.getUniqueId();
        OfflinePlayer op = Bukkit.getOfflinePlayer(name);
        if (op.hasPlayedBefore()) return op.getUniqueId();
        for (UUID uuid : plugin.store().knownPlayers()) {
            String saved = plugin.store().loadPlayerName(uuid);
            if (saved != null && saved.equalsIgnoreCase(name)) return uuid;
        }
        return null;
    }

    private void deny(CommandSender s) {
        s.sendMessage(Component.text("You need the exceltour.admin permission for that.", NamedTextColor.RED));
    }

    private void usage(CommandSender s) {
        s.sendMessage("Tour commands: /tour (Guide view), /tour start <route>, /tour next, /tour skip, /tour repeat, "
                + "/tour restart, /tour status [player], /tour reset [player], /tour version"
                + (isAdmin(s) ? ", /tour reload" : ""));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String v : List.of("menu", "start", "next", "skip", "repeat", "restart", "status", "reset", "version", "reload"))
                if (v.startsWith(args[0].toLowerCase())) out.add(v);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("start")) {
            for (String id : plugin.engine().routes().keySet()) if (id.startsWith(args[1])) out.add(id);
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("status") || args[0].equalsIgnoreCase("reset"))) {
            for (Player p : Bukkit.getOnlinePlayers()) if (p.getName().toLowerCase().startsWith(args[1].toLowerCase())) out.add(p.getName());
        }
        return out;
    }
}
