package com.winkreyes.exceltour;

/** Version fragments for the in-jar fingerprint gate (house pattern). */
public final class BuildInfo {
    public static final String VERSION = "1.0.1";
    public static final String BUILD_ID = "EXC-TOUR-1.0.1-WRV-20261114-01-bb09";
    public static final String BUILD_TAG = "bb09";
    private BuildInfo() {}
}
