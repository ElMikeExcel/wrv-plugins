package com.winkreyes.excelquartermaster;

/**
 * Names of the Old Quartermaster's recorded tale clips.
 *
 * ExcelQuartermaster plays a per-tale sound,
 * {@code player.playSound(..., "wrv:quartermaster.tale<N>", ...)} with
 * N = tale index + 1. Geyser forwards names it does not know VERBATIM to
 * the Bedrock client (proven for the GuildGate narrator pack against the
 * live Geyser jar: JavaSoundTranslator sends the name as-is on a registry
 * miss), and the Bedrock voice pack
 * (wrv-quartermaster-voice-bedrock.mcpack, in Geyser's packs folder)
 * defines exactly these names in its sound_definitions.json.
 *
 * Since 0.2.1 the same names are ALSO defined for Java clients by the
 * Java voice pack (wrv-quartermaster-voice-java.zip: namespace "wrv",
 * assets/wrv/sounds.json keys quartermaster.tale1..11, the identical
 * recordings), so one name serves both platforms - Mike's parity rule.
 * A client without either pack simply stays silent; the tale text
 * always arrives.
 *
 * No Bukkit dependencies, so the mapping is unit-testable on a plain JVM.
 */
public final class SoundNames {

    /** Config default; clip for tale index i is prefix + (i + 1). */
    public static final String DEFAULT_PREFIX = "wrv:quartermaster.tale";

    /** How many clips both shipped voice packs (Bedrock .mcpack and
     *  Java .zip) carry. */
    public static final int PACK_CLIP_COUNT = 11;

    private SoundNames() {}

    /**
     * The sound name for a tale index, or null when there is nothing
     * sensible to play (blank prefix or negative index). Indexes beyond
     * the pack's clip count still produce a name; the client simply has
     * no definition for it and stays silent, which is the intended
     * fail-soft if an admin ever adds tales beyond the recorded set.
     */
    public static String soundFor(String prefix, int taleIndex) {
        if (prefix == null || prefix.isBlank() || taleIndex < 0) {
            return null;
        }
        return prefix + (taleIndex + 1);
    }

    /** True when the shipped voice pack actually carries a clip for this index. */
    public static boolean hasClip(int taleIndex) {
        return taleIndex >= 0 && taleIndex < PACK_CLIP_COUNT;
    }
}
