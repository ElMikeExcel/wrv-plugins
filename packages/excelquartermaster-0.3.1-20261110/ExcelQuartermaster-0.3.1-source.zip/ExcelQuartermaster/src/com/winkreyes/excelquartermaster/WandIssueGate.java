package com.winkreyes.excelquartermaster;

/**
 * The wand-issue gate (0.3.0): the pure decision matrix that decides
 * what a plain click on the Old Quartermaster means once a seal has
 * fallen. No Bukkit dependencies - the wiring gathers the facts
 * (seal count, Magic's record, the pouch, the issued list) and this
 * class alone decides, so the whole matrix is unit-testable.
 *
 * The doctrine, from the WAND-ISSUE-SPEC and Mike's rulings:
 *
 * - Issue mode exists only when a seal is KNOWN broken (a GuildGate
 *   read that failed or a missing GuildGate is NOT a seal: tales
 *   only, exactly the pre-0.3.0 behavior - never guess).
 * - Magic must be installed: there is no wand to give without it.
 *   (His tales still switch to the Seal 1 set on the seal alone -
 *   see sealOneTales - the valley changed whether or not Magic is
 *   answering today.)
 * - A give requires ALL THREE not-holding legs green at the give
 *   instant: (a) our own issued list has no record, (b) the Utility
 *   Pouch holds no wand (a parked wand is a held wand), (c) Magic's
 *   own bound-wand record is empty. Any leg red is a decline, never
 *   a give: a duplicate bound wand can never be deleted, so the
 *   gate fails closed on every uncertainty.
 * - A record read that FAILED is not an empty record: BLOCKED, no
 *   give, "come back in a little while".
 * - Issued-but-gone is its own verdict: the player was issued a
 *   wand, and neither the pouch nor Magic's record can find one
 *   now. He does NOT re-issue (re-issue is console-only, Mike's
 *   Oct 18 ruling - this flow must never become a restore path);
 *   he points them at the pouch and at Mike or Argus, matching the
 *   Valley Guide's taught wording.
 */
public final class WandIssueGate {

    private WandIssueGate() {}

    /** What one click in seal mode should do. */
    public enum Verdict {
        /** Not issue mode at all: ordinary tales on the active set. */
        NOT_ISSUE_MODE,
        /** All legs green: present the wand offer. */
        OFFER,
        /** The player already holds a wand (any leg proves it). */
        DECLINE_HOLDER,
        /** We issued this player a wand and no record can find it now. */
        DECLINE_GONE,
        /** A verification leg could not answer: no give right now. */
        BLOCKED
    }

    /** Magic's bound-wand record, as read by the wiring. */
    public enum MagicRead {
        HOLDS,
        NONE,
        FAILED
    }

    /**
     * Do his tales come from the Seal 1 set? Keyed on the seal
     * alone: known-broken &ge; 1. An unknown count is the pre-seal
     * set - never guess.
     */
    public static boolean sealOneTales(boolean sealsKnown, int seals) {
        return sealsKnown && seals >= 1;
    }

    /**
     * The gate matrix. Legs are evaluated in a fixed precedence so
     * the verdict (and therefore his line) is always explainable:
     * mode checks first, then the gone case (issued, and provably
     * nothing held anywhere), then any positive holding proof, then
     * the unverifiable case, and only then an offer.
     */
    public static Verdict decide(boolean enabled, boolean sealsKnown, int seals,
                                 boolean magicPresent, boolean issuedListHit,
                                 boolean pouchHolds, MagicRead magicRead) {
        if (!enabled || !sealsKnown || seals < 1 || !magicPresent) {
            return Verdict.NOT_ISSUE_MODE;
        }
        if (magicRead == null) {
            magicRead = MagicRead.FAILED;
        }
        if (issuedListHit && !pouchHolds && magicRead == MagicRead.NONE) {
            return Verdict.DECLINE_GONE;
        }
        if (pouchHolds || magicRead == MagicRead.HOLDS) {
            return Verdict.DECLINE_HOLDER;
        }
        if (magicRead == MagicRead.FAILED) {
            return Verdict.BLOCKED;
        }
        return Verdict.OFFER;
    }
}
