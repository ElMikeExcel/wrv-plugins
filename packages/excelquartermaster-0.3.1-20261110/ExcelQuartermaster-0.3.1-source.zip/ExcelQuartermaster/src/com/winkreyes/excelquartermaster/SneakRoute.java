package com.winkreyes.excelquartermaster;

/**
 * Where a sneak-click on the Old Quartermaster goes (0.2.1) - the
 * Java sneak-trade fix, as a pure decision so the whole matrix is
 * unit-testable on a plain JVM. The Bukkit wiring computes the inputs
 * and carries out the action.
 *
 * The problem, diagnosed Oct 18, 2026 from the Shopkeepers 2.28.0 jar
 * that runs on this server (decompiled, not guessed):
 *
 * - Shopkeepers routes a click on a shopkeeper purely on the sneak
 *   state: AbstractShopkeeper.onPlayerInteraction does
 *   "if (player.isSneaking()) openEditorWindow(player); else
 *   openTradingWindow(player);" - nothing else feeds the choice.
 * - For an admin shop, the editor window's canAccess
 *   (RegularAdminShopEditorViewProvider) requires the shop type's
 *   permission, "shopkeeper.admin". A player without it gets
 *   Messages.noPermission - "You don't have the permission to do
 *   that." - and NOTHING opens. There is no fallback to trading.
 * - So a Java visitor sneak-clicking the Quartermaster (Marvin's
 *   report: "says i don't have permission to do that") hits a wall,
 *   where a Bedrock player's sneak-tap reached the trade window -
 *   Geyser delivers the Bedrock tap without the sneak flag set, so
 *   Shopkeepers saw a plain click and opened trading. Java players
 *   following the same "sneak to trade" habit Bedrock taught them
 *   were punished for it. Parity rule: fix the Java side.
 *
 * The fix: when a sneak-click on the Quartermaster comes from a Java
 * player who could NOT edit him anyway, we open the trading window
 * ourselves through the Shopkeepers API and cancel the event.
 * Shopkeepers explicitly honors a pre-cancelled event (its listener
 * logs "Ignoring already cancelled event." and returns), so its
 * editor attempt - and the denial - never happens.
 *
 * Who is NEVER redirected (PASSTHROUGH, byte-for-byte today's
 * behavior):
 * - Bedrock players: their sneak path already works; do not touch it.
 * - Anyone who can edit (holder of "shopkeeper.admin", the exact node
 *   the editor checks, or "shopkeeper.bypass"): their sneak must keep
 *   reaching the editor, owners and admins included.
 * - Everyone, when the Shopkeepers trade redirect is unavailable (the
 *   plugin or its API unreachable): fall back to the status quo rather
 *   than swallowing the click into a worse dead end.
 *
 * OPEN_TRADING vs CANCEL_ONLY: one physical right-click on an entity
 * surfaces as TWO Bukkit events (PlayerInteractEntityEvent and its
 * subclass PlayerInteractAtEntityEvent). The first opens the trade
 * window; the twin, arriving within the debounce window, must still
 * be cancelled - or Shopkeepers would run its editor attempt on it
 * and print the denial over the open window - but must not reopen
 * the window. Genuine later clicks (past the window) open trading
 * again.
 */
public final class SneakRoute {

    /** Permissions that mark a player as able to edit the
     *  Quartermaster: the admin-shop editor's own node, plus
     *  Shopkeepers' bypass node. Conservative on purpose - a holder
     *  of either is never redirected. */
    public static final String[] EDIT_PERMISSIONS = {"shopkeeper.admin", "shopkeeper.bypass"};

    /** How long after a redirect the twin event of the same click is
     *  still recognised (and cancelled without reopening). */
    public static final long DEFAULT_DEBOUNCE_MILLIS = 500L;

    /** What the listener should do with one matched sneak-click. */
    public enum Action {
        /** Leave the event entirely alone (Shopkeepers decides). */
        PASSTHROUGH,
        /** Open the trading window via the API and cancel the event. */
        OPEN_TRADING,
        /** Cancel the event but do not reopen (the twin event). */
        CANCEL_ONLY
    }

    private SneakRoute() {}

    /**
     * @param bedrock                the player is on Bedrock (Geyser)
     * @param canEdit                the player holds an edit permission
     * @param redirectAvailable      the Shopkeepers API trade redirect
     *                               is reachable right now
     * @param millisSinceLastRedirect ms since this player's last
     *                               redirect, or negative if never
     * @param debounceMillis         the twin-event window
     */
    public static Action decide(boolean bedrock, boolean canEdit, boolean redirectAvailable,
                                long millisSinceLastRedirect, long debounceMillis) {
        if (bedrock || canEdit || !redirectAvailable) {
            return Action.PASSTHROUGH;
        }
        if (millisSinceLastRedirect >= 0
                && millisSinceLastRedirect < Math.max(0L, debounceMillis)) {
            return Action.CANCEL_ONLY;
        }
        return Action.OPEN_TRADING;
    }
}
