package com.winkreyes.excelquartermaster;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

/**
 * Persistence for the issued-wand ledger: a tiny line-based text
 * format in the TaleStore tradition, one issuance per line:
 *
 *   &lt;uuid&gt; &lt;issuedMillis&gt; &lt;template&gt; &lt;name...&gt;
 *
 * The name comes LAST so Bedrock gamertags with spaces survive the
 * round trip. Serialization is sorted by UUID string, so the file
 * is stable and diff-friendly, and it carries a comment header
 * explaining itself to a human reading it at the panel - this file
 * replaced a paper list, and it should read like one. Parsing is
 * forgiving: blank lines, comments (#), and malformed lines are
 * skipped, and on a duplicate UUID the FIRST record stands (the
 * ledger never rewrites its own history).
 */
public final class IssuedWandStore {

    private IssuedWandStore() {}

    static final String HEADER = """
            # ExcelQuartermaster issued wands - the Old Quartermaster's ledger.
            # One line per player he has handed a first wand to:
            #   <uuid> <issuedMillis> <template> <name...>
            # This list is how he knows a wand was already issued. Re-issue is
            # a manual, console-only decision (Mike or Argus) - never delete a
            # line to make him hand out a second wand.
            """;

    /** Serialize records to the on-disk text form. */
    public static String serialize(Map<UUID, IssuedWands.Entry> records) {
        StringBuilder out = new StringBuilder(HEADER);
        if (records == null || records.isEmpty()) {
            return out.toString();
        }
        TreeMap<String, IssuedWands.Entry> sorted = new TreeMap<>();
        for (Map.Entry<UUID, IssuedWands.Entry> e : records.entrySet()) {
            if (e.getKey() != null && e.getValue() != null) {
                sorted.put(e.getKey().toString(), e.getValue());
            }
        }
        for (Map.Entry<String, IssuedWands.Entry> e : sorted.entrySet()) {
            IssuedWands.Entry entry = e.getValue();
            out.append(e.getKey()).append(' ')
               .append(Math.max(0L, entry.issuedMillis())).append(' ')
               .append(IssuedWands.sanitizeTemplate(entry.template()));
            String name = IssuedWands.sanitizeName(entry.name());
            if (!name.isEmpty()) {
                out.append(' ').append(name);
            }
            out.append('\n');
        }
        return out.toString();
    }

    /** Parse the on-disk text form. Never throws on bad content. */
    public static Map<UUID, IssuedWands.Entry> parse(String text) {
        Map<UUID, IssuedWands.Entry> out = new LinkedHashMap<>();
        if (text == null || text.isBlank()) {
            return out;
        }
        for (String line : text.split("\\R")) {
            String trimmed = line.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("#")) {
                continue;
            }
            String[] parts = trimmed.split("\\s+", 4);
            if (parts.length < 3) {
                continue;
            }
            try {
                UUID id = UUID.fromString(parts[0]);
                long millis = Long.parseLong(parts[1]);
                String template = parts[2];
                String name = parts.length == 4 ? parts[3] : "";
                out.putIfAbsent(id, new IssuedWands.Entry(
                        IssuedWands.sanitizeName(name),
                        Math.max(0L, millis),
                        IssuedWands.sanitizeTemplate(template)));
            } catch (IllegalArgumentException badLine) {
                // Skip the malformed line; one bad record must not lose the rest.
            }
        }
        return out;
    }

    /** Load records from a file; a missing file reads as an empty map. */
    public static Map<UUID, IssuedWands.Entry> load(Path file) throws IOException {
        if (file == null || !Files.exists(file)) {
            return new LinkedHashMap<>();
        }
        return parse(Files.readString(file, StandardCharsets.UTF_8));
    }

    /** Save records to a file, creating parent folders as needed. */
    public static void save(Path file, Map<UUID, IssuedWands.Entry> records) throws IOException {
        if (file == null) {
            return;
        }
        Path parent = file.getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }
        Files.writeString(file, serialize(records), StandardCharsets.UTF_8);
    }
}
