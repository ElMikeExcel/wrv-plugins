package com.winkreyes.excelquartermaster;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * The Bedrock dialogue session rules behind ExcelQuartermaster 0.2.0.
 *
 * On Bedrock, a tale is presented as a dialogue-style form (his name as
 * the title, the tale as the body, "Another tale" / "Farewell" buttons).
 * One player has at most ONE live session. Every session carries a
 * generation number: opening a new dialogue (a fresh tap on the old man)
 * supersedes the old one, and any late callback from a superseded form
 * is recognized by its stale generation and ignored, so an old form can
 * never advance or close a newer conversation.
 *
 * Timing rules (the design call, made for 0.2.0 and documented in the
 * README): the interact cooldown from 0.1.0 gates NEW taps on the
 * villager, unchanged. Inside an open dialogue, "Another tale" may
 * advance right away - the player is mid-conversation, not re-tapping -
 * subject only to a short anti-spam floor between advances. Every
 * advance re-stamps the rotation clock (via TaleRotation.commitTold),
 * so closing the dialogue and tapping him again within the interact
 * cooldown of the last tale heard stays silent, exactly the 0.1.0 feel.
 *
 * No Bukkit dependencies, so the whole rule set is unit-testable.
 */
public final class DialogueFlow {

    /** Which presentation a tell should use. */
    public enum Presentation {
        /** Dialogue form (Bedrock only). */
        DIALOGUE,
        /** Plain chat lines (Java, and every fail-soft path). */
        CHAT
    }

    /** Result of an "Another tale" press inside a dialogue. */
    public enum Advance {
        /** The dialogue advanced to the supplied tale index. */
        ADVANCED,
        /** Too soon after the previous tale in this dialogue; stay put. */
        TOO_FAST,
        /** No live session for that generation (closed or superseded). */
        NO_SESSION
    }

    /**
     * One open dialogue.
     *
     * @param generation        unique per open; callbacks must match it
     * @param taleIndex         the tale currently on screen
     * @param lastAdvanceMillis when the current tale was presented
     */
    public record Session(int generation, int taleIndex, long lastAdvanceMillis) {}

    private final Map<UUID, Session> sessions = new HashMap<>();
    private int generationCounter = 0;

    /**
     * The presentation decision, kept pure so every input combination is
     * testable: dialogue only for a Bedrock player, with the feature on,
     * and the form channel available. Anything else is chat.
     */
    public static Presentation choose(boolean bedrockPlayer, boolean dialogueEnabled,
                                      boolean formsAvailable) {
        return bedrockPlayer && dialogueEnabled && formsAvailable
                ? Presentation.DIALOGUE
                : Presentation.CHAT;
    }

    /** Open a session for a player, superseding any previous one. */
    public synchronized Session open(UUID playerId, int taleIndex, long nowMillis) {
        Session session = new Session(++generationCounter, taleIndex, nowMillis);
        if (playerId != null) {
            sessions.put(playerId, session);
        }
        return session;
    }

    /** The player's live session, or null. */
    public synchronized Session session(UUID playerId) {
        return playerId == null ? null : sessions.get(playerId);
    }

    /** True when a callback's generation is the player's live session. */
    public synchronized boolean isCurrent(UUID playerId, int generation) {
        Session s = session(playerId);
        return s != null && s.generation() == generation;
    }

    /**
     * An "Another tale" press: advance the session to {@code newTaleIndex}
     * when the generation is live and the anti-spam floor has passed.
     * Mutates only on ADVANCED.
     */
    public synchronized Advance advance(UUID playerId, int generation, int newTaleIndex,
                                        long nowMillis, long minIntervalMillis) {
        Session s = session(playerId);
        if (s == null || s.generation() != generation) {
            return Advance.NO_SESSION;
        }
        if (minIntervalMillis > 0 && nowMillis - s.lastAdvanceMillis() < minIntervalMillis) {
            return Advance.TOO_FAST;
        }
        sessions.put(playerId, new Session(generation, newTaleIndex, nowMillis));
        return Advance.ADVANCED;
    }

    /** Close the session, but only if the generation is still the live one. */
    public synchronized void close(UUID playerId, int generation) {
        if (isCurrent(playerId, generation)) {
            sessions.remove(playerId);
        }
    }

    /** Forget any session for a player (quit, disable). */
    public synchronized void drop(UUID playerId) {
        if (playerId != null) {
            sessions.remove(playerId);
        }
    }

    /** How many dialogues are open right now. */
    public synchronized int activeCount() {
        return sessions.size();
    }
}
