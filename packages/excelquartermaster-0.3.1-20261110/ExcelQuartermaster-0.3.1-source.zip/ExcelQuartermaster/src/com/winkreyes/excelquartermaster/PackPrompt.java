package com.winkreyes.excelquartermaster;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Who has been offered the Java voice pack, and what happened - the
 * offer discipline behind the Quartermaster's Java voice.
 *
 * No Bukkit dependencies: the whole state machine is unit-testable on
 * a plain JVM. The Bukkit wiring calls {@link #decide} on join, hands
 * the pack to the player when it says SEND, and reports the outcome
 * back through {@link #applySend} / {@link #applyStatus}. Records are
 * persisted by PackStateStore in the same line style as TaleStore.
 *
 * THE RULE (Mike, Oct 19, 2026 - supersedes the 0.2.1 discipline):
 * players tap-spam prompts without reading them, so three lifetime
 * offers was too few and a 30-day reset cycle was the wrong shape.
 * Every player now gets FIVE chances to accept the pack:
 *
 * - An OFFER is one send to a player who has not accepted. Offers
 *   are counted by {@link #applySend} - never by status events, so
 *   the cap cannot be dodged or tripped by client chatter - and the
 *   count persists across restarts, rejoins and reloads in
 *   java-pack-state.txt.
 * - Never heard of the player: offer #1.
 * - SENT (no outcome yet), DECLINED, FAILED: offer again on a later
 *   join while total offers stay under {@link #MAX_OFFERS}. A
 *   decline costs one chance, not all of them - but there is no
 *   clock that ever gives a chance back. No 30-day window, no reset.
 * - The fifth offer is the last: a player who has used all five
 *   without accepting is never offered the pack again, ever.
 * - LOADED (accepted): never offered again, ever. The pack is still
 *   RE-SENT silently on later joins - a resource pack only exists
 *   for the session it is sent in, so without the re-send there is
 *   no voice at all - but a client that already accepted applies it
 *   without showing any prompt, and the wiring does not count the
 *   re-send as an offer. An accept is terminal: the offer count
 *   freezes where it was.
 *
 * MIGRATION from 0.2.1: the persisted format already stores the send
 * count ("attempts"), so no format change is needed and every offer
 * recorded under 0.2.1 counts toward the five - a player recorded at
 * 3 has exactly 2 chances left, and a player who accepted under
 * 0.2.1 (LOADED, whatever the count) stays done.
 *
 * ESCAPE HATCH: the five are a discipline, not a life sentence -
 * an admin can wipe a record with {@code /qm packreset} (see
 * PackReset), which is the ONLY way a used-up count comes back.
 */
public final class PackPrompt {

    /** Mike's rule (Oct 19, 2026): five chances, then never again. */
    public static final int MAX_OFFERS = 5;

    /** The last known outcome for one player. */
    public enum Outcome {
        SENT, LOADED, DECLINED, FAILED
    }

    /**
     * @param outcome          last known outcome
     * @param attempts         total pack offers so far (never negative;
     *                         silent re-sends to an accepted player are
     *                         not counted)
     * @param lastChangeMillis when the outcome last changed (or the
     *                         last offer, for SENT)
     */
    public record Record(Outcome outcome, int attempts, long lastChangeMillis) {}

    /** What the join wiring should do for one player. */
    public enum Action {
        SEND, SKIP
    }

    private final Map<UUID, Record> players = new LinkedHashMap<>();

    /** A player's record, or null if they have never been offered the pack. */
    public synchronized Record record(UUID playerId) {
        return playerId == null ? null : players.get(playerId);
    }

    /** How many players carry a pack record. */
    public synchronized int trackedCount() {
        return players.size();
    }

    /** Snapshot of every record. */
    public synchronized Map<UUID, Record> snapshot() {
        return new LinkedHashMap<>(players);
    }

    /**
     * Forget one player entirely - the admin reset behind
     * {@code /qm packreset} (see PackReset). Count and exhausted
     * flag are the record itself, so removing it zeroes both;
     * returns true when a record was actually removed. Whether an
     * accepted player may be reset at all is the caller's policy
     * (PackReset says no), not this class's.
     */
    public synchronized boolean reset(UUID playerId) {
        return playerId != null && players.remove(playerId) != null;
    }

    /**
     * Forget every player who has NOT accepted - the {@code all}
     * half of the admin reset. Accepted records are kept exactly as
     * they are. Returns how many records were removed.
     */
    public synchronized int resetAllNonAccepted() {
        int before = players.size();
        players.values().removeIf(r -> r.outcome() != Outcome.LOADED);
        return before - players.size();
    }

    /** Restore persisted records. Null keys/values are skipped;
     *  attempts and timestamps clamp at 0. */
    public synchronized void restore(Map<UUID, Record> records) {
        players.clear();
        if (records != null) {
            for (Map.Entry<UUID, Record> e : records.entrySet()) {
                if (e.getKey() != null && e.getValue() != null && e.getValue().outcome() != null) {
                    players.put(e.getKey(), new Record(e.getValue().outcome(),
                            Math.max(0, e.getValue().attempts()),
                            Math.max(0L, e.getValue().lastChangeMillis())));
                }
            }
        }
    }

    /**
     * Record that one OFFER was just sent to this player. The wiring
     * calls this only for offers - never for the silent re-send to a
     * player who already accepted (see {@link #isAccepted}) - so the
     * attempts count IS the offer count, under 0.2.1 and 0.2.2 alike.
     */
    public synchronized Record applySend(UUID playerId, long nowMillis) {
        if (playerId == null) {
            return null;
        }
        Record prev = players.get(playerId);
        Record next = new Record(Outcome.SENT,
                (prev == null ? 0 : prev.attempts()) + 1, nowMillis);
        players.put(playerId, next);
        return next;
    }

    /**
     * Fold one client status into the record. Returns true when the
     * record changed (so the caller persists). IGNORED statuses and
     * null players never change anything. The offer count is carried
     * through untouched: statuses never mint or burn chances.
     */
    public synchronized boolean applyStatus(UUID playerId, JavaPack.Status status,
                                            long nowMillis) {
        if (playerId == null || status == null || status == JavaPack.Status.IGNORED) {
            return false;
        }
        Outcome outcome = switch (status) {
            case LOADED -> Outcome.LOADED;
            case DECLINED -> Outcome.DECLINED;
            case FAILED -> Outcome.FAILED;
            case IGNORED -> null; // unreachable; guarded above
        };
        if (outcome == null) {
            return false;
        }
        Record prev = players.get(playerId);
        Record next = new Record(outcome, prev == null ? 0 : prev.attempts(), nowMillis);
        if (next.equals(prev)) {
            return false;
        }
        players.put(playerId, next);
        return true;
    }

    /**
     * The join decision. Pure: same record, same answer, no state
     * read or written, and - unlike the 0.2.1 discipline - no clock:
     * time never gives a chance back and never takes one away.
     *
     * SEND for a LOADED record means "re-send silently" (the client
     * shows no prompt); the wiring tells the two SENDs apart with
     * {@link #isAccepted} and only counts and captions real offers.
     */
    public static Action decide(Record record) {
        if (record == null) {
            return Action.SEND;
        }
        return switch (record.outcome()) {
            case LOADED -> Action.SEND;
            case SENT, DECLINED, FAILED ->
                    record.attempts() < MAX_OFFERS ? Action.SEND : Action.SKIP;
        };
    }

    /** True once the player has accepted the pack. Terminal: an
     *  accepted player is never offered it again. */
    public static boolean isAccepted(Record record) {
        return record != null && record.outcome() == Outcome.LOADED;
    }

    /** Offers used so far (0 for a player with no record). */
    public static int offersUsed(Record record) {
        return record == null ? 0 : Math.max(0, record.attempts());
    }

    /**
     * Chances left: {@link #MAX_OFFERS} for a brand-new player,
     * counting down with each offer, 0 once all five are used - and
     * 0 for an accepted player, who needs no more chances.
     */
    public static int offersRemaining(Record record) {
        if (isAccepted(record)) {
            return 0;
        }
        return Math.max(0, MAX_OFFERS - offersUsed(record));
    }

    /**
     * The counter the next offer will carry ("offer N of 5"): one
     * past the offers already used. Only meaningful when
     * {@link #decide} says SEND for a player who has not accepted.
     */
    public static int nextOfferNumber(Record record) {
        return offersUsed(record) + 1;
    }
}
