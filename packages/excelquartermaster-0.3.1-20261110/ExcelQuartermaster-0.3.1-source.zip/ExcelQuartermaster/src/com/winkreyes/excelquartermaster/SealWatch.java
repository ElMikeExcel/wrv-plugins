package com.winkreyes.excelquartermaster;

import java.lang.reflect.Method;
import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

/**
 * The broken-seal read (0.3.0): how many seals ExcelGuildGate
 * currently counts as broken, via its public API, reflectively -
 * the exact pattern ExcelMagicGate established, so this plugin keeps
 * no compile-time or load-time dependency on GuildGate.
 *
 * Returns null when the count is UNAVAILABLE (GuildGate missing,
 * disabled, API not yet bound, or a read error): the caller treats
 * null as "no seal knowledge", which the gate reads as tales only,
 * never as a guessed zero and never as a guessed one. The cached
 * reflective method clears itself on failure so a GuildGate reload
 * re-resolves cleanly.
 */
final class SealWatch {

    private SealWatch() {}

    private static Method cachedCountMethod;

    /** The broken-seal count, or null when it cannot be known right now. */
    static Integer sealsBroken(Logger log) {
        try {
            Plugin guildGate = Bukkit.getPluginManager().getPlugin("ExcelGuildGate");
            if (guildGate == null || !guildGate.isEnabled()) {
                return null;
            }
            Method method = cachedCountMethod;
            if (method == null) {
                Class<?> api = Class.forName("com.winkreyes.guildgate.api.GuildGateAPI",
                        true, guildGate.getClass().getClassLoader());
                method = api.getMethod("sealsBrokenCount");
                cachedCountMethod = method;
            }
            Object result = method.invoke(null);
            return result instanceof Integer count ? count : null;
        } catch (Exception e) {
            cachedCountMethod = null;
            log.warning("SealWatch: seal count unavailable ("
                    + e.getClass().getSimpleName() + ": " + e.getMessage()
                    + "); the Quartermaster tells pre-seal tales until it answers.");
            return null;
        }
    }
}
