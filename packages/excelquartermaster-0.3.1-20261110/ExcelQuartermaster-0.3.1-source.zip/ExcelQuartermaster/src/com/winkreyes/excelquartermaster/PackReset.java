package com.winkreyes.excelquartermaster;

import java.util.Map;
import java.util.UUID;

/**
 * The manual escape hatch for the five-chances rule (Mike's
 * follow-up, Oct 19, 2026: "Can we manually reset if needed?"):
 * {@code /qm packreset <player|all>}, behind the
 * {@code excelquartermaster.admin} permission, console included.
 *
 * Semantics:
 * - Resetting a player DELETES their pack record - count and
 *   exhausted flag together, including counts migrated from 0.2.1 -
 *   so their next join starts again at "offer 1 of 5".
 * - A player who already ACCEPTED (LOADED) is left untouched: they
 *   have the pack, there is nothing to reset, and the command says
 *   so. The same holds for {@code all}: every non-accepted record
 *   is cleared and the reply reports how many were reset and how
 *   many accepted players were left alone.
 * - A name or UUID with no record is "nothing to reset", not an
 *   error - a player who was never offered has nothing recorded.
 *
 * No Bukkit dependencies: the decisions, the counts and the exact
 * reply texts live here and are unit-tested on a plain JVM; the
 * plugin class only resolves names and delivers the messages.
 */
public final class PackReset {

    /** What one single-player reset did. */
    public enum Single {
        /** A non-accepted record existed and was cleared. */
        RESET,
        /** The player already has the pack; record left untouched. */
        ALREADY_HAS_PACK,
        /** No record at all; there was nothing to clear. */
        NOTHING_TO_RESET
    }

    /** The tally of an {@code all} reset. */
    public record AllResult(int resetCount, int acceptedKept) {}

    private PackReset() {}

    /**
     * Reset one player in the given prompt state. Returns what
     * happened; a RESET mutates the PackPrompt (the caller persists).
     */
    public static Single resetOne(PackPrompt prompt, UUID playerId) {
        if (prompt == null || playerId == null) {
            return Single.NOTHING_TO_RESET;
        }
        PackPrompt.Record record = prompt.record(playerId);
        if (record == null) {
            return Single.NOTHING_TO_RESET;
        }
        if (PackPrompt.isAccepted(record)) {
            return Single.ALREADY_HAS_PACK;
        }
        prompt.reset(playerId);
        return Single.RESET;
    }

    /** Reset every non-accepted player; accepted players are kept. */
    public static AllResult resetAll(PackPrompt prompt) {
        if (prompt == null) {
            return new AllResult(0, 0);
        }
        int kept = 0;
        for (Map.Entry<UUID, PackPrompt.Record> e : prompt.snapshot().entrySet()) {
            if (PackPrompt.isAccepted(e.getValue())) {
                kept++;
            }
        }
        int reset = prompt.resetAllNonAccepted();
        return new AllResult(reset, kept);
    }

    /** The one-line reply for a single-player reset. */
    public static String messageFor(Single result, String displayName) {
        String who = (displayName == null || displayName.isBlank()) ? "that player" : displayName;
        return switch (result) {
            case RESET -> "Voice-pack offers reset for " + who
                    + ": their next join starts again at offer 1 of "
                    + PackPrompt.MAX_OFFERS + ".";
            case ALREADY_HAS_PACK -> who + " already has the voice pack "
                    + "- nothing to reset.";
            case NOTHING_TO_RESET -> "Nothing to reset for " + who
                    + ": no voice-pack offers are on record.";
        };
    }

    /** The one-line reply for an {@code all} reset. */
    public static String messageForAll(AllResult result) {
        return "Voice-pack offers reset for " + result.resetCount() + " player(s); "
                + result.acceptedKept() + " player(s) already have the pack "
                + "and were left untouched.";
    }

    /** Usage line for a bare or malformed /qm invocation. */
    public static final String USAGE = "Usage: /qm packreset <player|all>";
}
