package com.winkreyes.excelquartermaster;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * The issued-wand ledger (0.3.0): which players the Old
 * Quartermaster has personally handed a first wand to. This is leg
 * (a) of the wand-issue gate and the automation's half of the
 * paper issued list the WAND-ISSUE-SPEC ran by hand - the record
 * that makes "exactly once per player" survive restarts.
 *
 * The ledger is append-only truth: a player is recorded at the give
 * instant (after the console give is dispatched AND Magic's own
 * record confirms the wand landed - see the wiring), and a record
 * is never removed by the plugin. Re-issue is a human, console-only
 * decision (Mike's Oct 18 ruling), so there is deliberately no
 * erase path here.
 *
 * No Bukkit dependencies; persistence lives in IssuedWandStore.
 */
public final class IssuedWands {

    /** One issuance: who, when, and which wand template was given. */
    public record Entry(String name, long issuedMillis, String template) {}

    private final Map<UUID, Entry> entries = new LinkedHashMap<>();

    public boolean isIssued(UUID id) {
        return id != null && entries.containsKey(id);
    }

    public Entry entry(UUID id) {
        return id == null ? null : entries.get(id);
    }

    /**
     * Record a first issuance.
     *
     * @return true when this call wrote a NEW record; false when
     *         the player was already recorded (the first record
     *         stands - the ledger never rewrites its own history)
     */
    public boolean record(UUID id, String name, long issuedMillis, String template) {
        if (id == null || entries.containsKey(id)) {
            return false;
        }
        entries.put(id, new Entry(sanitizeName(name),
                Math.max(0L, issuedMillis), sanitizeTemplate(template)));
        return true;
    }

    public int size() {
        return entries.size();
    }

    /** A defensive copy for the store. */
    public Map<UUID, Entry> snapshot() {
        return new LinkedHashMap<>(entries);
    }

    /** Replace the contents with a loaded map (startup). */
    public void restore(Map<UUID, Entry> loaded) {
        entries.clear();
        if (loaded != null) {
            for (Map.Entry<UUID, Entry> e : loaded.entrySet()) {
                if (e.getKey() != null && e.getValue() != null) {
                    entries.put(e.getKey(), e.getValue());
                }
            }
        }
    }

    /**
     * Names ride at the END of the ledger line so they may contain
     * spaces (Bedrock gamertags can); the one thing they may not
     * contain is a line break or a run of whitespace that would
     * blur the field boundary.
     */
    static String sanitizeName(String name) {
        if (name == null) {
            return "";
        }
        return name.trim().replaceAll("\\s+", " ");
    }

    static String sanitizeTemplate(String template) {
        if (template == null || template.isBlank()) {
            return "beginner";
        }
        return template.trim().replaceAll("\\s+", "_");
    }
}
