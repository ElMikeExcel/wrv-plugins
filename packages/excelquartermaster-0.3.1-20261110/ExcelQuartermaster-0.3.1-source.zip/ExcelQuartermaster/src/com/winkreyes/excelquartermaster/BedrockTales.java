package com.winkreyes.excelquartermaster;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/**
 * Bedrock dialogue wiring for ExcelQuartermaster 0.2.0.
 *
 * Everything here is reflection against Geyser's OWN classloader - the
 * same proven pattern as ExcelBedrockMenu's GeyserForms - so this plugin
 * defines no Geyser/Cumulus types itself, has no compile-time dependency
 * on either, and degrades to "not Bedrock / forms unavailable" (the
 * caller then falls back to the 0.1.0 chat tale) whenever anything is
 * missing or throws. A form failure can never become a dead tap.
 *
 * About the presentation: Cumulus - the forms API Geyser and Floodgate
 * ship, and the only form channel a Bukkit plugin can reach on this
 * server - has exactly three form types (SimpleForm, ModalForm,
 * CustomForm); the deployed floodgate and Geyser jars were inspected
 * and contain no DialogForm, and the Bedrock client's native NPC
 * dialogue (NpcDialoguePacket) belongs to real Bedrock NPC entities,
 * which a Java villager translated by Geyser is not. So the dialogue
 * presentation here is a SimpleForm styled as a conversation: his name
 * as the title, the tale as the body, "Another tale" and "Farewell"
 * as the buttons. That is the strongest dialogue a plugin can honestly
 * give him on this stack; it is not faked NPC dialogue and the build
 * record says so.
 */
final class BedrockTales {

    private BedrockTales() {}

    /** True if the Geyser plugin is present and enabled (form channel exists). */
    static boolean formsAvailable() {
        Plugin geyser = Bukkit.getPluginManager().getPlugin("Geyser-Spigot");
        return geyser != null && geyser.isEnabled();
    }

    /** True if the player is connected via Geyser (Bedrock). Never throws. */
    static boolean isBedrockPlayer(Player player, Logger log) {
        return Boolean.TRUE.equals(bedrockOrNull(player, log));
    }

    /**
     * Tri-state platform detection for callers where "unknown" must
     * not be treated as "Java" (0.2.1's Java pack offer: sending a
     * Java resource pack at a Bedrock client whose platform check
     * merely glitched would be worse than not sending). Returns
     * Boolean.TRUE for Bedrock, Boolean.FALSE for a confirmed Java
     * player, and null when the platform cannot be determined.
     * Note the asymmetry: when Geyser is absent entirely nobody can
     * be on Bedrock, so every player is confirmed Java (FALSE).
     */
    static Boolean bedrockOrNull(Player player, Logger log) {
        try {
            Plugin geyser = Bukkit.getPluginManager().getPlugin("Geyser-Spigot");
            if (geyser == null || !geyser.isEnabled()) {
                return Boolean.FALSE;
            }
            ClassLoader loader = geyser.getClass().getClassLoader();
            Class<?> apiClass = Class.forName("org.geysermc.geyser.api.GeyserApi", true, loader);
            Object api = apiClass.getMethod("api").invoke(null);
            Object result = apiClass.getMethod("isBedrockPlayer", UUID.class)
                    .invoke(api, player.getUniqueId());
            if (result instanceof Boolean b) {
                return b;
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Send the dialogue form. {@code onButton} receives 0 for the first
     * button ("Another tale") and 1 for the second ("Farewell");
     * {@code onClosed} runs when the player dismisses the form without
     * pressing a button (or the form result is invalid). Handlers are
     * invoked on whatever thread Geyser uses; the caller re-dispatches
     * to the main thread before touching game state. Returns true only
     * when the form was actually sent.
     */
    static boolean sendDialogueForm(Player player, String title, String content,
                                    String nextButton, String closeButton,
                                    IntConsumer onButton, Runnable onClosed, Logger log) {
        String step = "start";
        try {
            if (!formsAvailable()) {
                return false;
            }
            Plugin geyserPlugin = Bukkit.getPluginManager().getPlugin("Geyser-Spigot");
            ClassLoader loader = geyserPlugin.getClass().getClassLoader();
            UUID uuid = player.getUniqueId();

            step = "GeyserApi.api()";
            Class<?> apiClass = Class.forName("org.geysermc.geyser.api.GeyserApi", true, loader);
            Object api = apiClass.getMethod("api").invoke(null);

            step = "connectionByUuid";
            Object connection = apiClass.getMethod("connectionByUuid", UUID.class).invoke(api, uuid);
            if (connection == null) {
                return false;
            }

            step = "SimpleForm.builder()";
            Class<?> formClass = Class.forName("org.geysermc.cumulus.form.SimpleForm", true, loader);
            Object builder = formClass.getMethod("builder").invoke(null);
            Class<?> builderClass = builder.getClass();

            step = "title/content/buttons";
            builderClass.getMethod("title", String.class).invoke(builder, title);
            builderClass.getMethod("content", String.class).invoke(builder, content);
            Method buttonMethod = builderClass.getMethod("button", String.class);
            buttonMethod.invoke(builder, nextButton);
            buttonMethod.invoke(builder, closeButton);

            step = "validResultHandler";
            Class<?> responseClass = Class.forName(
                    "org.geysermc.cumulus.response.SimpleFormResponse", true, loader);
            Class<?> biConsumerClass = Class.forName("java.util.function.BiConsumer", true, loader);
            Object validHandler = Proxy.newProxyInstance(loader,
                    new Class<?>[]{biConsumerClass},
                    (proxy, method, methodArgs) -> {
                        if (method.getName().equals("accept") && methodArgs != null
                                && methodArgs.length == 2 && methodArgs[1] != null) {
                            int id = (int) responseClass.getMethod("clickedButtonId")
                                    .invoke(methodArgs[1]);
                            onButton.accept(id);
                        }
                        return null;
                    });
            Method vrh = findHandler(builderClass, "validResultHandler", validHandler);
            if (vrh == null) {
                log.warning("BedrockTales: no compatible validResultHandler (SimpleForm)");
                return false;
            }
            vrh.invoke(builder, validHandler);

            step = "closed/invalid handlers";
            wireTerminalHandler(builder, builderClass, loader, "closedResultHandler", onClosed, log);
            wireTerminalHandler(builder, builderClass, loader, "invalidResultHandler", onClosed, log);

            step = "build+send";
            Object form = builderClass.getMethod("build").invoke(builder);
            Method sendForm = findSendForm(connection.getClass(), form.getClass());
            if (sendForm == null) {
                log.warning("BedrockTales: no compatible sendForm (SimpleForm)");
                return false;
            }
            return (boolean) sendForm.invoke(connection, form);
        } catch (Exception e) {
            log.warning("BedrockTales dialogue form '" + title + "' failed at [" + step + "]: "
                    + e.getClass().getSimpleName() + ": " + e.getMessage());
            return false;
        }
    }

    /**
     * Wire a no-result terminal handler (closed / invalid) when the
     * deployed Cumulus offers one. Absence is not an error: the session
     * then ends by supersession, Farewell, or quit instead, and the
     * generation checks keep stale callbacks harmless.
     */
    private static void wireTerminalHandler(Object builder, Class<?> builderClass,
                                            ClassLoader loader, String name,
                                            Runnable onClosed, Logger log) {
        try {
            for (Method m : builderClass.getMethods()) {
                if (!m.getName().equals(name) || m.getParameterCount() != 1) {
                    continue;
                }
                Class<?> pt = m.getParameterTypes()[0];
                if (!pt.isInterface()) {
                    continue;
                }
                Object handler = Proxy.newProxyInstance(loader, new Class<?>[]{pt},
                        (proxy, method, methodArgs) -> {
                            if (method.getName().equals("accept")) {
                                onClosed.run();
                            }
                            return null;
                        });
                if (pt.isAssignableFrom(handler.getClass())) {
                    m.invoke(builder, handler);
                    return;
                }
                // Consumer-shaped parameter but the proxy check above
                // should already have matched; try a plain Consumer too.
                if (pt.isAssignableFrom(Consumer.class)) {
                    m.invoke(builder, (Consumer<Object>) ignored -> onClosed.run());
                    return;
                }
            }
        } catch (Exception e) {
            log.fine("BedrockTales: " + name + " not wired: " + e.getMessage());
        }
    }

    private static Method findHandler(Class<?> builderClass, String name, Object handler) {
        for (Method m : builderClass.getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == 1) {
                Class<?> pt = m.getParameterTypes()[0];
                if (pt.isAssignableFrom(handler.getClass())) {
                    return m;
                }
            }
        }
        return null;
    }

    private static Method findSendForm(Class<?> connectionClass, Class<?> formClass) {
        for (Method m : connectionClass.getMethods()) {
            if (m.getName().equals("sendForm") && m.getParameterCount() == 1) {
                Class<?> pt = m.getParameterTypes()[0];
                if (pt.isAssignableFrom(formClass)) {
                    return m;
                }
            }
        }
        return null;
    }
}
