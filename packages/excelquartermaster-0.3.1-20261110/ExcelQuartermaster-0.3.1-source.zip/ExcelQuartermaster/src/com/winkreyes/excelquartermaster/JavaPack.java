package com.winkreyes.excelquartermaster;

import java.util.UUID;

/**
 * The Old Quartermaster's JAVA voice pack (0.2.1): constants and the
 * pure mappings behind it. No Bukkit dependencies, so this is
 * unit-testable on a plain JVM; the Bukkit wiring lives in
 * ExcelQuartermaster.
 *
 * Why this exists: 0.2.0 gave Bedrock players Briggs's recorded voice
 * through a .mcpack in Geyser's packs folder, and Java players -
 * exactly as in 0.1.0 - never heard him, because a Java client cannot
 * read a Bedrock pack. Mike's platform parity rule (Oct 18, 2026:
 * "we should always treat java people how we treat bedrock") makes
 * that gap a defect, so 0.2.1 ships the mirror image for Java:
 * wrv-quartermaster-voice-java.zip, a Java resource pack carrying the
 * SAME 11 .ogg recordings (byte-identical to the .mcpack's audio;
 * verify-java-pack.py proves it) under the SAME sound names -
 * assets/wrv/sounds.json defines quartermaster.tale1..11, so the
 * "wrv:quartermaster.tale<N>" strings SoundNames already produces
 * resolve on Java exactly as they do on Bedrock.
 *
 * The pack is delivered per player with Player.addResourcePack (NOT
 * setResourcePack): add stacks alongside the server.properties pack
 * (the GuildGate narrator pack), which must keep working untouched.
 * PACK_ID is fixed forever: status events are matched against it (so
 * the narrator pack's own status events are never mistaken for ours),
 * and a client that accepted the pack once applies it on later sends
 * without being asked again.
 *
 * Pack format: pack.mcmeta pins min_format/max_format [88, 0], the
 * Paper 26.2 values - the same shape as the live GuildGate narrator
 * Java pack (wrv-guildgate-narrator-pack.zip), whose layout this pack
 * mirrors (namespace "wrv", assets/wrv/sounds.json).
 */
public final class JavaPack {

    /** Fixed id of the Quartermaster Java pack. Never change. */
    public static final UUID PACK_ID =
            UUID.fromString("7d3f9a41-5c2e-4b8f-a1d6-3e5b7c9f2a08");

    /** Where the pack zip is hosted (the website repo's packs folder,
     *  the same host as the narrator pack). Config can override. */
    public static final String DEFAULT_URL =
            "https://elmikeexcel.github.io/winkreyesvalley/packs/wrv-quartermaster-voice-java.zip";

    /** SHA-1 of the shipped wrv-quartermaster-voice-java.zip
     *  (751,535 B; see JAVA-PACK-SHA.txt). Config can override; if the
     *  hosted zip is ever rebuilt, this default must move with it. */
    public static final String DEFAULT_SHA1 =
            "ee82a47eb26405b23c8353b6ca46319c5f224572";

    /**
     * The base text of the prompt a Java player sees for this pack.
     * Since 0.2.2 it is never sent bare: {@link #offerPrompt} wraps
     * it with the "offer N of 5" counter and the never-again line
     * (Mike's rule, Oct 19, 2026).
     */
    public static final String DEFAULT_PROMPT =
            "The Old Quartermaster has a voice. Accept this small pack to hear "
            + "his tales spoken aloud - declining changes nothing else.";

    /**
     * The full text of one pack OFFER (0.2.2): the counter first -
     * "Quartermaster voice pack — offer N of 5" - then the base
     * prompt, then the plain never-again line: after maxOffers
     * offers, or once the player downloads it, they will not be
     * asked again. Mike's rule (Oct 19, 2026) is that the count is
     * ON the prompt, because players tap-spam prompts without
     * reading them and deserve to see how many chances remain.
     *
     * Only real offers are captioned this way; the silent re-send to
     * a player who already accepted carries the bare base prompt
     * (their client never displays it anyway). A null or blank base
     * falls back to {@link #DEFAULT_PROMPT}.
     */
    public static String offerPrompt(String basePrompt, int offerNumber, int maxOffers) {
        String base = (basePrompt == null || basePrompt.isBlank())
                ? DEFAULT_PROMPT : basePrompt;
        int max = Math.max(1, maxOffers);
        int n = Math.max(1, offerNumber);
        return "Quartermaster voice pack \u2014 offer " + n + " of " + max + ". "
                + base
                + " After " + max + " offers \u2014 or once you download it \u2014 "
                + "you won't be asked again.";
    }

    /** sounds.json key for tale index i (0-based): "quartermaster.tale<N>". */
    public static String soundsJsonKey(int taleIndex) {
        return taleIndex < 0 ? null : "quartermaster.tale" + (taleIndex + 1);
    }

    /** What one Bukkit PlayerResourcePackStatusEvent status means for us. */
    public enum Status {
        /** The client downloaded and applied the pack. */
        LOADED,
        /** The player said no. Remember it; do not nag. */
        DECLINED,
        /** Download or reload failed on the client side. */
        FAILED,
        /** Progress noise (ACCEPTED, DOWNLOADED) or anything unknown:
         *  no state change. */
        IGNORED
    }

    /**
     * Map a Bukkit status name to our Status. String in, enum out, so
     * the wiring passes {@code event.getStatus().name()} and this stays
     * testable without Bukkit. Unknown and null names are IGNORED.
     */
    public static Status mapStatus(String bukkitStatusName) {
        if (bukkitStatusName == null) {
            return Status.IGNORED;
        }
        return switch (bukkitStatusName) {
            case "SUCCESSFULLY_LOADED" -> Status.LOADED;
            case "DECLINED" -> Status.DECLINED;
            case "FAILED_DOWNLOAD", "FAILED_RELOAD", "INVALID_URL", "DISCARDED" -> Status.FAILED;
            default -> Status.IGNORED;
        };
    }

    /**
     * Parse a 40-character hex SHA-1 into the 20 bytes addResourcePack
     * wants. Returns null for anything else (null, blank, wrong length,
     * non-hex) - the caller then sends without a hash rather than
     * crashing on a mistyped config value.
     */
    public static byte[] parseSha1(String hex) {
        if (hex == null) {
            return null;
        }
        String s = hex.trim();
        if (s.length() != 40) {
            return null;
        }
        byte[] out = new byte[20];
        for (int i = 0; i < 20; i++) {
            int hi = Character.digit(s.charAt(2 * i), 16);
            int lo = Character.digit(s.charAt(2 * i + 1), 16);
            if (hi < 0 || lo < 0) {
                return null;
            }
            out[i] = (byte) ((hi << 4) | lo);
        }
        return out;
    }

    private JavaPack() {}
}
