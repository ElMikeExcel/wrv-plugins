package com.winkreyes.excelquartermaster;

import java.util.UUID;

/**
 * The read-only inspection half of the console-admin surface
 * (0.3.1, Mike's Nov 3, 2026 console-admin rule; the console-admin
 * coverage audit of Nov 9, 2026 found 0.3.0 a FAIL because the
 * console could reset a player's voice-pack offers with
 * {@code /qm packreset} but could not inspect them at all):
 * {@code /qm status <player>}, behind the same
 * {@code excelquartermaster.admin} permission as packreset,
 * console included.
 *
 * What it reports is exactly what the plugin's real state holds —
 * the player's {@link PackPrompt} record, the same record
 * packreset acts on:
 * - offers used: the record's attempts count, out of
 *   {@link PackPrompt#MAX_OFFERS}, plus the chances remaining
 *   (PackPrompt's own arithmetic, not a re-derivation);
 * - pack state: the record's last outcome (SENT / LOADED /
 *   DECLINED / FAILED), spelled out — accepted (LOADED, terminal),
 *   exhausted (all five offers used without accepting), or no
 *   record at all (never offered);
 * - the record's last-change timestamp, verbatim, so an operator
 *   can tell a fresh record from a stale one.
 *
 * READ-ONLY by construction: this class only formats a record the
 * caller already read out of PackPrompt; it holds no reference to
 * the prompt state, mutates nothing, and creates no record for a
 * player who has none. Target resolution lives in the plugin
 * class and is packreset's, unchanged: online player name first,
 * then a raw UUID (for offline players) — an offline player known
 * only by name cannot be resolved, exactly as with packreset.
 *
 * No Bukkit dependencies: the formatting and the exact reply text
 * live here and are unit-tested on a plain JVM; the plugin class
 * only resolves names and delivers the message.
 */
public final class PackStatus {

    /** Usage line for a bare or malformed /qm status invocation. */
    public static final String USAGE = "Usage: /qm status <player>";

    private PackStatus() {}

    /**
     * The one-line status reply for one player.
     *
     * @param record      the player's pack record, or null when
     *                    they have never been offered the pack
     * @param displayName who to name in the reply (the online
     *                    player's name, or the target text — a UUID
     *                    string — for an offline target, matching
     *                    packreset's display behaviour)
     * @param playerId    the resolved UUID, named in the reply so
     *                    an operator can re-use it verbatim
     */
    public static String messageFor(PackPrompt.Record record, String displayName,
                                    UUID playerId) {
        String who = (displayName == null || displayName.isBlank())
                ? "that player" : displayName;
        String id = playerId == null ? "unknown uuid" : playerId.toString();
        int used = PackPrompt.offersUsed(record);
        if (record == null) {
            return "Pack status for " + who + " (" + id + "): no record - "
                    + "never offered the Java voice pack; offers used 0 of "
                    + PackPrompt.MAX_OFFERS + ", " + PackPrompt.MAX_OFFERS
                    + " remaining; next join offers 1 of "
                    + PackPrompt.MAX_OFFERS + ".";
        }
        String state = stateFor(record);
        return "Pack status for " + who + " (" + id + "): offers used "
                + used + " of " + PackPrompt.MAX_OFFERS + ", "
                + PackPrompt.offersRemaining(record) + " remaining; "
                + "pack state: " + state
                + "; last change " + Math.max(0L, record.lastChangeMillis()) + ".";
    }

    /**
     * The pack-state wording for one record: the stored outcome,
     * with the two terminal shapes (accepted, exhausted) called
     * out in the terms PackPrompt itself uses.
     */
    public static String stateFor(PackPrompt.Record record) {
        if (record == null) {
            return "NO RECORD";
        }
        return switch (record.outcome()) {
            case LOADED -> "LOADED (accepted - has the voice pack; terminal)";
            case SENT -> PackPrompt.offersRemaining(record) == 0
                    ? "SENT (offered, no outcome yet; offers exhausted)"
                    : "SENT (offered, no outcome yet)";
            case DECLINED -> PackPrompt.offersRemaining(record) == 0
                    ? "DECLINED (offers exhausted - never offered again "
                            + "unless an admin runs /qm packreset)"
                    : "DECLINED";
            case FAILED -> PackPrompt.offersRemaining(record) == 0
                    ? "FAILED (offers exhausted - never offered again "
                            + "unless an admin runs /qm packreset)"
                    : "FAILED";
        };
    }
}
