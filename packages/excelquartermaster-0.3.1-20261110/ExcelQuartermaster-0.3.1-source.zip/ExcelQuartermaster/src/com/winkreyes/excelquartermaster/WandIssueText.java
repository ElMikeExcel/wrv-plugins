package com.winkreyes.excelquartermaster;

import java.util.List;

/**
 * The Seal 1 words (0.3.0): shipped defaults for every line the
 * wand-issue flow speaks, taken VERBATIM from DIALOGUE.md wherever
 * that document has the line. Config may override each one, but
 * these defaults are what an unmerged live config (written before
 * 0.3.0 existed) will say - the established every-key-has-a-shipped-
 * default discipline of this plugin.
 *
 * Two lines are NOT in DIALOGUE.md and were written for the flow:
 *
 * - GONE_LINE: the issued-but-gone case. Its instruction half is
 *   the Valley Guide's taught wording - "tell Mike or Argus" - so
 *   every surface in the valley tells a wand-loser the same thing.
 * - BLOCKED_LINE: the verification-failed case. It promises
 *   nothing and blames no one; the player simply comes back.
 *
 * No Bukkit dependencies; the wiring reads config over these.
 */
public final class WandIssueText {

    private WandIssueText() {}

    /** The first wand's Magic template (WAND-ISSUE-SPEC: beginner, NOT apprentice). */
    public static final String DEFAULT_TEMPLATE = "beginner";

    /** Offer lead: DIALOGUE.md, Seal 1 lines - the late-arrival variant. */
    public static final String LATE_LINE =
            "Word travels slow, but it travels. The first seal fell, and every called mage "
            + "in this valley gets a wand from my hand. Here is yours.";

    /** Offer close: DIALOGUE.md, Seal 1 lines - the hand-over. */
    public static final String ISSUE_LINE =
            "Hold out your hand. This is a bound wand, tied to you and no one else. "
            + "It will not leave you, and it cannot be lost like a dropped sword. Keep it close.";

    /** Holder decline: DIALOGUE.md, Seal 1 lines - the already-holds variant. */
    public static final String HOLDER_LINE =
            "You already carry yours, I can see it plain as day. One wand, one mage. "
            + "If you truly lose it, which should be near impossible, come back and we will talk.";

    /** Issued-but-gone decline (flow-written; Guide wording for the instruction). */
    public static final String GONE_LINE =
            "My ledger says a wand already left these stores with your name on it, "
            + "and I do not hand out seconds. A bound wand cannot truly be lost: "
            + "check your Utility Pouch first. If it is truly gone, tell Mike or Argus "
            + "and they will reissue it.";

    /** Verification-failed line (flow-written; no promise, no blame). */
    public static final String BLOCKED_LINE =
            "Hmm. My stores are not answering me just now, young one. "
            + "Come back in a little while, and we will see about that wand.";

    /** The Java confirm affordance, shown under the chat offer. */
    public static final String CONFIRM_HINT = "&8[Speak to him again to take the wand]";

    /** The Bedrock offer form's confirm button. */
    public static final String TAKE_BUTTON = "Take the wand";

    /** DIALOGUE.md, Seal 1 lines - the arts, taught right after the give. */
    public static final String ARTS_LINE =
            "That wand knows the Healer's arts to start: mending, curing, feeding, "
            + "and keeping the fire and the deep water off you. Cast, and it will teach "
            + "you more. That is how wands learn: by being used.";

    /** DIALOGUE.md, Seal 1 lines - spell points, taught right after the give. */
    public static final String SPELL_POINTS_LINE =
            "Spell points come from casting, not from waiting. Small spells, often, "
            + "and the ladder climbs itself.";

    /** DIALOGUE.md, Seal 1 lines - his opener once a seal has fallen. */
    public static final String FIRST_SEAL_LINE =
            "You felt it too, then. The first seal is down, and the valley just took "
            + "a breath it has been holding for years.";

    /** Said in chat right after a successful give (the issue line was the offer). */
    public static final List<String> DEFAULT_TEACH_LINES =
            List.of(ARTS_LINE, SPELL_POINTS_LINE);

    /**
     * The rotation once a seal has fallen: every line DIALOGUE.md
     * gives him for the new era that reads as an ongoing tale. The
     * issue lines themselves live in the flow, not the rotation.
     */
    public static final List<String> DEFAULT_SEAL_ONE_TALES =
            List.of(FIRST_SEAL_LINE, ARTS_LINE, SPELL_POINTS_LINE);
}
