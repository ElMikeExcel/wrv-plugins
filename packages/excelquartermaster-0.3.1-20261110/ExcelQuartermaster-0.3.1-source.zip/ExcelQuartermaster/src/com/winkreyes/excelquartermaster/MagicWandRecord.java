package com.winkreyes.excelquartermaster;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;

/**
 * The Magic wand-record read behind the wand-issue gate (0.3.0).
 *
 * The question this answers: "does Magic itself believe this player
 * already owns a bound wand?" Magic is the authority - it keeps a
 * per-player record of bound wands (the same record its own wand
 * recovery hands back from), independent of where the physical wand
 * item currently sits: hand, chest, ender chest, or parked in the
 * Utility Pouch (the pouch leg of the gate is separate, because a
 * parked wand is also in this record - belt and braces by design).
 *
 * The read goes through Magic's public API by reflection, the same
 * no-hard-dependency pattern as BedrockTales and SealWatch:
 *   Magic plugin -> its MagicAPI service (or the plugin object,
 *   which implements the API) -> getMage(player) -> getBoundWands().
 * A non-empty bound-wand list means HOLDS. The template keys are
 * carried along for logging.
 *
 * Failure discipline: a read that cannot be completed is FAILED,
 * never a guessed NONE - the gate treats FAILED as "do not issue
 * right now", because issuing on an unverifiable record is exactly
 * how duplicate bound wands (which can never be deleted) are minted.
 * Magic absent entirely is a separate, calmer fact the caller
 * checks via {@link #magicPresent()}: no Magic, no wands, no issue
 * mode at all.
 */
final class MagicWandRecord {

    private MagicWandRecord() {}

    /** Outcome of one record read. */
    enum Read {
        /** Magic's record lists at least one bound wand for the player. */
        HOLDS,
        /** Magic answered: the record is empty. */
        NONE,
        /** Magic is installed but the read could not be completed. */
        FAILED
    }

    /**
     * @param read      the outcome
     * @param templates template keys of the bound wands (HOLDS only;
     *                  for logging/diagnostics, never for decisions)
     */
    record Result(Read read, List<String> templates) {}

    private static final Result FAILED_RESULT = new Result(Read.FAILED, List.of());

    /** True when the Magic plugin is installed and enabled. */
    static boolean magicPresent() {
        Plugin magic = Bukkit.getPluginManager().getPlugin("Magic");
        return magic != null && magic.isEnabled();
    }

    /** Read the player's bound-wand record from Magic's API. Never throws. */
    static Result read(Player player, Logger log) {
        try {
            Plugin magic = Bukkit.getPluginManager().getPlugin("Magic");
            if (magic == null || !magic.isEnabled() || player == null) {
                return FAILED_RESULT;
            }
            ClassLoader loader = magic.getClass().getClassLoader();
            Class<?> apiClass = Class.forName(
                    "com.elmakers.mine.bukkit.api.magic.MagicAPI", true, loader);
            Object api = findApi(apiClass, magic);
            if (api == null) {
                log.warning("MagicWandRecord: Magic is enabled but no MagicAPI "
                        + "service or plugin instance could be resolved.");
                return FAILED_RESULT;
            }
            Method getMage = apiClass.getMethod("getMage", CommandSender.class);
            Object mage = getMage.invoke(api, player);
            if (mage == null) {
                log.warning("MagicWandRecord: MagicAPI.getMage returned null for "
                        + player.getName() + ".");
                return FAILED_RESULT;
            }
            Class<?> mageClass = Class.forName(
                    "com.elmakers.mine.bukkit.api.magic.Mage", true, loader);
            Method getBoundWands = mageClass.getMethod("getBoundWands");
            Object bound = getBoundWands.invoke(mage);
            if (!(bound instanceof List<?> wands)) {
                log.warning("MagicWandRecord: getBoundWands returned an unexpected "
                        + "shape for " + player.getName() + ".");
                return FAILED_RESULT;
            }
            if (wands.isEmpty()) {
                return new Result(Read.NONE, List.of());
            }
            List<String> templates = new ArrayList<>();
            try {
                Class<?> wandClass = Class.forName(
                        "com.elmakers.mine.bukkit.api.wand.Wand", true, loader);
                Method getTemplateKey = wandClass.getMethod("getTemplateKey");
                for (Object wand : wands) {
                    Object key = wand == null ? null : getTemplateKey.invoke(wand);
                    templates.add(key == null ? "?" : key.toString());
                }
            } catch (Exception keysFailed) {
                // The count already answered the gate's question; the
                // keys are diagnostics only and may stay unknown.
                templates.clear();
                for (int i = 0; i < wands.size(); i++) {
                    templates.add("?");
                }
            }
            return new Result(Read.HOLDS, List.copyOf(templates));
        } catch (Exception e) {
            log.warning("MagicWandRecord: read failed for "
                    + (player == null ? "?" : player.getName()) + ": "
                    + e.getClass().getSimpleName() + ": " + e.getMessage());
            return FAILED_RESULT;
        }
    }

    /**
     * Resolve the MagicAPI instance: the service Magic registers for
     * its own plugin first (the PouchCompassCheck pattern - scanning
     * the owning plugin's registrations sidesteps classloader
     * questions), then the plugin object itself, which implements
     * the API in Magic 11.x.
     */
    private static Object findApi(Class<?> apiClass, Plugin magic) {
        try {
            for (RegisteredServiceProvider<?> rsp
                    : Bukkit.getServicesManager().getRegistrations(magic)) {
                Object provider = rsp.getProvider();
                if (provider != null && apiClass.isInstance(provider)) {
                    return provider;
                }
            }
        } catch (Exception ignored) {
            // Fall through to the plugin instance.
        }
        return apiClass.isInstance(magic) ? magic : null;
    }
}
