package com.winkreyes.excelquartermaster;

import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/**
 * Shopkeepers wiring for the 0.2.1 Java sneak-trade fix: open a
 * shopkeeper's trading window directly, through Shopkeepers' own
 * public API, reached by reflection against Shopkeepers' classloader
 * - the same fail-soft pattern as BedrockTales, so this plugin has no
 * compile-time dependency on Shopkeepers (softdepend only) and every
 * failure degrades to "redirect unavailable", which SneakRoute turns
 * into a passthrough (today's behavior) rather than a dead click.
 *
 * The API calls, against Shopkeepers 2.28.0 (the build on this
 * server, inspected directly):
 *   ShopkeepersAPI.getShopkeeperRegistry()
 *     .getShopkeeperByEntity(entity)   -> Shopkeeper or null
 *     .openTradingWindow(player)       -> boolean
 * openTradingWindow is the very method Shopkeepers itself calls for a
 * non-sneak click, so a redirected visitor gets the identical window,
 * permission checks and all (trading permission, open/closed state),
 * that a plain click would have produced.
 */
final class ShopTradeOpener {

    private ShopTradeOpener() {}

    /** True when the Shopkeepers plugin is enabled and its API loads. */
    static boolean apiAvailable(Logger log) {
        try {
            Plugin sk = shopkeepersPlugin();
            if (sk == null) {
                return false;
            }
            Class.forName("com.nisovin.shopkeepers.api.ShopkeepersAPI", true,
                    sk.getClass().getClassLoader());
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Open the trading window of the shopkeeper {@code entity} belongs
     * to, for {@code player}. Returns true only when Shopkeepers
     * reports the window opened; false on every failure (plugin
     * missing, entity not a shopkeeper, API moved, window refused).
     */
    static boolean openTradingWindow(Player player, Entity entity, Logger log) {
        String step = "start";
        try {
            Plugin sk = shopkeepersPlugin();
            if (sk == null) {
                return false;
            }
            ClassLoader loader = sk.getClass().getClassLoader();

            step = "ShopkeepersAPI.getShopkeeperRegistry";
            Class<?> apiClass = Class.forName(
                    "com.nisovin.shopkeepers.api.ShopkeepersAPI", true, loader);
            Object registry = apiClass.getMethod("getShopkeeperRegistry").invoke(null);
            if (registry == null) {
                return false;
            }

            step = "registry.getShopkeeperByEntity";
            Object shopkeeper = registry.getClass()
                    .getMethod("getShopkeeperByEntity", Entity.class)
                    .invoke(registry, entity);
            if (shopkeeper == null) {
                return false; // not (or no longer) a shopkeeper entity
            }

            step = "shopkeeper.openTradingWindow";
            Object result = shopkeeper.getClass()
                    .getMethod("openTradingWindow", Player.class)
                    .invoke(shopkeeper, player);
            return Boolean.TRUE.equals(result);
        } catch (Exception e) {
            log.fine("ShopTradeOpener failed at [" + step + "]: "
                    + e.getClass().getSimpleName() + ": " + e.getMessage());
            return false;
        }
    }

    private static Plugin shopkeepersPlugin() {
        Plugin sk = Bukkit.getPluginManager().getPlugin("Shopkeepers");
        return sk != null && sk.isEnabled() ? sk : null;
    }
}
