package com.winkreyes.excelquartermaster;

/**
 * Text shaping for the Bedrock dialogue form: Cumulus form bodies render
 * Bedrock's section-sign (§) formatting codes, while our config tales
 * are written with the Bukkit-style ampersand codes the chat path uses.
 * This converts one to the other so a tale reads the same in the form
 * as it does in chat.
 *
 * No Bukkit dependencies (unit-testable). Only real code pairs (&amp;
 * followed by a legacy code character) are translated; a lone ampersand
 * in prose is left alone.
 */
public final class TaleFormText {

    private TaleFormText() {}

    /** The tale as form body text: &amp;x code pairs become §x. Null becomes "". */
    public static String toFormText(String tale) {
        if (tale == null) {
            return "";
        }
        StringBuilder out = new StringBuilder(tale.length());
        for (int i = 0; i < tale.length(); i++) {
            char c = tale.charAt(i);
            if (c == '&' && i + 1 < tale.length() && TaleText.isCodeChar(tale.charAt(i + 1))) {
                out.append('§').append(tale.charAt(i + 1));
                i++;
            } else {
                out.append(c);
            }
        }
        return out.toString();
    }
}
