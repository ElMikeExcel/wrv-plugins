package com.winkreyes.excelquartermaster;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * The pending-offer state of the wand issue (0.3.0): the two-step
 * "hold out your hand" beat. The QM first OFFERS the wand (his Seal
 * 1 lines, with a Take-the-wand button on Bedrock or a
 * speak-to-him-again prompt in Java chat); only a deliberate second
 * step - the button, or the next plain click while the offer is
 * live - CONFIRMS, and the give happens at that instant (with the
 * gate re-checked there, never on the strength of the offer).
 *
 * Pure state, in-memory only: an offer is a moment, not a record.
 * Quitting, expiry, or a completed confirm all end it. No Bukkit
 * dependencies; time is injected so the window is unit-testable.
 */
public final class WandIssueFlow {

    private final Map<UUID, Long> offers = new HashMap<>();
    private final long windowMillis;

    public WandIssueFlow(long windowMillis) {
        this.windowMillis = Math.max(0L, windowMillis);
    }

    /** Start (or refresh) the offer window for a player. */
    public void offer(UUID id, long now) {
        if (id != null) {
            offers.put(id, now);
        }
    }

    /** True while an unexpired offer stands for the player. */
    public boolean hasLiveOffer(UUID id, long now) {
        Long at = id == null ? null : offers.get(id);
        if (at == null) {
            return false;
        }
        if (now - at > windowMillis) {
            offers.remove(id);
            return false;
        }
        return true;
    }

    /**
     * The confirm step: consumes the offer either way (a confirm is
     * answered once - give, decline, or blocked - never left
     * dangling) and reports whether a live offer stood.
     */
    public boolean confirm(UUID id, long now) {
        boolean live = hasLiveOffer(id, now);
        if (id != null) {
            offers.remove(id);
        }
        return live;
    }

    /** Forget any offer (quit, farewell, a give already landed). */
    public void drop(UUID id) {
        if (id != null) {
            offers.remove(id);
        }
    }

    public int pendingCount() {
        return offers.size();
    }
}
