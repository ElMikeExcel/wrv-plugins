package com.winkreyes.excelquartermaster;

import java.lang.reflect.Method;
import java.util.UUID;
import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;

/**
 * The pouch leg of the wand-issue gate (0.3.0): does this player's
 * Utility Pouch currently hold a magic wand? A wand PARKED in the
 * pouch counts as HOLDING - the WAND-ISSUE-SPEC's step-0 check,
 * because Magic's own wand restore cannot see into the pouch, and
 * neither can a plain inventory scan: the pouch is exactly where a
 * "lost" wand usually is.
 *
 * The read goes through ExcelPouch's PouchQuery service by
 * reflection, the PouchCompassCheck pattern (scan the owning
 * plugin's service registrations for a holdsKind(UUID, String)
 * method), so there is no compile-time or load-time dependency on
 * ExcelPouch.
 *
 * Failure discipline DIFFERS from the compass check on purpose:
 * ExcelMenuJoin fails OPEN (no answer -> give the compass) because
 * a duplicate compass is harmless. A duplicate bound wand is not
 * harmless - it can never be deleted - but a missing ExcelPouch is
 * not uncertainty either: no pouch plugin means no pouch, so no
 * parked wand can exist. So: plugin ABSENT reads as a plain false
 * (there is provably nowhere to park), while a present-but-
 * unanswerable service returns null, and the caller treats null as
 * BLOCKED - the verification could not be completed.
 */
final class PouchHoldCheck {

    private PouchHoldCheck() {}

    /** The ExcelPouch kind id a parked wand reports under. */
    static final String MAGIC_WAND_KIND = "magic_wand";

    /**
     * @return TRUE/FALSE when ExcelPouch answered; null when the
     *         pouch plugin is present but no answer could be had.
     *         A wholly absent pouch plugin answers FALSE (no pouch
     *         exists to hold anything).
     */
    static Boolean pouchHoldsWand(UUID playerId, Logger log) {
        Plugin pouch = Bukkit.getPluginManager().getPlugin("ExcelPouch");
        if (pouch == null || !pouch.isEnabled()) {
            return Boolean.FALSE;
        }
        if (playerId == null) {
            return null;
        }
        try {
            for (RegisteredServiceProvider<?> rsp
                    : Bukkit.getServicesManager().getRegistrations(pouch)) {
                Object provider = rsp.getProvider();
                if (provider == null) {
                    continue;
                }
                try {
                    Method m = provider.getClass().getMethod("holdsKind", UUID.class, String.class);
                    Object answer = m.invoke(provider, playerId, MAGIC_WAND_KIND);
                    if (answer instanceof Boolean b) {
                        return b;
                    }
                } catch (NoSuchMethodException notTheService) {
                    // Some other service of the same plugin: keep looking.
                }
            }
        } catch (Exception e) {
            log.warning("PouchHoldCheck: pouch read failed: "
                    + e.getClass().getSimpleName() + ": " + e.getMessage());
            return null;
        }
        log.warning("PouchHoldCheck: ExcelPouch is enabled but no PouchQuery "
                + "service answered; treating the pouch leg as unverifiable.");
        return null;
    }
}
