package com.winkreyes.excelquartermaster;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * ExcelQuartermaster - the Old Quartermaster's voice.
 *
 * The village quartermaster is a Shopkeepers admin-shop villager: he can
 * hold trades but he cannot speak. This plugin gives him his tales. When a
 * player right-clicks the villager whose custom name matches the
 * configured NPC name (optionally also anchored near a configured spot),
 * the interaction is cancelled - so his deliberately empty trade window
 * never opens - and the player instead hears the next tale from the
 * rotation.
 *
 * 0.1.0 told every tale in chat. 0.2.0 added his Bedrock presentation:
 * a Bedrock player gets the tale in a dialogue-style form (his name as
 * the title, the tale as the body, "Another tale" / "Farewell" buttons)
 * and hears the tale spoken, from the recorded clips in the Bedrock
 * voice pack (wrv-quartermaster-voice-bedrock.mcpack, served by
 * Geyser). Every Bedrock step is fail-soft: if forms or Geyser are
 * unavailable for a client, the chat tale is told instead - a tap is
 * never dead.
 *
 * 0.2.1 is the JAVA PARITY release (Mike's rule, Oct 18, 2026: "we
 * should always treat java people how we treat bedrock"):
 * - Java voice: Java players are offered a Java resource pack
 *   (wrv-quartermaster-voice-java.zip - the same 11 recordings, the
 *   same sound names) once, via Player.addResourcePack, and hear the
 *   tales spoken exactly as Bedrock players do. The chat tale always
 *   arrives either way; the voice is additive, never blocking, and
 *   the offer follows the PackPrompt prompt-once discipline (a
 *   decline is respected, never nagged) - superseded by the
 *   five-chances rule in 0.2.2, below.
 * - Java sneak-trade fix: Shopkeepers routes sneak-clicks to its
 *   editor, which non-editors are denied ("You don't have the
 *   permission to do that.") with no fallback to trading - so a Java
 *   visitor sneak-clicking him hit a wall where Bedrock worked. A
 *   sneak-click from a Java player who could not edit him anyway now
 *   opens his trading window directly through the Shopkeepers API
 *   (see SneakRoute for the diagnosed mechanics). Editors and all
 *   Bedrock players keep the exact 0.2.0 sneak behavior.
 *
 * 0.2.2 changes ONLY the Java pack offer discipline, to Mike's
 * five-chances rule (Oct 19, 2026): players tap-spam prompts
 * without reading them, so every player gets five lifetime offers
 * of the voice pack, each prompt shows its counter ("offer N of
 * 5") and states that after 5 offers - or once downloaded - it
 * will not ask again. An accept is terminal and the silent re-send
 * to an accepted player is never counted as an offer; the 0.2.1
 * 30-day reoffer window and max-3 cap are gone (offers recorded
 * under 0.2.1 count toward the five). See PackPrompt for the state
 * machine. The sneak-trade fix and everything else are 0.2.1's,
 * unchanged. And because Mike asked "can we manually reset if
 * needed?", 0.2.2 also adds the escape hatch: /qm packreset
 * <player|all> (excelquartermaster.admin, console included) wipes
 * a player's offer record so the offers start again at 1 of 5;
 * players who already accepted are left untouched. See PackReset.
 *
 * 0.3.0 gives him his second job: WAND ISSUE. Until now the first
 * wand of the magic era could only be handed over by a human at the
 * console - the WAND-ISSUE-SPEC's manual /mgive procedure - because
 * the QM's click answered with tale text or an empty trade window,
 * never a wand (the gap Jester_Turtle walked into on Oct 20, 2026,
 * the night the first seal fell and rose again). Now the QM reads
 * the broken-seal count himself (SealWatch, the reflective
 * GuildGateAPI pattern ExcelMagicGate established), and from the
 * first broken seal his tales switch to the DIALOGUE.md Seal 1 set
 * and a plain click from a player who holds no wand runs the issue
 * flow: his Seal 1 lines offer the wand, a deliberate confirm step
 * (the Take-the-wand button on Bedrock, a second click on Java)
 * dispatches the specced console give - mgive <player> beginner -
 * exactly once per player, behind the three-leg not-holding gate in
 * WandIssueGate (own issued ledger / Utility Pouch / Magic's own
 * bound-wand record), with the issuance recorded only once Magic's
 * record confirms the wand landed. A player already holding gets
 * his holder line, an issued-but-gone player gets pointed at the
 * pouch and at Mike or Argus (re-issue stays console-only; this
 * flow is never a restore path), and with no seal knowledge he is
 * exactly the 0.2.2 QM: pre-seal tales, no issue, never a guess.
 *
 * 0.3.1 changes ONLY the console-admin surface, under Mike's
 * Nov 3, 2026 console-admin rule (the Nov 9, 2026 coverage audit
 * found 0.3.0 a FAIL: the console could reset a player's pack
 * offers but could not inspect them): /qm status <player> now
 * reports a player's offers used and pack state from their real
 * PackPrompt record, read-only, beside the existing packreset —
 * same excelquartermaster.admin permission, console included,
 * same target resolution. See PackStatus. Every player-facing
 * path (tales, packs, wand issue) is 0.3.0's, unchanged.
 *
 * All decision rules live in the Bukkit-free classes (TaleRotation,
 * NpcMatcher, TaleText, TaleStore, DialogueFlow, SoundNames,
 * TaleFormText, JavaPack, PackPrompt, PackStateStore, SneakRoute,
 * WandIssueGate, WandIssueFlow, WandIssueText, IssuedWands,
 * IssuedWandStore, PackReset, PackStatus) and are unit-tested on
 * a plain JVM. This class
 * (plus the reflective BedrockTales, ShopTradeOpener, SealWatch,
 * MagicWandRecord and PouchHoldCheck) is only the wiring: config
 * in, events in, tales out, and the per-player state saved to
 * player-tales.txt / java-pack-state.txt / issued-wands.txt in the
 * plugin folder.
 */
public final class ExcelQuartermaster extends JavaPlugin implements Listener {

    private String npcName;
    private String header;
    private long cooldownMillis;
    private boolean anchorEnabled;
    private String anchorWorld;
    private double anchorX;
    private double anchorY;
    private double anchorZ;
    private double anchorRadius;
    private List<String> tales = List.of();

    private boolean dialogueEnabled;
    private boolean voiceEnabled;
    private String soundPrefix;
    private String nextButton;
    private String closeButton;
    private long advanceCooldownMillis;

    private boolean javaSneakFix;
    private boolean javaVoiceEnabled;
    private String javaPackUrl;
    private String javaPackSha1;
    private String javaPackPrompt;
    private long javaSendDelayTicks;

    private List<String> talesSeal1 = List.of();
    private boolean wandIssueEnabled;
    private String wandTemplate;
    private String issueTakeButton;
    private String issueLateLine;
    private String issueLine;
    private String holderLine;
    private String goneLine;
    private String blockedLine;
    private String confirmHint;
    private List<String> teachLines = List.of();

    private final TaleRotation rotation = new TaleRotation();
    private final DialogueFlow dialogue = new DialogueFlow();
    private final PackPrompt packPrompt = new PackPrompt();
    private final Map<UUID, Long> lastSneakRedirect = new HashMap<>();
    private final IssuedWands issuedWands = new IssuedWands();
    private WandIssueFlow issueFlow = new WandIssueFlow(60_000L);
    /** Players who have already heard a decline line this session (quit clears). */
    private final java.util.Set<UUID> declineShown = new java.util.HashSet<>();
    /** Players whose give is dispatched and awaiting Magic-record verification. */
    private final java.util.Set<UUID> giveInFlight = new java.util.HashSet<>();
    private File dataFile;
    private File packStateFile;
    private File issuedFile;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        reloadSettings();
        dataFile = new File(getDataFolder(), "player-tales.txt");
        try {
            rotation.restore(TaleStore.load(dataFile.toPath()));
        } catch (IOException e) {
            getLogger().log(Level.WARNING, "Could not read " + dataFile.getName()
                    + "; starting the tale rotation fresh.", e);
        }
        packStateFile = new File(getDataFolder(), "java-pack-state.txt");
        try {
            packPrompt.restore(PackStateStore.load(packStateFile.toPath()));
        } catch (IOException e) {
            getLogger().log(Level.WARNING, "Could not read " + packStateFile.getName()
                    + "; starting the Java pack records fresh.", e);
        }
        issuedFile = new File(getDataFolder(), "issued-wands.txt");
        try {
            issuedWands.restore(IssuedWandStore.load(issuedFile.toPath()));
        } catch (IOException e) {
            getLogger().log(Level.WARNING, "Could not read " + issuedFile.getName()
                    + "; starting the issued-wand ledger fresh. CAUTION: with the "
                    + "ledger lost, the Magic-record and pouch legs are the only "
                    + "duplicate guards until it rebuilds.", e);
        }
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("ExcelQuartermaster enabled: '" + npcName + "' will tell his tales ("
                + tales.size() + " tales, anchor " + (anchorEnabled
                        ? "on: " + anchorWorld + " " + fmt(anchorX) + "," + fmt(anchorY) + ","
                                + fmt(anchorZ) + " r" + fmt(anchorRadius)
                        : "off")
                + ", cooldown " + (cooldownMillis / 1000) + "s, "
                + rotation.trackedCount() + " players with saved progress).");
        getLogger().info("Bedrock presentation: dialogue " + (dialogueEnabled ? "on" : "off")
                + ", voice " + (voiceEnabled
                        ? "on ('" + soundPrefix + "<N>', " + SoundNames.PACK_CLIP_COUNT
                                + " recorded clips)"
                        : "off")
                + ", dialogue advance cooldown " + (advanceCooldownMillis / 1000) + "s.");
        getLogger().info("Java parity: voice " + (javaVoiceEnabled
                        ? "on (pack '" + javaPackUrl + "')"
                        : "off")
                + ", sneak-trade fix " + (javaSneakFix ? "on" : "off")
                + ", " + packPrompt.trackedCount() + " players with saved pack state.");
        if (javaSneakFix) {
            getLogger().info("Shopkeepers trade redirect: "
                    + (ShopTradeOpener.apiAvailable(getLogger())
                            ? "available"
                            : "UNAVAILABLE (Java sneak clicks keep the old passthrough)"));
        }
        Integer sealsAtBoot = SealWatch.sealsBroken(getLogger());
        getLogger().info("Wand issue: " + (wandIssueEnabled ? "on" : "off")
                + " (template '" + wandTemplate + "', " + issuedWands.size()
                + " issued on record, seals "
                + (sealsAtBoot == null ? "unknown (GuildGate not answering)" : sealsAtBoot)
                + ", Magic " + (MagicWandRecord.magicPresent() ? "present" : "ABSENT")
                + ", Seal 1 tales " + talesSeal1.size() + ").");
        if (wandIssueEnabled && !MagicWandRecord.magicPresent()) {
            getLogger().info("Wand issue is on but Magic is not installed: no wand "
                    + "exists to give, so he will tell his Seal 1 tales only.");
        }
        if (tales.isEmpty()) {
            getLogger().warning("No tales configured: clicks on '" + npcName
                    + "' will be quietly cancelled with nothing to say.");
        }
        if ((voiceEnabled || javaVoiceEnabled) && tales.size() > SoundNames.PACK_CLIP_COUNT) {
            getLogger().warning("Config lists " + tales.size() + " tales but the voice packs "
                    + "carry " + SoundNames.PACK_CLIP_COUNT + " clips: tales beyond that "
                    + "will show as text with no voice until the packs are re-recorded.");
        }
        if (javaVoiceEnabled && JavaPack.parseSha1(javaPackSha1) == null) {
            getLogger().warning("java.voice.pack-sha1 is not a 40-character hex SHA-1; "
                    + "the pack will be offered without a pinned hash.");
        }
    }

    @Override
    public void onDisable() {
        saveRotation();
        savePackState();
        saveIssued();
    }

    private void reloadSettings() {
        npcName = getConfig().getString("npc-name", "Old Quartermaster");
        header = getConfig().getString("header", "&6{name} &7says:");
        cooldownMillis = Math.max(0L, getConfig().getLong("cooldown-seconds", 8L)) * 1000L;
        anchorEnabled = getConfig().getBoolean("anchor.enabled", true);
        anchorWorld = getConfig().getString("anchor.world", "world");
        anchorX = getConfig().getDouble("anchor.x", -783.0);
        anchorY = getConfig().getDouble("anchor.y", 81.0);
        anchorZ = getConfig().getDouble("anchor.z", -299.0);
        anchorRadius = getConfig().getDouble("anchor.radius", 10.0);
        tales = getConfig().getStringList("tales");

        dialogueEnabled = getConfig().getBoolean("bedrock.dialogue", true);
        voiceEnabled = getConfig().getBoolean("bedrock.voice", true);
        soundPrefix = getConfig().getString("bedrock.sound-prefix", SoundNames.DEFAULT_PREFIX);
        nextButton = getConfig().getString("bedrock.next-button", "Another tale");
        closeButton = getConfig().getString("bedrock.close-button", "Farewell");
        advanceCooldownMillis = Math.max(0L,
                getConfig().getLong("bedrock.advance-cooldown-seconds", 2L)) * 1000L;

        // Every java.* key is read with its shipped default, so a live
        // config that predates 0.2.1 (no java: section at all) still
        // gets the full parity behavior; merging the section into the
        // live config is optional polish, never a requirement.
        javaSneakFix = getConfig().getBoolean("java.sneak-trade-fix", true);
        javaVoiceEnabled = getConfig().getBoolean("java.voice.enabled", true);
        javaPackUrl = getConfig().getString("java.voice.pack-url", JavaPack.DEFAULT_URL);
        javaPackSha1 = getConfig().getString("java.voice.pack-sha1", JavaPack.DEFAULT_SHA1);
        javaPackPrompt = getConfig().getString("java.voice.prompt", JavaPack.DEFAULT_PROMPT);
        // 0.2.2: the 0.2.1 keys java.voice.reoffer-days and
        // java.voice.max-send-attempts are no longer read - Mike's
        // five-chances rule (PackPrompt.MAX_OFFERS) is fixed, with
        // no reset window and no config knob to drift from it.
        javaSendDelayTicks = Math.max(0L,
                getConfig().getLong("java.voice.send-delay-ticks", 40L));

        // 0.3.0 wand issue: every key read with its DIALOGUE.md
        // shipped default, so a live config that predates 0.3.0
        // (no tales-seal1 list, no wand-issue section) still runs
        // the full Seal 1 behavior; merging the new sections into
        // the live config is optional polish, never a requirement.
        talesSeal1 = getConfig().getStringList("tales-seal1");
        if (talesSeal1.isEmpty()) {
            talesSeal1 = WandIssueText.DEFAULT_SEAL_ONE_TALES;
        }
        wandIssueEnabled = getConfig().getBoolean("wand-issue.enabled", true);
        wandTemplate = getConfig().getString("wand-issue.template",
                WandIssueText.DEFAULT_TEMPLATE);
        issueTakeButton = getConfig().getString("wand-issue.take-button",
                WandIssueText.TAKE_BUTTON);
        issueLateLine = getConfig().getString("wand-issue.late-line",
                WandIssueText.LATE_LINE);
        issueLine = getConfig().getString("wand-issue.issue-line",
                WandIssueText.ISSUE_LINE);
        holderLine = getConfig().getString("wand-issue.holder-line",
                WandIssueText.HOLDER_LINE);
        goneLine = getConfig().getString("wand-issue.gone-line",
                WandIssueText.GONE_LINE);
        blockedLine = getConfig().getString("wand-issue.blocked-line",
                WandIssueText.BLOCKED_LINE);
        confirmHint = getConfig().getString("wand-issue.confirm-hint",
                WandIssueText.CONFIRM_HINT);
        teachLines = getConfig().getStringList("wand-issue.teach-lines");
        if (teachLines.isEmpty()) {
            teachLines = WandIssueText.DEFAULT_TEACH_LINES;
        }
        issueFlow = new WandIssueFlow(Math.max(1L,
                getConfig().getLong("wand-issue.offer-window-seconds", 60L)) * 1000L);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEntityEvent event) {
        // The event fires once per hand; only the main hand acts, so one
        // click can never tell two tales.
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Entity entity = event.getRightClicked();
        if (entity.getType() != EntityType.VILLAGER) {
            return;
        }
        Location loc = entity.getLocation();
        boolean matched = NpcMatcher.matches(
                entity.getCustomName(), npcName,
                anchorEnabled, anchorWorld, anchorX, anchorY, anchorZ, anchorRadius,
                loc.getWorld() == null ? null : loc.getWorld().getName(),
                loc.getX(), loc.getY(), loc.getZ());
        if (!matched) {
            return;
        }
        Player player = event.getPlayer();
        if (player.isSneaking() && javaSneakFix && handleSneakTrade(player, entity, event)) {
            return; // the sneak click was fully handled (trading opened or twin swallowed)
        }
        // 0.3.0: the seal read drives both the tale set and the wand
        // issue flow. Plain clicks only - a sneak click stays
        // Shopkeepers' business (editor / trading), exactly as it
        // has always been, and decide() below still owns its
        // passthrough. An unknown seal count is the pre-seal world:
        // pre-seal tales, no issue, never a guess.
        Integer seals = SealWatch.sealsBroken(getLogger());
        boolean sealEra = WandIssueGate.sealOneTales(
                seals != null, seals == null ? 0 : seals);
        if (!player.isSneaking() && sealEra && handleWandIssue(player, seals)) {
            event.setCancelled(true);
            return;
        }
        List<String> activeTales = sealEra ? talesSeal1 : tales;
        TaleRotation.Outcome outcome = rotation.decide(
                player.getUniqueId(), player.isSneaking(),
                System.currentTimeMillis(), activeTales.size(), cooldownMillis);
        switch (outcome.kind()) {
            case PASSTHROUGH -> {
                // Sneak-click: the Shopkeepers editor path. Never interfere.
            }
            case CANCEL_SILENT -> event.setCancelled(true);
            case TELL -> {
                event.setCancelled(true);
                tell(player, outcome.taleIndex(), activeTales, sealEra);
                if (outcome.changed()) {
                    saveRotation();
                }
            }
        }
    }

    /**
     * One plain click in the seal era, routed to the wand-issue
     * flow. Returns true when the flow fully answered the click
     * (offer shown, give landed, or a verdict line spoken); false
     * sends the click on to the ordinary tale rotation - which is
     * what a holder hears after their one decline line per session,
     * and what everyone hears when issue mode is off.
     */
    private boolean handleWandIssue(Player player, int seals) {
        UUID uuid = player.getUniqueId();
        if (giveInFlight.contains(uuid)) {
            // A give for this player landed moments ago and its
            // verification is still running (see doGive): swallow
            // the click like a cooldown click. Without this guard a
            // fast second confirm could dispatch a second give in
            // the window before Magic's record flips to holding.
            return true;
        }
        long now = System.currentTimeMillis();
        // A live offer plus a fresh click is the Java confirm step;
        // a Bedrock player who clicks the villager instead of the
        // form button gets the same answer. The offer is consumed
        // and the gate re-checked at this instant - the offer alone
        // never gives anything.
        if (issueFlow.hasLiveOffer(uuid, now)) {
            issueFlow.confirm(uuid, now);
            return resolveConfirm(player, seals);
        }
        WandIssueGate.Verdict verdict = gateVerdict(player, seals);
        switch (verdict) {
            case OFFER -> {
                presentOffer(player);
                return true;
            }
            case DECLINE_HOLDER -> {
                if (declineShown.add(uuid)) {
                    presentIssueLine(player, holderLine);
                    return true;
                }
                return false;
            }
            case DECLINE_GONE -> {
                if (declineShown.add(uuid)) {
                    presentIssueLine(player, goneLine);
                    return true;
                }
                return false;
            }
            case BLOCKED -> {
                if (declineShown.add(uuid)) {
                    presentIssueLine(player, blockedLine);
                    return true;
                }
                return false;
            }
            default -> {
                return false;
            }
        }
    }

    /** The confirm step's answer, once the pending offer is consumed. */
    private boolean resolveConfirm(Player player, int seals) {
        WandIssueGate.Verdict verdict = gateVerdict(player, seals);
        switch (verdict) {
            case OFFER -> {
                doGive(player);
                return true;
            }
            case DECLINE_HOLDER -> {
                presentIssueLine(player, holderLine);
                return true;
            }
            case DECLINE_GONE -> {
                presentIssueLine(player, goneLine);
                return true;
            }
            case BLOCKED -> {
                presentIssueLine(player, blockedLine);
                return true;
            }
            default -> {
                // Issue mode itself vanished mid-beat (Magic
                // unloaded between offer and confirm): nothing to
                // answer with - let the click become a tale.
                return false;
            }
        }
    }

    /**
     * Gather the gate's facts and ask for the verdict. The cheap
     * mode prerequisites are checked first; the Magic-record read
     * (the only leg with real cost) runs only when a verdict is
     * actually reachable. An unanswerable pouch folds into the
     * record read as FAILED: every verdict that depends on the
     * pouch being empty (OFFER, DECLINE_GONE) stays closed, while a
     * positive Magic holding proof still declines as a holder.
     */
    private WandIssueGate.Verdict gateVerdict(Player player, int seals) {
        boolean magicPresent = MagicWandRecord.magicPresent();
        if (!wandIssueEnabled || seals < 1 || !magicPresent) {
            return WandIssueGate.decide(wandIssueEnabled, true, seals, magicPresent,
                    false, false, WandIssueGate.MagicRead.FAILED);
        }
        UUID uuid = player.getUniqueId();
        boolean issued = issuedWands.isIssued(uuid);
        Boolean pouch = PouchHoldCheck.pouchHoldsWand(uuid, getLogger());
        MagicWandRecord.Result record = MagicWandRecord.read(player, getLogger());
        WandIssueGate.MagicRead read = switch (record.read()) {
            case HOLDS -> WandIssueGate.MagicRead.HOLDS;
            case NONE -> WandIssueGate.MagicRead.NONE;
            case FAILED -> WandIssueGate.MagicRead.FAILED;
        };
        if (pouch == null) {
            if (read != WandIssueGate.MagicRead.HOLDS) {
                read = WandIssueGate.MagicRead.FAILED;
            }
            return WandIssueGate.decide(true, true, seals, true, issued, false, read);
        }
        return WandIssueGate.decide(true, true, seals, true, issued, pouch, read);
    }

    /**
     * Present the wand offer: his Seal 1 lines, with the confirm
     * affordance for the player's platform - a Take-the-wand button
     * on the Bedrock dialogue form, or the speak-to-him-again
     * prompt in Java chat. The pending offer is recorded either
     * way, so the next plain click confirms on both platforms.
     */
    private void presentOffer(Player player) {
        UUID uuid = player.getUniqueId();
        issueFlow.offer(uuid, System.currentTimeMillis());
        boolean bedrock = BedrockTales.isBedrockPlayer(player, getLogger());
        boolean useDialogue = DialogueFlow.choose(bedrock, dialogueEnabled,
                BedrockTales.formsAvailable()) == DialogueFlow.Presentation.DIALOGUE;
        if (useDialogue) {
            String body = TaleFormText.toFormText(issueLateLine + "\n\n" + issueLine);
            boolean sent = BedrockTales.sendDialogueForm(
                    player, npcName, body, issueTakeButton, closeButton,
                    button -> onOfferButton(uuid, button),
                    () -> onOfferClosed(uuid),
                    getLogger());
            if (sent) {
                return;
            }
            // The form did not go out: fall through to the chat offer.
        }
        player.sendMessage(color(header.replace("{name}", npcName)));
        for (String line : TaleText.splitForChat(issueLateLine)) {
            player.sendMessage(color(line));
        }
        for (String line : TaleText.splitForChat(issueLine)) {
            player.sendMessage(color(line));
        }
        player.sendMessage(color(confirmHint));
    }

    /** Offer-form buttons arrive off-thread; the answer moves on the main thread. */
    private void onOfferButton(UUID uuid, int button) {
        Bukkit.getScheduler().runTask(this, () -> {
            Player player = Bukkit.getPlayer(uuid);
            if (player == null || !player.isOnline()) {
                issueFlow.drop(uuid);
                return;
            }
            if (button != 0) {
                // "Farewell" (and any unexpected index): the offer ends ungiven.
                issueFlow.drop(uuid);
                return;
            }
            if (issueFlow.confirm(uuid, System.currentTimeMillis())) {
                Integer seals = SealWatch.sealsBroken(getLogger());
                if (seals != null) {
                    resolveConfirm(player, seals);
                }
            }
        });
    }

    private void onOfferClosed(UUID uuid) {
        Bukkit.getScheduler().runTask(this, () -> issueFlow.drop(uuid));
    }

    /**
     * The give itself: dispatch the specced console command, then
     * let Magic's own record - not the dispatch return - prove the
     * wand landed before anything is written to the ledger.
     *
     * The verification is deliberately NOT same-tick: Magic hands
     * over the wand item at once, but its bound-wand record flips
     * to holding a beat later (measured on the scratch stack,
     * Oct 21, 2026: a read in the dispatch tick reports NONE, a
     * read seconds later reports HOLDS). So verification retries on
     * a short schedule (about 0.5s, 1.5s, 3.5s, 7.5s), and the
     * player sits in giveInFlight meanwhile - further clicks are
     * swallowed, so no second give can be dispatched inside the
     * window. A give that never verifies records nothing in the
     * ledger and tells the player to come back (their next click
     * re-reads the gate fresh either way); a duplicate can never be
     * un-minted, so this path fails closed every time.
     */
    private void doGive(Player player) {
        UUID uuid = player.getUniqueId();
        String command = "mgive " + player.getName() + " " + wandTemplate;
        boolean dispatched = false;
        try {
            dispatched = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
        } catch (Exception e) {
            getLogger().log(Level.WARNING,
                    "Wand give dispatch threw for " + player.getName() + ".", e);
        }
        if (!dispatched) {
            getLogger().warning("Wand give for " + player.getName()
                    + " did NOT dispatch ('" + command + "' refused). "
                    + "Nothing was recorded in the issued ledger.");
            presentIssueLine(player, blockedLine);
            return;
        }
        giveInFlight.add(uuid);
        scheduleVerify(uuid, 1);
    }

    /** Verification attempt delays in ticks: cumulative ≈ 0.5s, 1.5s, 3.5s, 7.5s. */
    private static final long[] VERIFY_DELAYS_TICKS = {10L, 20L, 40L, 80L};

    private void scheduleVerify(UUID uuid, int attempt) {
        long delay = VERIFY_DELAYS_TICKS[
                Math.min(attempt - 1, VERIFY_DELAYS_TICKS.length - 1)];
        Bukkit.getScheduler().runTaskLater(this, () -> verifyGive(uuid, attempt), delay);
    }

    private void verifyGive(UUID uuid, int attempt) {
        if (!giveInFlight.contains(uuid)) {
            return; // already resolved (or the player quit and it was dropped)
        }
        Player player = Bukkit.getPlayer(uuid);
        if (player == null) {
            giveInFlight.remove(uuid);
            getLogger().info("Wand give verification for " + uuid
                    + " ended: the player left before Magic's record could be "
                    + "confirmed. The gate's Magic-record leg covers them on "
                    + "their next visit either way.");
            return;
        }
        MagicWandRecord.Result after = MagicWandRecord.read(player, getLogger());
        if (after.read() == MagicWandRecord.Read.HOLDS) {
            giveInFlight.remove(uuid);
            issuedWands.record(uuid, player.getName(),
                    System.currentTimeMillis(), wandTemplate);
            saveIssued();
            declineShown.add(uuid); // the teaching replaces the holder line this session
            getLogger().info("Wand issued by the Old Quartermaster: " + player.getName()
                    + " (" + uuid + ") received '" + wandTemplate + "' (bound templates now "
                    + after.templates() + ", verified on attempt " + attempt + ").");
            player.sendMessage(color(header.replace("{name}", npcName)));
            for (String teach : teachLines) {
                for (String line : TaleText.splitForChat(teach)) {
                    player.sendMessage(color(line));
                }
            }
            return;
        }
        if (attempt < VERIFY_DELAYS_TICKS.length) {
            scheduleVerify(uuid, attempt + 1);
            return;
        }
        giveInFlight.remove(uuid);
        getLogger().warning("Wand give for " + player.getName() + " did NOT verify: "
                + "dispatched=true, Magic record after " + attempt + " attempts="
                + after.read() + ". Nothing was recorded in the issued ledger.");
        presentIssueLine(player, blockedLine);
    }

    /** A single verdict line, spoken in chat on both platforms. */
    private void presentIssueLine(Player player, String line) {
        player.sendMessage(color(header.replace("{name}", npcName)));
        for (String part : TaleText.splitForChat(line)) {
            player.sendMessage(color(part));
        }
    }

    /**
     * The 0.2.1 sneak route for one matched sneak-click (see
     * SneakRoute for the rules). Returns true when the click is fully
     * handled here: the trading window was opened for a Java
     * non-editor (event cancelled, so Shopkeepers never runs its
     * editor attempt and never prints the denial), or the click was
     * the twin event of a redirect a moment ago (cancelled, nothing
     * reopened). Returns false for everyone the route passes through -
     * Bedrock players, editors, and every failure - and the caller
     * falls back to the untouched 0.2.0 passthrough.
     */
    private boolean handleSneakTrade(Player player, Entity entity,
                                     PlayerInteractEntityEvent event) {
        boolean bedrock = BedrockTales.isBedrockPlayer(player, getLogger());
        boolean canEdit = false;
        for (String permission : SneakRoute.EDIT_PERMISSIONS) {
            if (player.hasPermission(permission)) {
                canEdit = true;
                break;
            }
        }
        Long last = lastSneakRedirect.get(player.getUniqueId());
        long since = last == null ? -1L : System.currentTimeMillis() - last;
        SneakRoute.Action action = SneakRoute.decide(bedrock, canEdit,
                ShopTradeOpener.apiAvailable(getLogger()), since,
                SneakRoute.DEFAULT_DEBOUNCE_MILLIS);
        switch (action) {
            case OPEN_TRADING -> {
                if (ShopTradeOpener.openTradingWindow(player, entity, getLogger())) {
                    event.setCancelled(true);
                    lastSneakRedirect.put(player.getUniqueId(), System.currentTimeMillis());
                    return true;
                }
                return false; // window refused: status quo beats a dead click
            }
            case CANCEL_ONLY -> {
                event.setCancelled(true);
                return true;
            }
            default -> {
                return false;
            }
        }
    }

    /**
     * Offer the Java voice pack to a freshly joined player, a couple
     * of seconds in (the narrator pack from server.properties gets
     * the login moment to itself). Only confirmed-Java players are
     * offered: unknown platform means no send. At most one offer per
     * join, and PackPrompt's five-chances discipline decides who is
     * asked at all.
     */
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (!javaVoiceEnabled) {
            return;
        }
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> offerJavaPack(player),
                javaSendDelayTicks);
    }

    private void offerJavaPack(Player player) {
        if (!javaVoiceEnabled || !player.isOnline()) {
            return;
        }
        if (!Boolean.FALSE.equals(BedrockTales.bedrockOrNull(player, getLogger()))) {
            return; // Bedrock, or platform unknown: never send
        }
        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();
        PackPrompt.Record record = packPrompt.record(uuid);
        if (PackPrompt.decide(record) != PackPrompt.Action.SEND) {
            return;
        }
        // An accepted player is re-sent the pack silently (their
        // client applies it without any prompt) and the re-send is
        // NOT an offer: no counter text, no count. Everyone else
        // gets a real offer, captioned with its number ("offer N of
        // 5") and counted the moment it is sent.
        boolean accepted = PackPrompt.isAccepted(record);
        String prompt = accepted
                ? javaPackPrompt
                : JavaPack.offerPrompt(javaPackPrompt,
                        PackPrompt.nextOfferNumber(record), PackPrompt.MAX_OFFERS);
        try {
            player.addResourcePack(JavaPack.PACK_ID, javaPackUrl,
                    JavaPack.parseSha1(javaPackSha1), prompt, false);
        } catch (Exception e) {
            getLogger().fine("Could not offer the Java voice pack to "
                    + player.getName() + ": " + e.getMessage());
            return;
        }
        if (!accepted) {
            packPrompt.applySend(uuid, now);
            savePackState();
        }
    }

    /**
     * Track the fate of OUR pack offer only: the event also fires for
     * the narrator pack (server.properties) and any other pack, and
     * those are matched out by the pack id before anything is read
     * into our records.
     */
    @EventHandler
    public void onPackStatus(PlayerResourcePackStatusEvent event) {
        if (!JavaPack.PACK_ID.equals(event.getID())) {
            return;
        }
        JavaPack.Status status = JavaPack.mapStatus(event.getStatus().name());
        if (packPrompt.applyStatus(event.getPlayer().getUniqueId(), status,
                System.currentTimeMillis())) {
            savePackState();
        }
    }

    /**
     * /qm status <player> - the read-only inspection half of the
     * console-admin surface (0.3.1; Mike's Nov 3, 2026 rule). The
     * plugin.yml permission (excelquartermaster.admin) is checked
     * by Bukkit before this runs, console included in the allowed
     * callers as always; the reply text lives in PackStatus and is
     * formatted from the player's real PackPrompt record. Target
     * resolution is packreset's, unchanged: online player name
     * first, then a raw UUID (for offline players). The lookup
     * mutates nothing and creates no record: PackPrompt.record is
     * a plain map read, and nothing here is ever saved.
     */
    private boolean handleStatus(CommandSender sender, String target) {
        UUID uuid = null;
        String display = target;
        Player online = Bukkit.getPlayerExact(target);
        if (online != null) {
            uuid = online.getUniqueId();
            display = online.getName();
        } else {
            try {
                uuid = UUID.fromString(target);
            } catch (IllegalArgumentException notUuid) {
                sender.sendMessage("No online player named '" + target
                        + "', and it is not a UUID. Nothing was looked up.");
                return true;
            }
        }
        sender.sendMessage(PackStatus.messageFor(packPrompt.record(uuid), display, uuid));
        return true;
    }

    /**
     * /qm packreset <player|all> - the manual escape hatch for the
     * five-chances rule (Mike's follow-up, Oct 19, 2026). The
     * plugin.yml permission (excelquartermaster.admin) is checked
     * by Bukkit before this runs, console included in the allowed
     * callers as always; the semantics and the exact reply texts
     * live in PackReset. A target resolves by online player name
     * first, then as a raw UUID (for offline players); "all" clears
     * every non-accepted record and reports the counts.
     *
     * /qm status <player> (0.3.1) is dispatched before the
     * packreset shape check; a bare or malformed /qm prints both
     * usage lines.
     */
    @Override
    public boolean onCommand(CommandSender sender, Command command,
                             String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("qm")) {
            return false;
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("status")) {
            return handleStatus(sender, args[1]);
        }
        if (args.length != 2 || !args[0].equalsIgnoreCase("packreset")) {
            sender.sendMessage(PackReset.USAGE);
            sender.sendMessage(PackStatus.USAGE);
            return true;
        }
        String target = args[1];
        if (target.equalsIgnoreCase("all")) {
            PackReset.AllResult result = PackReset.resetAll(packPrompt);
            if (result.resetCount() > 0) {
                savePackState();
            }
            sender.sendMessage(PackReset.messageForAll(result));
            getLogger().info("Pack offers reset (all) by " + sender.getName()
                    + ": " + PackReset.messageForAll(result));
            return true;
        }
        UUID uuid = null;
        String display = target;
        Player online = Bukkit.getPlayerExact(target);
        if (online != null) {
            uuid = online.getUniqueId();
            display = online.getName();
        } else {
            try {
                uuid = UUID.fromString(target);
            } catch (IllegalArgumentException notUuid) {
                sender.sendMessage("No online player named '" + target
                        + "', and it is not a UUID. Nothing was reset.");
                return true;
            }
        }
        PackReset.Single result = PackReset.resetOne(packPrompt, uuid);
        if (result == PackReset.Single.RESET) {
            savePackState();
        }
        sender.sendMessage(PackReset.messageFor(result, display));
        getLogger().info("Pack offers reset by " + sender.getName()
                + " for " + display + " (" + uuid + "): " + result);
        return true;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        dialogue.drop(event.getPlayer().getUniqueId());
        lastSneakRedirect.remove(event.getPlayer().getUniqueId());
        issueFlow.drop(event.getPlayer().getUniqueId());
        declineShown.remove(event.getPlayer().getUniqueId());
        giveInFlight.remove(event.getPlayer().getUniqueId());
    }

    /**
     * Present one tale from the active set. Bedrock players get the dialogue form (plus the
     * recorded voice) when the whole chain is available; everyone else -
     * and every failure along the Bedrock chain - gets the 0.1.0 chat
     * tale. A Bedrock player whose form failed still hears the voice
     * alongside the chat tale when voice is on: the two channels are
     * independent, and either one working beats a silent tap. Java
     * players on the chat tale hear the same clip through the Java
     * voice pack when they have accepted it (0.2.1); without the pack
     * the sound name is unknown to their client and stays silent.
     *
     * Seal-era tales are text-only on purpose: the voice packs carry
     * clips for the eleven pre-seal tales, indexed by position, and
     * playing clip N against a different line would put the wrong
     * words in his mouth. Until Seal-era clips are recorded, the
     * seal-era set never triggers a sound.
     */
    private void tell(Player player, int taleIndex, List<String> activeTales,
                      boolean sealEra) {
        UUID uuid = player.getUniqueId();
        boolean bedrock = BedrockTales.isBedrockPlayer(player, getLogger());
        boolean useDialogue = DialogueFlow.choose(bedrock, dialogueEnabled,
                BedrockTales.formsAvailable()) == DialogueFlow.Presentation.DIALOGUE;
        if (useDialogue) {
            DialogueFlow.Session session = dialogue.open(uuid, taleIndex,
                    System.currentTimeMillis());
            if (presentDialogue(player, session.generation(), taleIndex, true,
                    activeTales, sealEra)) {
                return;
            }
            // The form did not go out: end the session and fall through
            // to the chat tale below.
            dialogue.close(uuid, session.generation());
        }
        sendChatTale(player, taleIndex, activeTales);
        if (sealEra) {
            return; // no recordings exist for the Seal 1 lines: never fake his voice
        }
        if (bedrock && voiceEnabled) {
            playTaleSound(player, taleIndex);
        } else if (!bedrock && javaVoiceEnabled) {
            playTaleSound(player, taleIndex);
        }
    }

    /** The 0.1.0 chat presentation, unchanged. */
    private void sendChatTale(Player player, int taleIndex, List<String> activeTales) {
        player.sendMessage(color(header.replace("{name}", npcName)));
        for (String line : TaleText.splitForChat(
                activeTales.get(Math.floorMod(taleIndex, activeTales.size())))) {
            player.sendMessage(color(line));
        }
    }

    /**
     * Send (or re-send) the dialogue form for one tale in a live
     * session, playing the tale's voice clip when asked and enabled.
     * Returns false when the form could not be sent.
     */
    private boolean presentDialogue(Player player, int generation, int taleIndex,
                                    boolean withVoice, List<String> activeTales,
                                    boolean sealEra) {
        UUID uuid = player.getUniqueId();
        boolean sent = BedrockTales.sendDialogueForm(
                player, npcName, TaleFormText.toFormText(
                        activeTales.get(Math.floorMod(taleIndex, activeTales.size()))),
                nextButton, closeButton,
                button -> onDialogueButton(uuid, generation, button),
                () -> onDialogueClosed(uuid, generation),
                getLogger());
        if (sent && withVoice && voiceEnabled && !sealEra) {
            playTaleSound(player, taleIndex);
        }
        return sent;
    }

    /** Form button callbacks arrive off-thread; game state moves on the main thread. */
    private void onDialogueButton(UUID uuid, int generation, int button) {
        Bukkit.getScheduler().runTask(this, () -> {
            Player player = Bukkit.getPlayer(uuid);
            if (player == null || !player.isOnline()) {
                dialogue.drop(uuid);
                return;
            }
            if (button == 0) {
                advanceDialogue(player, generation);
            } else {
                // "Farewell" (and any unexpected index): end politely.
                dialogue.close(uuid, generation);
            }
        });
    }

    private void onDialogueClosed(UUID uuid, int generation) {
        Bukkit.getScheduler().runTask(this, () -> dialogue.close(uuid, generation));
    }

    /**
     * "Another tale" was pressed. The rotation itself decides which
     * tale is next; DialogueFlow owns the session and the anti-spam
     * floor. Tales advanced this way are committed to the rotation (and
     * re-stamp its cooldown clock), so the conversation and later taps
     * stay consistent.
     */
    private void advanceDialogue(Player player, int generation) {
        UUID uuid = player.getUniqueId();
        DialogueFlow.Session session = dialogue.session(uuid);
        if (session == null || session.generation() != generation) {
            return; // stale form: a newer dialogue (or none) owns this player now
        }
        // The tale set is re-read at advance time, like at click
        // time: if the era turned mid-conversation, the dialogue
        // continues on the now-active set (indices are modulo-safe
        // at presentation).
        Integer seals = SealWatch.sealsBroken(getLogger());
        boolean sealEra = WandIssueGate.sealOneTales(
                seals != null, seals == null ? 0 : seals);
        List<String> activeTales = sealEra ? talesSeal1 : tales;
        int next = rotation.peekNextIndex(uuid, activeTales.size());
        if (next < 0) {
            dialogue.close(uuid, generation);
            return;
        }
        long now = System.currentTimeMillis();
        DialogueFlow.Advance advance = dialogue.advance(uuid, generation, next, now,
                advanceCooldownMillis);
        switch (advance) {
            case ADVANCED -> {
                rotation.commitTold(uuid, next, now);
                saveRotation();
                if (!presentDialogue(player, generation, next, true, activeTales, sealEra)) {
                    dialogue.close(uuid, generation);
                }
            }
            case TOO_FAST -> {
                // Re-present the tale already on screen; no rotation
                // change and no voice replay.
                if (!presentDialogue(player, generation, session.taleIndex(), false,
                        activeTales, sealEra)) {
                    dialogue.close(uuid, generation);
                }
            }
            case NO_SESSION -> {
                // Superseded between the session read and the advance.
            }
        }
    }

    /**
     * Play the tale's recorded clip to this player. The name resolves
     * through whichever voice pack the player's platform carries -
     * the Bedrock .mcpack via Geyser, or the Java .zip offered at
     * join. Fire-and-forget by design: a client without the pack
     * simply stays silent.
     */
    private void playTaleSound(Player player, int taleIndex) {
        String sound = SoundNames.soundFor(soundPrefix, taleIndex);
        if (sound == null) {
            return;
        }
        try {
            player.playSound(player.getLocation(), sound, SoundCategory.MASTER, 1.0f, 1.0f);
        } catch (Exception e) {
            getLogger().fine("Could not play tale sound " + sound + ": " + e.getMessage());
        }
    }

    private void saveRotation() {
        if (dataFile == null) {
            return;
        }
        try {
            TaleStore.save(dataFile.toPath(), rotation.snapshot());
        } catch (IOException e) {
            getLogger().log(Level.WARNING, "Could not save tale rotation to "
                    + dataFile.getName() + ".", e);
        }
    }

    private void savePackState() {
        if (packStateFile == null) {
            return;
        }
        try {
            PackStateStore.save(packStateFile.toPath(), packPrompt.snapshot());
        } catch (IOException e) {
            getLogger().log(Level.WARNING, "Could not save Java pack state to "
                    + packStateFile.getName() + ".", e);
        }
    }

    private void saveIssued() {
        if (issuedFile == null) {
            return;
        }
        try {
            IssuedWandStore.save(issuedFile.toPath(), issuedWands.snapshot());
        } catch (IOException e) {
            getLogger().log(Level.WARNING, "Could not save the issued-wand ledger to "
                    + issuedFile.getName() + ". The give still landed and Magic's "
                    + "record still guards the duplicate; the ledger heals on the "
                    + "next successful save.", e);
        }
    }

    private static String fmt(double value) {
        return value == Math.rint(value) ? Long.toString(Math.round(value)) : Double.toString(value);
    }

    private static String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }
}
