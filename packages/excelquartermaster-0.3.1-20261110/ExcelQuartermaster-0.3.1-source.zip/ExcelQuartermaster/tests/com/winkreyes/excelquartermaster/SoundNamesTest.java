package com.winkreyes.excelquartermaster;

/**
 * Plain main-method test harness for SoundNames (same style as the other
 * ExcelQuartermaster harnesses). Run via run-tests.sh.
 */
public final class SoundNamesTest {

    private static int checks = 0;
    private static int failures = 0;

    private static void check(String name, boolean condition) {
        checks++;
        if (!condition) {
            failures++;
            System.out.println("FAIL: " + name);
        }
    }

    private static void checkEq(String name, Object expected, Object actual) {
        checks++;
        if (!java.util.Objects.equals(expected, actual)) {
            failures++;
            System.out.println("FAIL: " + name + " expected=" + expected + " actual=" + actual);
        }
    }

    public static void main(String[] args) {
        mappingIsOneBased();
        everyPackClipIsReachable();
        customPrefixIsHonored();
        unusableInputsReturnNull();
        clipBounds();
        System.out.println("SoundNamesTest: " + (checks - failures) + "/" + checks
                + " checks passed" + (failures == 0 ? " - ALL PASS" : " - " + failures + " FAILED"));
        if (failures > 0) {
            System.exit(1);
        }
    }

    private static void mappingIsOneBased() {
        checkEq("map: tale index 0", "wrv:quartermaster.tale1",
                SoundNames.soundFor(SoundNames.DEFAULT_PREFIX, 0));
        checkEq("map: tale index 1", "wrv:quartermaster.tale2",
                SoundNames.soundFor(SoundNames.DEFAULT_PREFIX, 1));
        checkEq("map: tale index 10", "wrv:quartermaster.tale11",
                SoundNames.soundFor(SoundNames.DEFAULT_PREFIX, 10));
    }

    private static void everyPackClipIsReachable() {
        // The pack defines tale1..tale11; the names the plugin can ask
        // for over the recorded range must be exactly that set.
        for (int i = 0; i < SoundNames.PACK_CLIP_COUNT; i++) {
            checkEq("pack clip " + (i + 1), "wrv:quartermaster.tale" + (i + 1),
                    SoundNames.soundFor(SoundNames.DEFAULT_PREFIX, i));
        }
        checkEq("pack clip count is 11", 11, SoundNames.PACK_CLIP_COUNT);
        checkEq("default prefix", "wrv:quartermaster.tale", SoundNames.DEFAULT_PREFIX);
    }

    private static void customPrefixIsHonored() {
        checkEq("custom prefix", "wrv:other.tale3", SoundNames.soundFor("wrv:other.tale", 2));
    }

    private static void unusableInputsReturnNull() {
        checkEq("null prefix", null, SoundNames.soundFor(null, 0));
        checkEq("empty prefix", null, SoundNames.soundFor("", 0));
        checkEq("blank prefix", null, SoundNames.soundFor("   ", 0));
        checkEq("negative index", null, SoundNames.soundFor(SoundNames.DEFAULT_PREFIX, -1));
    }

    private static void clipBounds() {
        check("clip: index 0 has one", SoundNames.hasClip(0));
        check("clip: index 10 has one", SoundNames.hasClip(10));
        check("clip: index 11 has none", !SoundNames.hasClip(11));
        check("clip: negative has none", !SoundNames.hasClip(-1));
        // Beyond the pack the name still forms (fail-soft: the client
        // has no definition and stays silent; text still arrives).
        checkEq("beyond pack still names", "wrv:quartermaster.tale12",
                SoundNames.soundFor(SoundNames.DEFAULT_PREFIX, 11));
    }
}
