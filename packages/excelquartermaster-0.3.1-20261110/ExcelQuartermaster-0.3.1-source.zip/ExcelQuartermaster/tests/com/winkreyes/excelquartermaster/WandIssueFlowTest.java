package com.winkreyes.excelquartermaster;

import java.util.UUID;

/**
 * Plain main-method test harness for WandIssueFlow (same style as
 * the other ExcelQuartermaster harnesses: no test framework, every
 * check counted, any failure prints and exits the JVM with status 1).
 *
 * The offer window is the deliberate-confirm discipline: a give can
 * only be answered while an offer stands, a confirm consumes the
 * offer exactly once, and an expired offer confirms nothing.
 *
 * Run via run-tests.sh.
 */
public final class WandIssueFlowTest {

    private static int checks = 0;
    private static int failures = 0;

    private static void check(String name, boolean condition) {
        checks++;
        if (!condition) {
            failures++;
            System.out.println("FAIL: " + name);
        }
    }

    private static final UUID A = UUID.fromString("11111111-1111-1111-1111-111111111111");
    private static final UUID B = UUID.fromString("22222222-2222-2222-2222-222222222222");
    private static final long WINDOW = 60_000L;

    public static void main(String[] args) {
        offerAndConfirm();
        expiry();
        refreshAndDrop();
        System.out.println("WandIssueFlowTest: " + (checks - failures) + "/" + checks
                + " checks passed" + (failures == 0 ? " - ALL PASS" : " - " + failures + " FAILED"));
        if (failures > 0) {
            System.exit(1);
        }
    }

    private static void offerAndConfirm() {
        WandIssueFlow flow = new WandIssueFlow(WINDOW);
        long t0 = 1_000_000L;
        check("no offer: nothing live", !flow.hasLiveOffer(A, t0));
        check("no offer: confirm refuses", !flow.confirm(A, t0));
        flow.offer(A, t0);
        check("offer stands", flow.hasLiveOffer(A, t0 + 1_000L));
        checkEqCount("one pending", 1, flow);
        check("confirm inside window", flow.confirm(A, t0 + 30_000L));
        check("confirm consumed the offer", !flow.hasLiveOffer(A, t0 + 30_000L));
        check("second confirm refuses (exactly once)", !flow.confirm(A, t0 + 31_000L));
        check("other player unaffected", !flow.hasLiveOffer(B, t0));
    }

    private static void expiry() {
        WandIssueFlow flow = new WandIssueFlow(WINDOW);
        long t0 = 5_000_000L;
        flow.offer(A, t0);
        check("live at the window edge", flow.hasLiveOffer(A, t0 + WINDOW));
        check("expired past the window", !flow.hasLiveOffer(A, t0 + WINDOW + 1L));
        check("expired offer confirms nothing", !flow.confirm(A, t0 + WINDOW + 2L));
        checkEqCount("expiry dropped the record", 0, flow);

        WandIssueFlow zero = new WandIssueFlow(0L);
        zero.offer(A, t0);
        check("zero window: live at the same instant", zero.hasLiveOffer(A, t0));
        check("zero window: dead a tick later", !zero.hasLiveOffer(A, t0 + 1L));

        WandIssueFlow negative = new WandIssueFlow(-5L);
        negative.offer(A, t0);
        check("negative window clamps to zero", negative.hasLiveOffer(A, t0));
    }

    private static void refreshAndDrop() {
        WandIssueFlow flow = new WandIssueFlow(WINDOW);
        long t0 = 9_000_000L;
        flow.offer(A, t0);
        flow.offer(A, t0 + 50_000L); // re-offer refreshes the window
        check("refreshed offer outlives the first window",
                flow.hasLiveOffer(A, t0 + WINDOW + 1L));
        check("refreshed offer still dies on its own clock",
                !flow.hasLiveOffer(A, t0 + 50_000L + WINDOW + 1L));
        flow.offer(B, t0);
        flow.drop(B);
        check("drop clears", !flow.hasLiveOffer(B, t0));
        flow.drop(null); // must not throw
        flow.offer(null, t0); // must not throw, records nothing
        checkEqCount("null offers record nothing", 0, flow);
    }

    private static void checkEqCount(String name, int expected, WandIssueFlow flow) {
        checks++;
        if (flow.pendingCount() != expected) {
            failures++;
            System.out.println("FAIL: " + name + " expected=" + expected
                    + " actual=" + flow.pendingCount());
        }
    }
}
