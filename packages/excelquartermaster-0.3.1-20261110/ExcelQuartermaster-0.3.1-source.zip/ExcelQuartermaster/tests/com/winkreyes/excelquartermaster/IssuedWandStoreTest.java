package com.winkreyes.excelquartermaster;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.UUID;

/**
 * Plain main-method test harness for IssuedWands + IssuedWandStore
 * (same style as the other ExcelQuartermaster harnesses: no test
 * framework, every check counted, any failure prints and exits the
 * JVM with status 1).
 *
 * The ledger is the exactly-once record: the first record stands,
 * names with spaces (Bedrock gamertags) round-trip, malformed lines
 * never lose the good ones, and the file on disk is sorted and
 * self-explaining.
 *
 * Run via run-tests.sh.
 */
public final class IssuedWandStoreTest {

    private static int checks = 0;
    private static int failures = 0;

    private static void check(String name, boolean condition) {
        checks++;
        if (!condition) {
            failures++;
            System.out.println("FAIL: " + name);
        }
    }

    private static void checkEq(String name, Object expected, Object actual) {
        checks++;
        if (!java.util.Objects.equals(expected, actual)) {
            failures++;
            System.out.println("FAIL: " + name + " expected=" + expected + " actual=" + actual);
        }
    }

    private static final UUID A = UUID.fromString("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa");
    private static final UUID B = UUID.fromString("bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb");
    private static final UUID FLOOD = UUID.fromString("00000000-0000-0000-0009-01feb74ea7be");

    public static void main(String[] args) throws Exception {
        ledgerRules();
        codecRoundTrip();
        forgivingParse();
        fileRoundTrip();
        System.out.println("IssuedWandStoreTest: " + (checks - failures) + "/" + checks
                + " checks passed" + (failures == 0 ? " - ALL PASS" : " - " + failures + " FAILED"));
        if (failures > 0) {
            System.exit(1);
        }
    }

    private static void ledgerRules() {
        IssuedWands ledger = new IssuedWands();
        check("unknown player not issued", !ledger.isIssued(A));
        check("null not issued", !ledger.isIssued(null));
        check("first record writes", ledger.record(A, "Jester_Turtle", 1234L, "beginner"));
        check("now issued", ledger.isIssued(A));
        check("duplicate record refused", !ledger.record(A, "Jester_Turtle", 9999L, "beginner"));
        checkEq("first record stands", 1234L, ledger.entry(A).issuedMillis());
        check("null id refused", !ledger.record(null, "x", 1L, "beginner"));
        checkEq("size", 1, ledger.size());

        IssuedWands messy = new IssuedWands();
        messy.record(B, "  Many   Spaces\nName ", -50L, "  ");
        checkEq("name whitespace collapsed", "Many Spaces Name", messy.entry(B).name());
        checkEq("negative millis clamped", 0L, messy.entry(B).issuedMillis());
        checkEq("blank template defaults", "beginner", messy.entry(B).template());
    }

    private static void codecRoundTrip() {
        IssuedWands ledger = new IssuedWands();
        ledger.record(B, ".Sun Flower", 2000L, "beginner");       // Bedrock-style spaced name
        ledger.record(A, "Jester_Turtle", 1000L, "beginner");
        ledger.record(FLOOD, ".MikeExcel", 3000L, "beginner");
        String text = IssuedWandStore.serialize(ledger.snapshot());
        check("header explains the file", text.startsWith("# ExcelQuartermaster issued wands"));
        check("header warns against deleting lines", text.contains("never delete a"));
        int posA = text.indexOf(A.toString());
        int posF = text.indexOf(FLOOD.toString());
        int posB = text.indexOf(B.toString());
        check("sorted by uuid string", posF >= 0 && posF < posA && posA < posB);
        Map<UUID, IssuedWands.Entry> back = IssuedWandStore.parse(text);
        checkEq("round trip size", 3, back.size());
        checkEq("spaced name survives", ".Sun Flower", back.get(B).name());
        checkEq("floodgate name survives", ".MikeExcel", back.get(FLOOD).name());
        checkEq("millis survive", 1000L, back.get(A).issuedMillis());
        checkEq("template survives", "beginner", back.get(A).template());
        check("empty ledger serializes to header only",
                IssuedWandStore.parse(IssuedWandStore.serialize(Map.of())).isEmpty());
    }

    private static void forgivingParse() {
        String text = "# a comment\n"
                + "\n"
                + "   \n"
                + "not-a-uuid 100 beginner Name\n"
                + A + " notanumber beginner Name\n"
                + A + " 100\n"                       // too few fields
                + A + " 777 beginner First\n"
                + A + " 888 beginner Second\n"        // duplicate: first wins
                + B + " -5 beginner Neg\n"
                + FLOOD + " 42 beginner\n";           // no name: allowed
        Map<UUID, IssuedWands.Entry> parsed = IssuedWandStore.parse(text);
        checkEq("only good lines survive", 3, parsed.size());
        checkEq("duplicate uuid: first wins", 777L, parsed.get(A).issuedMillis());
        checkEq("first name wins too", "First", parsed.get(A).name());
        checkEq("negative millis clamped", 0L, parsed.get(B).issuedMillis());
        checkEq("missing name is empty", "", parsed.get(FLOOD).name());
        check("null text parses empty", IssuedWandStore.parse(null).isEmpty());
        check("blank text parses empty", IssuedWandStore.parse("  \n ").isEmpty());
    }

    private static void fileRoundTrip() throws Exception {
        Path dir = Files.createTempDirectory("issued-wands-test");
        Path file = dir.resolve("nested/issued-wands.txt");
        IssuedWands ledger = new IssuedWands();
        ledger.record(A, "Jester_Turtle", 4242L, "beginner");
        IssuedWandStore.save(file, ledger.snapshot());
        check("save creates parent folders", Files.exists(file));
        Map<UUID, IssuedWands.Entry> loaded = IssuedWandStore.load(file);
        checkEq("file round trip", 4242L, loaded.get(A).issuedMillis());
        check("missing file loads empty",
                IssuedWandStore.load(dir.resolve("nope.txt")).isEmpty());
        IssuedWands restored = new IssuedWands();
        restored.restore(loaded);
        check("restore fills the ledger", restored.isIssued(A));
        Map<UUID, IssuedWands.Entry> snap = restored.snapshot();
        snap.clear();
        check("snapshot is a copy", restored.isIssued(A));
        Files.deleteIfExists(file);
        Files.deleteIfExists(file.getParent());
        Files.deleteIfExists(dir);
    }
}
