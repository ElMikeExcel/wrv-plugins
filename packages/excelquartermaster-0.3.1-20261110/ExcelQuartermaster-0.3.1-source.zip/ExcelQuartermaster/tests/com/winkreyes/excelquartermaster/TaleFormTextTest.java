package com.winkreyes.excelquartermaster;

/**
 * Plain main-method test harness for TaleFormText (same style as the
 * other ExcelQuartermaster harnesses). Run via run-tests.sh.
 */
public final class TaleFormTextTest {

    private static int checks = 0;
    private static int failures = 0;

    private static void check(String name, boolean condition) {
        checks++;
        if (!condition) {
            failures++;
            System.out.println("FAIL: " + name);
        }
    }

    private static void checkEq(String name, Object expected, Object actual) {
        checks++;
        if (!java.util.Objects.equals(expected, actual)) {
            failures++;
            System.out.println("FAIL: " + name + " expected=" + expected + " actual=" + actual);
        }
    }

    public static void main(String[] args) {
        ampersandCodesBecomeSectionCodes();
        proseAmpersandsSurvive();
        everyShippedTaleConvertsCleanly();
        System.out.println("TaleFormTextTest: " + (checks - failures) + "/" + checks
                + " checks passed" + (failures == 0 ? " - ALL PASS" : " - " + failures + " FAILED"));
        if (failures > 0) {
            System.exit(1);
        }
    }

    private static void ampersandCodesBecomeSectionCodes() {
        checkEq("form: &7 prefix", "§7Sit a moment.", TaleFormText.toFormText("&7Sit a moment."));
        checkEq("form: mid-string code", "plain §6gold§r done",
                TaleFormText.toFormText("plain &6gold&r done"));
        checkEq("form: uppercase code", "§Lbold", TaleFormText.toFormText("&Lbold"));
        checkEq("form: no codes is identity", "Just a tale.", TaleFormText.toFormText("Just a tale."));
        checkEq("form: already section-coded stays", "§7done", TaleFormText.toFormText("§7done"));
    }

    private static void proseAmpersandsSurvive() {
        checkEq("form: lone ampersand", "fish & chips", TaleFormText.toFormText("fish & chips"));
        checkEq("form: trailing ampersand", "salt &", TaleFormText.toFormText("salt &"));
        checkEq("form: ampersand before non-code", "R&Q dept", TaleFormText.toFormText("R&Q dept"));
        checkEq("form: &d IS a code (matches chat)", "R§d dept", TaleFormText.toFormText("R&d dept"));
        checkEq("form: null", "", TaleFormText.toFormText(null));
        checkEq("form: empty", "", TaleFormText.toFormText(""));
    }

    private static void everyShippedTaleConvertsCleanly() {
        // The 11 shipped tales all start with &7 and carry no other
        // ampersands: each must convert to a §7-led string with no &
        // left behind, and the visible text must be unchanged.
        String[] tales = {
            "&7Sit a moment. I kept the stores for the Adventurers Guild, back when its doors stood open and the road was never quiet.",
            "&7Five seals hold that guild now. A dragon, a wither, an old guardian of the deep, the thing that hunts by sound, and a village that must be defended. Break them all, and the doors open.",
            "&7You have seen the guild's name in your menu, grey and locked. That is no decoration. That is a promise the valley made.",
            "&7In my day, magic ran free through this valley like water in a river. Everything drank from it. Everything.",
            "&7Aye, the monsters too. The beasts of my time were stronger than yours, because the magic fed them same as it fed us. Many a good adventurer learned that the hard way.",
            "&7Magic is a double-edged sword, young one. It lifts the hand that holds it, and it sharpens what comes at that hand.",
            "&7You are wondering about wands. I can see it. When the first seal falls, come back to me. My old stores are not as empty as they look.",
            "&7A wand is not a toy and not a treasure. It is a promise you make to the valley. I only hand them to those the valley has already called. The seals will do the calling.",
            "&7Start with the dragon, when you are ready. The End is far, but every road to the guild starts with a single broken seal.",
            "&7What is coming back to this valley now is stronger than what I knew. Ours was a river. Yours will be a flood. Mind it treats you kindly, and mind what it wakes up.",
            "&7Train hard while the days are kind. Skills, gear, a full belly and good company. The seals are not beaten by heroes. They are beaten by families.",
        };
        checkEq("shipped tales counted", SoundNames.PACK_CLIP_COUNT, tales.length);
        for (int i = 0; i < tales.length; i++) {
            String form = TaleFormText.toFormText(tales[i]);
            check("tale " + (i + 1) + ": starts with §7", form.startsWith("§7"));
            check("tale " + (i + 1) + ": no ampersand remains", !form.contains("&"));
            checkEq("tale " + (i + 1) + ": visible length preserved",
                    TaleText.visibleLength(tales[i]), TaleText.visibleLength(form));
        }
    }
}
