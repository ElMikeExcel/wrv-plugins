package com.winkreyes.excelquartermaster;

/**
 * Plain main-method test harness for PackPrompt + PackStateStore
 * (same style as the other ExcelQuartermaster harnesses: no test
 * framework, every check counted, any failure prints and exits the
 * JVM with status 1).
 *
 * 0.2.2: the decide discipline is Mike's five-chances rule (Oct 19,
 * 2026). The 0.2.1 checks that pinned the RETIRED discipline
 * (30-day reoffer window, max-3 cap, reoffer boundary timing) were
 * replaced by the five-cap matrix, the no-offer-#6 walks and the
 * 0.2.1-state migration checks; every check that did not pin the
 * retired discipline (send/status flow, store round-trip, forgiving
 * parse) is carried unmodified.
 *
 * Run via run-tests.sh.
 */
public final class PackPromptTest {

    private static final java.util.UUID A =
            java.util.UUID.fromString("11111111-1111-1111-1111-111111111111");
    private static final java.util.UUID B =
            java.util.UUID.fromString("22222222-2222-2222-2222-222222222222");
    private static final java.util.UUID C =
            java.util.UUID.fromString("33333333-3333-3333-3333-333333333333");
    private static final java.util.UUID D =
            java.util.UUID.fromString("44444444-4444-4444-4444-444444444444");
    private static final java.util.UUID E =
            java.util.UUID.fromString("55555555-5555-5555-5555-555555555555");
    private static final java.util.UUID F =
            java.util.UUID.fromString("66666666-6666-6666-6666-666666666666");

    private static int checks = 0;
    private static int failures = 0;

    private static void check(String name, boolean condition) {
        checks++;
        if (!condition) {
            failures++;
            System.out.println("FAIL: " + name);
        }
    }

    private static void checkEq(String name, Object expected, Object actual) {
        checks++;
        if (!java.util.Objects.equals(expected, actual)) {
            failures++;
            System.out.println("FAIL: " + name + " expected=" + expected + " actual=" + actual);
        }
    }

    private static PackPrompt.Record rec(PackPrompt.Outcome o, int attempts, long when) {
        return new PackPrompt.Record(o, attempts, when);
    }

    public static void main(String[] args) {
        decideMatrix();
        counterHelpers();
        fiveCapWalks();
        migrationFrom021();
        sendAndStatusFlow();
        storeRoundTrip();
        storeForgivingParse();
        System.out.println("PackPromptTest: " + (checks - failures) + "/" + checks
                + " checks passed" + (failures == 0 ? " - ALL PASS" : " - " + failures + " FAILED"));
        if (failures > 0) {
            System.exit(1);
        }
    }

    private static void decideMatrix() {
        long t = 123_456_789L;
        checkEq("the rule is five chances", 5, PackPrompt.MAX_OFFERS);
        checkEq("no record: send (offer 1)", PackPrompt.Action.SEND,
                PackPrompt.decide(null));
        checkEq("loaded: silent re-send", PackPrompt.Action.SEND,
                PackPrompt.decide(rec(PackPrompt.Outcome.LOADED, 1, t)));
        checkEq("loaded past the cap: still the silent re-send", PackPrompt.Action.SEND,
                PackPrompt.decide(rec(PackPrompt.Outcome.LOADED, 9, t)));
        checkEq("sent, chances left: send", PackPrompt.Action.SEND,
                PackPrompt.decide(rec(PackPrompt.Outcome.SENT, 1, t)));
        checkEq("sent, on the last chance: send", PackPrompt.Action.SEND,
                PackPrompt.decide(rec(PackPrompt.Outcome.SENT, 4, t)));
        checkEq("sent, all five used: skip", PackPrompt.Action.SKIP,
                PackPrompt.decide(rec(PackPrompt.Outcome.SENT, 5, t)));
        checkEq("declined once: send (a decline costs one chance, not all)",
                PackPrompt.Action.SEND,
                PackPrompt.decide(rec(PackPrompt.Outcome.DECLINED, 1, t)));
        checkEq("declined, on the last chance: send", PackPrompt.Action.SEND,
                PackPrompt.decide(rec(PackPrompt.Outcome.DECLINED, 4, t)));
        checkEq("declined, all five used: skip forever", PackPrompt.Action.SKIP,
                PackPrompt.decide(rec(PackPrompt.Outcome.DECLINED, 5, t)));
        checkEq("failed, chances left: send", PackPrompt.Action.SEND,
                PackPrompt.decide(rec(PackPrompt.Outcome.FAILED, 4, t)));
        checkEq("failed, all five used: skip forever", PackPrompt.Action.SKIP,
                PackPrompt.decide(rec(PackPrompt.Outcome.FAILED, 5, t)));
        // No clock in the new discipline: a record stamped long ago
        // and one stamped just now with the same count decide alike
        // (the matrix above already spans both shapes; this pins the
        // ancient-decline case the 30-day window used to resurrect).
        checkEq("ancient decline under the cap: send (no window needed)",
                PackPrompt.Action.SEND,
                PackPrompt.decide(rec(PackPrompt.Outcome.DECLINED, 2, 1L)));
        checkEq("over-count record from 0.2.1 re-sends: skip", PackPrompt.Action.SKIP,
                PackPrompt.decide(rec(PackPrompt.Outcome.SENT, 7, t)));
    }

    private static void counterHelpers() {
        long t = 999L;
        checkEq("offersUsed of no record", 0, PackPrompt.offersUsed(null));
        checkEq("offersUsed reads the count", 3,
                PackPrompt.offersUsed(rec(PackPrompt.Outcome.SENT, 3, t)));
        checkEq("brand-new player has all five", 5, PackPrompt.offersRemaining(null));
        checkEq("three used, two left", 2,
                PackPrompt.offersRemaining(rec(PackPrompt.Outcome.DECLINED, 3, t)));
        checkEq("five used, none left", 0,
                PackPrompt.offersRemaining(rec(PackPrompt.Outcome.DECLINED, 5, t)));
        checkEq("over-count clamps at none left", 0,
                PackPrompt.offersRemaining(rec(PackPrompt.Outcome.SENT, 7, t)));
        checkEq("accepted player needs no more chances", 0,
                PackPrompt.offersRemaining(rec(PackPrompt.Outcome.LOADED, 2, t)));
        check("loaded means accepted",
                PackPrompt.isAccepted(rec(PackPrompt.Outcome.LOADED, 1, t)));
        check("declined is not accepted",
                !PackPrompt.isAccepted(rec(PackPrompt.Outcome.DECLINED, 1, t)));
        check("no record is not accepted", !PackPrompt.isAccepted(null));
        checkEq("first offer is number 1", 1, PackPrompt.nextOfferNumber(null));
        checkEq("next number counts up", 3,
                PackPrompt.nextOfferNumber(rec(PackPrompt.Outcome.SENT, 2, t)));
        checkEq("fifth offer is number 5", 5,
                PackPrompt.nextOfferNumber(rec(PackPrompt.Outcome.FAILED, 4, t)));
    }

    /**
     * The no-offer-#6 guarantee, walked end to end the way the wiring
     * walks it: decide -> (counter) -> applySend -> applyStatus, once
     * per join. Whatever the player does - declines, vanishes
     * mid-download, or fails - the sixth join is silent.
     */
    private static void fiveCapWalks() {
        // Walk 1: the tap-spammer who declines all five.
        PackPrompt pp = new PackPrompt();
        for (int offer = 1; offer <= 5; offer++) {
            checkEq("decline walk: offer " + offer + " is sent", PackPrompt.Action.SEND,
                    PackPrompt.decide(pp.record(A)));
            checkEq("decline walk: offer " + offer + " carries its number",
                    offer, PackPrompt.nextOfferNumber(pp.record(A)));
            pp.applySend(A, offer * 1_000L);
            pp.applyStatus(A, JavaPack.Status.DECLINED, offer * 1_000L + 1);
        }
        checkEq("decline walk: no offer 6", PackPrompt.Action.SKIP,
                PackPrompt.decide(pp.record(A)));
        checkEq("decline walk: no chances left", 0, PackPrompt.offersRemaining(pp.record(A)));

        // Walk 2: the ghost - sends happen, no status ever arrives.
        PackPrompt ghost = new PackPrompt();
        for (int offer = 1; offer <= 5; offer++) {
            checkEq("ghost walk: offer " + offer + " is sent", PackPrompt.Action.SEND,
                    PackPrompt.decide(ghost.record(B)));
            ghost.applySend(B, offer * 1_000L);
        }
        checkEq("ghost walk: five offers recorded", 5,
                PackPrompt.offersUsed(ghost.record(B)));
        checkEq("ghost walk: no offer 6", PackPrompt.Action.SKIP,
                PackPrompt.decide(ghost.record(B)));

        // Walk 3: the flaky connection - every download fails.
        PackPrompt flaky = new PackPrompt();
        for (int offer = 1; offer <= 5; offer++) {
            checkEq("failed walk: offer " + offer + " is sent", PackPrompt.Action.SEND,
                    PackPrompt.decide(flaky.record(C)));
            flaky.applySend(C, offer * 1_000L);
            flaky.applyStatus(C, JavaPack.Status.FAILED, offer * 1_000L + 1);
        }
        checkEq("failed walk: no offer 6", PackPrompt.Action.SKIP,
                PackPrompt.decide(flaky.record(C)));

        // Walk 4: decline, decline, accept - terminal, count frozen.
        PackPrompt late = new PackPrompt();
        late.applySend(D, 1_000L);
        late.applyStatus(D, JavaPack.Status.DECLINED, 1_001L);
        late.applySend(D, 2_000L);
        late.applyStatus(D, JavaPack.Status.DECLINED, 2_001L);
        late.applySend(D, 3_000L);
        late.applyStatus(D, JavaPack.Status.LOADED, 3_001L);
        check("accept walk: accepted", PackPrompt.isAccepted(late.record(D)));
        checkEq("accept walk: decide still re-sends silently", PackPrompt.Action.SEND,
                PackPrompt.decide(late.record(D)));
        checkEq("accept walk: no chances shown as left", 0,
                PackPrompt.offersRemaining(late.record(D)));
        // A later LOADED status (the silent re-send landing) must
        // not move the frozen offer count.
        late.applyStatus(D, JavaPack.Status.LOADED, 9_999L);
        checkEq("accept walk: count frozen at 3", 3, PackPrompt.offersUsed(late.record(D)));
    }

    /**
     * Migration: state files written by 0.2.1 (same line format -
     * uuid, outcome, attempts, millis) load as-is, and every offer
     * 0.2.1 already recorded counts toward the five.
     */
    private static void migrationFrom021() {
        String state021 = A + " LOADED 3 172800000\n"
                + B + " DECLINED 3 172800000\n"
                + C + " SENT 0 172800000\n"
                + D + " DECLINED 5 172800000\n"
                + E + " SENT 7 172800000\n"
                + F + " FAILED 4 172800000\n";
        java.util.Map<java.util.UUID, PackPrompt.Record> parsed = PackStateStore.parse(state021);
        checkEq("all six 0.2.1 records parse", 6, parsed.size());

        check("migrated accept stays accepted", PackPrompt.isAccepted(parsed.get(A)));
        checkEq("migrated accept: no chances left (and none needed)", 0,
                PackPrompt.offersRemaining(parsed.get(A)));
        checkEq("migrated accept: silent re-send only", PackPrompt.Action.SEND,
                PackPrompt.decide(parsed.get(A)));

        checkEq("migrated 3 offers: exactly 2 left", 2, PackPrompt.offersRemaining(parsed.get(B)));
        PackPrompt migrated = new PackPrompt();
        migrated.restore(parsed);
        migrated.applySend(B, 200_000_000L);
        migrated.applyStatus(B, JavaPack.Status.DECLINED, 200_000_001L);
        checkEq("migrated 3 + 1: still one left", PackPrompt.Action.SEND,
                PackPrompt.decide(migrated.record(B)));
        migrated.applySend(B, 200_100_000L);
        migrated.applyStatus(B, JavaPack.Status.DECLINED, 200_100_001L);
        checkEq("migrated 3 + 2: cap reached, no offer 6", PackPrompt.Action.SKIP,
                PackPrompt.decide(migrated.record(B)));

        checkEq("migrated 0 offers: all five left", 5, PackPrompt.offersRemaining(parsed.get(C)));
        checkEq("migrated 5 declines: nothing left", 0, PackPrompt.offersRemaining(parsed.get(D)));
        checkEq("migrated 5 declines: never offered again", PackPrompt.Action.SKIP,
                PackPrompt.decide(parsed.get(D)));
        checkEq("migrated over-count: never offered again", PackPrompt.Action.SKIP,
                PackPrompt.decide(parsed.get(E)));
        checkEq("migrated 4 failures: exactly 1 left", 1, PackPrompt.offersRemaining(parsed.get(F)));
        checkEq("migrated 4 failures: the last chance is offered", PackPrompt.Action.SEND,
                PackPrompt.decide(parsed.get(F)));
    }

    private static void sendAndStatusFlow() {
        PackPrompt pp = new PackPrompt();
        checkEq("fresh instance tracks nobody", 0, pp.trackedCount());
        checkEq("unknown player has no record", null, pp.record(A));

        PackPrompt.Record sent = pp.applySend(A, 1_000L);
        checkEq("first send: SENT x1", rec(PackPrompt.Outcome.SENT, 1, 1_000L), sent);
        checkEq("record visible after send", sent, pp.record(A));
        pp.applySend(A, 2_000L);
        checkEq("second send: attempts 2, restamped",
                rec(PackPrompt.Outcome.SENT, 2, 2_000L), pp.record(A));

        check("LOADED status changes the record",
                pp.applyStatus(A, JavaPack.Status.LOADED, 3_000L));
        checkEq("after load", rec(PackPrompt.Outcome.LOADED, 2, 3_000L), pp.record(A));
        check("same LOADED again is not a change",
                !pp.applyStatus(A, JavaPack.Status.LOADED, 3_000L));
        check("IGNORED never changes anything",
                !pp.applyStatus(A, JavaPack.Status.IGNORED, 4_000L));
        checkEq("record survives IGNORED", rec(PackPrompt.Outcome.LOADED, 2, 3_000L), pp.record(A));
        check("null status is a no-op", !pp.applyStatus(A, null, 4_000L));
        check("null player send is a no-op", pp.applySend(null, 4_000L) == null);
        check("null player status is a no-op", !pp.applyStatus(null, JavaPack.Status.LOADED, 4_000L));

        check("DECLINED lands", pp.applyStatus(B, JavaPack.Status.DECLINED, 5_000L));
        checkEq("decline without a prior send keeps attempts 0",
                rec(PackPrompt.Outcome.DECLINED, 0, 5_000L), pp.record(B));
        check("FAILED lands over a decline",
                pp.applyStatus(B, JavaPack.Status.FAILED, 6_000L));
        checkEq("statuses never move the offer count", 0, PackPrompt.offersUsed(pp.record(B)));
        checkEq("players are independent", rec(PackPrompt.Outcome.LOADED, 2, 3_000L), pp.record(A));
        checkEq("two players tracked", 2, pp.trackedCount());

        // The new-rule lifecycle in one line: a decline at one offer
        // used means the next join offers again - one chance spent,
        // four to go, no waiting period of any kind.
        PackPrompt life = new PackPrompt();
        life.applySend(A, 0L);
        life.applyStatus(A, JavaPack.Status.DECLINED, 1_000L);
        checkEq("lifecycle: declined once, next join offers again", PackPrompt.Action.SEND,
                PackPrompt.decide(life.record(A)));
        checkEq("lifecycle: four chances remain", 4, PackPrompt.offersRemaining(life.record(A)));
    }

    private static void storeRoundTrip() {
        java.util.Map<java.util.UUID, PackPrompt.Record> in = new java.util.LinkedHashMap<>();
        in.put(B, rec(PackPrompt.Outcome.DECLINED, 1, 123_456L));
        in.put(A, rec(PackPrompt.Outcome.LOADED, 2, 999L));
        String text = PackStateStore.serialize(in);
        check("serialization is sorted by uuid",
                text.indexOf(A.toString()) < text.indexOf(B.toString()));
        checkEq("round trip preserves every record", in, PackStateStore.parse(text));
        checkEq("empty map serializes to empty text", "",
                PackStateStore.serialize(java.util.Map.of()));
        checkEq("null map serializes to empty text", "", PackStateStore.serialize(null));
        checkEq("empty text parses to empty map", java.util.Map.of(), PackStateStore.parse(""));
        checkEq("null text parses to empty map", java.util.Map.of(), PackStateStore.parse(null));
    }

    private static void storeForgivingParse() {
        String messy = "# a comment\n"
                + "\n"
                + A + " LOADED 2 999\n"
                + "not-a-uuid SENT 1 1\n"
                + B + " BOGUS 1 1\n"
                + B + " SENT notanumber 1\n"
                + B + " SENT 1\n"
                + B + " FAILED -3 -50\n";
        java.util.Map<java.util.UUID, PackPrompt.Record> out = PackStateStore.parse(messy);
        checkEq("good line survives the mess", rec(PackPrompt.Outcome.LOADED, 2, 999L), out.get(A));
        checkEq("negative numbers clamp to 0",
                rec(PackPrompt.Outcome.FAILED, 0, 0L), out.get(B));
        checkEq("only the two valid records parse", 2, out.size());

        PackPrompt restored = new PackPrompt();
        restored.restore(out);
        checkEq("restore lands both records", 2, restored.trackedCount());
        restored.restore(null);
        checkEq("restore of null clears to empty", 0, restored.trackedCount());
        java.util.Map<java.util.UUID, PackPrompt.Record> withNulls = new java.util.HashMap<>();
        withNulls.put(null, rec(PackPrompt.Outcome.SENT, 1, 1L));
        withNulls.put(A, null);
        restored.restore(withNulls);
        checkEq("restore skips null keys and values", 0, restored.trackedCount());
    }
}
