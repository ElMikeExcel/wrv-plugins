package com.winkreyes.excelquartermaster;

/**
 * Plain main-method test harness for WandIssueGate (same style as
 * the other ExcelQuartermaster harnesses: no test framework, every
 * check counted, any failure prints and exits the JVM with status 1).
 *
 * The matrix is the whole point of the 0.3.0 wand issue:
 *  - no seal knowledge, no mode (never guess),
 *  - all legs green is the ONLY path to an offer,
 *  - every holding proof declines as a holder,
 *  - issued-but-gone is its own verdict (never a re-issue),
 *  - an unverifiable read blocks, never offers.
 *
 * Run via run-tests.sh.
 */
public final class WandIssueGateTest {

    private static int checks = 0;
    private static int failures = 0;

    private static void check(String name, boolean condition) {
        checks++;
        if (!condition) {
            failures++;
            System.out.println("FAIL: " + name);
        }
    }

    private static void checkEq(String name, Object expected, Object actual) {
        checks++;
        if (!java.util.Objects.equals(expected, actual)) {
            failures++;
            System.out.println("FAIL: " + name + " expected=" + expected + " actual=" + actual);
        }
    }

    private static WandIssueGate.Verdict decide(boolean enabled, boolean known, int seals,
                                                boolean magic, boolean issued,
                                                boolean pouch, WandIssueGate.MagicRead read) {
        return WandIssueGate.decide(enabled, known, seals, magic, issued, pouch, read);
    }

    public static void main(String[] args) {
        modeGuards();
        offerPath();
        declines();
        blockedPaths();
        sealEraChoice();
        System.out.println("WandIssueGateTest: " + (checks - failures) + "/" + checks
                + " checks passed" + (failures == 0 ? " - ALL PASS" : " - " + failures + " FAILED"));
        if (failures > 0) {
            System.exit(1);
        }
    }

    private static void modeGuards() {
        // Brief case: seals 0 -> no offer, even with every leg green.
        checkEq("seals 0, all green", WandIssueGate.Verdict.NOT_ISSUE_MODE,
                decide(true, true, 0, true, false, false, WandIssueGate.MagicRead.NONE));
        // Brief case: GuildGate unavailable -> tales only.
        checkEq("seals unknown", WandIssueGate.Verdict.NOT_ISSUE_MODE,
                decide(true, false, 0, true, false, false, WandIssueGate.MagicRead.NONE));
        checkEq("feature disabled", WandIssueGate.Verdict.NOT_ISSUE_MODE,
                decide(false, true, 3, true, false, false, WandIssueGate.MagicRead.NONE));
        checkEq("magic absent", WandIssueGate.Verdict.NOT_ISSUE_MODE,
                decide(true, true, 1, false, false, false, WandIssueGate.MagicRead.NONE));
        checkEq("negative seals", WandIssueGate.Verdict.NOT_ISSUE_MODE,
                decide(true, true, -2, true, false, false, WandIssueGate.MagicRead.NONE));
    }

    private static void offerPath() {
        // Brief case: seals >= 1 + not holding -> the offer (give
        // happens only at the confirm step, gate re-checked there).
        checkEq("seal 1, all clear", WandIssueGate.Verdict.OFFER,
                decide(true, true, 1, true, false, false, WandIssueGate.MagicRead.NONE));
        checkEq("seal 5, all clear", WandIssueGate.Verdict.OFFER,
                decide(true, true, 5, true, false, false, WandIssueGate.MagicRead.NONE));
    }

    private static void declines() {
        // Brief case: issued-list hit (and holding, the normal case).
        checkEq("issued + magic holds", WandIssueGate.Verdict.DECLINE_HOLDER,
                decide(true, true, 1, true, true, false, WandIssueGate.MagicRead.HOLDS));
        // Brief case: issued-list hit + nothing anywhere = gone.
        checkEq("issued + nothing found", WandIssueGate.Verdict.DECLINE_GONE,
                decide(true, true, 1, true, true, false, WandIssueGate.MagicRead.NONE));
        // Issued, but the wand is parked in the pouch: held, not gone.
        checkEq("issued + parked wand", WandIssueGate.Verdict.DECLINE_HOLDER,
                decide(true, true, 1, true, true, true, WandIssueGate.MagicRead.NONE));
        // Brief case: parked wand declines even with no ledger record
        // (a console-given wand put away is still a held wand).
        checkEq("parked wand, no ledger", WandIssueGate.Verdict.DECLINE_HOLDER,
                decide(true, true, 1, true, false, true, WandIssueGate.MagicRead.NONE));
        // Brief case: Magic-record hit declines (console-given wand
        // the QM never issued: he still hands out no second).
        checkEq("magic holds, no ledger", WandIssueGate.Verdict.DECLINE_HOLDER,
                decide(true, true, 1, true, false, false, WandIssueGate.MagicRead.HOLDS));
        // A positive holding proof outranks an unverifiable other leg.
        checkEq("parked + magic read failed", WandIssueGate.Verdict.DECLINE_HOLDER,
                decide(true, true, 1, true, false, true, WandIssueGate.MagicRead.FAILED));
        checkEq("magic holds + read would be gone-case otherwise",
                WandIssueGate.Verdict.DECLINE_HOLDER,
                decide(true, true, 2, true, true, false, WandIssueGate.MagicRead.HOLDS));
    }

    private static void blockedPaths() {
        // A failed read is not an empty record: blocked, never offered.
        checkEq("read failed, no ledger", WandIssueGate.Verdict.BLOCKED,
                decide(true, true, 1, true, false, false, WandIssueGate.MagicRead.FAILED));
        checkEq("read failed, issued", WandIssueGate.Verdict.BLOCKED,
                decide(true, true, 1, true, true, false, WandIssueGate.MagicRead.FAILED));
        checkEq("null read treated as failed", WandIssueGate.Verdict.BLOCKED,
                decide(true, true, 1, true, false, false, null));
    }

    private static void sealEraChoice() {
        check("unknown seals: pre-seal tales", !WandIssueGate.sealOneTales(false, 0));
        check("unknown seals claiming 3: still pre-seal", !WandIssueGate.sealOneTales(false, 3));
        check("known 0: pre-seal tales", !WandIssueGate.sealOneTales(true, 0));
        check("known 1: seal tales", WandIssueGate.sealOneTales(true, 1));
        check("known 5: seal tales", WandIssueGate.sealOneTales(true, 5));
        check("known negative: pre-seal tales", !WandIssueGate.sealOneTales(true, -1));
    }
}
