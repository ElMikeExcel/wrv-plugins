package com.winkreyes.excelquartermaster;

/**
 * Plain main-method test harness for PackStatus (0.3.1) — the
 * read-only {@code /qm status <player>} reply — in the same style
 * as the other ExcelQuartermaster harnesses: no test framework,
 * every check counted, any failure prints and exits the JVM with
 * status 1.
 *
 * What is pinned here: the exact reply text for every pack-state
 * shape the real state model can hold (no record, SENT mid-count,
 * SENT exhausted, DECLINED mid-count, DECLINED exhausted, FAILED
 * exhausted, LOADED accepted), the offers-used / remaining
 * numbers coming from PackPrompt's own arithmetic, the graceful
 * name/UUID fallbacks, the read-only guarantee (formatting and
 * looking up never create or mutate a record), and the
 * plugin.yml wiring (version 0.3.1, the status usage form, the
 * excelquartermaster.admin gate defaulting to op) — parsed off
 * the shipped plugin.yml on the test classpath, like
 * PackResetTest, so the gate cannot silently drift.
 *
 * Run via run-tests.sh.
 */
public final class PackStatusTest {

    private static final java.util.UUID A =
            java.util.UUID.fromString("11111111-1111-1111-1111-111111111111");
    private static final java.util.UUID B =
            java.util.UUID.fromString("22222222-2222-2222-2222-222222222222");
    private static final java.util.UUID C =
            java.util.UUID.fromString("33333333-3333-3333-3333-333333333333");
    private static final java.util.UUID D =
            java.util.UUID.fromString("44444444-4444-4444-4444-444444444444");
    private static final java.util.UUID E =
            java.util.UUID.fromString("55555555-5555-5555-5555-555555555555");
    private static final java.util.UUID F =
            java.util.UUID.fromString("66666666-6666-6666-6666-666666666666");
    private static final java.util.UUID UNKNOWN =
            java.util.UUID.fromString("99999999-9999-9999-9999-999999999999");

    private static int checks = 0;
    private static int failures = 0;

    private static void check(String name, boolean condition) {
        checks++;
        if (!condition) {
            failures++;
            System.out.println("FAIL: " + name);
        }
    }

    private static void checkEq(String name, Object expected, Object actual) {
        checks++;
        if (!java.util.Objects.equals(expected, actual)) {
            failures++;
            System.out.println("FAIL: " + name + " expected=" + expected + " actual=" + actual);
        }
    }

    /** A prompt state with one record per interesting shape. */
    private static PackPrompt seeded() {
        PackPrompt pp = new PackPrompt();
        java.util.Map<java.util.UUID, PackPrompt.Record> seed = new java.util.LinkedHashMap<>();
        seed.put(A, new PackPrompt.Record(PackPrompt.Outcome.DECLINED, 2, 1_000L));
        seed.put(B, new PackPrompt.Record(PackPrompt.Outcome.DECLINED, 5, 2_000L));
        seed.put(C, new PackPrompt.Record(PackPrompt.Outcome.SENT, 3, 3_000L));
        seed.put(D, new PackPrompt.Record(PackPrompt.Outcome.LOADED, 3, 4_000L));
        seed.put(E, new PackPrompt.Record(PackPrompt.Outcome.FAILED, 5, 5_000L));
        seed.put(F, new PackPrompt.Record(PackPrompt.Outcome.SENT, 5, 6_000L));
        pp.restore(seed);
        return pp;
    }

    public static void main(String[] args) throws Exception {
        exactReplies();
        stateWording();
        fallbacks();
        readOnly();
        permissionGate();
        System.out.println("PackStatusTest: " + (checks - failures) + "/" + checks
                + " checks passed" + (failures == 0 ? " - ALL PASS" : " - " + failures + " FAILED"));
        if (failures > 0) {
            System.exit(1);
        }
    }

    private static void exactReplies() {
        PackPrompt pp = seeded();
        checkEq("no record reply",
                "Pack status for NewPlayer (99999999-9999-9999-9999-999999999999): "
                        + "no record - never offered the Java voice pack; offers used 0 of 5, "
                        + "5 remaining; next join offers 1 of 5.",
                PackStatus.messageFor(pp.record(UNKNOWN), "NewPlayer", UNKNOWN));
        checkEq("declined mid-count reply",
                "Pack status for Marvin (11111111-1111-1111-1111-111111111111): "
                        + "offers used 2 of 5, 3 remaining; pack state: DECLINED; "
                        + "last change 1000.",
                PackStatus.messageFor(pp.record(A), "Marvin", A));
        checkEq("sent mid-count reply",
                "Pack status for Marvin (33333333-3333-3333-3333-333333333333): "
                        + "offers used 3 of 5, 2 remaining; pack state: "
                        + "SENT (offered, no outcome yet); last change 3000.",
                PackStatus.messageFor(pp.record(C), "Marvin", C));
        checkEq("accepted reply: count frozen, remaining 0 by PackPrompt's rule",
                "Pack status for Marvin (44444444-4444-4444-4444-444444444444): "
                        + "offers used 3 of 5, 0 remaining; pack state: "
                        + "LOADED (accepted - has the voice pack; terminal); "
                        + "last change 4000.",
                PackStatus.messageFor(pp.record(D), "Marvin", D));
        checkEq("declined exhausted reply names the packreset way back",
                "Pack status for Marvin (22222222-2222-2222-2222-222222222222): "
                        + "offers used 5 of 5, 0 remaining; pack state: "
                        + "DECLINED (offers exhausted - never offered again "
                        + "unless an admin runs /qm packreset); last change 2000.",
                PackStatus.messageFor(pp.record(B), "Marvin", B));
        checkEq("failed exhausted reply",
                "Pack status for Marvin (55555555-5555-5555-5555-555555555555): "
                        + "offers used 5 of 5, 0 remaining; pack state: "
                        + "FAILED (offers exhausted - never offered again "
                        + "unless an admin runs /qm packreset); last change 5000.",
                PackStatus.messageFor(pp.record(E), "Marvin", E));
        checkEq("sent exhausted reply",
                "Pack status for Marvin (66666666-6666-6666-6666-666666666666): "
                        + "offers used 5 of 5, 0 remaining; pack state: "
                        + "SENT (offered, no outcome yet; offers exhausted); "
                        + "last change 6000.",
                PackStatus.messageFor(pp.record(F), "Marvin", F));
    }

    private static void stateWording() {
        PackPrompt pp = seeded();
        checkEq("stateFor null record", "NO RECORD", PackStatus.stateFor(null));
        checkEq("stateFor accepted", "LOADED (accepted - has the voice pack; terminal)",
                PackStatus.stateFor(pp.record(D)));
        checkEq("stateFor declined mid-count", "DECLINED",
                PackStatus.stateFor(pp.record(A)));
        check("status reply always names the max from PackPrompt",
                PackStatus.messageFor(pp.record(A), "X", A)
                        .contains("of " + PackPrompt.MAX_OFFERS));
    }

    private static void fallbacks() {
        PackPrompt pp = seeded();
        check("blank display name falls back gracefully",
                PackStatus.messageFor(pp.record(A), "  ", A)
                        .startsWith("Pack status for that player ("));
        check("null display name falls back gracefully",
                PackStatus.messageFor(null, null, UNKNOWN)
                        .startsWith("Pack status for that player ("));
        check("null uuid renders as unknown uuid, never throws",
                PackStatus.messageFor(pp.record(A), "Marvin", null)
                        .contains("(unknown uuid)"));
        checkEq("usage names the status form", "Usage: /qm status <player>",
                PackStatus.USAGE);
    }

    private static void readOnly() {
        PackPrompt pp = seeded();
        java.util.Map<java.util.UUID, PackPrompt.Record> before = pp.snapshot();
        // Format a reply for every seeded shape plus the unknown
        // player, exactly as the command handler does (record()
        // read, then format).
        for (java.util.UUID id : new java.util.UUID[] {A, B, C, D, E, F, UNKNOWN}) {
            PackStatus.messageFor(pp.record(id), id.toString(), id);
        }
        checkEq("formatting mutates no record", before, pp.snapshot());
        checkEq("lookup of an unknown player creates no record", null, pp.record(UNKNOWN));
        checkEq("tracked count unchanged", 6, pp.trackedCount());
        // And the read survives a persist/restore round trip
        // unchanged: status reads the same state packreset acts on.
        PackPrompt revived = new PackPrompt();
        revived.restore(PackStateStore.parse(PackStateStore.serialize(pp.snapshot())));
        checkEq("status after round trip reads the same record",
                PackStatus.messageFor(pp.record(A), "Marvin", A),
                PackStatus.messageFor(revived.record(A), "Marvin", A));
    }

    /** The gate is Bukkit's, driven by plugin.yml — pin it. */
    private static void permissionGate() throws Exception {
        String yml;
        try (java.io.InputStream in = PackStatusTest.class.getResourceAsStream("/plugin.yml")) {
            check("plugin.yml is on the test classpath", in != null);
            if (in == null) {
                return;
            }
            yml = new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        }
        check("plugin.yml version is 0.3.1", yml.contains("version: 0.3.1"));
        check("plugin.yml declares the qm command", yml.contains("  qm:"));
        check("qm command is gated by excelquartermaster.admin",
                yml.contains("permission: excelquartermaster.admin"));
        check("the admin permission itself is declared",
                yml.contains("  excelquartermaster.admin:"));
        check("the admin permission defaults to op (console always allowed)",
                yml.contains("default: op"));
        check("usage names the status form beside packreset",
                yml.contains("/qm packreset <player|all> | /qm status <player>"));
        check("permission description names the status form",
                yml.contains("/qm status"));
    }
}
