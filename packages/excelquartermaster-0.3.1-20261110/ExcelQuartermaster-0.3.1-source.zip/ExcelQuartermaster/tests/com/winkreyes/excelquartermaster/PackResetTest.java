package com.winkreyes.excelquartermaster;

/**
 * Plain main-method test harness for PackReset + the PackPrompt
 * reset primitives + the plugin.yml permission wiring (same style
 * as the other ExcelQuartermaster harnesses: no test framework,
 * every check counted, any failure prints and exits the JVM with
 * status 1).
 *
 * The permission gate lives in plugin.yml (Bukkit refuses callers
 * without excelquartermaster.admin before onCommand runs), so it is
 * pinned here by parsing the shipped plugin.yml off the test
 * classpath and asserting the command, its permission and the
 * permission's declaration - if any of those lines drift, the gate
 * is gone and this harness goes red.
 *
 * Run via run-tests.sh.
 */
public final class PackResetTest {

    private static final java.util.UUID A =
            java.util.UUID.fromString("11111111-1111-1111-1111-111111111111");
    private static final java.util.UUID B =
            java.util.UUID.fromString("22222222-2222-2222-2222-222222222222");
    private static final java.util.UUID C =
            java.util.UUID.fromString("33333333-3333-3333-3333-333333333333");
    private static final java.util.UUID D =
            java.util.UUID.fromString("44444444-4444-4444-4444-444444444444");
    private static final java.util.UUID E =
            java.util.UUID.fromString("55555555-5555-5555-5555-555555555555");

    private static int checks = 0;
    private static int failures = 0;

    private static void check(String name, boolean condition) {
        checks++;
        if (!condition) {
            failures++;
            System.out.println("FAIL: " + name);
        }
    }

    private static void checkEq(String name, Object expected, Object actual) {
        checks++;
        if (!java.util.Objects.equals(expected, actual)) {
            failures++;
            System.out.println("FAIL: " + name + " expected=" + expected + " actual=" + actual);
        }
    }

    /** A prompt state with one record per interesting shape. */
    private static PackPrompt seeded() {
        PackPrompt pp = new PackPrompt();
        java.util.Map<java.util.UUID, PackPrompt.Record> seed = new java.util.LinkedHashMap<>();
        // A: mid-count (used 2 of 5 under 0.2.2 semantics).
        seed.put(A, new PackPrompt.Record(PackPrompt.Outcome.DECLINED, 2, 1_000L));
        // B: exhausted - all five used.
        seed.put(B, new PackPrompt.Record(PackPrompt.Outcome.DECLINED, 5, 1_000L));
        // C: migrated from 0.2.1 at 3 sends (the state file's shape
        // is identical; restore is what the plugin does at boot).
        seed.put(C, new PackPrompt.Record(PackPrompt.Outcome.SENT, 3, 1_000L));
        // D: accepted under 0.2.1 - LOADED at 3.
        seed.put(D, new PackPrompt.Record(PackPrompt.Outcome.LOADED, 3, 1_000L));
        // E: failed out at 5.
        seed.put(E, new PackPrompt.Record(PackPrompt.Outcome.FAILED, 5, 1_000L));
        pp.restore(seed);
        return pp;
    }

    public static void main(String[] args) throws Exception {
        resetSinglePlayers();
        resetAcceptedUntouched();
        resetNothingCases();
        resetAllCounts();
        resetPrimitives();
        permissionGate();
        messageTexts();
        System.out.println("PackResetTest: " + (checks - failures) + "/" + checks
                + " checks passed" + (failures == 0 ? " - ALL PASS" : " - " + failures + " FAILED"));
        if (failures > 0) {
            System.exit(1);
        }
    }

    private static void resetSinglePlayers() {
        PackPrompt pp = seeded();
        checkEq("mid-count player resets", PackReset.Single.RESET,
                PackReset.resetOne(pp, A));
        checkEq("mid-count record is gone", null, pp.record(A));
        checkEq("mid-count player restarts at offer 1", 1,
                PackPrompt.nextOfferNumber(pp.record(A)));
        checkEq("mid-count player has all five again", 5,
                PackPrompt.offersRemaining(pp.record(A)));
        checkEq("mid-count player is offered on next join", PackPrompt.Action.SEND,
                PackPrompt.decide(pp.record(A)));

        checkEq("exhausted player resets", PackReset.Single.RESET,
                PackReset.resetOne(pp, B));
        checkEq("exhausted record is gone", null, pp.record(B));
        checkEq("exhausted player is offered again", PackPrompt.Action.SEND,
                PackPrompt.decide(pp.record(B)));

        checkEq("migrated (3) player resets", PackReset.Single.RESET,
                PackReset.resetOne(pp, C));
        checkEq("migrated record is gone - count zeroed, not topped up",
                null, pp.record(C));
        checkEq("migrated player restarts at offer 1", 1,
                PackPrompt.nextOfferNumber(pp.record(C)));

        checkEq("failed-out player resets", PackReset.Single.RESET,
                PackReset.resetOne(pp, E));
        checkEq("failed-out record is gone", null, pp.record(E));

        // And the reset survives a persist/restore round trip: the
        // cleared players stay cleared.
        PackPrompt revived = new PackPrompt();
        revived.restore(PackStateStore.parse(PackStateStore.serialize(pp.snapshot())));
        checkEq("reset persists: A stays cleared", null, revived.record(A));
        checkEq("reset persists: B stays cleared", null, revived.record(B));
        checkEq("only the accepted record remains", 1, revived.trackedCount());
    }

    private static void resetAcceptedUntouched() {
        PackPrompt pp = seeded();
        java.util.Map<java.util.UUID, PackPrompt.Record> before = pp.snapshot();
        checkEq("accepted player reports ALREADY_HAS_PACK", PackReset.Single.ALREADY_HAS_PACK,
                PackReset.resetOne(pp, D));
        checkEq("accepted record is byte-identical afterwards",
                before.get(D), pp.record(D));
        checkEq("accepted record still counts as accepted",
                true, PackPrompt.isAccepted(pp.record(D)));
        checkEq("no other record moved", before.size(), pp.trackedCount());
    }

    private static void resetNothingCases() {
        PackPrompt pp = seeded();
        java.util.UUID unknown =
                java.util.UUID.fromString("99999999-9999-9999-9999-999999999999");
        checkEq("unknown player: nothing to reset", PackReset.Single.NOTHING_TO_RESET,
                PackReset.resetOne(pp, unknown));
        checkEq("null player: nothing to reset", PackReset.Single.NOTHING_TO_RESET,
                PackReset.resetOne(pp, null));
        checkEq("null prompt: nothing to reset", PackReset.Single.NOTHING_TO_RESET,
                PackReset.resetOne(null, A));
        checkEq("nothing-cases never mutate state", 5, pp.trackedCount());
    }

    private static void resetAllCounts() {
        PackPrompt pp = seeded();
        PackReset.AllResult result = PackReset.resetAll(pp);
        checkEq("all: four non-accepted reset", 4, result.resetCount());
        checkEq("all: one accepted kept", 1, result.acceptedKept());
        checkEq("all: only the accepted record remains", 1, pp.trackedCount());
        checkEq("all: the accepted record is D's, untouched",
                new PackPrompt.Record(PackPrompt.Outcome.LOADED, 3, 1_000L), pp.record(D));

        PackReset.AllResult again = PackReset.resetAll(pp);
        checkEq("all again: nothing left to reset", 0, again.resetCount());
        checkEq("all again: accepted still kept", 1, again.acceptedKept());

        PackReset.AllResult empty = PackReset.resetAll(new PackPrompt());
        checkEq("all on empty state: 0 reset", 0, empty.resetCount());
        checkEq("all on empty state: 0 kept", 0, empty.acceptedKept());
        checkEq("all on null prompt: 0/0", new PackReset.AllResult(0, 0),
                PackReset.resetAll(null));
    }

    private static void resetPrimitives() {
        PackPrompt pp = seeded();
        check("reset of a present record returns true", pp.reset(A));
        check("reset of the same record again returns false", !pp.reset(A));
        check("reset of null returns false", !pp.reset(null));
        checkEq("resetAllNonAccepted counts the cleared", 3, pp.resetAllNonAccepted());
        checkEq("resetAllNonAccepted keeps only the accepted", 1, pp.trackedCount());
    }

    /**
     * The no-permission refusal is Bukkit's, driven by plugin.yml -
     * pin the exact wiring so it cannot silently fall off.
     */
    private static void permissionGate() throws Exception {
        String yml;
        try (java.io.InputStream in = PackResetTest.class.getResourceAsStream("/plugin.yml")) {
            check("plugin.yml is on the test classpath", in != null);
            if (in == null) {
                return;
            }
            yml = new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        }
        check("plugin.yml declares the qm command", yml.contains("  qm:"));
        check("qm command is gated by excelquartermaster.admin",
                yml.contains("permission: excelquartermaster.admin"));
        check("a refusal message is set",
                yml.contains("permission-message:"));
        check("the admin permission itself is declared",
                yml.contains("  excelquartermaster.admin:"));
        check("the admin permission defaults to op (console always allowed)",
                yml.contains("default: op"));
        check("usage names the command and its argument shape",
                PackReset.USAGE.contains("/qm packreset <player|all>"));
    }

    private static void messageTexts() {
        checkEq("reset reply",
                "Voice-pack offers reset for Marvin: their next join starts again at offer 1 of 5.",
                PackReset.messageFor(PackReset.Single.RESET, "Marvin"));
        checkEq("accepted reply says already has the pack, nothing to reset",
                "Marvin already has the voice pack - nothing to reset.",
                PackReset.messageFor(PackReset.Single.ALREADY_HAS_PACK, "Marvin"));
        checkEq("nothing reply",
                "Nothing to reset for Marvin: no voice-pack offers are on record.",
                PackReset.messageFor(PackReset.Single.NOTHING_TO_RESET, "Marvin"));
        check("accepted reply carries Mike's phrase",
                PackReset.messageFor(PackReset.Single.ALREADY_HAS_PACK, "X")
                        .contains("already has the voice pack"));
        checkEq("all reply reports both counts",
                "Voice-pack offers reset for 4 player(s); 1 player(s) already have the pack "
                        + "and were left untouched.",
                PackReset.messageForAll(new PackReset.AllResult(4, 1)));
        checkEq("blank name falls back gracefully",
                "Nothing to reset for that player: no voice-pack offers are on record.",
                PackReset.messageFor(PackReset.Single.NOTHING_TO_RESET, "  "));
    }
}
