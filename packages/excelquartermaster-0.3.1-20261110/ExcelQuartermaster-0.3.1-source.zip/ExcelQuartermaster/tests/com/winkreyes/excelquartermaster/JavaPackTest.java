package com.winkreyes.excelquartermaster;

/**
 * Plain main-method test harness for JavaPack (same style as the
 * other ExcelQuartermaster harnesses: no test framework, every check
 * counted, any failure prints and exits the JVM with status 1).
 *
 * Run via run-tests.sh.
 */
public final class JavaPackTest {

    private static int checks = 0;
    private static int failures = 0;

    private static void check(String name, boolean condition) {
        checks++;
        if (!condition) {
            failures++;
            System.out.println("FAIL: " + name);
        }
    }

    private static void checkEq(String name, Object expected, Object actual) {
        checks++;
        if (!java.util.Objects.equals(expected, actual)) {
            failures++;
            System.out.println("FAIL: " + name + " expected=" + expected + " actual=" + actual);
        }
    }

    public static void main(String[] args) {
        statusMapping();
        sha1Parsing();
        soundsJsonKeyParity();
        offerPromptText();
        System.out.println("JavaPackTest: " + (checks - failures) + "/" + checks
                + " checks passed" + (failures == 0 ? " - ALL PASS" : " - " + failures + " FAILED"));
        if (failures > 0) {
            System.exit(1);
        }
    }

    private static void statusMapping() {
        // Every status the Bukkit event can carry (PlayerResourcePackStatusEvent.Status
        // in the Paper API this plugin compiles against), each mapped once.
        checkEq("SUCCESSFULLY_LOADED", JavaPack.Status.LOADED,
                JavaPack.mapStatus("SUCCESSFULLY_LOADED"));
        checkEq("DECLINED", JavaPack.Status.DECLINED, JavaPack.mapStatus("DECLINED"));
        checkEq("FAILED_DOWNLOAD", JavaPack.Status.FAILED, JavaPack.mapStatus("FAILED_DOWNLOAD"));
        checkEq("FAILED_RELOAD", JavaPack.Status.FAILED, JavaPack.mapStatus("FAILED_RELOAD"));
        checkEq("INVALID_URL", JavaPack.Status.FAILED, JavaPack.mapStatus("INVALID_URL"));
        checkEq("DISCARDED", JavaPack.Status.FAILED, JavaPack.mapStatus("DISCARDED"));
        checkEq("ACCEPTED is progress noise", JavaPack.Status.IGNORED,
                JavaPack.mapStatus("ACCEPTED"));
        checkEq("DOWNLOADED is progress noise", JavaPack.Status.IGNORED,
                JavaPack.mapStatus("DOWNLOADED"));
        checkEq("unknown status ignored", JavaPack.Status.IGNORED,
                JavaPack.mapStatus("SOME_FUTURE_STATUS"));
        checkEq("null status ignored", JavaPack.Status.IGNORED, JavaPack.mapStatus(null));
        checkEq("empty status ignored", JavaPack.Status.IGNORED, JavaPack.mapStatus(""));
    }

    private static void sha1Parsing() {
        byte[] parsed = JavaPack.parseSha1(JavaPack.DEFAULT_SHA1);
        check("shipped default SHA-1 parses", parsed != null);
        check("parsed hash is 20 bytes", parsed != null && parsed.length == 20);
        check("first byte matches ee", parsed != null && parsed[0] == (byte) 0xee);
        check("last byte matches 72", parsed != null && parsed[19] == (byte) 0x72);
        check("uppercase hex parses",
                JavaPack.parseSha1(JavaPack.DEFAULT_SHA1.toUpperCase()) != null);
        check("surrounding whitespace tolerated",
                JavaPack.parseSha1("  " + JavaPack.DEFAULT_SHA1 + " ") != null);
        checkEq("null rejected", null, JavaPack.parseSha1(null));
        checkEq("blank rejected", null, JavaPack.parseSha1("   "));
        checkEq("short rejected", null, JavaPack.parseSha1("ee82a47e"));
        checkEq("long rejected", null, JavaPack.parseSha1(JavaPack.DEFAULT_SHA1 + "00"));
        checkEq("non-hex rejected", null,
                JavaPack.parseSha1("zz82a47eb26405b23c8353b6ca46319c5f224572"));
        // A re-typed digest must round-trip exactly, digit for digit.
        byte[] a = JavaPack.parseSha1("0123456789abcdef0123456789abcdef01234567");
        check("round-trip byte 0", a != null && a[0] == (byte) 0x01);
        check("round-trip byte 19", a != null && a[19] == (byte) 0x67);
    }

    private static void soundsJsonKeyParity() {
        // The Java pack's sounds.json keys must be exactly the suffixes of
        // the sound names the plugin already plays (SoundNames with the
        // default prefix), or Java clients would resolve nothing.
        for (int i = 0; i < SoundNames.PACK_CLIP_COUNT; i++) {
            String played = SoundNames.soundFor(SoundNames.DEFAULT_PREFIX, i);
            checkEq("sound name for tale " + (i + 1), "wrv:quartermaster.tale" + (i + 1), played);
            checkEq("sounds.json key for tale " + (i + 1),
                    "quartermaster.tale" + (i + 1), JavaPack.soundsJsonKey(i));
            check("played name ends with the key, tale " + (i + 1),
                    played != null && played.endsWith(JavaPack.soundsJsonKey(i)));
        }
        checkEq("negative index has no key", null, JavaPack.soundsJsonKey(-1));
    }

    /**
     * 0.2.2: the offer prompt text - Mike's rule is that the counter
     * is ON the prompt ("offer N of 5") together with the plain
     * never-again line, because players tap-spam prompts unread.
     */
    private static void offerPromptText() {
        String first = JavaPack.offerPrompt(JavaPack.DEFAULT_PROMPT, 1, PackPrompt.MAX_OFFERS);
        check("counter leads the prompt",
                first.startsWith("Quartermaster voice pack \u2014 offer 1 of 5."));
        for (int n = 1; n <= 5; n++) {
            String text = JavaPack.offerPrompt(JavaPack.DEFAULT_PROMPT, n, PackPrompt.MAX_OFFERS);
            check("offer " + n + " shows its number", text.contains("offer " + n + " of 5"));
        }
        check("base prompt carried verbatim", first.contains(JavaPack.DEFAULT_PROMPT));
        check("never-again line closes the prompt",
                first.endsWith("After 5 offers \u2014 or once you download it \u2014 "
                        + "you won't be asked again."));
        check("never-again line names the download exit",
                first.contains("once you download it"));

        String custom = JavaPack.offerPrompt("Custom base text.", 3, PackPrompt.MAX_OFFERS);
        check("custom base carried verbatim", custom.contains("Custom base text."));
        check("custom base still gets the counter",
                custom.startsWith("Quartermaster voice pack \u2014 offer 3 of 5."));

        check("null base falls back to the default",
                JavaPack.offerPrompt(null, 2, 5).contains(JavaPack.DEFAULT_PROMPT));
        check("blank base falls back to the default",
                JavaPack.offerPrompt("   ", 2, 5).contains(JavaPack.DEFAULT_PROMPT));

        String other = JavaPack.offerPrompt(JavaPack.DEFAULT_PROMPT, 2, 3);
        check("a different cap renders in the counter", other.contains("offer 2 of 3"));
        check("a different cap renders in the closing line",
                other.contains("After 3 offers"));
    }
}
