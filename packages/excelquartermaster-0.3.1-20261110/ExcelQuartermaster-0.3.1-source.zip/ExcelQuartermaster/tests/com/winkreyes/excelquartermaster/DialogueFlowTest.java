package com.winkreyes.excelquartermaster;

/**
 * Plain main-method test harness for DialogueFlow (same style as the
 * other ExcelQuartermaster harnesses: no test framework, every check
 * counted, any failure prints and exits the JVM with status 1).
 *
 * Run via run-tests.sh.
 */
public final class DialogueFlowTest {

    private static final java.util.UUID A =
            java.util.UUID.fromString("11111111-1111-1111-1111-111111111111");
    private static final java.util.UUID B =
            java.util.UUID.fromString("22222222-2222-2222-2222-222222222222");

    private static int checks = 0;
    private static int failures = 0;

    private static void check(String name, boolean condition) {
        checks++;
        if (!condition) {
            failures++;
            System.out.println("FAIL: " + name);
        }
    }

    private static void checkEq(String name, Object expected, Object actual) {
        checks++;
        if (!java.util.Objects.equals(expected, actual)) {
            failures++;
            System.out.println("FAIL: " + name + " expected=" + expected + " actual=" + actual);
        }
    }

    public static void main(String[] args) {
        chooseMatrix();
        openSupersedesAndStaleCallbacksAreIgnored();
        advanceRespectsTheAntiSpamFloor();
        advanceWithZeroFloorIsImmediate();
        closeWithStaleGenerationKeepsNewerSession();
        farewellCloseRemovesSession();
        dropForgetsSession();
        playersAreIndependent();
        nullPlayerIsSafe();
        rotationAcrossDialogueSessions();
        System.out.println("DialogueFlowTest: " + (checks - failures) + "/" + checks
                + " checks passed" + (failures == 0 ? " - ALL PASS" : " - " + failures + " FAILED"));
        if (failures > 0) {
            System.exit(1);
        }
    }

    private static void chooseMatrix() {
        checkEq("choose: bedrock+on+forms", DialogueFlow.Presentation.DIALOGUE,
                DialogueFlow.choose(true, true, true));
        checkEq("choose: java player", DialogueFlow.Presentation.CHAT,
                DialogueFlow.choose(false, true, true));
        checkEq("choose: feature off", DialogueFlow.Presentation.CHAT,
                DialogueFlow.choose(true, false, true));
        checkEq("choose: forms unavailable", DialogueFlow.Presentation.CHAT,
                DialogueFlow.choose(true, true, false));
        checkEq("choose: nothing available", DialogueFlow.Presentation.CHAT,
                DialogueFlow.choose(false, false, false));
    }

    private static void openSupersedesAndStaleCallbacksAreIgnored() {
        DialogueFlow f = new DialogueFlow();
        DialogueFlow.Session s1 = f.open(A, 0, 1000L);
        DialogueFlow.Session s2 = f.open(A, 1, 2000L);
        check("supersede: generations differ", s1.generation() != s2.generation());
        checkEq("supersede: live session is the new one", s2, f.session(A));
        check("supersede: old generation not current", !f.isCurrent(A, s1.generation()));
        check("supersede: new generation current", f.isCurrent(A, s2.generation()));
        checkEq("supersede: stale advance is NO_SESSION", DialogueFlow.Advance.NO_SESSION,
                f.advance(A, s1.generation(), 2, 3000L, 0L));
        checkEq("supersede: live session untouched by stale advance", s2, f.session(A));
        checkEq("supersede: one active session", 1, f.activeCount());
    }

    private static void advanceRespectsTheAntiSpamFloor() {
        DialogueFlow f = new DialogueFlow();
        DialogueFlow.Session s = f.open(A, 0, 10_000L);
        checkEq("floor: press 1s after open (floor 2s)", DialogueFlow.Advance.TOO_FAST,
                f.advance(A, s.generation(), 1, 11_000L, 2000L));
        checkEq("floor: session still on tale 0", 0, f.session(A).taleIndex());
        checkEq("floor: press exactly at 2s advances", DialogueFlow.Advance.ADVANCED,
                f.advance(A, s.generation(), 1, 12_000L, 2000L));
        checkEq("floor: session now on tale 1", 1, f.session(A).taleIndex());
        checkEq("floor: stamp moved to advance time", 12_000L, f.session(A).lastAdvanceMillis());
        checkEq("floor: next press 1s later is too fast again", DialogueFlow.Advance.TOO_FAST,
                f.advance(A, s.generation(), 2, 13_000L, 2000L));
    }

    private static void advanceWithZeroFloorIsImmediate() {
        DialogueFlow f = new DialogueFlow();
        DialogueFlow.Session s = f.open(A, 0, 5000L);
        checkEq("floor 0: same-millisecond press advances", DialogueFlow.Advance.ADVANCED,
                f.advance(A, s.generation(), 1, 5000L, 0L));
    }

    private static void closeWithStaleGenerationKeepsNewerSession() {
        DialogueFlow f = new DialogueFlow();
        DialogueFlow.Session s1 = f.open(A, 0, 1000L);
        DialogueFlow.Session s2 = f.open(A, 1, 2000L);
        f.close(A, s1.generation()); // late "closed" callback from the superseded form
        checkEq("stale close: newer session survives", s2, f.session(A));
        f.close(A, s2.generation());
        checkEq("live close: session gone", null, f.session(A));
    }

    private static void farewellCloseRemovesSession() {
        DialogueFlow f = new DialogueFlow();
        DialogueFlow.Session s = f.open(A, 3, 1000L);
        f.close(A, s.generation());
        checkEq("farewell: no session", null, f.session(A));
        checkEq("farewell: advance after close is NO_SESSION", DialogueFlow.Advance.NO_SESSION,
                f.advance(A, s.generation(), 4, 5000L, 0L));
        checkEq("farewell: zero active", 0, f.activeCount());
    }

    private static void dropForgetsSession() {
        DialogueFlow f = new DialogueFlow();
        f.open(A, 0, 1000L);
        f.drop(A);
        checkEq("drop: no session", null, f.session(A));
        f.drop(A); // dropping twice is harmless
        checkEq("drop: still none", 0, f.activeCount());
    }

    private static void playersAreIndependent() {
        DialogueFlow f = new DialogueFlow();
        DialogueFlow.Session sa = f.open(A, 0, 1000L);
        DialogueFlow.Session sb = f.open(B, 5, 1000L);
        checkEq("independent: two active", 2, f.activeCount());
        checkEq("independent: A advances", DialogueFlow.Advance.ADVANCED,
                f.advance(A, sa.generation(), 1, 4000L, 2000L));
        checkEq("independent: B untouched", sb, f.session(B));
        f.close(B, sb.generation());
        checkEq("independent: A survives B's close", 1, f.session(A).taleIndex());
    }

    private static void nullPlayerIsSafe() {
        DialogueFlow f = new DialogueFlow();
        DialogueFlow.Session s = f.open(null, 0, 1000L);
        check("null: open still returns a session", s != null);
        checkEq("null: nothing tracked", 0, f.activeCount());
        checkEq("null: session lookup", null, f.session(null));
        checkEq("null: advance", DialogueFlow.Advance.NO_SESSION,
                f.advance(null, s.generation(), 1, 2000L, 0L));
        f.close(null, s.generation());
        f.drop(null);
        check("null: no crash, not current", !f.isCurrent(null, s.generation()));
    }

    /**
     * The full conversation loop against a real TaleRotation - the same
     * sequence the plugin's wiring performs: tap (decide), then
     * "Another tale" presses (peek + advance + commitTold), then a
     * fresh tap inside the interact cooldown, then one after it.
     */
    private static void rotationAcrossDialogueSessions() {
        TaleRotation rotation = new TaleRotation();
        DialogueFlow flow = new DialogueFlow();
        int tales = 3;
        long interactCooldown = 8000L;
        long floor = 2000L;

        // Tap at t=1000: tale 0, dialogue opens.
        TaleRotation.Outcome o = rotation.decide(A, false, 1000L, tales, interactCooldown);
        checkEq("loop: tap tells tale 0", 0, o.taleIndex());
        DialogueFlow.Session s = flow.open(A, o.taleIndex(), 1000L);

        // Press "Another tale" at t=3500 (past the 2s floor): tale 1.
        int next = rotation.peekNextIndex(A, tales);
        checkEq("loop: peek says tale 1", 1, next);
        checkEq("loop: advance 1", DialogueFlow.Advance.ADVANCED,
                flow.advance(A, s.generation(), next, 3500L, floor));
        rotation.commitTold(A, next, 3500L);

        // Press again at t=6000: tale 2.
        next = rotation.peekNextIndex(A, tales);
        checkEq("loop: peek says tale 2", 2, next);
        checkEq("loop: advance 2", DialogueFlow.Advance.ADVANCED,
                flow.advance(A, s.generation(), next, 6000L, floor));
        rotation.commitTold(A, next, 6000L);

        // Farewell at t=6500. Fresh tap at t=9000 is only 3s after the
        // last tale heard (t=6000): the interact cooldown (8s) silences
        // it - the dialogue did not leak a way around the cooldown.
        flow.close(A, s.generation());
        TaleRotation.Outcome mid = rotation.decide(A, false, 9000L, tales, interactCooldown);
        checkEq("loop: tap inside cooldown is silent", TaleRotation.Kind.CANCEL_SILENT, mid.kind());

        // Tap at t=14001 (8s+ after t=6000): wraps to tale 0 again.
        TaleRotation.Outcome later = rotation.decide(A, false, 14_001L, tales, interactCooldown);
        checkEq("loop: tap after cooldown tells", TaleRotation.Kind.TELL, later.kind());
        checkEq("loop: rotation wrapped to tale 0", 0, later.taleIndex());
    }
}
