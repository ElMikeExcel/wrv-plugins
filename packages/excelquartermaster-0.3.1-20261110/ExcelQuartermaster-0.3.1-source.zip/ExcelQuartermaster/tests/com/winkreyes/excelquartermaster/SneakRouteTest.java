package com.winkreyes.excelquartermaster;

/**
 * Plain main-method test harness for SneakRoute (same style as the
 * other ExcelQuartermaster harnesses: no test framework, every check
 * counted, any failure prints and exits the JVM with status 1).
 *
 * The matrix is the whole point of the 0.2.1 sneak fix:
 *  - platform (Bedrock must never be redirected),
 *  - edit permission (owners/admins must never be redirected),
 *  - redirect availability (fail-soft to passthrough),
 *  - the twin-event debounce (cancel, but do not reopen).
 *
 * Run via run-tests.sh.
 */
public final class SneakRouteTest {

    private static final long DEBOUNCE = SneakRoute.DEFAULT_DEBOUNCE_MILLIS;

    private static int checks = 0;
    private static int failures = 0;

    private static void check(String name, boolean condition) {
        checks++;
        if (!condition) {
            failures++;
            System.out.println("FAIL: " + name);
        }
    }

    private static void checkEq(String name, Object expected, Object actual) {
        checks++;
        if (!java.util.Objects.equals(expected, actual)) {
            failures++;
            System.out.println("FAIL: " + name + " expected=" + expected + " actual=" + actual);
        }
    }

    private static SneakRoute.Action decide(boolean bedrock, boolean canEdit,
                                            boolean available, long since) {
        return SneakRoute.decide(bedrock, canEdit, available, since, DEBOUNCE);
    }

    public static void main(String[] args) {
        passthroughGuards();
        redirectAndDebounce();
        fullMatrix();
        System.out.println("SneakRouteTest: " + (checks - failures) + "/" + checks
                + " checks passed" + (failures == 0 ? " - ALL PASS" : " - " + failures + " FAILED"));
        if (failures > 0) {
            System.exit(1);
        }
    }

    private static void passthroughGuards() {
        // Bedrock: untouched, whatever else is true.
        checkEq("bedrock visitor", SneakRoute.Action.PASSTHROUGH, decide(true, false, true, -1));
        checkEq("bedrock editor", SneakRoute.Action.PASSTHROUGH, decide(true, true, true, -1));
        checkEq("bedrock, api down", SneakRoute.Action.PASSTHROUGH, decide(true, false, false, -1));
        checkEq("bedrock inside debounce", SneakRoute.Action.PASSTHROUGH, decide(true, false, true, 0));
        // Editors (owners/admins): sneak must keep reaching the editor.
        checkEq("java editor", SneakRoute.Action.PASSTHROUGH, decide(false, true, true, -1));
        checkEq("java editor inside debounce", SneakRoute.Action.PASSTHROUGH, decide(false, true, true, 10));
        // Redirect unavailable: status quo beats a swallowed click.
        checkEq("java visitor, api down", SneakRoute.Action.PASSTHROUGH, decide(false, false, false, -1));
        checkEq("java visitor, api down, inside debounce",
                SneakRoute.Action.PASSTHROUGH, decide(false, false, false, 10));
    }

    private static void redirectAndDebounce() {
        checkEq("java visitor, first click: open trading",
                SneakRoute.Action.OPEN_TRADING, decide(false, false, true, -1));
        checkEq("twin event at 0ms: cancel only",
                SneakRoute.Action.CANCEL_ONLY, decide(false, false, true, 0));
        checkEq("twin event mid-window: cancel only",
                SneakRoute.Action.CANCEL_ONLY, decide(false, false, true, DEBOUNCE / 2));
        checkEq("twin event 1ms before window ends: cancel only",
                SneakRoute.Action.CANCEL_ONLY, decide(false, false, true, DEBOUNCE - 1));
        checkEq("exactly at the window edge: a new click, open again",
                SneakRoute.Action.OPEN_TRADING, decide(false, false, true, DEBOUNCE));
        checkEq("long after: open again",
                SneakRoute.Action.OPEN_TRADING, decide(false, false, true, 60_000));
        checkEq("negative 'since' other than never (-5): treated as no recent redirect",
                SneakRoute.Action.OPEN_TRADING, decide(false, false, true, -5));
        // A zero debounce window disables the twin guard entirely.
        checkEq("zero debounce: immediate second click opens",
                SneakRoute.Action.OPEN_TRADING,
                SneakRoute.decide(false, false, true, 0, 0));
    }

    private static void fullMatrix() {
        // All 16 combinations of the three booleans x (never / inside
        // debounce): only ONE cell may redirect, only ONE may cancel-only.
        boolean[] bools = {false, true};
        for (boolean bedrock : bools) {
            for (boolean canEdit : bools) {
                for (boolean available : bools) {
                    String cell = "bedrock=" + bedrock + " edit=" + canEdit + " api=" + available;
                    SneakRoute.Action fresh = decide(bedrock, canEdit, available, -1);
                    SneakRoute.Action twin = decide(bedrock, canEdit, available, 1);
                    if (!bedrock && !canEdit && available) {
                        checkEq(cell + " fresh", SneakRoute.Action.OPEN_TRADING, fresh);
                        checkEq(cell + " twin", SneakRoute.Action.CANCEL_ONLY, twin);
                    } else {
                        checkEq(cell + " fresh", SneakRoute.Action.PASSTHROUGH, fresh);
                        checkEq(cell + " twin", SneakRoute.Action.PASSTHROUGH, twin);
                    }
                }
            }
        }
        check("edit permission list names the editor node first",
                SneakRoute.EDIT_PERMISSIONS.length >= 1
                        && SneakRoute.EDIT_PERMISSIONS[0].equals("shopkeeper.admin"));
        check("edit permission list includes the bypass node",
                java.util.List.of(SneakRoute.EDIT_PERMISSIONS).contains("shopkeeper.bypass"));
    }
}
