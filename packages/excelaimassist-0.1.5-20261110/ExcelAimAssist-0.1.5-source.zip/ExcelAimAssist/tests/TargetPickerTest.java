import com.winkreyes.excelaimassist.core.AimMath;
import com.winkreyes.excelaimassist.core.AimMath.Vec;
import com.winkreyes.excelaimassist.core.TargetPicker;
import com.winkreyes.excelaimassist.core.TargetPicker.Candidate;

import java.util.List;

public class TargetPickerTest {
    static Candidate c(double angle, double dist, boolean los, boolean hostile) {
        return new Candidate(angle, dist, los, hostile);
    }
    static final double CONE = 6.0, RANGE = 30.0;

    static Vec vv(double x, double y, double z) { return new Vec(x, y, z); }

    /** A candidate measured exactly as the Bukkit glue measures one (0.1.3). */
    static Candidate measured(Vec vel, Vec from, Vec to) {
        return new Candidate(AimMath.angleDegrees(vel, to.sub(from)),
                AimMath.travelDistance(vel, from, to), true, true);
    }

    public static void run() {
        System.out.println("TargetPickerTest");

        // Nothing to pick from.
        Check.eq(-1, TargetPicker.pickBest(List.of(), CONE, RANGE), "empty list -> no pick");
        Check.eq(-1, TargetPicker.pickBest(null, CONE, RANGE), "null list -> no pick");

        // The straightforward case.
        Check.eq(0, TargetPicker.pickBest(List.of(c(3.0, 12.0, true, true)), CONE, RANGE),
                "single in-cone hostile with LOS is picked");

        // Cone gating.
        Check.eq(0, TargetPicker.pickBest(List.of(c(6.0, 12.0, true, true)), CONE, RANGE),
                "target exactly at cone edge (6.0) qualifies - edge inclusive");
        Check.eq(-1, TargetPicker.pickBest(List.of(c(6.000001, 12.0, true, true)), CONE, RANGE),
                "target a hair past the cone edge does not qualify");
        Check.eq(-1, TargetPicker.pickBest(List.of(c(15.0, 12.0, true, true)), CONE, RANGE),
                "15 deg off (the rig's miss case) is never bent");
        Check.eq(0, TargetPicker.pickBest(List.of(c(0.0, 12.0, true, true)), CONE, RANGE),
                "dead-center target qualifies");

        // Range gating.
        Check.eq(0, TargetPicker.pickBest(List.of(c(2.0, 30.0, true, true)), CONE, RANGE),
                "target exactly at range edge qualifies");
        Check.eq(-1, TargetPicker.pickBest(List.of(c(2.0, 30.5, true, true)), CONE, RANGE),
                "target past range does not qualify");

        // Line of sight gating (the behind-a-wall case).
        Check.eq(-1, TargetPicker.pickBest(List.of(c(1.0, 8.0, false, true)), CONE, RANGE),
                "in-cone but behind a wall (no LOS) is excluded");
        Check.eq(1, TargetPicker.pickBest(List.of(
                c(1.0, 8.0, false, true), c(4.0, 9.0, true, true)), CONE, RANGE),
                "walled-off best angle skipped; next visible in-cone mob wins");

        // Hostility gating: players/animals/villagers must never bend a shot.
        Check.eq(-1, TargetPicker.pickBest(List.of(c(0.5, 6.0, true, false)), CONE, RANGE),
                "non-hostile dead-center is never picked");

        // Best-target pick: smallest angle beats nearer-but-wider.
        Check.eq(1, TargetPicker.pickBest(List.of(
                c(5.0, 5.0, true, true), c(2.0, 20.0, true, true)), CONE, RANGE),
                "two mobs in cone: smallest angle wins over nearer mob");
        Check.eq(0, TargetPicker.pickBest(List.of(
                c(2.0, 20.0, true, true), c(5.0, 5.0, true, true)), CONE, RANGE),
                "same pair, reversed order: still the 2 deg mob");
        // Tie on angle: nearer wins; tie on both: first wins (stable).
        Check.eq(1, TargetPicker.pickBest(List.of(
                c(3.0, 18.0, true, true), c(3.0, 9.0, true, true)), CONE, RANGE),
                "angle tie broken by nearer distance");
        Check.eq(0, TargetPicker.pickBest(List.of(
                c(3.0, 9.0, true, true), c(3.0, 9.0, true, true)), CONE, RANGE),
                "full tie keeps the first candidate");

        // Degenerate inputs never bend.
        Check.eq(-1, TargetPicker.pickBest(List.of(c(Double.NaN, 10.0, true, true)), CONE, RANGE),
                "NaN angle never qualifies");
        Check.eq(-1, TargetPicker.pickBest(List.of(c(2.0, Double.NaN, true, true)), CONE, RANGE),
                "NaN distance never qualifies");
        Check.eq(-1, TargetPicker.pickBest(List.of(c(-1.0, 10.0, true, true)), CONE, RANGE),
                "negative angle rejected");
        Check.eq(-1, TargetPicker.pickBest(List.of(c(2.0, -3.0, true, true)), CONE, RANGE),
                "negative distance rejected");
        Check.eq(-1, TargetPicker.pickBest(List.of(c(2.0, 10.0, true, true)), Double.NaN, RANGE),
                "NaN cone -> no pick");
        Check.eq(-1, TargetPicker.pickBest(List.of(c(2.0, 10.0, true, true)), CONE, 0.0),
                "zero range -> no pick");
        Check.eq(1, TargetPicker.pickBest(java.util.Arrays.asList(
                null, c(2.0, 10.0, true, true)), CONE, RANGE),
                "null candidate row is skipped, valid row still picked");

        // A config cone of 0 means only a mathematically perfect shot "bends" (to itself).
        Check.eq(0, TargetPicker.pickBest(List.of(c(0.0, 10.0, true, true)), 0.0, RANGE),
                "cone 0 admits a 0 deg target");
        Check.eq(-1, TargetPicker.pickBest(List.of(c(0.5, 10.0, true, true)), 0.0, RANGE),
                "cone 0 rejects anything off-axis");

        // --- 0.1.1 wide cone (15 deg) / long range (40): same rules, new constants ---
        final double CONE2 = 15.0, RANGE2 = 40.0;
        Check.eq(0, TargetPicker.pickBest(List.of(c(15.0, 12.0, true, true)), CONE2, RANGE2),
                "0.1.1: target exactly at the 15 deg edge qualifies - edge inclusive");
        Check.eq(-1, TargetPicker.pickBest(List.of(c(15.000001, 12.0, true, true)), CONE2, RANGE2),
                "0.1.1: a hair past 15 deg does not qualify");
        Check.eq(0, TargetPicker.pickBest(List.of(c(10.0, 12.0, true, true)), CONE2, RANGE2),
                "0.1.1: 10 deg off qualifies now (rejected at the 0.1.0 cone)");
        Check.eq(0, TargetPicker.pickBest(List.of(c(14.9, 39.0, true, true)), CONE2, RANGE2),
                "0.1.1: wide angle at long range still qualifies");
        Check.eq(0, TargetPicker.pickBest(List.of(c(2.0, 40.0, true, true)), CONE2, RANGE2),
                "0.1.1: target exactly at the 40 block edge qualifies");
        Check.eq(-1, TargetPicker.pickBest(List.of(c(2.0, 40.5, true, true)), CONE2, RANGE2),
                "0.1.1: past 40 blocks does not qualify");
        Check.eq(1, TargetPicker.pickBest(List.of(
                c(12.0, 8.0, true, true), c(9.0, 25.0, true, true)), CONE2, RANGE2),
                "0.1.1: among several in the wide cone, closest to trajectory (9 deg) wins over nearer 12 deg");
        Check.eq(-1, TargetPicker.pickBest(List.of(c(0.0, 6.0, true, false)), CONE2, RANGE2),
                "0.1.1: non-hostile (player/animal flag) dead-center is never picked, even in the wide cone");
        Check.eq(-1, TargetPicker.pickBest(List.of(c(3.0, 20.0, false, true)), CONE2, RANGE2),
                "0.1.1: no-LOS hostile inside the wide cone is excluded");

        // --- 0.1.3: range is judged on along-shot travel distance ---
        // Geometry exactly as the scratch rig stages it: arrow
        // origin at x=0.5, zombie chest at x=0.5+dist (height
        // 122.152), full-draw velocity with its slight downward
        // pitch. Candidates are built by the glue's own measures.
        final double CONE3 = 15.0, RANGE3 = 40.0;
        Vec vel = vv(3, -0.045, 0);
        Vec org = vv(0.5, 122.62, 0.5);
        Vec still40 = vv(40.5, 122.152, 0.5);
        Vec strafe40 = vv(40.5, 122.152, 0.5 + 1.43); // mid-flight strafe step

        Check.eq(0, TargetPicker.pickBest(List.of(measured(vel, org, still40)), CONE3, RANGE3),
                "0.1.3: stationary target at exactly 40.0 is picked (edge inclusive)");
        Check.eq(0, TargetPicker.pickBest(List.of(measured(vel, org, strafe40)), CONE3, RANGE3),
                "0.1.3: strafing target at exactly 40.0 along-shot is picked (the fix)");
        // The same strafing geometry under the PRE-0.1.3 measure is
        // rejected — this pair pins the behavioural delta itself.
        Candidate oldMeasure = new Candidate(
                AimMath.angleDegrees(vel, strafe40.sub(org)),
                AimMath.horizontalDistance(org, strafe40), true, true);
        Check.eq(-1, TargetPicker.pickBest(List.of(oldMeasure), CONE3, RANGE3),
                "0.1.3: the same strafing chest under the old horizontal measure is NOT picked (the defect)");
        Check.eq(-1, TargetPicker.pickBest(List.of(measured(vel, org, vv(41.0, 122.152, 0.5))), CONE3, RANGE3),
                "0.1.3: target at 40.5 along-shot is just outside and rejected");
        Check.eq(-1, TargetPicker.pickBest(List.of(measured(vel, org, vv(40.500001, 122.152, 0.5))), CONE3, RANGE3),
                "0.1.3: target a hair past 40.0 along-shot is rejected — the edge did not move");
        Check.eq(0, TargetPicker.pickBest(List.of(measured(vel, org, vv(40.4, 122.152, 3.5))), CONE3, RANGE3),
                "0.1.3: target just inside on travel (39.9) with lateral offset is picked");

        // Tie-breaks read the same measure: equal angle, nearer
        // travel distance wins.
        Check.eq(1, TargetPicker.pickBest(List.of(
                c(3.0, 40.0, true, true), c(3.0, 39.0, true, true)), CONE3, RANGE3),
                "0.1.3: angle tie broken by nearer travel distance");

        // Boundary consistency: for the UN-led chest point, the
        // picker's verdict and the leading fallback gate's verdict
        // (AimMath.leadQualifies) must agree on every geometry —
        // cone, range edge, behind, and the no-heading shot.
        Vec[] chests = {
                still40,                                            // edge, dead ahead
                strafe40,                                           // edge, strafed
                vv(40.5, 122.152, 3.0),                             // edge, strafed to the reversal bound
                vv(41.0, 122.152, 0.5),                             // just outside
                vv(40.4, 122.152, 3.5),                             // just inside, offset
                vv(0.5 + 20 * Math.cos(Math.toRadians(20)), 122.152,
                        0.5 + 20 * Math.sin(Math.toRadians(20))),   // in range, outside the cone
                vv(-9.5, 122.152, 0.5),                             // behind the shooter
        };
        String[] names = {"edge dead ahead", "edge strafed", "edge strafed to bound",
                "just outside", "just inside offset", "outside cone", "behind"};
        for (int i = 0; i < chests.length; i++) {
            boolean gate = AimMath.leadQualifies(vel, org, chests[i], CONE3, RANGE3);
            int pick = TargetPicker.pickBest(List.of(measured(vel, org, chests[i])), CONE3, RANGE3);
            Check.ok((pick == 0) == gate,
                    "0.1.3: picker and fallback gate agree (" + names[i] + ": gate=" + gate + ", pick=" + pick + ")");
        }
        Vec upVel = vv(0, 3, 0);
        boolean upGate = AimMath.leadQualifies(upVel, org, still40, CONE3, RANGE3);
        int upPick = TargetPicker.pickBest(List.of(measured(upVel, org, still40)), CONE3, RANGE3);
        Check.ok((upPick == 0) == upGate && upPick == -1,
                "0.1.3: straight-up shot — picker and gate both refuse (no heading)");
    }
}
