import com.winkreyes.excelaimassist.core.ToggleStore;

import java.util.UUID;

public class ToggleStoreTest {
    static final UUID A = UUID.fromString("11111111-1111-1111-1111-111111111111");
    static final UUID B = UUID.fromString("22222222-2222-2222-2222-222222222222");
    static final UUID C = UUID.fromString("33333333-3333-3333-3333-333333333333");

    public static void run() {
        System.out.println("ToggleStoreTest");

        // Default is ON for anyone who never toggled.
        ToggleStore fresh = new ToggleStore();
        Check.ok(fresh.isEnabled(A), "fresh store: unknown player defaults ON");
        Check.ok(!fresh.hasExplicit(A), "fresh store: no explicit choice recorded");
        Check.ok(fresh.isEnabled(null), "null uuid reads as default ON (no crash)");

        // Explicit choices stick and are independent per player.
        ToggleStore s = new ToggleStore();
        s.set(A, false);
        s.set(B, true);
        Check.ok(!s.isEnabled(A), "explicit OFF reads OFF");
        Check.ok(s.isEnabled(B), "explicit ON reads ON");
        Check.ok(s.isEnabled(C), "untouched third player still defaults ON");
        Check.eq(2, s.size(), "two explicit toggles stored");

        // Serialize -> parse round-trip restores exactly.
        ToggleStore.ParseResult rt = ToggleStore.parse(s.serialize());
        Check.eq(0, rt.errors().size(), "round-trip produces no parse errors");
        Check.ok(!rt.store().isEnabled(A), "round-trip keeps A OFF");
        Check.ok(rt.store().isEnabled(B), "round-trip keeps B ON");
        Check.ok(rt.store().hasExplicit(B), "round-trip keeps B explicit");
        Check.ok(!rt.store().hasExplicit(C), "round-trip keeps C implicit");

        // Serialized form is sorted + stable across a second round-trip.
        String once = s.serialize();
        String twice = ToggleStore.parse(once).store().serialize();
        Check.eq(once, twice, "serialize is idempotent (sorted, stable)");
        Check.ok(once.indexOf(A.toString()) < once.indexOf(B.toString()), "serialize sorts by uuid");

        // Parse tolerates real-world file shapes.
        ToggleStore.ParseResult messy = ToggleStore.parse(
                "# a comment\n\n  \n" + A + " = off \n" + B + "=TRUE\n");
        Check.eq(0, messy.errors().size(), "comments/blanks/whitespace/case tolerated");
        Check.ok(!messy.store().isEnabled(A), "messy parse: 'off' with spaces reads OFF");
        Check.ok(messy.store().isEnabled(B), "messy parse: 'TRUE' reads ON");

        // Junk rows are reported and skipped; good rows survive.
        ToggleStore.ParseResult junk = ToggleStore.parse(
                "not-a-uuid=off\n" + A + "=maybe\nnoequalsline\n" + B + "=off\n");
        Check.eq(3, junk.errors().size(), "three junk rows reported");
        Check.ok(!junk.store().isEnabled(B), "good row survives junk neighbours");
        Check.ok(junk.store().isEnabled(A), "row with bad value skipped -> default ON");

        // Later duplicate wins (a re-toggle appended by hand edits).
        ToggleStore.ParseResult dup = ToggleStore.parse(A + "=off\n" + A + "=on\n");
        Check.ok(dup.store().isEnabled(A), "duplicate rows: last one wins");

        // Empty inputs.
        Check.eq(0, ToggleStore.parse(null).errors().size(), "null text parses clean");
        Check.eq(0, ToggleStore.parse("").store().size(), "empty text = fresh store");
        Check.ok(new ToggleStore().serialize().contains("#"), "fresh serialize still writes the header");

        // toggle() — the 0.1.4 menu/command flip (state-flipping, never stale).
        ToggleStore t = new ToggleStore();
        Check.ok(!t.toggle(A), "toggle: default ON flips to OFF, returns new state");
        Check.ok(!t.isEnabled(A), "toggle: state is OFF after first flip");
        Check.ok(t.hasExplicit(A), "toggle: flip records an explicit choice");
        Check.ok(t.toggle(A), "toggle: OFF flips back to ON");
        Check.ok(t.isEnabled(A), "toggle: state is ON after second flip");
        t.set(B, false);
        Check.ok(t.toggle(B), "toggle: explicit OFF flips to ON");
        Check.ok(t.isEnabled(C), "toggle: other players untouched");
        Check.eq(2, t.size(), "toggle: two explicit choices stored");
        // A toggle survives the same serialize -> parse round-trip as set().
        ToggleStore.ParseResult trt = ToggleStore.parse(t.serialize());
        Check.ok(trt.store().isEnabled(A), "toggle: round-trip keeps A ON");
        Check.ok(trt.store().isEnabled(B), "toggle: round-trip keeps B ON");
        // Double-toggle returns to the starting state (menu double-click safety).
        ToggleStore d = new ToggleStore();
        d.toggle(C);
        d.toggle(C);
        Check.ok(d.isEnabled(C), "toggle: double flip returns to default ON");
        // Null still fails loudly, like set().
        boolean threw = false;
        try { t.toggle(null); } catch (IllegalArgumentException expected) { threw = true; }
        Check.ok(threw, "toggle: null uuid throws, matching set()");
    }
}
