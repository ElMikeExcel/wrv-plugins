import com.winkreyes.excelaimassist.core.AdminCommands;
import com.winkreyes.excelaimassist.core.ToggleStore;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

/**
 * The 0.1.5 console-admin surface (/aimassist admin status /
 * admin set), in the house Check style. What is pinned here: the
 * gate decision (console allowed, permission otherwise, denial
 * for a non-admin), the on/off parsing, the exact status and set
 * reply texts for every state shape the real ToggleStore can
 * hold (explicit ON, explicit OFF, default ON with no entry),
 * status being read-only, set writing through the store's real
 * API (explicit entry, persistence round-trip, other players
 * untouched), the malformed-usage and not-found texts, and the
 * plugin.yml wiring (version 0.1.5, excelaimassist.admin
 * defaulting to op, the toggle node unchanged, and NO
 * command-level permission gate that would close the
 * self-service forms) — read off the shipped plugin.yml, like
 * the Quartermaster PackStatusTest, so the gate cannot silently
 * drift.
 */
public class AdminCommandsTest {
    static final UUID A = UUID.fromString("11111111-1111-1111-1111-111111111111");
    static final UUID B = UUID.fromString("22222222-2222-2222-2222-222222222222");
    static final UUID C = UUID.fromString("33333333-3333-3333-3333-333333333333");

    public static void run() {
        System.out.println("AdminCommandsTest");

        // ---- the gate: console allowed, permission otherwise ----
        Check.ok(AdminCommands.allowed(true, false), "gate: console allowed without the node (explicit console path)");
        Check.ok(AdminCommands.allowed(true, true), "gate: console allowed with the node");
        Check.ok(AdminCommands.allowed(false, true), "gate: non-console sender WITH excelaimassist.admin allowed");
        Check.ok(!AdminCommands.allowed(false, false), "gate: non-console sender WITHOUT the node denied");
        Check.eq("excelaimassist.admin", AdminCommands.PERMISSION, "gate: permission node name");

        // ---- on/off parsing for the set form ----
        Check.eq(Boolean.TRUE, AdminCommands.parseOnOff("on"), "parse: 'on' -> TRUE");
        Check.eq(Boolean.TRUE, AdminCommands.parseOnOff("ON"), "parse: 'ON' (case) -> TRUE");
        Check.eq(Boolean.FALSE, AdminCommands.parseOnOff("off"), "parse: 'off' -> FALSE");
        Check.eq(Boolean.FALSE, AdminCommands.parseOnOff("False"), "parse: 'False' (file spelling) -> FALSE");
        Check.eq(Boolean.TRUE, AdminCommands.parseOnOff(" true "), "parse: ' true ' (trimmed) -> TRUE");
        Check.eq(null, AdminCommands.parseOnOff("toggle"), "parse: 'toggle' is not a set value -> null (usage)");
        Check.eq(null, AdminCommands.parseOnOff("maybe"), "parse: junk -> null (usage)");
        Check.eq(null, AdminCommands.parseOnOff(null), "parse: null -> null (usage), no crash");

        // ---- status: exact replies for every real state shape ----
        ToggleStore s = new ToggleStore();
        s.set(A, false);
        s.set(B, true);
        Check.eq("Aim assist status for Marvin (" + A + "): OFF (explicit choice).",
                AdminCommands.statusMessage(s, "Marvin", A), "status: explicit OFF reply");
        Check.eq("Aim assist status for Marvin (" + B + "): ON (explicit choice).",
                AdminCommands.statusMessage(s, "Marvin", B), "status: explicit ON reply");
        Check.eq("Aim assist status for NewPlayer (" + C + "): ON (default - no explicit choice stored).",
                AdminCommands.statusMessage(s, "NewPlayer", C), "status: never-toggled player reads default ON, spelled out");
        Check.eq("Aim assist status for that player (" + A + "): OFF (explicit choice).",
                AdminCommands.statusMessage(s, "  ", A), "status: blank name falls back gracefully");
        Check.eq("Aim assist status for Marvin (unknown uuid): ON (default - no explicit choice stored).",
                AdminCommands.statusMessage(s, "Marvin", null), "status: null uuid renders as unknown uuid, never throws");

        // ---- status is read-only ----
        String before = s.serialize();
        AdminCommands.statusMessage(s, "NewPlayer", C);
        AdminCommands.statusMessage(s, "Marvin", A);
        Check.eq(2, s.size(), "status: reading creates no entry for a default player");
        Check.eq(before, s.serialize(), "status: store bytes unchanged by reads");
        Check.ok(!s.hasExplicit(C), "status: default player still has no explicit choice after a read");

        // ---- set: writes through the store's real API ----
        ToggleStore t = new ToggleStore();
        Check.eq("Aim assist for NewPlayer (" + C + ") set to OFF (was ON).",
                AdminCommands.applySet(t, "NewPlayer", C, false), "set: default ON -> OFF reply names the was-state");
        Check.ok(!t.isEnabled(C), "set: target now reads OFF (the state the self toggle and menus read)");
        Check.ok(t.hasExplicit(C), "set: choice stored as an explicit entry, like the player's own on/off");
        Check.eq("Aim assist for Marvin (" + C + ") set to ON (was OFF).",
                AdminCommands.applySet(t, "Marvin", C, true), "set: explicit OFF -> ON reply");
        Check.eq("Aim assist for Marvin (" + C + ") set to ON (was ON).",
                AdminCommands.applySet(t, "Marvin", C, true), "set: same-value set is a no-op write, reply still truthful");
        Check.ok(t.isEnabled(B), "set: other players untouched");
        ToggleStore.ParseResult rt = ToggleStore.parse(t.serialize());
        Check.eq(0, rt.errors().size(), "set: persisted form parses clean");
        Check.ok(rt.store().isEnabled(C) && rt.store().hasExplicit(C), "set: choice survives the serialize -> parse round-trip (toggles.txt persistence)");
        Check.eq("Aim assist for that player (" + A + ") set to OFF (was ON).",
                AdminCommands.applySet(new ToggleStore(), null, A, false), "set: null name falls back gracefully");

        // ---- malformed usage + not-found texts ----
        Check.eq("Usage: /aimassist admin status <player>", AdminCommands.USAGE_STATUS, "usage: status form");
        Check.eq("Usage: /aimassist admin set <player> on|off", AdminCommands.USAGE_SET, "usage: set form");
        Check.eq("You do not have permission to do that. (excelaimassist.admin required)",
                AdminCommands.DENIED, "denied: text names the required node");
        Check.eq("No online player named 'NobodyHereXYZ', and it is not a UUID. Nothing was looked up.",
                AdminCommands.notFoundStatus("NobodyHereXYZ"), "not-found: status rejection (nothing looked up)");
        Check.eq("No online player named 'NobodyHereXYZ', and it is not a UUID. Nothing was changed.",
                AdminCommands.notFoundSet("NobodyHereXYZ"), "not-found: set rejection (nothing changed)");

        // ---- plugin.yml wiring (read off the shipped file) ----
        String yml = null;
        try {
            try (InputStream in = AdminCommandsTest.class.getResourceAsStream("/plugin.yml")) {
                if (in != null) yml = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
            if (yml == null && Files.exists(Path.of("plugin.yml"))) {
                yml = Files.readString(Path.of("plugin.yml"));
            }
        } catch (Exception e) {
            System.out.println("    plugin.yml read failed: " + e);
        }
        Check.ok(yml != null, "plugin.yml is readable from the test run");
        if (yml != null) {
            Check.ok(yml.contains("version: 0.1.5"), "plugin.yml: version is 0.1.5");
            Check.ok(yml.contains("  excelaimassist.admin:"), "plugin.yml: the admin permission is declared");
            Check.ok(yml.contains("default: op"), "plugin.yml: the admin permission defaults to op (console satisfies op)");
            Check.ok(yml.contains("  excelaimassist.toggle:"), "plugin.yml: the menu toggle node is still declared");
            Check.ok(yml.contains("default: true"), "plugin.yml: the menu toggle node still defaults to true (menu behaviour unchanged)");
            Check.ok(yml.contains("/aimassist admin status <player>"), "plugin.yml: usage names the admin status form");
            Check.ok(yml.contains("/aimassist admin set <player> on|off"), "plugin.yml: usage names the admin set form");
            Check.ok(!yml.contains("\n    permission:"), "plugin.yml: NO command-level permission gate (self-service forms stay open to every player)");
        }
    }
}
