import com.winkreyes.excelaimassist.core.AimMath;
import com.winkreyes.excelaimassist.core.AimMath.Vec;

public class AimMathTest {
    static Vec v(double x, double y, double z) { return new Vec(x, y, z); }

    public static void run() {
        System.out.println("AimMathTest");

        // --- angleDegrees: known geometry ---
        Check.close(0.0, AimMath.angleDegrees(v(1, 0, 0), v(1, 0, 0)), "identical direction = 0 deg");
        Check.near(0.0, AimMath.angleDegrees(v(2, 0, 0), v(5, 0, 0)), 1e-9, "parallel, different lengths = 0 deg");
        Check.close(180.0, AimMath.angleDegrees(v(1, 0, 0), v(-1, 0, 0)), "opposite = 180 deg");
        Check.close(90.0, AimMath.angleDegrees(v(1, 0, 0), v(0, 1, 0)), "perpendicular = 90 deg");
        Check.near(45.0, AimMath.angleDegrees(v(1, 0, 0), v(1, 1, 0)), 1e-9, "diagonal = 45 deg");
        Check.near(4.0, AimMath.angleDegrees(v(1, 0, 0),
                v(Math.cos(Math.toRadians(4)), Math.sin(Math.toRadians(4)), 0)), 1e-6, "constructed 4 deg offset measures 4");
        Check.near(6.0, AimMath.angleDegrees(v(0, 0, -3),
                v(Math.sin(Math.toRadians(6)) * 3, 0, -Math.cos(Math.toRadians(6)) * 3)), 1e-6,
                "constructed 6 deg offset (cone edge) measures 6");
        Check.near(30.0, AimMath.angleDegrees(v(1, 0, 0),
                v(Math.cos(Math.toRadians(30)), 0, Math.sin(Math.toRadians(30)))), 1e-6, "3D offset measures true angle");

        // --- angleDegrees: degenerate vectors ---
        Check.ok(Double.isNaN(AimMath.angleDegrees(v(0, 0, 0), v(1, 0, 0))), "zero first vector = NaN");
        Check.ok(Double.isNaN(AimMath.angleDegrees(v(1, 0, 0), v(0, 0, 0))), "zero second vector = NaN");
        Check.ok(Double.isNaN(AimMath.angleDegrees(null, v(1, 0, 0))), "null vector = NaN");

        // --- bentVelocity: speed preserved, direction exact ---
        Vec bent = AimMath.bentVelocity(v(3, 0, 0), v(0, 1.62, 0), v(10, 1.0, 0));
        Check.near(3.0, bent.length(), 1e-9, "bend preserves speed exactly");
        Vec want = v(10, 1.0, 0).sub(v(0, 1.62, 0)).normalized();
        Vec got = bent.normalized();
        Check.near(want.x(), got.x(), 1e-9, "bent direction x matches origin->aim");
        Check.near(want.y(), got.y(), 1e-9, "bent direction y matches origin->aim");
        Check.near(want.z(), got.z(), 1e-9, "bent direction z matches origin->aim");
        Check.near(0.0, AimMath.angleDegrees(bent, v(10, 1.0, 0).sub(v(0, 1.62, 0))), 1e-6,
                "bent velocity is collinear with origin->aim");

        // Dead-on shot: bending toward a point already on the line changes nothing.
        Vec deadOn = AimMath.bentVelocity(v(0, 0, -3), v(0, 1.62, 0), v(0, 1.62, -10));
        Check.near(0.0, deadOn.x(), 1e-12, "dead-on bend keeps x");
        Check.near(0.0, deadOn.y(), 1e-12, "dead-on bend keeps y");
        Check.near(-3.0, deadOn.z(), 1e-12, "dead-on bend keeps z");

        // --- bentVelocity: safety edges ---
        Vec zeroVel = AimMath.bentVelocity(v(0, 0, 0), v(0, 0, 0), v(5, 0, 0));
        Check.ok(zeroVel.isZero(), "zero velocity is never bent");
        Vec tiny = AimMath.bentVelocity(v(1e-9, 0, 0), v(0, 0, 0), v(5, 0, 0));
        Check.close(1e-9, tiny.x(), "sub-threshold velocity returned untouched");
        Vec samePoint = AimMath.bentVelocity(v(1, 2, 3), v(4, 4, 4), v(4, 4, 4));
        Check.close(1.0, samePoint.x(), "aim point on origin: velocity unchanged (x)");
        Check.close(2.0, samePoint.y(), "aim point on origin: velocity unchanged (y)");
        Check.close(3.0, samePoint.z(), "aim point on origin: velocity unchanged (z)");
        Check.ok(AimMath.bentVelocity(null, v(0, 0, 0), v(1, 0, 0)) == null, "null velocity passes through");

        // --- Vec basics the glue relies on ---
        Check.close(5.0, v(3, 4, 0).length(), "length 3-4-5");
        Check.close(1.0, v(3, 4, 0).normalized().length(), "normalized length 1");
        Check.ok(v(0, 0, 0).normalized().isZero(), "zero vector normalizes to itself");

        // --- 0.1.1 ballistics: an UNcompensated straight-line snap lands low ---
        Vec eye = v(0, 1.62, 0);
        Vec flatVel = v(3.0, 0, 0); // full-draw speed, fired perfectly level
        double pass10 = AimMath.passHeightAt(eye, flatVel, v(10, 1.62, 0));
        Check.ok(pass10 < 1.62 && pass10 > 1.0,
                "flat shot passes below launch height at 10 blocks (drop is real), got " + pass10);
        double pass40 = AimMath.passHeightAt(eye, flatVel, v(40, 1.62, 0));
        Check.ok(1.62 - pass40 > 3.0,
                "flat shot falls more than 3 blocks short of launch height at 40, got drop " + (1.62 - pass40));
        Check.ok(Double.isNaN(AimMath.passHeightAt(eye, v(-3.0, 0, 0), v(10, 1.62, 0))),
                "shot fired away from the target never crosses it (NaN)");

        // --- 0.1.1 drop compensation: the snapped shot LANDS on the chest ---
        // Rig-shaped geometry: eye at 1.62, zombie chest (0.6 x 1.95) at 1.17.
        double prevRaise = -1;
        Vec rawVel = v(3.0, 0.2, 0.4); // a spread shot; its true length is the speed to preserve
        double rawSpeed = rawVel.length();
        for (double d : new double[]{10, 20, 30, 40}) {
            Vec chest = v(d, 1.17, 0);
            Vec aimPt = AimMath.dropCompensatedAimPoint(eye, chest, rawSpeed);
            Vec snapped = AimMath.bentVelocity(rawVel, eye, aimPt);
            Check.near(rawSpeed, snapped.length(), 1e-9, "compensated snap preserves speed at " + (int) d + " blocks");
            double landY = AimMath.passHeightAt(eye, snapped, chest);
            Check.near(1.17, landY, 0.25,
                    "compensated snap passes at chest height at " + (int) d + " blocks, got " + landY);
            Check.ok(aimPt.y() > chest.y(), "compensated aim point is above the chest at " + (int) d);
            double raise = aimPt.y() - chest.y();
            Check.ok(raise > prevRaise, "aim raise grows with distance (" + (int) d + " blocks: " + raise + ")");
            prevRaise = raise;
        }
        // Same solver at crossbow speed and at half-draw speed.
        Vec chest20 = v(20, 1.17, 0);
        Vec aimSlow = AimMath.dropCompensatedAimPoint(eye, chest20, 1.5);
        double landSlow = AimMath.passHeightAt(eye,
                AimMath.bentVelocity(v(1.5, 0, 0), eye, aimSlow), chest20);
        Check.near(1.17, landSlow, 0.25, "half-draw (speed 1.5) compensated snap still lands at 20, got " + landSlow);
        // Uncompensated contrast at 40: straight-line snap to the chest passes far below it.
        Vec chest40 = v(40, 1.17, 0);
        double landRaw = AimMath.passHeightAt(eye,
                AimMath.bentVelocity(v(3.0, 0, 0), eye, chest40), chest40);
        Check.ok(1.17 - landRaw > 2.5,
                "without compensation the 40-block snap passes >2.5 blocks under the chest, got " + (1.17 - landRaw));

        // --- horizontalDistance: the range-edge semantics (0.1.1 rig find) ---
        Vec projSpawn = v(0, 122.52, 0), chestEdge = v(40, 122.17, 0);
        Check.near(40.0, AimMath.horizontalDistance(projSpawn, chestEdge), 1e-9,
                "mob at exactly 40 horizontal measures exactly 40 (edge passes the range gate)");
        Check.ok(projSpawn.sub(chestEdge).length() > 40.0,
                "the same pair's raw 3D distance over-reads 40 (the 0.1.0 edge defect), got "
                        + projSpawn.sub(chestEdge).length());
        Check.near(5.0, AimMath.horizontalDistance(v(0, 99, 0), v(3, -50, 4)), 1e-9,
                "horizontal distance ignores height entirely (3-4-5 across a cliff)");
        Check.ok(Double.isNaN(AimMath.horizontalDistance(null, chestEdge)), "null point = NaN distance");

        // --- compensation safety edges ---
        Vec still = AimMath.dropCompensatedAimPoint(eye, chest20, 0.0);
        Check.ok(still.equals(chest20), "zero speed: aim point returned unchanged");
        Vec nullAim = AimMath.dropCompensatedAimPoint(null, chest20, 3.0);
        Check.ok(chest20.equals(nullAim), "null origin: target returned unchanged");

        // ============================================================
        // 0.1.2 — target leading
        // ============================================================

        // --- flightTicksAt: the flight-time estimate leading stands on ---
        Check.close(0.0, AimMath.flightTicksAt(eye, v(3, 0, 0), eye), "target at the origin XZ = 0 ticks");
        Check.ok(Double.isNaN(AimMath.flightTicksAt(eye, v(-3, 0, 0), chest20)),
                "shot fired away from the target never arrives (NaN)");
        double ticks40 = AimMath.flightTicksAt(eye, v(3, 0, 0), v(40, 1.62, 0));
        // Closed form for the drag series: 300*(1-0.99^n) = 40 -> n = 14.24.
        Check.near(14.24, ticks40, 0.35, "full-draw flight to 40 blocks ~14.2 ticks, got " + ticks40);
        double ticks20slow = AimMath.flightTicksAt(eye, v(1.5, 0, 0), v(20, 1.62, 0));
        Check.near(ticks40, ticks20slow, 0.35,
                "half speed to half distance = same flight time, got " + ticks20slow);
        double t10 = AimMath.flightTicksAt(eye, v(3, 0, 0), v(10, 1.62, 0));
        double t20 = AimMath.flightTicksAt(eye, v(3, 0, 0), v(20, 1.62, 0));
        double t30 = AimMath.flightTicksAt(eye, v(3, 0, 0), v(30, 1.62, 0));
        Check.ok(t10 < t20 && t20 < t30 && t30 < ticks40,
                "flight time grows with distance (" + t10 + " < " + t20 + " < " + t30 + " < " + ticks40 + ")");

        // --- ledAimPoint: identity cases (the 0.1.1 floor) ---
        double minSpeed = 0.5 / 20.0; // shipped default: 0.5 blocks/sec, in per-tick units
        Vec chestAt20 = v(20, 1.17, 0);
        Check.ok(chestAt20.equals(AimMath.ledAimPoint(eye, chestAt20, v(0, 0, 0), 3.0, true, minSpeed, 5.0)),
                "stationary target: led point IS the target, bit for bit");
        Check.ok(chestAt20.equals(AimMath.ledAimPoint(eye, chestAt20, v(0, 0, 0.01), 3.0, true, minSpeed, 5.0)),
                "target below the speed threshold (0.2 blocks/sec): no lead");
        Check.ok(chestAt20.equals(AimMath.ledAimPoint(eye, chestAt20, v(0, 0.5, 0), 3.0, true, minSpeed, 5.0)),
                "vertical-only motion: no lead (leading is horizontal)");
        Check.ok(chestAt20.equals(AimMath.ledAimPoint(eye, chestAt20, null, 3.0, true, minSpeed, 5.0)),
                "null target velocity: target unchanged");
        Check.ok(chestAt20.equals(AimMath.ledAimPoint(eye, chestAt20, v(0, 0, 0.1), 0.0, true, minSpeed, 5.0)),
                "zero shot speed: target unchanged");
        Check.ok(chestAt20.equals(AimMath.ledAimPoint(eye, chestAt20, v(0, 0, 0.1), 3.0, true, minSpeed, 0.0)),
                "max lead of 0: target unchanged");
        Check.ok(chestAt20.equals(AimMath.ledAimPoint(eye, chestAt20, v(0, 0, 0.1), 3.0, true, 99.0, 5.0)),
                "threshold above the target's speed: target unchanged (the lead-off equivalence)");

        // --- ledAimPoint: the prediction itself ---
        // Perpendicular strafe at the rig's profile: 0.10 blocks/tick = 2 blocks/sec.
        Vec ledStrafe = AimMath.ledAimPoint(eye, chestAt20, v(0, 0, 0.10), 3.0, true, minSpeed, 5.0);
        Check.close(20.0, ledStrafe.x(), "strafe lead keeps the target's x exactly");
        Check.close(1.17, ledStrafe.y(), "strafe lead keeps the chest height exactly");
        Check.ok(ledStrafe.z() > 0.5 && ledStrafe.z() < 0.95,
                "strafe lead at 20 blocks ~0.7 blocks ahead of the motion, got " + ledStrafe.z());
        // Moving directly away / directly toward the shooter.
        Vec ledAway = AimMath.ledAimPoint(eye, chestAt20, v(0.10, 0, 0), 3.0, true, minSpeed, 5.0);
        Check.ok(ledAway.x() > 20.4 && ledAway.x() < 21.3,
                "target fleeing straight away is led uprange, got x=" + ledAway.x());
        Vec ledToward = AimMath.ledAimPoint(eye, chestAt20, v(-0.10, 0, 0), 3.0, true, minSpeed, 5.0);
        Check.ok(ledToward.x() < 19.6 && ledToward.x() > 18.7,
                "target charging straight in is led downrange, got x=" + ledToward.x());
        // The clamp: an absurd 20 blocks/sec strafe at 40 blocks would
        // want ~14 blocks of lead; the cap holds it to exactly max.
        Vec chestAt40 = v(40, 1.17, 0);
        Vec ledClamped = AimMath.ledAimPoint(eye, chestAt40, v(0, 0, 1.0), 3.0, true, minSpeed, 5.0);
        Check.near(5.0, AimMath.horizontalDistance(chestAt40, ledClamped), 1e-9,
                "lead displacement clamps to exactly max-blocks");
        Check.ok(ledClamped.z() > 0, "clamped lead still points along the motion");

        // --- leadQualifies: the cone/range fallback gate ---
        Vec shotVel = v(3, 0, 0);
        Vec at10deg = v(20 * Math.cos(Math.toRadians(10)), 1.17, 20 * Math.sin(Math.toRadians(10)));
        Check.ok(AimMath.leadQualifies(shotVel, eye, at10deg, 15.0, 40.0),
                "led point 10 deg off at 20 blocks qualifies at cone 15 / range 40");
        Vec at20deg = v(20 * Math.cos(Math.toRadians(20)), 1.17, 20 * Math.sin(Math.toRadians(20)));
        Check.ok(!AimMath.leadQualifies(shotVel, eye, at20deg, 15.0, 40.0),
                "led point 20 deg off is outside cone 15: falls back");
        Check.ok(!AimMath.leadQualifies(shotVel, eye, v(41, 1.17, 0), 15.0, 40.0),
                "led point at 41 blocks is outside range 40: falls back");
        Check.ok(AimMath.leadQualifies(shotVel, eye, chestAt40, 15.0, 40.0),
                "led point exactly at the range edge qualifies (edge inclusive)");
        Check.ok(!AimMath.leadQualifies(shotVel, eye, v(Double.NaN, 1.17, 0), 15.0, 40.0),
                "NaN led point never qualifies");
        // The max-range strafe trap (0.1.2 rig find): a 40-block
        // target's led point sits 1.43 blocks sideways — its raw
        // horizontal distance measures 40.03, over the edge, but
        // the shot still TRAVELS exactly 40 to reach it, so the
        // travel-distance gate admits it.
        Vec velToFarChest = chestAt40.sub(eye).normalized().scale(3.0);
        Vec ledFar = v(40, 1.17, 1.43);
        Check.ok(AimMath.horizontalDistance(eye, ledFar) > 40.0,
                "the max-range led point's raw horizontal distance over-reads the edge ("
                        + AimMath.horizontalDistance(eye, ledFar) + ")");
        Check.ok(AimMath.leadQualifies(velToFarChest, eye, ledFar, 15.0, 40.0),
                "max-range led point qualifies on travel distance (the rig's 40-block strafe case)");
        Check.ok(!AimMath.leadQualifies(v(0, 3, 0), eye, ledFar, 15.0, 40.0),
                "a straight-up shot has no heading: led point never qualifies");

        // --- the full glue pipeline: speed preserved, stationary bit-identical ---
        Vec rawVel2 = v(2.9, 0.3, 0.2);
        double rawSpeed2 = rawVel2.length();
        Vec ledFull = AimMath.ledAimPoint(eye, chestAt20, v(0, 0, 0.10), rawSpeed2, true, minSpeed, 5.0);
        Vec bentLed = AimMath.bentVelocity(rawVel2, eye, AimMath.dropCompensatedAimPoint(eye, ledFull, rawSpeed2));
        Check.near(rawSpeed2, bentLed.length(), 1e-9, "led + compensated snap preserves speed exactly");
        Vec bentStillNew = AimMath.bentVelocity(rawVel2, eye, AimMath.dropCompensatedAimPoint(eye,
                AimMath.ledAimPoint(eye, chestAt20, v(0, 0, 0), rawSpeed2, true, minSpeed, 5.0), rawSpeed2));
        Vec bentStillOld = AimMath.bentVelocity(rawVel2, eye, AimMath.dropCompensatedAimPoint(eye, chestAt20, rawSpeed2));
        Check.ok(bentStillNew.equals(bentStillOld),
                "stationary target: the 0.1.2 pipeline's bent velocity is bit-identical to 0.1.1's");

        // --- end-to-end flight sim vs a strafing chest (the rig in miniature) ---
        // Full draw, bot-style aim straight at the chest; zombie strafes
        // at the rig profile (0.10 blocks/tick). With lead the arrow's
        // closest approach is inside the hitbox column; without lead
        // (the 0.1.1 snap) the zombie has stepped out of it at 20+.
        for (double d : new double[]{20, 30, 40}) {
            Vec chest = v(d, 1.17, 0);
            Vec vel0 = chest.sub(eye).normalized().scale(3.0);
            Vec chestVel = v(0, 0, 0.10);
            Vec snapOld = AimMath.bentVelocity(vel0, eye, AimMath.dropCompensatedAimPoint(eye, chest, 3.0));
            Vec ledPt = AimMath.ledAimPoint(eye, chest, chestVel, 3.0, true, minSpeed, 5.0);
            Vec snapNew = AimMath.bentVelocity(vel0, eye, AimMath.dropCompensatedAimPoint(eye, ledPt, 3.0));
            double missOld = closestApproach(eye, snapOld, chest, chestVel);
            double missNew = closestApproach(eye, snapNew, chest, chestVel);
            Check.ok(missNew < 0.2,
                    "led shot's closest approach at " + (int) d + " blocks is inside the hitbox, got " + missNew);
            Check.ok(missOld > 0.45,
                    "un-led shot's closest approach at " + (int) d + " blocks misses the hitbox, got " + missOld);
            Check.ok(missOld - missNew > 0.4,
                    "leading closes most of the gap at " + (int) d + " blocks (" + missOld + " -> " + missNew + ")");
        }

        // ============================================================
        // 0.1.3 — travelDistance: the one range measure
        // ============================================================

        // Rig-shaped geometry: arrow origin and zombie chest points
        // exactly as the scratch rig stages them (shooter at x=0.5,
        // zombie chest at x=0.5+dist, chest height 1.152 above feet).
        Vec shotEast = v(3, -0.045, 0); // a real full-draw velocity, slight downward pitch
        Vec projOrigin = v(0.5, 122.62, 0.5);
        Vec chestStill40 = v(40.5, 122.152, 0.5);
        Check.near(40.0, AimMath.travelDistance(shotEast, projOrigin, chestStill40), 1e-9,
                "target dead ahead at 40: travel distance is exactly 40 (the stationary edge)");
        Vec chestStrafe40 = v(40.5, 122.152, 0.5 + 1.43);
        Check.near(40.0, AimMath.travelDistance(shotEast, projOrigin, chestStrafe40), 1e-9,
                "the same target 1.43 blocks sideways: travel distance still exactly 40");
        Check.ok(AimMath.horizontalDistance(projOrigin, chestStrafe40) > 40.0,
                "...while its raw horizontal distance over-reads the edge (the 0.1.1-0.1.2 picker defect), got "
                        + AimMath.horizontalDistance(projOrigin, chestStrafe40));
        Check.near(20.0, AimMath.travelDistance(shotEast, projOrigin, v(20.5, 122.152, 6.5)), 1e-9,
                "lateral offset never inflates the travel measure (20 along, 6 sideways)");
        Check.near(0.0, AimMath.travelDistance(shotEast, projOrigin, projOrigin), 1e-12,
                "point at the origin's XZ: travel distance 0");
        Check.ok(AimMath.travelDistance(shotEast, projOrigin, v(-9.5, 122.152, 0.5)) < 0.0,
                "point behind the heading: travel distance is negative");
        Check.ok(Double.isNaN(AimMath.travelDistance(v(0, 3, 0), projOrigin, chestStill40)),
                "straight-up shot (no horizontal heading): travel distance is NaN");
        Check.ok(Double.isNaN(AimMath.travelDistance(null, projOrigin, chestStill40)), "null velocity = NaN travel");
        Check.ok(Double.isNaN(AimMath.travelDistance(shotEast, null, chestStill40)), "null origin = NaN travel");
        Check.ok(Double.isNaN(AimMath.travelDistance(shotEast, projOrigin, null)), "null point = NaN travel");
        Check.near(AimMath.travelDistance(v(3, 0, 0), projOrigin, chestStrafe40),
                AimMath.travelDistance(v(3, -2.9, 0), projOrigin, chestStrafe40), 1e-9,
                "the shot's pitch never enters the measure — only its horizontal heading");
        // The refactored gate still reads its measure off the same helper:
        // its travel figure for the max-range strafe point IS the helper's.
        Check.ok(AimMath.leadQualifies(shotEast, projOrigin, chestStrafe40, 15.0, 40.0),
                "fallback gate admits the max-range strafing chest on the shared measure");
    }

    /**
     * Smallest horizontal distance between a simulated projectile
     * (vanilla tick: integrate, drag, gravity) and a chest point
     * moving at a constant per-tick velocity, over the flight.
     * Positions are sampled at 0.02-tick substeps: at ~3 blocks
     * per tick, whole-tick sampling would swamp the lateral miss
     * with along-track sampling error (the game itself sweeps
     * the arrow's per-tick segment against hitboxes).
     */
    static double closestApproach(Vec origin, Vec velocity, Vec targetStart, Vec targetVelPerTick) {
        Vec pos = origin, vel = velocity, tgt = targetStart;
        double best = Double.MAX_VALUE;
        int substeps = 50;
        for (int tick = 0; tick < 400; tick++) {
            for (int s = 0; s < substeps; s++) {
                pos = pos.add(vel.scale(1.0 / substeps));
                tgt = tgt.add(targetVelPerTick.scale(1.0 / substeps));
                double dx = pos.x() - tgt.x(), dz = pos.z() - tgt.z();
                double dist = Math.sqrt(dx * dx + dz * dz);
                // Only count passes while the shot is roughly at body height.
                if (Math.abs(pos.y() - tgt.y()) < 1.0 && dist < best) best = dist;
            }
            vel = vel.scale(AimMath.PROJECTILE_DRAG);
            vel = new Vec(vel.x(), vel.y() - AimMath.PROJECTILE_GRAVITY, vel.z());
            if (vel.dot(vel) < 1.0e-12) break;
        }
        return best;
    }
}
