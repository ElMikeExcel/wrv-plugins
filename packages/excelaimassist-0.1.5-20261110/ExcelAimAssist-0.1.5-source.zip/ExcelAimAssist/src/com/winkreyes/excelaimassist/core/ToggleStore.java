package com.winkreyes.excelaimassist.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

/**
 * Per-player aim-assist toggles. Default is ON — a player who has
 * never touched /aimassist has the assist. Only explicit choices
 * are stored, in a tiny line file the glue persists:
 *
 *   <uuid>=on
 *   <uuid>=off
 *
 * One bad line never sinks the file: bad rows are skipped and
 * reported in the parse errors (the glue logs them as warnings).
 * Pure logic; the glue owns the file itself.
 */
public final class ToggleStore {

    public record ParseResult(ToggleStore store, List<String> errors) {}

    // Sorted by UUID string so the persisted file is stable.
    private final Map<UUID, Boolean> explicit = new TreeMap<>((a, b) -> a.toString().compareTo(b.toString()));

    /** Assist state for a player: the explicit choice, else the default ON. */
    public boolean isEnabled(UUID id) {
        if (id == null) return true;
        Boolean b = explicit.get(id);
        return b == null || b;
    }

    /** True when the player has an explicit stored choice. */
    public boolean hasExplicit(UUID id) {
        return id != null && explicit.containsKey(id);
    }

    public void set(UUID id, boolean on) {
        if (id == null) throw new IllegalArgumentException("uuid is null");
        explicit.put(id, on);
    }

    /**
     * Flip a player's state and store the result as an explicit
     * choice (since 0.1.4 — backs /aimassist toggle and the Server
     * Menu buttons, which must never write a stale state read
     * earlier). Returns the NEW state: true = assist on.
     */
    public boolean toggle(UUID id) {
        boolean now = !isEnabled(id);
        set(id, now);
        return now;
    }

    public int size() {
        return explicit.size();
    }

    /** Parse the persisted text (null/empty = fresh store, no errors). */
    public static ParseResult parse(String text) {
        ToggleStore store = new ToggleStore();
        List<String> errors = new ArrayList<>();
        if (text == null || text.isBlank()) return new ParseResult(store, errors);
        for (String raw : text.split("\\R")) {
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            int eq = line.indexOf('=');
            if (eq <= 0) {
                errors.add("toggle line '" + line + "' has no '=' - skipped");
                continue;
            }
            UUID id;
            try {
                id = UUID.fromString(line.substring(0, eq).trim());
            } catch (Exception e) {
                errors.add("toggle line '" + line + "' has a bad UUID - skipped");
                continue;
            }
            String value = line.substring(eq + 1).trim().toLowerCase();
            if (value.equals("on") || value.equals("true")) {
                store.explicit.put(id, Boolean.TRUE);
            } else if (value.equals("off") || value.equals("false")) {
                store.explicit.put(id, Boolean.FALSE);
            } else {
                errors.add("toggle line '" + line + "' has an unknown value '" + value + "' - skipped");
            }
        }
        return new ParseResult(store, errors);
    }

    /** Serialize for persistence: header + one sorted line per explicit toggle. */
    public String serialize() {
        StringBuilder sb = new StringBuilder();
        sb.append("# ExcelAimAssist per-player toggles (default: on).\n");
        for (Map.Entry<UUID, Boolean> e : explicit.entrySet()) {
            sb.append(e.getKey()).append('=').append(e.getValue() ? "on" : "off").append('\n');
        }
        return sb.toString();
    }

    /** Unmodifiable snapshot of explicit choices, sorted by UUID string. */
    public Map<UUID, Boolean> snapshot() {
        return Collections.unmodifiableMap(new TreeMap<>(explicit));
    }
}
