package com.winkreyes.excelaimassist;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;

/**
 * Provides %aimassist_status% -> ON/OFF for the Server Menu's Aim
 * Assist toggle trio (ExcelMenu view-requirement string-equals,
 * the ExcelMenuJoin %menujoin_status% pattern). Plain ON/OFF with
 * no color codes: the menu compares the raw string. Registered
 * only when PlaceholderAPI is present; without it the menu shows
 * its "unavailable" fallback item and nothing breaks.
 */
public class ExcelAimAssistExpansion extends PlaceholderExpansion {
    private final ExcelAimAssist plugin;
    public ExcelAimAssistExpansion(ExcelAimAssist plugin) { this.plugin = plugin; }
    @Override public String getIdentifier() { return "aimassist"; }
    @Override public String getAuthor() { return "WinkReyesValley"; }
    @Override public String getVersion() { return plugin.getDescription().getVersion(); }
    @Override public boolean persist() { return true; }
    @Override public String onPlaceholderRequest(Player p, String id) {
        if (p == null) return "";
        if (id.equalsIgnoreCase("status")) return plugin.aimStatus(p.getUniqueId());
        return null;
    }
}
