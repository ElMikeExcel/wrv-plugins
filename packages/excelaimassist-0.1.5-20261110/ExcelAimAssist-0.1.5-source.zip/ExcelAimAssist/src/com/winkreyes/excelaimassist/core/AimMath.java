package com.winkreyes.excelaimassist.core;

/**
 * Pure 3D aim geometry for the magnetism snap. No Bukkit types
 * here — the glue converts locations/vectors to Vec and back.
 * All angles are degrees.
 *
 * Since 0.1.1 the snap is drop-compensated: a straight-line snap
 * at a far mob still arcs under gravity and lands low (about
 * 4.5 blocks low at 40 blocks for a full-draw bow), so the snap
 * aims at a RAISED point whose simulated trajectory passes
 * through the real target point. The simulation below mirrors
 * the vanilla arrow/trident tick: position integrates the
 * current velocity, then drag (x0.99) and gravity (-0.05) shape
 * the next tick.
 *
 * Since 0.1.2 the snap also LEADS a moving target: the led aim
 * point is where the target's chest will be when the shot
 * arrives, predicted from the target's current velocity and
 * the simulated time of flight. Leading is horizontal only,
 * gated by a minimum target speed (a stationary target's led
 * point is the target itself, bit for bit), and clamped to a
 * maximum lead distance.
 *
 * Since 0.1.3 the picker's range gate judges the same measure
 * as the leading fallback gate: the along-shot travel distance
 * ({@link #travelDistance}) — how far the shot itself travels
 * to reach the target, projected onto the shot's horizontal
 * heading. The raw horizontal distance over-reads a strafing
 * target at exactly max range (40.0 square plus any lateral
 * offset roots above 40) and silently un-picked it in 0.1.1
 * and 0.1.2; the travel measure is immune to the sideways step.
 */
public final class AimMath {

    /** Immutable 3D vector (doubles). */
    public record Vec(double x, double y, double z) {
        public Vec add(Vec o) { return new Vec(x + o.x, y + o.y, z + o.z); }
        public Vec sub(Vec o) { return new Vec(x - o.x, y - o.y, z - o.z); }
        public Vec scale(double s) { return new Vec(x * s, y * s, z * s); }
        public double length() { return Math.sqrt(x * x + y * y + z * z); }
        public double dot(Vec o) { return x * o.x + y * o.y + z * o.z; }
        public boolean isZero() { return x == 0.0 && y == 0.0 && z == 0.0; }

        /** Unit vector in the same direction; the zero vector maps to itself. */
        public Vec normalized() {
            double len = length();
            return len == 0.0 ? this : scale(1.0 / len);
        }
    }

    /** Below this a velocity is treated as "not moving" — never bent. */
    public static final double MIN_SPEED = 1.0e-6;

    /** Vanilla projectile physics per tick, in air: velocity multiplier. */
    public static final double PROJECTILE_DRAG = 0.99;

    /** Vanilla projectile physics per tick, in air: gravity subtracted from vy. */
    public static final double PROJECTILE_GRAVITY = 0.05;

    /** Simulation budget; a full-draw bow crosses 40 blocks in ~15 ticks. */
    private static final int MAX_SIM_TICKS = 400;

    private AimMath() {}

    /**
     * Angle between two direction vectors, in degrees, in [0, 180].
     * Returns NaN when either vector is zero-length (undefined
     * direction); callers treat NaN as "no measurable offset" and
     * never bend on it.
     */
    public static double angleDegrees(Vec a, Vec b) {
        if (a == null || b == null) return Double.NaN;
        double la = a.length(), lb = b.length();
        if (la == 0.0 || lb == 0.0) return Double.NaN;
        double cos = a.dot(b) / (la * lb);
        // Clamp float noise so acos never sees |cos| > 1.
        if (cos > 1.0) cos = 1.0;
        if (cos < -1.0) cos = -1.0;
        return Math.toDegrees(Math.acos(cos));
    }

    /**
     * The bent velocity: same speed as {@code velocity}, direction
     * exactly from {@code origin} toward {@code aimPoint}. Returns
     * {@code velocity} unchanged (same value) when the bend is
     * undefined: zero velocity, or the aim point sits exactly on
     * the origin (no direction to aim along).
     */
    public static Vec bentVelocity(Vec velocity, Vec origin, Vec aimPoint) {
        if (velocity == null || origin == null || aimPoint == null) return velocity;
        double speed = velocity.length();
        if (speed < MIN_SPEED) return velocity;
        Vec dir = aimPoint.sub(origin);
        if (dir.isZero()) return velocity;
        return dir.normalized().scale(speed);
    }

    /**
     * The height (world y) at which a projectile launched from
     * {@code origin} with {@code velocity} passes over the
     * target's horizontal (XZ) position, linearly interpolated
     * between the two ticks that bracket the crossing. Returns
     * NaN when the projectile's horizontal travel never reaches
     * the target's XZ (fired away from it, or it dies first).
     * A target at the origin's own XZ (straight up/down shot)
     * reports the origin's height.
     */
    public static double passHeightAt(Vec origin, Vec velocity, Vec target) {
        if (origin == null || velocity == null || target == null) return Double.NaN;
        double dx = target.x() - origin.x(), dz = target.z() - origin.z();
        double targetDist = Math.sqrt(dx * dx + dz * dz);
        if (targetDist == 0.0) return origin.y();
        double ux = dx / targetDist, uz = dz / targetDist;
        Vec pos = origin;
        Vec vel = velocity;
        Vec prevPos = pos;
        double prevAlong = 0.0;
        for (int tick = 0; tick < MAX_SIM_TICKS; tick++) {
            pos = pos.add(vel);
            double along = (pos.x() - origin.x()) * ux + (pos.z() - origin.z()) * uz;
            if (along >= targetDist) {
                double span = along - prevAlong;
                double f = span == 0.0 ? 0.0 : (targetDist - prevAlong) / span;
                return prevPos.y() + (pos.y() - prevPos.y()) * f;
            }
            vel = vel.scale(PROJECTILE_DRAG);
            vel = new Vec(vel.x(), vel.y() - PROJECTILE_GRAVITY, vel.z());
            prevPos = pos;
            prevAlong = along;
            if (vel.dot(vel) < 1.0e-12) break;
        }
        return Double.NaN;
    }

    /**
     * Horizontal (XZ-plane) distance between two points. Range
     * gating uses this, not the raw 3D distance: "40 blocks away"
     * is a ground-plane judgement, and the 3D distance to a chest
     * point runs a hair over the nominal range at the edge (the
     * vertical eye-to-chest gap adds ~0.002-0.005), which silently
     * ate the exact-edge case in 0.1.0 — a mob at exactly the
     * configured 30 measured 30.005 and was never a candidate.
     */
    public static double horizontalDistance(Vec a, Vec b) {
        if (a == null || b == null) return Double.NaN;
        double dx = a.x() - b.x(), dz = a.z() - b.z();
        return Math.sqrt(dx * dx + dz * dz);
    }

    /**
     * The fractional tick count at which a projectile launched
     * from {@code origin} with {@code velocity} crosses the
     * target's horizontal (XZ) distance, measured along the
     * shot's own horizontal heading — the same crossing
     * {@link #passHeightAt} reports the height for, interpolated
     * between the bracketing ticks. A target at the origin's own
     * XZ reports 0. Returns NaN when the projectile's horizontal
     * travel never reaches the target's XZ (fired away from it,
     * or it dies first).
     */
    public static double flightTicksAt(Vec origin, Vec velocity, Vec target) {
        if (origin == null || velocity == null || target == null) return Double.NaN;
        double dx = target.x() - origin.x(), dz = target.z() - origin.z();
        double targetDist = Math.sqrt(dx * dx + dz * dz);
        if (targetDist == 0.0) return 0.0;
        double ux = dx / targetDist, uz = dz / targetDist;
        Vec pos = origin;
        Vec vel = velocity;
        double prevAlong = 0.0;
        for (int tick = 0; tick < MAX_SIM_TICKS; tick++) {
            pos = pos.add(vel);
            double along = (pos.x() - origin.x()) * ux + (pos.z() - origin.z()) * uz;
            if (along >= targetDist) {
                double span = along - prevAlong;
                double f = span == 0.0 ? 0.0 : (targetDist - prevAlong) / span;
                return tick + f;
            }
            vel = vel.scale(PROJECTILE_DRAG);
            vel = new Vec(vel.x(), vel.y() - PROJECTILE_GRAVITY, vel.z());
            prevAlong = along;
            if (vel.dot(vel) < 1.0e-12) break;
        }
        return Double.NaN;
    }

    /**
     * The led aim point (0.1.2): where {@code target} (a chest
     * point) will be when a shot of {@code speed} fired from
     * {@code origin} arrives, given the target's current
     * {@code targetVelocity} (blocks per tick, the unit Bukkit
     * reports). The prediction is horizontal: the led point keeps
     * the target's height exactly. The flight time comes from
     * the same ballistics simulation as drop compensation,
     * iterated against the moving point until it settles.
     *
     * Identity guarantees (the 0.1.1 behaviour is the floor):
     * a target whose horizontal speed is below
     * {@code minTargetSpeedPerTick} — stationary included —
     * gets the target itself back, bit for bit; a shot that
     * cannot be simulated to the target, a non-positive
     * {@code maxLeadBlocks}, or any null input also returns the
     * target unchanged. The lead displacement is clamped to
     * {@code maxLeadBlocks} of horizontal travel.
     */
    public static Vec ledAimPoint(Vec origin, Vec target, Vec targetVelocity, double speed,
                                  boolean compensate, double minTargetSpeedPerTick,
                                  double maxLeadBlocks) {
        if (origin == null || target == null || targetVelocity == null) return target;
        if (speed < MIN_SPEED) return target;
        if (maxLeadBlocks <= 0.0) return target;
        double hvx = targetVelocity.x(), hvz = targetVelocity.z();
        double hSpeed = Math.sqrt(hvx * hvx + hvz * hvz);
        if (hSpeed < minTargetSpeedPerTick) return target;
        Vec point = target;
        for (int i = 0; i < 3; i++) {
            Vec flightAim = compensate ? dropCompensatedAimPoint(origin, point, speed) : point;
            Vec dir = flightAim.sub(origin);
            if (dir.isZero()) return target;
            double ticks = flightTicksAt(origin, dir.normalized().scale(speed), point);
            if (Double.isNaN(ticks)) return target;
            double leadX = hvx * ticks, leadZ = hvz * ticks;
            double leadLen = Math.sqrt(leadX * leadX + leadZ * leadZ);
            if (leadLen > maxLeadBlocks) {
                double s = maxLeadBlocks / leadLen;
                leadX *= s;
                leadZ *= s;
            }
            Vec next = new Vec(target.x() + leadX, target.y(), target.z() + leadZ);
            if (next.equals(point)) return next;
            point = next;
        }
        return point;
    }

    /**
     * The along-shot travel distance from {@code origin} to
     * {@code point}: the point's position projected onto the
     * shot's horizontal heading — how far the shot itself
     * travels before it is alongside the point. Sideways
     * displacement does not inflate it (a strafing target at
     * exactly max range keeps the travel distance it had
     * standing still), which is why range gating uses this
     * measure rather than the raw horizontal distance: the
     * Euclidean measure reads a max-range strafing target a
     * hair over the edge and vetoes exactly the shots the
     * assist exists for (the 0.1.1/0.1.2 picker edge, and the
     * same pathology the 0.1.1 range fix removed for the
     * un-led point). Negative when the point lies behind the
     * shot's heading; NaN on null input or a zero horizontal
     * heading (a straight up/down shot has no heading to
     * project onto). This is the ONE range measure of the
     * plugin: the picker (TargetPicker, via the glue) and the
     * {@link #leadQualifies} fallback gate both judge range
     * by it, so their boundary decisions agree by construction.
     */
    public static double travelDistance(Vec shotVelocity, Vec origin, Vec point) {
        if (shotVelocity == null || origin == null || point == null) return Double.NaN;
        double hvx = shotVelocity.x(), hvz = shotVelocity.z();
        double heading = Math.sqrt(hvx * hvx + hvz * hvz);
        if (heading == 0.0) return Double.NaN;
        return ((point.x() - origin.x()) * hvx + (point.z() - origin.z()) * hvz) / heading;
    }

    /**
     * Whether a led point still satisfies the snap's own gates:
     * its angle to the shot's {@code shotVelocity} within
     * {@code coneDegrees} (edge inclusive), and the shot's
     * travel distance to it ({@link #travelDistance}) within
     * {@code rangeBlocks} (edge inclusive). The range is judged
     * on travel distance, NOT on the raw horizontal distance to
     * the led point: leading displaces the aim point sideways,
     * and the Euclidean measure would inflate a max-range
     * target's led point a hair over the edge (a 40-block
     * target's 1.4-block lead measures 40.03) and veto exactly
     * the shots leading exists for. False on any NaN or a
     * zero-heading (straight up/down) shot. The glue falls back
     * to the un-led point when this is false, so a led shot is
     * never worse than the 0.1.1 snap. Since 0.1.3 the picker
     * judges a candidate's range by the same travel measure,
     * so a point this gate would admit at the chest is a point
     * the picker can pick in the first place.
     */
    public static boolean leadQualifies(Vec shotVelocity, Vec origin, Vec ledPoint,
                                        double coneDegrees, double rangeBlocks) {
        if (shotVelocity == null || origin == null || ledPoint == null) return false;
        double angle = angleDegrees(shotVelocity, ledPoint.sub(origin));
        if (Double.isNaN(angle) || angle > coneDegrees) return false;
        double along = travelDistance(shotVelocity, origin, ledPoint);
        return !Double.isNaN(along) && along >= 0.0 && along <= rangeBlocks;
    }

    /**
     * The drop-compensated aim point for a snap at {@code target}
     * with the given projectile {@code speed}: starts at the
     * target itself and repeatedly raises the aim point by the
     * simulated shortfall (the target's height minus the height
     * the shot actually passes at) until the simulated shot
     * passes within 0.02 blocks of the target's height. The aim
     * point only ever moves UP (same x/z); a shot that cannot be
     * simulated to the target keeps the aim it had. When the
     * speed is not moving, the target is returned unchanged.
     */
    public static Vec dropCompensatedAimPoint(Vec origin, Vec target, double speed) {
        if (origin == null || target == null) return target;
        if (speed < MIN_SPEED) return target;
        Vec aim = target;
        for (int i = 0; i < 4; i++) {
            Vec dir = aim.sub(origin);
            if (dir.isZero()) return target;
            double passY = passHeightAt(origin, dir.normalized().scale(speed), target);
            if (Double.isNaN(passY)) return aim;
            double shortfall = target.y() - passY;
            if (Math.abs(shortfall) <= 0.02) return aim;
            aim = new Vec(target.x(), aim.y() + shortfall, target.z());
        }
        return aim;
    }
}
