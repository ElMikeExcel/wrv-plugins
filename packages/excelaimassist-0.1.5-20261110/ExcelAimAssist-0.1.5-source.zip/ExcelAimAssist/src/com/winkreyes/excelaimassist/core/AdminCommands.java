package com.winkreyes.excelaimassist.core;

import java.util.UUID;

/**
 * The console-admin surface for one player's aim-assist toggle
 * (0.1.5, Mike's Nov 3, 2026 console-admin rule; the console-admin
 * coverage audit of Nov 9, 2026 found ExcelAimAssist a FAIL
 * because /aimassist was self-only and player-gated, so an
 * operator at the console could neither inspect nor fix another
 * player's toggle):
 *
 *   /aimassist admin status <player>
 *   /aimassist admin set <player> on|off
 *
 * Both forms are gated by the plugin.yml permission
 * {@link #PERMISSION} (default: op). The server console is
 * explicitly allowed ({@link #allowed}); any other sender needs
 * the permission. The check lives in code, not in a plugin.yml
 * command-level gate, because /aimassist itself must stay open
 * to every player for the self-service forms.
 *
 * What status reports — and what set changes — is exactly the
 * plugin's real state: the player's {@link ToggleStore} entry,
 * the same store the self toggle, /aimassist toggle, the Server
 * Menu buttons and %aimassist_status% all read. Status spells
 * out the state model's one subtlety: a player with no explicit
 * entry reads ON by default, and the reply says so, so a default
 * ON is never mistaken for a stored choice. Set writes through
 * {@link ToggleStore#set} — the same call the self-service
 * on/off forms make — so an admin-set choice is indistinguishable
 * from the player's own, persists in toggles.txt the same way,
 * and is what the menus and placeholder then report.
 *
 * Target resolution lives in the plugin class and is the house
 * shape: an online player by exact name first, then a raw UUID
 * (for offline players). This plugin keeps no name-to-UUID
 * record of its own, so an offline player known only by name
 * cannot be resolved — nothing here invents one.
 *
 * No Bukkit dependencies: the gate decision, the on/off parsing
 * and the exact reply texts live here and are unit-tested on a
 * plain JVM; the plugin class only resolves names, checks the
 * sender, persists after a set, and delivers the message.
 * Status is read-only by construction: it formats state the
 * caller already holds and mutates nothing.
 */
public final class AdminCommands {

    /** The admin permission node (plugin.yml, default: op). */
    public static final String PERMISSION = "excelaimassist.admin";

    /** Usage line for the admin status form. */
    public static final String USAGE_STATUS = "Usage: /aimassist admin status <player>";

    /** Usage line for the admin set form. */
    public static final String USAGE_SET = "Usage: /aimassist admin set <player> on|off";

    /** Reply when a non-console sender lacks the admin permission. */
    public static final String DENIED =
            "You do not have permission to do that. (excelaimassist.admin required)";

    private AdminCommands() {}

    /**
     * The gate decision: the console is always allowed (the
     * explicit console path, the ExcelCosmetics pattern); any
     * other sender needs the admin permission. In Bukkit/Paper
     * the console also satisfies hasPermission for an op-default
     * node — the explicit branch keeps the intent testable and
     * independent of that behaviour.
     */
    public static boolean allowed(boolean isConsole, boolean hasAdminPermission) {
        return isConsole || hasAdminPermission;
    }

    /**
     * Parse the set form's value: "on"/"true" -> TRUE,
     * "off"/"false" -> FALSE (the ToggleStore file spellings),
     * case-insensitive; anything else (including null) -> null,
     * which the caller answers with {@link #USAGE_SET}.
     */
    public static Boolean parseOnOff(String text) {
        if (text == null) return null;
        return switch (text.trim().toLowerCase()) {
            case "on", "true" -> Boolean.TRUE;
            case "off", "false" -> Boolean.FALSE;
            default -> null;
        };
    }

    /**
     * The one-line status reply for one player, from the store's
     * real state: the effective state (explicit choice, else the
     * default ON) with the explicit/default distinction spelled
     * out. Read-only: nothing is written to the store.
     *
     * @param displayName who to name in the reply (the online
     *                    player's name, or the target text — a
     *                    UUID string — for an offline target)
     * @param playerId    the resolved UUID, named in the reply so
     *                    an operator can re-use it verbatim
     */
    public static String statusMessage(ToggleStore store, String displayName, UUID playerId) {
        String who = (displayName == null || displayName.isBlank())
                ? "that player" : displayName;
        String id = playerId == null ? "unknown uuid" : playerId.toString();
        boolean on = store.isEnabled(playerId);
        String basis = store.hasExplicit(playerId)
                ? "explicit choice"
                : "default - no explicit choice stored";
        return "Aim assist status for " + who + " (" + id + "): "
                + (on ? "ON" : "OFF") + " (" + basis + ").";
    }

    /**
     * Apply a set to the store (the caller's glue persists
     * afterwards, exactly as the self-service forms do) and
     * return the one-line confirmation, naming the state before
     * and after so the log shows what actually changed.
     */
    public static String applySet(ToggleStore store, String displayName, UUID playerId,
                                  boolean on) {
        boolean was = store.isEnabled(playerId);
        store.set(playerId, on);
        String who = (displayName == null || displayName.isBlank())
                ? "that player" : displayName;
        String id = playerId == null ? "unknown uuid" : playerId.toString();
        return "Aim assist for " + who + " (" + id + ") set to "
                + (on ? "ON" : "OFF") + " (was " + (was ? "ON" : "OFF") + ").";
    }

    /** Rejection when a status target cannot be resolved. */
    public static String notFoundStatus(String target) {
        return "No online player named '" + target
                + "', and it is not a UUID. Nothing was looked up.";
    }

    /** Rejection when a set target cannot be resolved. */
    public static String notFoundSet(String target) {
        return "No online player named '" + target
                + "', and it is not a UUID. Nothing was changed.";
    }
}
