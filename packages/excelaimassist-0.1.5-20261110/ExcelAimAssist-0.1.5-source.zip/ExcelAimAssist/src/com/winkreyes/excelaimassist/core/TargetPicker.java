package com.winkreyes.excelaimassist.core;

import java.util.List;

/**
 * Picks which candidate mob (if any) a released shot bends toward.
 * Pure selection logic: the Bukkit glue measures each nearby
 * entity into a Candidate (angular offset from the shot's
 * direction, along-shot TRAVEL distance from the projectile —
 * see AimMath.travelDistance — line of sight, hostile flag)
 * and this class applies the rules:
 *
 *  - hostile mobs only (players/animals/villagers never arrive
 *    flagged hostile, and are double-guarded here);
 *  - line of sight required — no bending around walls;
 *  - travel distance must be within range;
 *  - angular offset must be within the cone, edge INCLUSIVE
 *    (a shot exactly at the cone edge still gets its nudge);
 *  - the smallest angular offset wins — that is the mob the
 *    player was most nearly aiming at; ties go to the nearer mob
 *    (by travel distance), then to the earlier candidate (stable).
 *
 * The cone bounds the assist: it only ever snaps a shot that was
 * already pointed near a mob. How near is config (15 degrees /
 * 40 blocks by default since 0.1.1). The selection rule is
 * unchanged from 0.1.0 EXCEPT the range measure: through 0.1.2
 * the candidate carried the raw horizontal distance, which
 * over-reads a strafing target standing at exactly max range
 * (any sideways step roots it above the edge) and silently
 * un-picked it; since 0.1.3 the candidate carries the along-shot
 * travel distance — the measure the leading fallback gate
 * (AimMath.leadQualifies) already used — so the picker's range
 * boundary and the fallback gate's agree by construction.
 */
public final class TargetPicker {

    public record Candidate(double angleDegrees, double travelDistance, boolean hasLineOfSight, boolean hostile) {}

    private TargetPicker() {}

    /**
     * Index of the winning candidate, or -1 when nothing qualifies.
     * NaN angles never qualify (undefined direction = no bend);
     * NaN or negative travel distances never qualify (no heading
     * to judge by, or the mob lies behind the shot).
     */
    public static int pickBest(List<Candidate> candidates, double coneDegrees, double rangeBlocks) {
        if (candidates == null || candidates.isEmpty()) return -1;
        if (Double.isNaN(coneDegrees) || coneDegrees < 0.0) return -1;
        if (Double.isNaN(rangeBlocks) || rangeBlocks <= 0.0) return -1;
        int best = -1;
        double bestAngle = 0.0, bestDist = 0.0;
        for (int i = 0; i < candidates.size(); i++) {
            Candidate c = candidates.get(i);
            if (c == null || !c.hostile() || !c.hasLineOfSight()) continue;
            if (Double.isNaN(c.angleDegrees()) || Double.isNaN(c.travelDistance())) continue;
            if (c.travelDistance() < 0.0 || c.travelDistance() > rangeBlocks) continue;
            if (c.angleDegrees() < 0.0 || c.angleDegrees() > coneDegrees) continue;
            if (best < 0 || c.angleDegrees() < bestAngle
                    || (c.angleDegrees() == bestAngle && c.travelDistance() < bestDist)) {
                best = i;
                bestAngle = c.angleDegrees();
                bestDist = c.travelDistance();
            }
        }
        return best;
    }
}
