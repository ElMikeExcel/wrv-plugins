package com.winkreyes.excelaimassist;

import com.winkreyes.excelaimassist.core.AdminCommands;
import com.winkreyes.excelaimassist.core.AimMath;
import com.winkreyes.excelaimassist.core.TargetPicker;
import com.winkreyes.excelaimassist.core.ToggleStore;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Trident;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

/**
 * ExcelAimAssist — strong bow magnetism (0.1.3).
 *
 * At the moment a player releases a bow/crossbow shot or throws a
 * trident, if a hostile mob is inside the cone around the shot's
 * direction (default 15 degrees, 40 blocks, line of sight
 * required — the candidate closest to the shot's trajectory
 * wins), the projectile's velocity is recomputed onto the line
 * to that mob's chest with its speed preserved exactly, raised
 * by the simulated gravity drop so the arc lands on the mob
 * instead of at its feet (drop compensation, on by default and
 * config-toggleable). Since 0.1.2 the snap also LEADS a moving
 * mob: the aim point is the chest's predicted position when the
 * shot arrives (target velocity x simulated flight time,
 * horizontal only, clamped, config-gated) — and only when that
 * predicted point still satisfies the cone and range gates; a
 * stationary mob is snapped exactly as in 0.1.1. Since 0.1.3 the
 * picker's range is judged on the shot's travel distance to the
 * mob (the measure the leading gate already used), so a mob
 * strafing at exactly max range stays pickable instead of
 * measuring a hair over the edge; nothing else about the snap
 * changed. A shot with nothing in its cone flies exactly as
 * released. Players are never targeted (PvP is off here, and
 * the candidate gate admits hostile mobs only).
 *
 * Nothing is ever shown in game for the assist itself: no
 * messages, no particles, no sounds. This is strong magnetism
 * by design (family server; touch and mobile aim) — the config
 * can soften it back without a rebuild. Per-player toggle:
 * /aimassist on|off|toggle, default ON, persisted in toggles.txt.
 *
 * Since 0.1.4 the toggle is also wired into the Server Menu on
 * both platforms, mirroring the ExcelSilkWatch pattern: the Java
 * menu reads %aimassist_status% (the PlaceholderAPI expansion in
 * ExcelAimAssistExpansion) and runs the namespaced on/off
 * commands; ExcelBedrockMenu reads aimStatus(UUID) reflectively
 * for its form label and dispatches "aimassist toggle" through
 * its guarded action path, so a menu click always flips the
 * CURRENT state and can never write a stale one.
 *
 * Since 0.1.5 an operator can also inspect and fix another
 * player's toggle from the console (Mike's Nov 3, 2026
 * console-admin rule; the Nov 9, 2026 coverage audit found
 * 0.1.3/0.1.4 a FAIL here): /aimassist admin status <player>
 * and /aimassist admin set <player> on|off, gated by the new
 * excelaimassist.admin permission (default op; the console is
 * explicitly allowed) and routed BEFORE the player-only gate
 * below. The reply texts and the gate decision live in
 * AdminCommands; the self-service forms are unchanged.
 *
 * Clean by construction against the neighbours: ExcelAttunement
 * and ExcelBossTrial both read the LANDED projectile and its
 * getShooter(); this plugin only ever rewrites a velocity vector
 * at release, never the shooter, never the entity.
 */
public final class ExcelAimAssist extends JavaPlugin implements Listener {

    private boolean masterEnabled = true;
    private double coneDegrees = 15.0;
    private double rangeBlocks = 40.0;
    private double aimHeightFraction = 0.6;
    private boolean dropCompensation = true;
    private boolean leadEnabled = true;
    private double leadMaxBlocks = 5.0;
    /** Config-facing unit: blocks per second. Bukkit velocities are per tick; the snap divides by 20. */
    private double leadMinTargetSpeedBps = 0.5;
    private boolean debug = false;
    private ToggleStore toggles = new ToggleStore();
    private File togglesFile;
    private ExcelAimAssistExpansion expansion;

    // ------------------------------------------------------------ lifecycle

    @Override
    public void onEnable() {
        saveDefaultConfig();
        masterEnabled = getConfig().getBoolean("enabled", true);
        coneDegrees = getConfig().getDouble("cone-degrees", 15.0);
        if (Double.isNaN(coneDegrees) || coneDegrees < 0.0 || coneDegrees > 45.0) {
            getLogger().warning("cone-degrees " + coneDegrees + " out of [0,45] - using 15.0");
            coneDegrees = 15.0;
        }
        rangeBlocks = getConfig().getDouble("range-blocks", 40.0);
        if (Double.isNaN(rangeBlocks) || rangeBlocks <= 0.0 || rangeBlocks > 100.0) {
            getLogger().warning("range-blocks " + rangeBlocks + " out of (0,100] - using 40.0");
            rangeBlocks = 40.0;
        }
        aimHeightFraction = getConfig().getDouble("aim-height-fraction", 0.6);
        if (Double.isNaN(aimHeightFraction) || aimHeightFraction <= 0.0 || aimHeightFraction > 1.0) {
            getLogger().warning("aim-height-fraction " + aimHeightFraction + " out of (0,1] - using 0.6");
            aimHeightFraction = 0.6;
        }
        dropCompensation = getConfig().getBoolean("drop-compensation", true);
        leadEnabled = getConfig().getBoolean("lead.enabled", true);
        leadMaxBlocks = getConfig().getDouble("lead.max-blocks", 5.0);
        if (Double.isNaN(leadMaxBlocks) || leadMaxBlocks <= 0.0 || leadMaxBlocks > 20.0) {
            getLogger().warning("lead.max-blocks " + leadMaxBlocks + " out of (0,20] - using 5.0");
            leadMaxBlocks = 5.0;
        }
        leadMinTargetSpeedBps = getConfig().getDouble("lead.min-target-speed", 0.5);
        if (Double.isNaN(leadMinTargetSpeedBps) || leadMinTargetSpeedBps < 0.0 || leadMinTargetSpeedBps > 10.0) {
            getLogger().warning("lead.min-target-speed " + leadMinTargetSpeedBps + " out of [0,10] - using 0.5");
            leadMinTargetSpeedBps = 0.5;
        }
        debug = getConfig().getBoolean("debug", false);

        togglesFile = new File(getDataFolder(), "toggles.txt");
        toggles = loadToggles();

        getServer().getPluginManager().registerEvents(this, this);
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            expansion = new ExcelAimAssistExpansion(this);
            expansion.register();
            getLogger().info("Hooked into PlaceholderAPI (%aimassist_status%).");
        }
        getLogger().info("ExcelAimAssist enabled: " + (masterEnabled ? "ON" : "OFF (master switch)")
                + ", cone " + coneDegrees + " deg, range " + rangeBlocks
                + " blocks, aim height " + aimHeightFraction
                + ", drop compensation " + (dropCompensation ? "ON" : "OFF")
                + ", target lead " + (leadEnabled
                        ? "ON (max " + leadMaxBlocks + " blocks, min target speed "
                                + leadMinTargetSpeedBps + " blocks/sec)"
                        : "OFF")
                + ", " + toggles.size() + " saved player toggle(s)");
    }

    @Override
    public void onDisable() {
        saveToggles();
        if (expansion != null) {
            try { expansion.unregister(); } catch (Exception ignored) { }
        }
    }

    // ------------------------------------------------------------ menu bridge

    /**
     * Public status API, read reflectively by ExcelBedrockMenu for
     * its Server Menu form label (the ExcelSilkWatch warningStatus
     * pattern): "ON" when the assist applies to this player —
     * explicit choice, else the default ON — else "OFF".
     */
    public String aimStatus(java.util.UUID uuid) {
        return toggles.isEnabled(uuid) ? "ON" : "OFF";
    }

    private ToggleStore loadToggles() {
        try {
            if (togglesFile != null && togglesFile.exists()) {
                ToggleStore.ParseResult parsed = ToggleStore.parse(Files.readString(togglesFile.toPath()));
                for (String err : parsed.errors()) getLogger().warning("toggles.txt: " + err);
                return parsed.store();
            }
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "could not read toggles.txt - starting fresh", e);
        }
        return new ToggleStore();
    }

    private void saveToggles() {
        if (togglesFile == null) return;
        try {
            Files.createDirectories(togglesFile.toPath().getParent());
            Files.writeString(togglesFile.toPath(), toggles.serialize());
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "could not save toggles.txt", e);
        }
    }

    // ------------------------------------------------------------ events

    /**
     * Bows and crossbows. Fires once per released projectile
     * (vanilla multishot fires it per arrow — each arrow is judged
     * on its own cone; at the 0.1.1 default 15-degree cone the
     * ±10-degree multishot side arrows now fall inside it and snap
     * too). Only AbstractArrow projectiles are bent: a crossbow's
     * firework rocket is not an arrow and is never touched.
     */
    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onShootBow(EntityShootBowEvent event) {
        if (!(event.getEntity() instanceof Player shooter)) return;
        if (!(event.getProjectile() instanceof AbstractArrow arrow)) return;
        assist(shooter, arrow);
    }

    /**
     * Thrown tridents. A real trident throw fires
     * ProjectileLaunchEvent with the trident's shooter set (rig-
     * verified on Paper 26.2-123 — see BUILD.md); arrows never
     * reach this handler because only Trident projectiles are
     * considered, so bow shots are never bent twice.
     */
    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onLaunch(ProjectileLaunchEvent event) {
        if (!(event.getEntity() instanceof Trident trident)) return;
        if (!(trident.getShooter() instanceof Player shooter)) return;
        assist(shooter, trident);
    }

    // ------------------------------------------------------------ the snap

    /** The chest point of a mob: the spot a player means by "that zombie". */
    private Location aimLocation(LivingEntity mob) {
        return mob.getLocation().add(0.0, mob.getHeight() * aimHeightFraction, 0.0);
    }

    private void assist(Player shooter, Projectile projectile) {
        if (!masterEnabled) return;
        if (!toggles.isEnabled(shooter.getUniqueId())) return;

        Vector velocity = projectile.getVelocity();
        double speed = velocity.length();
        if (speed < AimMath.MIN_SPEED) return; // not actually moving: nothing to bend

        Location origin = projectile.getLocation();
        AimMath.Vec vel = new AimMath.Vec(velocity.getX(), velocity.getY(), velocity.getZ());
        AimMath.Vec from = new AimMath.Vec(origin.getX(), origin.getY(), origin.getZ());

        List<TargetPicker.Candidate> candidates = new ArrayList<>();
        List<LivingEntity> mobs = new ArrayList<>();
        // Gather with a margin past the range: the search box edge
        // must never be the thing that decides (the picker applies
        // the real range gate to the measured distance).
        double gather = rangeBlocks + 2.0;
        for (Entity nearby : shooter.getNearbyEntities(gather, gather, gather)) {
            if (!(nearby instanceof Enemy) || !(nearby instanceof LivingEntity mob)) continue;
            if (mob.isDead()) continue;
            Location aimLoc = aimLocation(mob);
            AimMath.Vec to = new AimMath.Vec(aimLoc.getX(), aimLoc.getY(), aimLoc.getZ());
            // Range is judged on the shot's TRAVEL distance to
            // the chest (see AimMath.travelDistance) — the
            // measure the leading fallback gate uses. Through
            // 0.1.2 the picker judged the raw horizontal
            // distance instead, which over-reads a strafing mob
            // standing at exactly max range (40 squared plus
            // any lateral offset roots above 40) and silently
            // un-picked it: at the edge, a moving target could
            // never be snapped at all.
            double distance = AimMath.travelDistance(vel, from, to);
            double angle = AimMath.angleDegrees(vel, to.sub(from));
            boolean los = shooter.hasLineOfSight(mob);
            candidates.add(new TargetPicker.Candidate(angle, distance, los, true));
            mobs.add(mob);
        }
        int pick = TargetPicker.pickBest(candidates, coneDegrees, rangeBlocks);
        if (pick < 0) return;

        LivingEntity target = mobs.get(pick);
        Location aimLoc = aimLocation(target);
        AimMath.Vec aimPoint = new AimMath.Vec(aimLoc.getX(), aimLoc.getY(), aimLoc.getZ());
        boolean led = false;
        if (leadEnabled) {
            // 0.1.2: aim where the chest will be when the shot
            // arrives. A stationary mob's led point IS its chest
            // point (AimMath identity), so this changes nothing
            // for still targets; a led point that escapes the
            // cone/range gates falls back to the chest point, so
            // a led shot is never worse than the 0.1.1 snap.
            Vector tv = target.getVelocity();
            AimMath.Vec ledPoint = AimMath.ledAimPoint(from, aimPoint,
                    new AimMath.Vec(tv.getX(), tv.getY(), tv.getZ()), speed,
                    dropCompensation, leadMinTargetSpeedBps / 20.0, leadMaxBlocks);
            if (!ledPoint.equals(aimPoint)
                    && AimMath.leadQualifies(vel, from, ledPoint, coneDegrees, rangeBlocks)) {
                aimPoint = ledPoint;
                led = true;
            }
        }
        if (dropCompensation) {
            // Raise the snap point by the simulated gravity drop so
            // the arc lands on the chest instead of under it.
            aimPoint = AimMath.dropCompensatedAimPoint(from, aimPoint, speed);
        }
        AimMath.Vec bent = AimMath.bentVelocity(vel, from, aimPoint);
        projectile.setVelocity(new Vector(bent.x(), bent.y(), bent.z()));
        if (debug) {
            getLogger().info("bend: " + shooter.getName() + " -> " + target.getType()
                    + " angle=" + String.format("%.2f", candidates.get(pick).angleDegrees())
                    + " dist=" + String.format("%.1f", candidates.get(pick).travelDistance())
                    + (led ? " led" : "")
                    + " via " + projectile.getType());
        }
    }

    // ------------------------------------------------------------ command

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("aimassist")) return false;
        // 0.1.5: the admin branch routes BEFORE the player-only
        // gate, so the console (and any sender holding
        // excelaimassist.admin) can inspect and fix another
        // player's toggle. The self-service forms below are
        // byte-for-byte the 0.1.4 behaviour.
        if (args.length >= 1 && args[0].equalsIgnoreCase("admin")) {
            return handleAdmin(sender, args);
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage("aimassist is a per-player toggle - run it in game as /aimassist on|off|toggle.");
            return true;
        }
        if (args.length == 0) {
            player.sendMessage("Aim assist is " + (toggles.isEnabled(player.getUniqueId()) ? "ON" : "OFF")
                    + " for you. Use /aimassist on, /aimassist off or /aimassist toggle.");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "on" -> {
                toggles.set(player.getUniqueId(), true);
                saveToggles();
                player.sendMessage("Aim assist ON.");
            }
            case "off" -> {
                toggles.set(player.getUniqueId(), false);
                saveToggles();
                player.sendMessage("Aim assist OFF.");
            }
            case "toggle" -> {
                boolean now = toggles.toggle(player.getUniqueId());
                saveToggles();
                player.sendMessage("Aim assist " + (now ? "ON." : "OFF."));
            }
            default -> player.sendMessage("Usage: /aimassist on|off|toggle");
        }
        return true;
    }

    // ------------------------------------------------------------ admin (0.1.5)

    /**
     * /aimassist admin status <player> and
     * /aimassist admin set <player> on|off — the console-admin
     * surface (Mike's Nov 3, 2026 rule). The gate is checked in
     * code (AdminCommands.allowed: console explicitly allowed,
     * anyone else needs excelaimassist.admin, default op)
     * because /aimassist itself carries no command-level
     * permission — the self-service forms must stay open to
     * every player. Status only reads the ToggleStore; set
     * writes through ToggleStore.set — the same call the
     * self-service on/off forms make — and persists exactly as
     * they do. Both forms are logged, so the console exercise
     * leaves its own record in the server log.
     */
    private boolean handleAdmin(CommandSender sender, String[] args) {
        if (!AdminCommands.allowed(sender instanceof ConsoleCommandSender,
                sender.hasPermission(AdminCommands.PERMISSION))) {
            sender.sendMessage(AdminCommands.DENIED);
            return true;
        }
        if (args.length == 3 && args[1].equalsIgnoreCase("status")) {
            Resolved target = resolveAdminTarget(sender, args[2], false);
            if (target == null) return true;
            sender.sendMessage(AdminCommands.statusMessage(toggles, target.display(), target.uuid()));
            return true;
        }
        if (args.length == 4 && args[1].equalsIgnoreCase("set")) {
            Boolean on = AdminCommands.parseOnOff(args[3]);
            if (on == null) {
                sender.sendMessage(AdminCommands.USAGE_SET);
                return true;
            }
            Resolved target = resolveAdminTarget(sender, args[2], true);
            if (target == null) return true;
            String reply = AdminCommands.applySet(toggles, target.display(), target.uuid(), on);
            saveToggles();
            sender.sendMessage(reply);
            getLogger().info("Aim assist admin set by " + sender.getName() + ": " + reply);
            return true;
        }
        sender.sendMessage(AdminCommands.USAGE_STATUS);
        sender.sendMessage(AdminCommands.USAGE_SET);
        return true;
    }

    /** An admin target resolved to a UUID plus the name to print in replies. */
    private record Resolved(java.util.UUID uuid, String display) {}

    /**
     * Resolve an admin target: an online player by exact name
     * first (display = their real name), then a raw UUID (for
     * offline players; display = the UUID text as typed). On
     * failure the matching rejection line is sent and null
     * returned. This plugin keeps no name-to-UUID record of its
     * own, so an offline player known only by name cannot be
     * resolved.
     */
    private Resolved resolveAdminTarget(CommandSender sender, String target, boolean forSet) {
        Player online = getServer().getPlayerExact(target);
        if (online != null) return new Resolved(online.getUniqueId(), online.getName());
        try {
            return new Resolved(java.util.UUID.fromString(target), target);
        } catch (IllegalArgumentException notUuid) {
            sender.sendMessage(forSet
                    ? AdminCommands.notFoundSet(target)
                    : AdminCommands.notFoundStatus(target));
            return null;
        }
    }
}
