#!/bin/bash
# Build ExcelTrainingDummy-1.0.0.jar (deterministic: two builds byte-identical).
# House pattern (ExcelTour/ExcelChunks): manual javac, JDK 25 tree,
# --release 21, house build-libs Paper API (1.21.4) first + the Paper
# 26.3 API jar as fallback, tests run before the jar is packed.
set -euo pipefail
cd "$(dirname "$0")"
JDK=~/workspace/.jdk25
LIBS=/home/hatch/workspace/excelshops/build-libs
RT=/home/hatch/workspace/excelbuildmode-pilot/runtime-server/libraries
CP="$LIBS/paper-api.jar"
for j in adventure-api-4.20.0 adventure-key-4.20.0 adventure-text-minimessage-4.20.0 adventure-text-serializer-gson-4.20.0 adventure-text-serializer-json-4.20.0 adventure-text-serializer-legacy-4.20.0 adventure-text-serializer-plain-4.20.0 examination-api-1.3.0 examination-string-1.3.0 option-1.0.0 gson-2.11.0 guava-33.3.1-jre snakeyaml-2.2; do CP="$CP:$LIBS/$j.jar"; done
CP="$CP:/home/hatch/workspace/magic-los-fix/cp/paper-api-26.3.build.231-stable.jar"
CP="$CP:$RT/org/joml/joml/1.10.8/joml-1.10.8.jar:$RT/com/googlecode/json-simple/json-simple/1.1.1/json-simple-1.1.1.jar:$RT/it/unimi/dsi/fastutil/8.5.19/fastutil-8.5.19.jar:$RT/com/mojang/brigadier/1.3.10/brigadier-1.3.10.jar:$RT/net/md-5/bungeecord-chat/1.21-R0.2-deprecated+build.21/bungeecord-chat-1.21-R0.2-deprecated+build.21.jar:$RT/org/jspecify/jspecify/1.0.0/jspecify-1.0.0.jar:$RT/org/slf4j/slf4j-api/2.0.18/slf4j-api-2.0.18.jar:$RT/com/google/guava/failureaccess/1.0.3/failureaccess-1.0.3.jar:$RT/org/apache/logging/log4j/log4j-api/2.26.0/log4j-api-2.26.0.jar"

python3 -c "import yaml,sys; [yaml.safe_load(open(f)) for f in ['plugin.yml','config.yml']]" \
  || { echo 'YAML parse failure — refusing to build'; exit 1; }

rm -rf build/classes build/test-classes && mkdir -p build/classes build/test-classes
"$JDK/bin/javac" --release 21 -proc:none -nowarn -encoding UTF-8 -cp "$CP" -d build/classes $(find src -name '*.java' | sort)

# Tests: the Bukkit-free core + harness (no libraries needed).
"$JDK/bin/javac" --release 21 -proc:none -nowarn -encoding UTF-8 -cp "build/classes" -d build/test-classes $(find tests -name '*.java' | sort)
"$JDK/bin/java" -cp "build/test-classes:build/classes" com.winkreyes.exceltrainingdummy.DummyTest | tee ../TEST-RESULTS.txt

cp plugin.yml config.yml build/classes/
printf '%s\n' 'EXC-TDUMMY-1.0.0-WRV-20261112-01-178829' > build/classes/excel-build.txt
# Pin every staged file's mtime so the double-build is byte-identical.
find build/classes -exec touch -d "2026-11-12 00:00:00 UTC" {} +
OUT=../ExcelTrainingDummy-1.0.0.jar
OUT2=../ExcelTrainingDummy-1.0.0-repro.jar
rm -f "$OUT" "$OUT2"
"$JDK/bin/jar" --create --file "$OUT" --no-manifest --date=2026-11-12T00:00:00Z -C build/classes .
"$JDK/bin/jar" --create --file "$OUT2" --no-manifest --date=2026-11-12T00:00:00Z -C build/classes .
cmp "$OUT" "$OUT2" && echo 'double-build: byte-identical'
rm -f "$OUT2"
unzip -p "$OUT" excel-build.txt | grep -q '^EXC-TDUMMY-1.0.0-WRV-20261112-01-178829$' \
  || { echo 'FINGERPRINT GATE FAIL: excel-build.txt missing/incorrect in jar'; exit 1; }
echo "fingerprint gate: PASS (excel-build.txt EXC-TDUMMY-1.0.0-WRV-20261112-01-178829)"
cd ..
sha256sum ExcelTrainingDummy-1.0.0.jar
ls -l ExcelTrainingDummy-1.0.0.jar
