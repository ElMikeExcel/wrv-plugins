# ExcelTrainingDummy — design (copied from WoW + Guild Wars 2)
Mike's direction (Nov 10, 2026): look at what training dummies do in World of
Warcraft and Guild Wars 2 and copy that kind of design. Jesús's request
originally; the instrument for the spell audit's controlled tests.

## What the two games do (researched Nov 10, 2026)
WORLD OF WARCRAFT
- Standing dummies in tiers: normal / dungeon ("Dungeoneer's") / raid-boss
  ("Raider's") level, effectively unkillable, no XP, no loot. You practice
  rotations and read the result on a meter (Details — our meter's namesake).
- Specialized variants: cleave dummies (multi-target clusters), a tanking
  dummy that fights back (practice mitigation), group-healing dummies, PvP
  dummies. Several players may hit the same dummy at once.
- The new "Dummy Dome" (Patch 12.1): an instanced test room reached via an
  NPC; spawn 1 / 2 / 3 / 5 dummies on demand; a "Hazardous Dummy" for healers
  that deals ramping damage and can kill you if you do not heal through it;
  dummies carry raid-boss armor and huge pools, with a ~5-minute health-decay
  timer so a test is a timed window; low-health ("execute") phases testable.

GUILD WARS 2 — Special Forces Training Area
- A dedicated instance (raid lobby). A golem spawner console: pick hitbox
  size (small / average / large) and a health tier (benchmark standard is
  the 4,000,000 HP "average enemy"; smaller and larger tiers exist), plus
  stationary or moving.
- An arena console ("Adjust self"): apply raid-standard boons to yourself
  (25 Might, Fury, Quickness, Alacrity...) and conditions to the golem
  (Vulnerability etc.) so a solo test reproduces raid conditions.
- Built-in scoring: at every 20% of the golem's health, your DPS is printed
  to chat — no addon needed. Final numbers on the kill.
- A damaging field option (light / medium / intense) around the golem to
  practice staying alive and healing under pressure.

## The WRV dummy — same shape, our numbers
One small standalone plugin, ExcelTrainingDummy. All controls are menus
(Java menu + Bedrock form), per the house buttons rule.

1. SPAWN MENU (/dummy) — WoW Dome style. Spawn 1, 3, or 5 dummies in front
   of you (3 and 5 form the cleave cluster for AoE tests); remove-all button;
   dummies belong to the spawner, despawn on logout, after 10 idle minutes,
   or on remove. Server cap and per-player cap in config. Flat-ground and
   claim checks: your own claim, wilderness, or an admin training zone.
2. HEALTH TIERS — GW2 style, sized to our game (config):
   Practice 1,000 · Dungeon 5,000 · Seal 20,000 (a Warden-scale pool).
   Plus an ENDLESS mode (WoW style): the dummy cannot die; at 1 HP it stops
   the test, prints the report, and resets to full after a few seconds.
3. CHECKPOINT + FINAL REPORT — GW2 style, our meter. At each 25% of the
   pool, chat prints your running DPS. On finish: duration, total damage,
   average DPS, and the per-spell breakdown — read from the ExcelDetails
   segment for that dummy plus the ExcelProtect incident ledger (the two
   must agree; the dummy is stamped as a training target in both).
   Healing tests report HPS the same way.
4. BOSS-ARMOR PRESET — the "raid dummy" analog: a toggle that runs the
   dummy's intake through the same display-scale (x1000) presentation as
   seal bosses, so practice numbers read like fight-night numbers.
5. HAZARDOUS MODE — WoW Dome + GW2 field. The dummy pulses damage at the
   tester: Light / Medium / Intense. Default stops at 1 HP (never kills);
   an explicit Lethal toggle exists for Downed/resurrection controlled
   tests with a volunteer. Healer practice and mitigation reads live here.
6. EXECUTE PRESET — spawn the dummy already at 25% health (execute-range
   spells and effects become testable in seconds, not minutes).
7. CLEAN BY CONSTRUCTION: no XP (vanilla or mcMMO), no loot, no Jobs pay,
   no economy, no seal or boss credit, no DeathProtection interaction.
   Protect logs dummy damage under a training stamp, excluded from player
   rankings. Summons treat the dummy as a valid target (the Wolf/tree
   controlled casts); summon damage attributes to the owner as usual.
8. BEDROCK PARITY: the form carries the same spawn/tier/mode picks; the
   report prints in chat identically on both platforms.

## Tests this unlocks (already owed)
- Spell audit controlled tests: iframes (stream 1 s on one dummy, count
  Protect incidents), wave double-target (2-dummy cluster), anvil second
  fall, boomerang flight path (cluster spacing).
- Jester's controlled Arrow test (10 casts, fixed distance, fixed pool).
- Wolf controlled cast evidence + summon-tree cast proofs (tracker item 23).
- Healer rotation/HPS practice before EM dungeons; hazardous-mode Downed
  and Resurrection drills with a volunteer.

## Controls — two doors (Mike, Nov 10, 2026)
1. COMPASS MENU: a "Training Dummy" entry lives in the compass server menu
   (same pattern as the Details Settings entry, Nov 9): spawn picks
   (1 / 3 / 5, tier, presets), your active dummies, remove-all. The install
   checks the live server_menu layout headroom first (the Nov 7 settings
   group overflow lesson) and splits the group if slots are short.
2. TAP THE DUMMY: with the compass in hand, tapping (interacting with) a
   summoned dummy opens THAT dummy's settings directly — change health
   tier, hazardous level, boss-armor preset, execute reset, checkpoint
   prints on/off, or remove it — without walking back through the menus.
   The spawner edits; anyone else tapping with a compass gets the dummy's
   live status + current test readout (dummies are shared targets, WoW
   style). Bedrock: same tap with the compass held opens the form.
