package com.winkreyes.excelpouch.api;

import java.util.UUID;

/**
 * The pouch query service (SPEC Part I §5). ExcelPouch registers an
 * implementation with Bukkit's ServicesManager on enable; consumers
 * look it up at use time and FAIL OPEN (treat "no answer" as
 * "holds nothing") when the service is absent — Bukkit unregisters
 * a plugin's services when it disables, so a removed pouch simply
 * makes every answer "no", which is the self-healing property the
 * ExcelMenuJoin 1.4.0 integration is built on.
 *
 * Consumers compiled against other plugins (ExcelMenuJoin) call
 * this reflectively by method name so no hard dependency exists;
 * the signature here is the contract: one method, exact name and
 * parameter types.
 */
public interface PouchQuery {

    /**
     * @param player the pouch owner
     * @param kindId allowlist kind id, e.g. "menu_compass" or "magic_wand"
     * @return true if the player's pouch currently holds an item of
     *         that kind (any pocket, including pockets hidden by a
     *         config shrink); false if it does not, or if the
     *         player's store is not loaded.
     */
    boolean holdsKind(UUID player, String kindId);
}
