package com.winkreyes.excelpouch;

import com.winkreyes.excelpouch.core.KindMatcher;
import com.winkreyes.excelpouch.core.PouchLayout;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryCreativeEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.Map;

/**
 * All pouch GUI rules (SPEC Part I §8). Handlers run at HIGH —
 * after Magic's NORMAL-priority handlers, so a wand parking click
 * is read only after Magic has deactivated and flushed the wand's
 * state into the item (§6A Q2), and before any HIGHEST monitor
 * could disagree.
 *
 * The GUI is handled MANUALLY: every click inside the pouch view is
 * cancelled and the move is performed in code, so the store write
 * is deterministic and there is exactly one code path per gesture.
 * Gestures covered: cursor place/pickup/swap on pockets, shift out
 * to the player inventory, shift in from the player inventory,
 * number-key swap, offhand swap. Cancelled without effect: filler
 * and nameplate clicks, drags touching the pouch (§8), double-click
 * collection (§8), drop key over a pocket (§8), creative palette
 * sets, and the drop/throw actions. Death force-closes (contents
 * stay — §7); cross-world teleports force-close; opening while
 * dead is refused in ExcelPouch.openPouch.
 */
public final class PouchListener implements Listener {
    private final ExcelPouch plugin;

    public PouchListener(ExcelPouch plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------

    @EventHandler(priority = EventPriority.LOWEST)
    public void onJoin(PlayerJoinEvent e) {
        plugin.storeFor(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        if (isPouchOpen(p)) { try { p.closeInventory(); } catch (Exception ignored) { } }
        plugin.evictStore(p.getUniqueId());
        plugin.throttle().forget(p.getUniqueId());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        if (isPouchOpen(p)) { try { p.closeInventory(); } catch (Exception ignored) { } }
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        if (e.getFrom().getWorld() != e.getTo().getWorld() && isPouchOpen(e.getPlayer())) {
            try { e.getPlayer().closeInventory(); } catch (Exception ignored) { }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (e.getInventory().getHolder() instanceof PouchHolder holder) {
            plugin.syncAllFromGui(holder, e.getInventory());
        }
    }

    private boolean isPouchOpen(Player p) {
        return p.getOpenInventory().getTopInventory().getHolder() instanceof PouchHolder;
    }

    // ------------------------------------------------------------------
    // Click routing
    // ------------------------------------------------------------------

    @EventHandler(priority = EventPriority.HIGH)
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof PouchHolder holder)) return;
        if (!(e.getWhoClicked() instanceof Player p)) { e.setCancelled(true); return; }
        if (!holder.owner().equals(p.getUniqueId())) { e.setCancelled(true); return; }

        if (e.getClick() == ClickType.DOUBLE_CLICK
                || e.getAction() == InventoryAction.COLLECT_TO_CURSOR
                || e.getAction() == InventoryAction.UNKNOWN) {
            e.setCancelled(true);
            return;
        }
        int raw = e.getRawSlot();
        if (raw < 0) return; // clicked outside the window: vanilla cursor behavior

        if (raw >= top.getSize()) {
            // The player's own inventory under the GUI: only a
            // shift-click crosses into the pouch; the rest is vanilla.
            if (e.getAction() == InventoryAction.MOVE_TO_OTHER_INVENTORY) {
                e.setCancelled(true);
                shiftIn(e, holder, top);
                p.updateInventory();
            }
            return;
        }

        // Inside the pouch screen: every click is ours, manually.
        e.setCancelled(true);
        int pocket = PouchLayout.pocketIndex(plugin.slots(), raw);
        if (pocket < 0 || holder.isSealed(pocket)) return; // filler / nameplate / frozen pocket
        switch (e.getClick()) {
            case LEFT, RIGHT -> cursorExchange(e, holder, top, pocket);
            case SHIFT_LEFT, SHIFT_RIGHT -> shiftOut(e, holder, top, pocket);
            case NUMBER_KEY -> hotbarSwap(e, holder, top, pocket);
            case SWAP_OFFHAND -> offhandSwap(e, holder, top, pocket);
            default -> { /* DROP, CONTROL_DROP and friends: item stays (§8 drop rule) */ }
        }
        plugin.syncPocket(holder, top, pocket);
        p.updateInventory();
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDrag(InventoryDragEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof PouchHolder)) return;
        for (int raw : e.getRawSlots()) {
            if (raw >= 0 && raw < top.getSize()) { e.setCancelled(true); return; }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onCreative(InventoryCreativeEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof PouchHolder) {
            e.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------
    // Gestures (each leaves the GUI consistent; caller syncs the store)
    // ------------------------------------------------------------------

    private void cursorExchange(InventoryClickEvent e, PouchHolder holder, Inventory top, int pocket) {
        Player p = (Player) e.getWhoClicked();
        int guiSlot = PouchLayout.pocketSlots(plugin.slots())[pocket];
        ItemStack cursor = e.getCursor();
        ItemStack inPocket = top.getItem(guiSlot);
        if (isAir(cursor) && isAir(inPocket)) return;
        if (isAir(cursor)) {
            e.getView().setCursor(inPocket);
            top.setItem(guiSlot, null);
            return;
        }
        if (plugin.validateInsert(cursor, holder.owner()) == null) { refuse(p); return; }
        top.setItem(guiSlot, cursor);
        e.getView().setCursor(isAir(inPocket) ? null : inPocket);
    }

    private void shiftOut(InventoryClickEvent e, PouchHolder holder, Inventory top, int pocket) {
        Player p = (Player) e.getWhoClicked();
        int guiSlot = PouchLayout.pocketSlots(plugin.slots())[pocket];
        ItemStack inPocket = top.getItem(guiSlot);
        if (isAir(inPocket)) return;
        Map<Integer, ItemStack> left = p.getInventory().addItem(inPocket.clone());
        // Full inventory: everything stays in the pocket (§8 edge case).
        top.setItem(guiSlot, left.isEmpty() ? null : left.values().iterator().next());
    }

    private void shiftIn(InventoryClickEvent e, PouchHolder holder, Inventory top) {
        ItemStack clicked = e.getCurrentItem();
        if (isAir(clicked) && e.getClickedInventory() != null) {
            clicked = e.getClickedInventory().getItem(e.getSlot());
        }
        if (isAir(clicked)) return;
        int[] pockets = PouchLayout.pocketSlots(plugin.slots());
        int target = -1;
        for (int i = 0; i < pockets.length; i++) {
            if (!holder.isSealed(i) && isAir(top.getItem(pockets[i]))) { target = i; break; }
        }
        if (target < 0) return; // no free pocket: vanilla-like silence
        Player p = (Player) e.getWhoClicked();
        if (plugin.validateInsert(clicked, holder.owner()) == null) { refuse(p); return; }
        top.setItem(pockets[target], clicked.clone());
        e.getClickedInventory().setItem(e.getSlot(), null);
        plugin.syncPocket(holder, top, target);
    }

    private void hotbarSwap(InventoryClickEvent e, PouchHolder holder, Inventory top, int pocket) {
        int button = e.getHotbarButton();
        if (button < 0 || button > 8) return;
        Player p = (Player) e.getWhoClicked();
        PlayerInventory inv = p.getInventory();
        ItemStack other = inv.getItem(button);
        if (!isAir(other) && plugin.validateInsert(other, holder.owner()) == null) { refuse(p); return; }
        int guiSlot = PouchLayout.pocketSlots(plugin.slots())[pocket];
        ItemStack inPocket = top.getItem(guiSlot);
        top.setItem(guiSlot, isAir(other) ? null : other);
        inv.setItem(button, isAir(inPocket) ? null : inPocket);
    }

    private void offhandSwap(InventoryClickEvent e, PouchHolder holder, Inventory top, int pocket) {
        Player p = (Player) e.getWhoClicked();
        PlayerInventory inv = p.getInventory();
        ItemStack other = inv.getItemInOffHand();
        if (!isAir(other) && plugin.validateInsert(other, holder.owner()) == null) { refuse(p); return; }
        int guiSlot = PouchLayout.pocketSlots(plugin.slots())[pocket];
        ItemStack inPocket = top.getItem(guiSlot);
        top.setItem(guiSlot, isAir(other) ? null : other);
        inv.setItemInOffHand(isAir(inPocket) ? null : inPocket);
    }

    private void refuse(Player p) {
        if (plugin.throttle().trySend(p.getUniqueId())) {
            p.sendMessage(KindMatcher.REFUSAL_LINE);
        }
    }

    private static boolean isAir(ItemStack item) {
        return item == null || item.getType() == Material.AIR;
    }
}
