package com.winkreyes.excelpouch;

import com.winkreyes.excelpouch.api.PouchQuery;

import java.util.UUID;

/**
 * The registered PouchQuery implementation. Public class + public
 * method on purpose: cross-plugin consumers (ExcelMenuJoin) invoke
 * holdsKind reflectively by name (SPEC Part I §5).
 */
public final class PouchService implements PouchQuery {
    private final ExcelPouch plugin;

    public PouchService(ExcelPouch plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean holdsKind(UUID player, String kindId) {
        if (player == null || kindId == null) return false;
        try {
            PouchStore store = plugin.storeFor(player);
            return store != null && store.holdsKind(kindId);
        } catch (Exception e) {
            return false; // a query must never break a give path
        }
    }
}
