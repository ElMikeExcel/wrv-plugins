package com.winkreyes.excelpouch;

import com.winkreyes.excelpouch.api.PouchQuery;
import com.winkreyes.excelpouch.core.AdminSelector;
import com.winkreyes.excelpouch.core.KindMatcher;
import com.winkreyes.excelpouch.core.PouchFileCodec;
import com.winkreyes.excelpouch.core.PouchLayout;
import com.winkreyes.excelpouch.core.RefusalThrottle;
import com.winkreyes.excelpouch.core.WandInspector;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * ExcelPouch 0.1.1 — the Utility Pouch (SPEC Part I, ~/workspace/
 * inventory-expansion/SPEC.md): a per-player virtual pouch that
 * parks SERVER-ISSUED items only (v1 allowlist: the menu compass
 * and the player's own bound Magic wand), so server gear never
 * eats a real inventory slot.
 *
 * The store is the only truth: pockets hold ItemStack
 * .serializeAsBytes() output (full data-component fidelity — the
 * wand's learned spells and rank live in that payload, §6A Q1),
 * written through on every accepted GUI action. Pouch contents
 * stay through death (§7) and never enter death drops.
 */
public final class ExcelPouch extends JavaPlugin {
    private static final NamespacedKey COMPASS_KEY_NEW = new NamespacedKey("excelmenujoin", "menu_compass");
    private static final NamespacedKey COMPASS_KEY_LEGACY = new NamespacedKey("menujoin", "menu_compass");

    private int slots = 2;
    private Set<String> enabledKinds = Set.of(KindMatcher.MENU_COMPASS, KindMatcher.MAGIC_WAND);
    private String wandKey = "wand";
    private File dataDir;
    private final Map<UUID, PouchStore> stores = new HashMap<>();
    private final RefusalThrottle throttle = new RefusalThrottle();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        reloadSettings();
        dataDir = new File(getDataFolder(), "data");
        getServer().getPluginManager().registerEvents(new PouchListener(this), this);
        getServer().getServicesManager().register(PouchQuery.class, new PouchService(this), this, ServicePriority.Normal);
        // Belt-and-braces autosave (write-through already persists every mutation).
        Bukkit.getScheduler().runTaskTimer(this, () -> stores.values().forEach(PouchStore::save), 6000L, 6000L);
        getLogger().info("ExcelPouch enabled: " + slots + " pocket(s), allowlist " + enabledKinds + ", wand key '" + wandKey + "'.");
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof PouchHolder) {
                try { p.closeInventory(); } catch (Exception ignored) { }
            }
        }
        stores.values().forEach(PouchStore::save);
    }

    /** Re-read config.yml from disk and re-apply it (0.1.1 admin reload path). */
    public void reloadFromCommand() {
        reloadConfig();
        reloadSettings();
    }

    private void reloadSettings() {
        slots = PouchLayout.clampSlots(getConfig().getInt("slots", 2));
        Set<String> kinds = new HashSet<>();
        List<String> configured = getConfig().getStringList("allowlist");
        if (configured.isEmpty()) configured = List.of(KindMatcher.MENU_COMPASS, KindMatcher.MAGIC_WAND);
        for (String k : configured) {
            if (KindMatcher.MENU_COMPASS.equals(k) || KindMatcher.MAGIC_WAND.equals(k)) kinds.add(k);
            else getLogger().warning("Unknown allowlist kind '" + k + "' ignored (known: menu_compass, magic_wand).");
        }
        enabledKinds = Set.copyOf(kinds);
        String wk = getConfig().getString("magic-wand-key", "wand");
        wandKey = (wk == null || wk.isBlank()) ? "wand" : wk.trim();
    }

    public int slots() { return slots; }
    public Set<String> enabledKinds() { return enabledKinds; }
    public RefusalThrottle throttle() { return throttle; }

    // ------------------------------------------------------------------
    // Stores
    // ------------------------------------------------------------------

    /** The player's store, loaded on demand (join loads eagerly at LOWEST). */
    public synchronized PouchStore storeFor(UUID owner) {
        PouchStore store = stores.get(owner);
        if (store == null) {
            store = new PouchStore(owner, dataDir, getLogger());
            store.load(this);
            stores.put(owner, store);
        }
        return store;
    }

    public synchronized void evictStore(UUID owner) {
        PouchStore store = stores.remove(owner);
        if (store != null) store.save();
    }

    /**
     * Drop a store from memory WITHOUT saving (0.1.1 admin reads):
     * a pure read on an offline target must never mint an empty
     * <uuid>.yml via the autosave (design §4.5.2). Mutations have
     * already written through via setPocket before this is called.
     */
    public synchronized void evictWithoutSave(UUID owner) {
        stores.remove(owner);
    }

    public synchronized boolean isStoreLoaded(UUID owner) {
        return stores.containsKey(owner);
    }

    /** Kind of a stored item (for kind caches at load time); null if unreadable/unmatched. */
    String classifyStored(UUID owner, byte[] itemBytes) {
        try {
            ItemStack item = ItemStack.deserializeBytes(itemBytes);
            if (item == null || item.getType() == Material.AIR) return null;
            return KindMatcher.match(factsOf(item, owner), enabledKinds);
        } catch (Exception e) {
            return null;
        }
    }

    // ------------------------------------------------------------------
    // Item facts + insert validation
    // ------------------------------------------------------------------

    /** Extract the allowlist facts from a live item (SPEC Part I §3). */
    public KindMatcher.ItemFacts factsOf(ItemStack item, UUID pouchOwner) {
        boolean stamped = false;
        if (item.getType() == Material.COMPASS && item.hasItemMeta()) {
            PersistentDataContainer pdc = item.getItemMeta().getPersistentDataContainer();
            stamped = pdc.has(COMPASS_KEY_NEW, PersistentDataType.BOOLEAN)
                    || pdc.has(COMPASS_KEY_LEGACY, PersistentDataType.BOOLEAN);
        }
        WandInspector.Result wand = WandInspector.inspect(item.serializeAsBytes(), wandKey);
        return new KindMatcher.ItemFacts(item.getType().name(), item.getAmount(), stamped,
                wand.verdict(), wand.ownerId(), pouchOwner.toString());
    }

    /** @return the kind this item may enter the pouch as, or null (refused). */
    public String validateInsert(ItemStack item, UUID pouchOwner) {
        if (item == null || item.getType() == Material.AIR) return null;
        return KindMatcher.match(factsOf(item, pouchOwner), enabledKinds);
    }

    // ------------------------------------------------------------------
    // GUI
    // ------------------------------------------------------------------

    public void openPouch(Player p) {
        if (p.isDead()) {
            p.sendMessage("§7You can't open your §6Utility Pouch §7right now.");
            return;
        }
        PouchStore store = storeFor(p.getUniqueId());
        p.openInventory(render(store));
    }

    private Inventory render(PouchStore store) {
        PouchHolder holder = new PouchHolder(store.owner());
        Inventory inv = Bukkit.createInventory(holder, PouchLayout.guiSize(slots), "Utility Pouch");
        holder.bind(inv);
        ItemStack filler = pane(Material.LIGHT_GRAY_STAINED_GLASS_PANE, "");
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, filler.clone());
        int nameplate = PouchLayout.nameplateSlot(slots);
        if (nameplate >= 0) inv.setItem(nameplate, pane(Material.YELLOW_STAINED_GLASS_PANE, "§6Utility Pouch"));
        int[] pockets = PouchLayout.pocketSlots(slots);
        for (int i = 0; i < pockets.length; i++) {
            byte[] bytes = store.pocket(i);
            if (bytes == null) { inv.setItem(pockets[i], null); continue; }
            try {
                ItemStack item = ItemStack.deserializeBytes(bytes);
                inv.setItem(pockets[i], item);
            } catch (Exception e) {
                // Never lose the item: freeze the pocket behind a placeholder.
                holder.seal(i);
                ItemStack placeholder = new ItemStack(Material.BARRIER);
                ItemMeta meta = placeholder.getItemMeta();
                meta.setDisplayName("§cStored item could not be read");
                meta.setLore(List.of("§7Tell Mike — your item is still saved."));
                placeholder.setItemMeta(meta);
                inv.setItem(pockets[i], placeholder);
                getLogger().warning("Pouch of " + store.owner() + ": pocket " + i
                        + " failed to deserialize and was frozen in place (" + e.getMessage() + ").");
            }
        }
        return inv;
    }

    private static ItemStack pane(Material material, String name) {
        ItemStack pane = new ItemStack(material);
        ItemMeta meta = pane.getItemMeta();
        meta.setDisplayName(name);
        pane.setItemMeta(meta);
        return pane;
    }

    /** Write one GUI pocket back through to the store (sealed pockets never move). */
    public void syncPocket(PouchHolder holder, Inventory inv, int pocket) {
        if (holder.isSealed(pocket)) return;
        int guiSlot = PouchLayout.pocketSlots(slots)[pocket];
        ItemStack item = inv.getItem(guiSlot);
        PouchStore store = storeFor(holder.owner());
        if (item == null || item.getType() == Material.AIR) {
            store.setPocket(pocket, null, null);
        } else {
            byte[] bytes = item.serializeAsBytes();
            store.setPocket(pocket, bytes, classifyStored(holder.owner(), bytes));
        }
    }

    /** Close-time backstop sync of every visible pocket (SPEC Part I §8). */
    public void syncAllFromGui(PouchHolder holder, Inventory inv) {
        int[] pockets = PouchLayout.pocketSlots(slots);
        for (int i = 0; i < pockets.length; i++) syncPocket(holder, inv, i);
    }

    // ------------------------------------------------------------------
    // Command
    // ------------------------------------------------------------------

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!cmd.getName().equalsIgnoreCase("pouch")) return false;
        // 0.1.1: the admin branch is dispatched BEFORE the player gate
        // (design §4.0) — the bare player path below is unchanged.
        if (args.length >= 1 && args[0].equalsIgnoreCase("admin")) {
            handleAdmin(sender, args);
            return true;
        }
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Only players can use the Utility Pouch.");
            return true;
        }
        openPouch(p);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (!cmd.getName().equalsIgnoreCase("pouch")) return List.of();
        if (!isAdminSender(sender)) return List.of();
        // Admin branch only (design §4.5.6); the player path gains none.
        if (args.length == 1) return filterPrefix(List.of("admin"), args[0]);
        if (!args[0].equalsIgnoreCase("admin")) return List.of();
        if (args.length == 2) return filterPrefix(List.of("status", "return", "clear", "reload"), args[1]);
        String sub = args[1].toLowerCase(Locale.ROOT);
        if (args.length == 3 && (sub.equals("status") || sub.equals("return") || sub.equals("clear"))) {
            List<String> names = new ArrayList<>();
            for (Player p : Bukkit.getOnlinePlayers()) names.add(p.getName());
            return filterPrefix(names, args[2]);
        }
        if (args.length == 4 && (sub.equals("return") || sub.equals("clear"))) {
            return filterPrefix(List.of(KindMatcher.MENU_COMPASS, KindMatcher.MAGIC_WAND, "pocket:"), args[3]);
        }
        if (args.length == 5 && sub.equals("clear")) return filterPrefix(List.of("confirm"), args[4]);
        return List.of();
    }

    private static List<String> filterPrefix(List<String> options, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String o : options) if (o.toLowerCase(Locale.ROOT).startsWith(p)) out.add(o);
        return out;
    }

    // ------------------------------------------------------------------
    // Admin (0.1.1, design §4) — console rescue surface. Player-facing
    // behaviour is unchanged; everything below is operator-only.
    // ------------------------------------------------------------------

    private static final String ADMIN_PERMISSION = "excelpouch.admin";
    private static final DateTimeFormatter RESCUE_STAMP = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");

    private boolean isAdminSender(CommandSender sender) {
        return sender instanceof ConsoleCommandSender || sender.hasPermission(ADMIN_PERMISSION);
    }

    private static String actorOf(CommandSender sender) {
        return sender instanceof ConsoleCommandSender ? "CONSOLE" : sender.getName();
    }

    private void handleAdmin(CommandSender sender, String[] args) {
        if (!isAdminSender(sender)) {
            sender.sendMessage("You do not have permission to use pouch admin commands.");
            return;
        }
        if (args.length < 2) { sendAdminHelp(sender); return; }
        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "status" -> {
                if (args.length == 2) sendGlobalStatus(sender);
                else if (args.length == 3) adminStatus(sender, args[2]);
                else sendAdminHelp(sender);
            }
            case "return" -> {
                if (args.length == 4) adminReturn(sender, args[2], args[3]);
                else sendAdminHelp(sender);
            }
            case "clear" -> {
                if (args.length == 4) adminClear(sender, args[2], args[3], false);
                else if (args.length == 5 && args[4].equalsIgnoreCase("confirm")) adminClear(sender, args[2], args[3], true);
                else sendAdminHelp(sender);
            }
            case "reload" -> {
                if (args.length == 2) {
                    reloadFromCommand();
                    sendGlobalStatus(sender);
                } else sendAdminHelp(sender);
            }
            default -> sendAdminHelp(sender);
        }
    }

    private void sendAdminHelp(CommandSender sender) {
        sender.sendMessage("ExcelPouch admin — operator commands:");
        sender.sendMessage("  /pouch admin status [<player>] — inspect a pouch (read-only)");
        sender.sendMessage("  /pouch admin return <player> <selector> — hand a parked item back to its owner (online only; cannot destroy anything)");
        sender.sendMessage("  /pouch admin clear <player> <selector> confirm — delete one parked item (a verified rescue copy is written first)");
        sender.sendMessage("  /pouch admin reload — re-read config.yml");
        sender.sendMessage("Selectors: pocket:<n> (0-based, includes config-hidden pockets) or a kind id (menu_compass, magic_wand). A kind held in more than one pocket is refused — re-run with pocket:<n>.");
    }

    // ---- target resolution (design §4.0, shared) ----

    private record AdminTarget(UUID uuid, String name, Player online) { }

    /** @return the target, or null after sending the one-line rejection. */
    private AdminTarget resolveTarget(CommandSender sender, String arg) {
        Player online = Bukkit.getPlayerExact(arg);
        if (online != null) return new AdminTarget(online.getUniqueId(), online.getName(), online);
        UUID uuid = null;
        try { uuid = UUID.fromString(arg); } catch (IllegalArgumentException ignored) { }
        if (uuid != null) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(uuid);
            String name = op.getName() != null ? op.getName() : arg;
            return new AdminTarget(uuid, name, null);
        }
        @SuppressWarnings("deprecation")
        OfflinePlayer op = Bukkit.getOfflinePlayer(arg);
        if (op.hasPlayedBefore()) {
            return new AdminTarget(op.getUniqueId(), op.getName() != null ? op.getName() : arg, null);
        }
        sender.sendMessage("No player named '" + arg + "' has played here, and it is not a UUID — nothing was created.");
        return null;
    }

    /**
     * A loaded store plus whether this call loaded it for an offline
     * target (in which case the caller must release it without saving
     * when done, design §4.5.2).
     */
    private record LoadedStore(PouchStore store, boolean releaseAfter, boolean fileExisted, boolean wasLoaded) { }

    private LoadedStore loadForAdmin(AdminTarget target) {
        boolean wasLoaded = isStoreLoaded(target.uuid());
        boolean fileExisted = new File(dataDir, target.uuid() + ".yml").isFile();
        PouchStore store = storeFor(target.uuid());
        boolean release = !wasLoaded && target.online() == null;
        return new LoadedStore(store, release, fileExisted, wasLoaded);
    }

    private void release(LoadedStore loaded, AdminTarget target) {
        if (loaded.releaseAfter()) evictWithoutSave(target.uuid());
    }

    private static String brokenLine(AdminTarget target) {
        return "Store: BROKEN — file quarantined as " + target.uuid() + ".yml.corrupt, saves SUPPRESSED";
    }

    // ---- item description (design §4.1; deserializes a COPY, never writes back) ----

    /** @return the §4.1 item description, or null when the bytes fail to deserialize (UNREADABLE/sealed). */
    private String describeItem(UUID owner, byte[] bytes) {
        byte[] copy = bytes.clone();
        final ItemStack item;
        try {
            item = ItemStack.deserializeBytes(copy);
        } catch (Exception e) {
            return null;
        }
        if (item == null || item.getType() == Material.AIR) return null;
        StringBuilder sb = new StringBuilder();
        String kind = classifyStored(owner, bytes);
        sb.append(kind != null ? kind : "unknown").append(" — ").append(item.getType().name())
          .append(" x").append(item.getAmount());
        if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
            sb.append(" \"").append(item.getItemMeta().getDisplayName()).append("\"");
        }
        sb.append(" (").append(String.format(Locale.US, "%,d", bytes.length)).append(" bytes");
        WandInspector.Result wand = WandInspector.inspect(bytes, wandKey);
        if (wand.verdict() == WandInspector.Verdict.WAND_OWNED && wand.ownerId() != null) {
            sb.append(wand.ownerId().equals(owner.toString()) ? ", owner_id matches" : ", owner_id does NOT match");
        }
        return sb.append(")").toString();
    }

    private String pocketLine(PouchStore store, int index) {
        int[] gui = PouchLayout.pocketSlots(slots);
        String where = index < gui.length ? "[gui " + gui[index] + "]" : "[HIDDEN by config shrink]";
        byte[] bytes = store.pocket(index);
        if (bytes == null) return "Pocket " + index + " " + where + ": (empty)";
        String desc = describeItem(store.owner(), bytes);
        if (desc == null) {
            String kind = store.pocketKind(index);
            return "Pocket " + index + " " + where + ": " + (kind != null ? kind : "unknown")
                    + " — UNREADABLE (sealed in GUI; bytes preserved, " + bytes.length + " bytes)";
        }
        return "Pocket " + index + " " + where + ": " + desc;
    }

    // ---- status ----

    private void sendGlobalStatus(CommandSender sender) {
        List<String> kinds = new ArrayList<>();
        if (enabledKinds.contains(KindMatcher.MENU_COMPASS)) kinds.add(KindMatcher.MENU_COMPASS);
        if (enabledKinds.contains(KindMatcher.MAGIC_WAND)) kinds.add(KindMatcher.MAGIC_WAND);
        sender.sendMessage("ExcelPouch 0.1.1 — slots: " + slots + " (visible), allowlist: " + kinds
                + ", wand key: '" + wandKey + "'");
        int files = 0, corrupt = 0;
        File[] listing = dataDir == null ? null : dataDir.listFiles();
        if (listing != null) {
            for (File f : listing) {
                if (!f.isFile()) continue;
                if (f.getName().endsWith(".yml.corrupt")) corrupt++;
                else if (f.getName().endsWith(".yml")) files++;
            }
        }
        int loaded;
        synchronized (this) { loaded = stores.size(); }
        sender.sendMessage("Stores: " + loaded + " loaded in memory, " + files
                + " file(s) in plugins/ExcelPouch/data (" + corrupt + " quarantined .corrupt)");
        boolean registered = Bukkit.getServicesManager().getRegistration(PouchQuery.class) != null;
        sender.sendMessage("PouchQuery service: " + (registered
                ? "registered (holdsKind live for ExcelMenuJoin)" : "NOT registered"));
    }

    private void adminStatus(CommandSender sender, String arg) {
        AdminTarget target = resolveTarget(sender, arg);
        if (target == null) return;
        boolean guiOpen = target.online() != null
                && target.online().getOpenInventory().getTopInventory().getHolder() instanceof PouchHolder;
        LoadedStore loaded = loadForAdmin(target);
        try {
            PouchStore store = loaded.store();
            if (store.isBroken()) {
                sender.sendMessage("Utility Pouch — " + target.name() + " (uuid " + target.uuid() + ", "
                        + (target.online() != null ? "online" : "offline, no GUI") + ")");
                sender.sendMessage(brokenLine(target));
                return;
            }
            if (!loaded.fileExisted() && !loaded.wasLoaded() && target.online() == null) {
                sender.sendMessage("No pouch on file for " + target.name() + " — treated as empty; nothing was created.");
                return;
            }
            sender.sendMessage("Utility Pouch — " + target.name() + " (uuid " + target.uuid() + ", "
                    + (target.online() != null ? "online, pouch GUI " + (guiOpen ? "open" : "closed") : "offline, no GUI") + ")");
            for (int i = 0; i < store.storedCount(); i++) sender.sendMessage(pocketLine(store, i));
            sender.sendMessage("Store: loaded OK, saves enabled, file plugins/ExcelPouch/data/" + target.uuid() + ".yml");
        } finally {
            release(loaded, target);
        }
    }

    /** The §4.1 description, or the UNREADABLE wording when the bytes cannot be deserialized. */
    private String describeOrUnreadable(PouchStore store, int pocket, byte[] bytes) {
        String desc = describeItem(store.owner(), bytes);
        if (desc != null) return desc;
        String kind = store.pocketKind(pocket);
        return (kind != null ? kind : "unknown") + " — UNREADABLE (sealed in GUI; bytes preserved, "
                + bytes.length + " bytes)";
    }

    // ---- shared selector / GUI sequencing for the mutating ops ----

    /** @return the resolved pocket index, or -1 after sending the refusal/no-op line. */
    private int resolveSelector(CommandSender sender, AdminTarget target, PouchStore store, String selector, String verb) {
        List<String> kinds = new ArrayList<>(store.storedCount());
        for (PouchStore.PocketInfo info : store.snapshot()) kinds.add(info.kind());
        AdminSelector.Result r = AdminSelector.resolve(selector, kinds);
        switch (r.outcome()) {
            case POCKET, UNIQUE -> { return r.pocket(); }
            case ZERO -> sender.sendMessage("No " + selector.trim().toLowerCase(Locale.ROOT) + " is parked in "
                    + target.name() + "'s pouch — nothing to " + verb + ".");
            case MANY -> {
                StringBuilder list = new StringBuilder();
                for (int i = 0; i < r.matches().size(); i++) {
                    if (i > 0) list.append(", ");
                    list.append("pocket ").append(r.matches().get(i));
                }
                sender.sendMessage("Selector '" + selector + "' matches more than one pocket (" + list
                        + ") — re-run with pocket:<n> to choose exactly one.");
            }
            case OUT_OF_RANGE -> sender.sendMessage("Selector '" + selector + "': " + r.detail()
                    + " in " + target.name() + "'s pouch.");
            case MALFORMED -> sender.sendMessage("Unknown selector '" + selector
                    + "' — use pocket:<n>, menu_compass, or magic_wand.");
        }
        return -1;
    }

    /**
     * Close-GUI-first (design §4.5.1 / brief §3 step 2): if the online
     * target has the pouch GUI open, close it so the close-sync lands,
     * then report whether the pocket still holds what the operator
     * confirmed — the §4.1 item identity (kind, material, amount,
     * display name, wand owner), NOT the raw bytes: the GUI round-trip
     * re-serializes the item and Magic refreshes volatile wand fields
     * (mana / mana_timestamp — the 0.1.0 rig's own finding), so a
     * byte-strict compare would abort every wand op under an open
     * GUI even though the pocket holds the very item confirmed. A
     * genuinely different item (a compass where the wand sat) still
     * aborts, and the rescue copy is always taken from the post-sync
     * bytes, so the exact final state is what gets preserved.
     *
     * @return true if the pocket now holds a different item (caller aborts)
     */
    private boolean closeGuiFirst(AdminTarget target, PouchStore store, int pocket, byte[] before) {
        Player p = target.online();
        if (p == null) return false;
        if (!(p.getOpenInventory().getTopInventory().getHolder() instanceof PouchHolder)) return false;
        try { p.closeInventory(); } catch (Exception ignored) { return false; }
        byte[] after = store.pocket(pocket);
        return !sameItemIdentity(target.uuid(), before, after);
    }

    /** The §4.1 identity of a pocket's contents: same item, allowing volatile-field refresh. */
    private boolean sameItemIdentity(UUID owner, byte[] a, byte[] b) {
        if (a == null || b == null) return a == b;
        if (Arrays.equals(a, b)) return true;
        final ItemStack ia, ib;
        try {
            ia = ItemStack.deserializeBytes(a.clone());
            ib = ItemStack.deserializeBytes(b.clone());
        } catch (Exception e) {
            return false; // one side unreadable and bytes differ: not the same item
        }
        if (ia == null || ib == null) return false;
        if (ia.getType() != ib.getType() || ia.getAmount() != ib.getAmount()) return false;
        String na = ia.hasItemMeta() && ia.getItemMeta().hasDisplayName() ? ia.getItemMeta().getDisplayName() : null;
        String nb = ib.hasItemMeta() && ib.getItemMeta().hasDisplayName() ? ib.getItemMeta().getDisplayName() : null;
        if (na == null ? nb != null : !na.equals(nb)) return false;
        String ka = classifyStored(owner, a), kb = classifyStored(owner, b);
        if (ka == null ? kb != null : !ka.equals(kb)) return false;
        WandInspector.Result wa = WandInspector.inspect(a, wandKey), wb = WandInspector.inspect(b, wandKey);
        if (wa.verdict() != wb.verdict()) return false;
        return wa.ownerId() == null ? wb.ownerId() == null : wa.ownerId().equals(wb.ownerId());
    }

    private void audit(String verb, CommandSender sender, AdminTarget target, String selector, String kind, int bytes) {
        getLogger().info("Pouch admin " + verb + ": actor=" + actorOf(sender) + " target=" + target.name()
                + " (" + target.uuid() + ") selector=" + selector + " kind=" + (kind != null ? kind : "unknown")
                + " bytes=" + bytes);
    }

    // ---- return (design §4.2) ----

    private void adminReturn(CommandSender sender, String targetArg, String selector) {
        AdminTarget target = resolveTarget(sender, targetArg);
        if (target == null) return;
        if (target.online() == null) {
            sender.sendMessage(target.name() + " is offline — return needs a live inventory; use status, or clear only if deletion is intended");
            return;
        }
        LoadedStore loaded = loadForAdmin(target);
        PouchStore store = loaded.store();
        if (store.isBroken()) { sender.sendMessage(brokenLine(target)); return; }
        int pocket = resolveSelector(sender, target, store, selector, "return");
        if (pocket < 0) return;
        byte[] bytes = store.pocket(pocket);
        if (bytes == null) {
            sender.sendMessage("Pocket " + pocket + " is already empty — nothing to return.");
            return;
        }
        String desc = describeItem(target.uuid(), bytes);
        if (desc == null) {
            sender.sendMessage("Pocket " + pocket + " is UNREADABLE (sealed) — there is no item to hand over; use clear with 'confirm' to remove it under a rescue copy.");
            return;
        }
        if (closeGuiFirst(target, store, pocket, bytes)) {
            sender.sendMessage("Pocket " + pocket + " changed while " + target.name()
                    + "'s pouch GUI was closing — nothing was returned; re-check with status and re-run.");
            return;
        }
        bytes = store.pocket(pocket);
        if (bytes == null) {
            sender.sendMessage("Pocket " + pocket + " is already empty — nothing to return.");
            return;
        }
        desc = describeItem(target.uuid(), bytes);
        if (desc == null) {
            sender.sendMessage("Pocket " + pocket + " is UNREADABLE (sealed) — there is no item to hand over; use clear with 'confirm' to remove it under a rescue copy.");
            return;
        }
        final ItemStack item;
        try {
            item = ItemStack.deserializeBytes(bytes.clone());
        } catch (Exception e) {
            sender.sendMessage("Pocket " + pocket + " is UNREADABLE (sealed) — there is no item to hand over; use clear with 'confirm' to remove it under a rescue copy.");
            return;
        }
        Map<Integer, ItemStack> leftovers = target.online().getInventory().addItem(item.clone());
        if (!leftovers.isEmpty()) {
            sender.sendMessage("Inventory full — item left parked in pocket " + pocket + ".");
            return;
        }
        String kind = store.pocketKind(pocket);
        store.setPocket(pocket, null, null);
        audit("return", sender, target, selector, kind, bytes.length);
        sender.sendMessage("Returned " + desc + " from " + target.name() + "'s pocket " + pocket + " to their inventory.");
    }

    // ---- clear (design §4.3 + the D10 safety stack, brief §3) ----

    private void adminClear(CommandSender sender, String targetArg, String selector, boolean confirm) {
        AdminTarget target = resolveTarget(sender, targetArg);
        if (target == null) return;
        LoadedStore loaded = loadForAdmin(target);
        try {
            PouchStore store = loaded.store();
            if (store.isBroken()) { sender.sendMessage(brokenLine(target)); return; }
            int pocket = resolveSelector(sender, target, store, selector, "clear");
            if (pocket < 0) return;
            byte[] bytes = store.pocket(pocket);
            if (bytes == null) {
                sender.sendMessage("Pocket " + pocket + " is already empty — nothing cleared.");
                return;
            }
            String descOrUnreadable = describeOrUnreadable(store, pocket, bytes);
            // D10 step 1: the confirm literal gate comes before any
            // close, rescue write, or mutation.
            if (!confirm) {
                sender.sendMessage("Would clear pocket " + pocket + " (" + descOrUnreadable + "). "
                        + "Re-run with 'confirm' to delete it — or use return to hand it back instead.");
                return;
            }
            // D10 step 2: close-GUI-first, then re-validate the pocket
            // against the post-sync state.
            if (closeGuiFirst(target, store, pocket, bytes)) {
                sender.sendMessage("Pocket " + pocket + " changed while " + target.name()
                        + "'s pouch GUI was closing — nothing was cleared; re-check with status and re-run.");
                return;
            }
            bytes = store.pocket(pocket);
            if (bytes == null) {
                sender.sendMessage("Pocket " + pocket + " is already empty — nothing cleared.");
                return;
            }
            descOrUnreadable = describeOrUnreadable(store, pocket, bytes);
            // D10 step 3: a prior rescue copy, written and verified
            // BEFORE deletion. Failure aborts the clear.
            String raw = store.rawEntry(pocket);
            if (raw == null || PouchFileCodec.EMPTY.equals(raw)) raw = PouchFileCodec.encodePocket(bytes);
            File rescueDir = new File(dataDir, "rescue");
            String fileName = target.uuid() + "-pocket" + pocket + "-"
                    + LocalDateTime.now().format(RESCUE_STAMP) + ".b64";
            File rescueFile = new File(rescueDir, fileName);
            try {
                Files.createDirectories(rescueDir.toPath());
                Files.writeString(rescueFile.toPath(), raw, StandardCharsets.UTF_8);
                String back = Files.readString(rescueFile.toPath(), StandardCharsets.UTF_8);
                if (!raw.equals(back)) throw new IOException("rescue copy verify failed (content mismatch)");
            } catch (Exception e) {
                sender.sendMessage("Rescue copy could not be written and verified (" + e.getMessage()
                        + ") — pocket " + pocket + " was NOT cleared.");
                return;
            }
            // D10 step 4: delete only through setPocket, then audit.
            String kind = store.pocketKind(pocket);
            store.setPocket(pocket, null, null);
            audit("clear", sender, target, selector, kind, bytes.length);
            sender.sendMessage("Cleared pocket " + pocket + " (" + descOrUnreadable + ") from " + target.name()
                    + "'s pouch. Rescue copy: data/rescue/" + fileName);
        } finally {
            release(loaded, target);
        }
    }
}
