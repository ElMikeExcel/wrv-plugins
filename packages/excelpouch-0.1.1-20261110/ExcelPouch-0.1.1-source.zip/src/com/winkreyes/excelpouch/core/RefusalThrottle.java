package com.winkreyes.excelpouch.core;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.LongSupplier;

/**
 * The refusal line is throttled per player (SPEC Part I §8: "not
 * per-click spam"). One line per window no matter how many refused
 * clicks land inside it. Clock is injectable for tests.
 */
public final class RefusalThrottle {
    public static final long WINDOW_MS = 1500L;

    private final Map<UUID, Long> lastSent = new HashMap<>();
    private final LongSupplier clock;

    public RefusalThrottle() {
        this(System::currentTimeMillis);
    }

    public RefusalThrottle(LongSupplier clock) {
        this.clock = clock;
    }

    /** @return true if the line may be sent now (and records the send). */
    public synchronized boolean trySend(UUID player) {
        long now = clock.getAsLong();
        Long last = lastSent.get(player);
        if (last != null && now - last < WINDOW_MS) return false;
        lastSent.put(player, now);
        return true;
    }

    public synchronized void forget(UUID player) {
        lastSent.remove(player);
    }
}
