package com.winkreyes.excelpouch.core;

/**
 * GUI geometry (SPEC Part I §4). Bukkit screens are rows of 9.
 *
 * Launch shape (slots: 2): one 9-slot row; the two pockets are
 * slots 3 and 5, flanking the "Utility Pouch" nameplate pane at
 * slot 4; the other six slots are blank filler panes, each
 * hard-cancelled — the filler is the anti-misclick guard as well
 * as the frame.
 *
 * Growth (config-only, +1 per newly shipped server item): one row
 * up to 9 pockets (centered); past 9 the screen gains rows and
 * pockets come first, filler after (spec §4).
 */
public final class PouchLayout {
    private PouchLayout() { }

    public static int clampSlots(int slots) {
        return Math.max(1, Math.min(54, slots));
    }

    /** Total GUI size (a multiple of 9) for a pocket count. */
    public static int guiSize(int slots) {
        slots = clampSlots(slots);
        if (slots <= 9) return 9;
        return ((slots + 8) / 9) * 9;
    }

    /** Pocket GUI slot indexes, in pocket order. */
    public static int[] pocketSlots(int slots) {
        slots = clampSlots(slots);
        int[] out = new int[slots];
        if (slots <= 9) {
            if (slots == 2) return new int[] {3, 5};       // launch shape
            int start = (9 - slots) / 2;                    // centered run
            for (int i = 0; i < slots; i++) out[i] = start + i;
            return out;
        }
        for (int i = 0; i < slots; i++) out[i] = i;         // pockets first
        return out;
    }

    /** Nameplate GUI slot, or -1 when the layout has none. Launch shape only. */
    public static int nameplateSlot(int slots) {
        return clampSlots(slots) == 2 ? 4 : -1;
    }

    /** Pocket index for a GUI slot, or -1 if it is not a pocket. */
    public static int pocketIndex(int slots, int guiSlot) {
        int[] pockets = pocketSlots(slots);
        for (int i = 0; i < pockets.length; i++) if (pockets[i] == guiSlot) return i;
        return -1;
    }

    public static boolean isPocket(int slots, int guiSlot) {
        return pocketIndex(slots, guiSlot) >= 0;
    }
}
