package com.winkreyes.excelpouch.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Selector resolution for the /pouch admin ops (0.1.1, design §4.0):
 * a pocket is named either as {@code pocket:<n>} (0-based store
 * index, INCLUDING config-hidden pockets — they are real state) or
 * as a kind id ({@code menu_compass} / {@code magic_wand}).
 *
 * Pure logic, Bukkit-free, so the zero / one / many semantics are
 * plain-JVM testable in the house style (like KindMatcher /
 * PouchLayout). A kind matching more than one pocket is REFUSED
 * with the matching list — the command never picks one silently
 * (design-D4). The input kind list is the store-order kind cache:
 * one entry per stored pocket, null for an empty pocket.
 */
public final class AdminSelector {
    private AdminSelector() { }

    public static final Set<String> KNOWN_KINDS = Set.of(KindMatcher.MENU_COMPASS, KindMatcher.MAGIC_WAND);
    private static final String POCKET_PREFIX = "pocket:";

    public enum Outcome { POCKET, UNIQUE, ZERO, MANY, OUT_OF_RANGE, MALFORMED }

    /**
     * @param outcome what the resolution decided
     * @param pocket  the resolved pocket index for POCKET / UNIQUE, else -1
     * @param matches every matching pocket index for MANY (store order), else empty
     * @param detail  operator-facing reason for OUT_OF_RANGE / MALFORMED, else null
     */
    public record Result(Outcome outcome, int pocket, List<Integer> matches, String detail) {
        static Result of(Outcome o, int pocket) { return new Result(o, pocket, List.of(), null); }
    }

    public static Result resolve(String selector, List<String> pocketKinds) {
        List<String> kinds = pocketKinds == null ? List.of() : pocketKinds;
        if (selector == null || selector.isBlank()) {
            return new Result(Outcome.MALFORMED, -1, List.of(), "empty selector");
        }
        String sel = selector.trim().toLowerCase(java.util.Locale.ROOT);
        if (sel.startsWith(POCKET_PREFIX)) {
            String num = sel.substring(POCKET_PREFIX.length());
            if (num.isEmpty()) {
                return new Result(Outcome.MALFORMED, -1, List.of(), "pocket: with no number");
            }
            final int n;
            try {
                n = Integer.parseInt(num);
            } catch (NumberFormatException e) {
                return new Result(Outcome.MALFORMED, -1, List.of(), "pocket: number '" + num + "' is not a number");
            }
            if (n < 0 || n >= kinds.size()) {
                return new Result(Outcome.OUT_OF_RANGE, -1, List.of(),
                        "pocket " + n + " does not exist (" + kinds.size() + " stored pocket(s))");
            }
            return Result.of(Outcome.POCKET, n);
        }
        if (sel.contains(":") || !KNOWN_KINDS.contains(sel)) {
            return new Result(Outcome.MALFORMED, -1, List.of(), "unknown kind '" + selector.trim() + "'");
        }
        List<Integer> matches = new ArrayList<>();
        for (int i = 0; i < kinds.size(); i++) {
            if (sel.equals(kinds.get(i))) matches.add(i);
        }
        if (matches.isEmpty()) return Result.of(Outcome.ZERO, -1);
        if (matches.size() == 1) return Result.of(Outcome.UNIQUE, matches.get(0));
        return new Result(Outcome.MANY, -1, List.copyOf(matches), null);
    }
}
