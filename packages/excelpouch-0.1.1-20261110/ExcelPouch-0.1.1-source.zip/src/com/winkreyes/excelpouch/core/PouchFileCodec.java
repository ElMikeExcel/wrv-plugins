package com.winkreyes.excelpouch.core;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * Store file encoding: each pocket is one Base64 string (the item's
 * serializeAsBytes() output) or "-" for an empty pocket. Pure codec
 * so the round-trip is unit-testable; the glue layer owns the file
 * (per-player YAML under plugins/ExcelPouch/data/, written with the
 * atomic temp-file + rename pattern).
 *
 * A pocket whose string fails to decode decodes to EMPTY — the file
 * is ours alone, and a corrupt entry must never take the whole
 * pouch (or the server) down with it. The raw string is preserved
 * in the load result so the glue layer can log the loss loudly.
 */
public final class PouchFileCodec {
    private PouchFileCodec() { }

    public static final String EMPTY = "-";

    public static String encodePocket(byte[] itemBytes) {
        if (itemBytes == null || itemBytes.length == 0) return EMPTY;
        return Base64.getEncoder().encodeToString(itemBytes);
    }

    /** @return decoded bytes, or null for empty/corrupt. */
    public static byte[] decodePocket(String encoded) {
        if (encoded == null || encoded.isEmpty() || EMPTY.equals(encoded)) return null;
        try {
            byte[] b = Base64.getDecoder().decode(encoded);
            return b.length == 0 ? null : b;
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public static List<String> encodeAll(List<byte[]> pockets) {
        List<String> out = new ArrayList<>(pockets.size());
        for (byte[] b : pockets) out.add(encodePocket(b));
        return out;
    }

    /**
     * Decode a stored pocket list. The list may be longer than the
     * configured slot count (config shrunk after items were stored):
     * every entry is kept — size never deletes (SPEC Part I §4).
     * Entries beyond the visible pockets stay in the store (and
     * still answer holdsKind) until the player removes them after
     * the size grows back, or an admin intervenes.
     */
    public static List<byte[]> decodeAll(List<String> encoded) {
        List<byte[]> out = new ArrayList<>(encoded == null ? 0 : encoded.size());
        if (encoded != null) for (String s : encoded) out.add(decodePocket(s));
        return out;
    }
}
