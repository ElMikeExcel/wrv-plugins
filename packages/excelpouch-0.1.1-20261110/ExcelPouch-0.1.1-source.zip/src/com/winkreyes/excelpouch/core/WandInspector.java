package com.winkreyes.excelpouch.core;

import java.util.Map;

/**
 * Dependency-free Magic wand detection over an item's serialized
 * bytes, mirroring Magic's own test (SPEC Part I §3 / §6A):
 *
 *   isWand  := the item's minecraft:custom_data component carries a
 *              top-level compound under the wand key (Magic's
 *              WAND_KEY, default "wand" — Wand.java L300, containsTag
 *              check at L3319-3321).
 *   owner   := that compound's "owner_id" string (Wand.java
 *              L1210-1211, read back L2426-2427).
 *
 * Upgrade items (top-level "wand_upgrade"), spell items ("spell"),
 * brushes ("brush") and skill items ("skill") never carry the wand
 * compound, so they read NOT_A_WAND here by construction.
 */
public final class WandInspector {
    private WandInspector() { }

    public enum Verdict {
        /** No wand compound (or the bytes did not parse — fail closed). */
        NOT_A_WAND,
        /** Wand compound present but no owner_id: pre-bind window; refused. */
        WAND_UNOWNED,
        /** Wand compound present with an owner_id. */
        WAND_OWNED
    }

    public record Result(Verdict verdict, String ownerId) {
        static Result notWand() { return new Result(Verdict.NOT_A_WAND, null); }
    }

    /** Full item path: serialized bytes -> custom_data -> wand compound. Never throws. */
    public static Result inspect(byte[] serializedItem, String wandKey) {
        Map<String, Object> root;
        try {
            root = Nbt.parseRoot(serializedItem);
        } catch (Exception e) {
            return Result.notWand();
        }
        return inspectRoot(root, wandKey);
    }

    /** Tree path (also used by tests that navigate a parsed tree directly). */
    public static Result inspectRoot(Map<String, Object> root, String wandKey) {
        Map<String, Object> components = Nbt.compound(root, "components");
        Map<String, Object> customData = Nbt.compound(components, "minecraft:custom_data");
        Map<String, Object> wand = Nbt.compound(customData, wandKey);
        if (wand == null) return Result.notWand();
        String owner = Nbt.string(wand, "owner_id");
        if (owner == null || owner.isEmpty()) return new Result(Verdict.WAND_UNOWNED, null);
        return new Result(Verdict.WAND_OWNED, owner);
    }
}
