package com.winkreyes.excelpouch.core;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/**
 * Minimal read-only NBT reader — just enough to walk the tree that
 * {@code ItemStack.serializeAsBytes()} produces (a GZIP-compressed root
 * compound: {DataVersion, id, count, components:{...}}).
 *
 * Exists because this Paper build's API exposes no typed CUSTOM_DATA
 * component and ItemMeta's CustomItemTagContainer does NOT see
 * minecraft:custom_data (both proven by probe on the Magic bind-test
 * rig, 2026-10-19 — see BUILD.md). Reading the serialized bytes with
 * Bukkit's own serializer keeps detection dependency-free: the same
 * bytes the pouch store persists are the bytes detection reads.
 *
 * Tree values: Byte, Short, Integer, Long, Float, Double, byte[],
 * String, List<Object>, int[], long[], and Map<String,Object> for
 * compounds (insertion-ordered). Parsing is fail-closed: any
 * malformed input raises IOException and callers treat the item as
 * "not a wand".
 */
public final class Nbt {
    private Nbt() { }

    static final int MAX_DEPTH = 64;
    static final int MAX_STRING = 1 << 20;
    static final int MAX_LIST = 1 << 17;
    static final int MAX_BYTES = 1 << 24;

    /** Parse serializeAsBytes() output (GZIP) or a raw NBT stream into the root compound. */
    public static Map<String, Object> parseRoot(byte[] bytes) throws IOException {
        if (bytes == null || bytes.length < 3) throw new IOException("empty");
        byte[] raw = bytes;
        if ((bytes[0] & 0xFF) == 0x1F && (bytes[1] & 0xFF) == 0x8B) {
            try (GZIPInputStream gz = new GZIPInputStream(new ByteArrayInputStream(bytes))) {
                raw = gz.readAllBytes();
            }
        }
        if (raw.length > MAX_BYTES) throw new IOException("oversized");
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(raw));
        int type = in.readUnsignedByte();
        if (type != 10) throw new IOException("root is not a compound (tag " + type + ")");
        readUtf(in); // root name, ignored
        Object root = readPayload(in, type, 0);
        if (!(root instanceof Map)) throw new IOException("root is not a compound");
        @SuppressWarnings("unchecked") Map<String, Object> map = (Map<String, Object>) root;
        return map;
    }

    private static String readUtf(DataInputStream in) throws IOException {
        int len = in.readUnsignedShort();
        if (len > MAX_STRING) throw new IOException("string too long");
        byte[] b = in.readNBytes(len);
        if (b.length != len) throw new IOException("eof in string");
        return new String(b, java.nio.charset.StandardCharsets.UTF_8);
    }

    private static Object readPayload(DataInputStream in, int type, int depth) throws IOException {
        if (depth > MAX_DEPTH) throw new IOException("too deep");
        switch (type) {
            case 1: return in.readByte();
            case 2: return in.readShort();
            case 3: return in.readInt();
            case 4: return in.readLong();
            case 5: return in.readFloat();
            case 6: return in.readDouble();
            case 7: {
                int n = in.readInt();
                if (n < 0 || n > MAX_BYTES) throw new IOException("bad byte array");
                byte[] b = in.readNBytes(n);
                if (b.length != n) throw new IOException("eof in byte array");
                return b;
            }
            case 8: return readUtf(in);
            case 9: {
                int elem = in.readUnsignedByte();
                int n = in.readInt();
                if (n < 0 || n > MAX_LIST) throw new IOException("bad list");
                List<Object> list = new ArrayList<>(Math.min(n, 1024));
                for (int i = 0; i < n; i++) list.add(readPayload(in, elem, depth + 1));
                return list;
            }
            case 10: {
                Map<String, Object> map = new LinkedHashMap<>();
                while (true) {
                    int t = in.readUnsignedByte();
                    if (t == 0) break;
                    if (t < 1 || t > 12) throw new IOException("bad tag " + t);
                    String name = readUtf(in);
                    map.put(name, readPayload(in, t, depth + 1));
                }
                return map;
            }
            case 11: {
                int n = in.readInt();
                if (n < 0 || n > MAX_LIST) throw new IOException("bad int array");
                int[] a = new int[n];
                for (int i = 0; i < n; i++) a[i] = in.readInt();
                return a;
            }
            case 12: {
                int n = in.readInt();
                if (n < 0 || n > MAX_LIST) throw new IOException("bad long array");
                long[] a = new long[n];
                for (int i = 0; i < n; i++) a[i] = in.readLong();
                return a;
            }
            default: throw new IOException("bad tag " + type);
        }
    }

    /** Navigate: child compound of a compound, or null. */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> compound(Map<String, Object> parent, String key) {
        if (parent == null) return null;
        Object v = parent.get(key);
        return (v instanceof Map) ? (Map<String, Object>) v : null;
    }

    /** Child string of a compound, or null. */
    public static String string(Map<String, Object> parent, String key) {
        if (parent == null) return null;
        Object v = parent.get(key);
        return (v instanceof String) ? (String) v : null;
    }

    /**
     * Deep equality over NBT trees (byte/int/long arrays by content,
     * compounds and lists recursively, numbers by exact boxed value —
     * so a Byte(1) never equals an Integer(1): tag type is part of
     * the value, exactly as the §6A round-trip assert requires).
     */
    public static boolean deepEquals(Object a, Object b) {
        if (a == b) return true;
        if (a == null || b == null) return false;
        if (a instanceof byte[] x && b instanceof byte[] y) return Arrays.equals(x, y);
        if (a instanceof int[] x && b instanceof int[] y) return Arrays.equals(x, y);
        if (a instanceof long[] x && b instanceof long[] y) return Arrays.equals(x, y);
        if (a instanceof Map<?, ?> x && b instanceof Map<?, ?> y) {
            if (x.size() != y.size()) return false;
            for (Map.Entry<?, ?> e : x.entrySet()) {
                if (!y.containsKey(e.getKey())) return false;
                if (!deepEquals(e.getValue(), y.get(e.getKey()))) return false;
            }
            return true;
        }
        if (a instanceof List<?> x && b instanceof List<?> y) {
            if (x.size() != y.size()) return false;
            for (int i = 0; i < x.size(); i++) if (!deepEquals(x.get(i), y.get(i))) return false;
            return true;
        }
        return a.equals(b);
    }
}
