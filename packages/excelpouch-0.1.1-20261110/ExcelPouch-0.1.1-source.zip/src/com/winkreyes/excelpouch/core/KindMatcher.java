package com.winkreyes.excelpouch.core;

import java.util.Set;

/**
 * The allowlist decision (SPEC Part I §3): default-deny. An item may
 * enter a pocket only if it matches an ENABLED kind:
 *
 *   menu_compass — a COMPASS carrying the excelmenujoin:menu_compass
 *                  PDC stamp OR the legacy menujoin:menu_compass
 *                  stamp (the recognition rule ExcelMenuJoin 1.3.0
 *                  and ExcelShops share).
 *   magic_wand   — a wand (see WandInspector) whose owner_id equals
 *                  the pouch owner's UUID, amount exactly 1. Another
 *                  player's wand, and an unowned wand, never match.
 *
 * The glue layer extracts ItemFacts from the live ItemStack; every
 * branch of the decision is exercised by KindMatcherTest.
 */
public final class KindMatcher {
    private KindMatcher() { }

    public static final String MENU_COMPASS = "menu_compass";
    public static final String MAGIC_WAND = "magic_wand";

    /** The one refusal line (SPEC Part I §3, wording verbatim). */
    public static final String REFUSAL_LINE =
            "§7The §6Utility Pouch §7only holds server gear — that stays in your inventory.";

    /**
     * Facts about one candidate item, extracted by the glue layer.
     *
     * @param materialName    Bukkit Material name, e.g. "COMPASS"
     * @param amount          stack amount
     * @param compassStamped  carries either menu-compass PDC stamp
     * @param wand            wand verdict from WandInspector
     * @param wandOwnerId     owner_id if the verdict is WAND_OWNED
     * @param pouchOwnerId    UUID string of the pouch's owner
     */
    public record ItemFacts(String materialName, int amount, boolean compassStamped,
                            WandInspector.Verdict wand, String wandOwnerId, String pouchOwnerId) { }

    /** @return the matched kind id, or null for "refused". */
    public static String match(ItemFacts f, Set<String> enabledKinds) {
        if (f == null || enabledKinds == null) return null;
        if (enabledKinds.contains(MENU_COMPASS)
                && "COMPASS".equals(f.materialName())
                && f.compassStamped()) {
            return MENU_COMPASS;
        }
        if (enabledKinds.contains(MAGIC_WAND)
                && f.wand() == WandInspector.Verdict.WAND_OWNED
                && f.wandOwnerId() != null
                && f.wandOwnerId().equals(f.pouchOwnerId())
                && f.amount() == 1) {
            return MAGIC_WAND;
        }
        return null;
    }
}
