package com.winkreyes.excelpouch;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.UUID;

/** Marks an inventory as a player's Utility Pouch screen. */
public final class PouchHolder implements InventoryHolder {
    private final UUID owner;
    private final java.util.Set<Integer> sealed = new java.util.HashSet<>();
    private Inventory inventory;

    public PouchHolder(UUID owner) {
        this.owner = owner;
    }

    public UUID owner() { return owner; }

    /** Freeze a pocket whose stored item failed to deserialize — its bytes never move. */
    public void seal(int pocket) { sealed.add(pocket); }

    public boolean isSealed(int pocket) { return sealed.contains(pocket); }

    void bind(Inventory inventory) { this.inventory = inventory; }

    @Override
    public Inventory getInventory() { return inventory; }
}
