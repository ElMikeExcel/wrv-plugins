package com.winkreyes.excelpouch;

import com.winkreyes.excelpouch.core.PouchFileCodec;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * One player's pouch: the store is the only truth (SPEC Part I §8).
 * Pockets hold serializeAsBytes() output; pocket kinds are cached
 * alongside (recomputed on every write and on load) so PouchQuery
 * never deserializes on the MenuJoin hot path.
 *
 * Persistence: plugins/ExcelPouch/data/<uuid>.yml, written through
 * on every mutation with the atomic temp-file + rename pattern.
 * A store list may be LONGER than the configured slot count (the
 * config shrank after items were stored): the excess stays stored
 * — size never deletes (SPEC Part I §4) — it just isn't rendered.
 */
public final class PouchStore {
    private final UUID owner;
    private final File file;
    private final Logger logger;
    private final List<byte[]> pockets = new ArrayList<>();
    private final List<String> kinds = new ArrayList<>();
    /** The verbatim stored Base64 entry per pocket (parallel to pockets), so an admin rescue copy is the stored entry itself, never a re-encode (0.1.1). */
    private final List<String> entries = new ArrayList<>();
    private boolean loaded;
    /** Set when the on-disk file could not be read: saves are suppressed so a bad read can never overwrite the only copy. */
    private boolean broken;

    PouchStore(UUID owner, File dataDir, Logger logger) {
        this.owner = owner;
        this.file = new File(dataDir, owner + ".yml");
        this.logger = logger;
    }

    public UUID owner() { return owner; }
    public boolean isLoaded() { return loaded; }
    public int storedCount() { return pockets.size(); }

    /** True when the on-disk file could not be read and saves are suppressed (0.1.1 accessor; the flag itself is 0.1.0). */
    public synchronized boolean isBroken() { return broken; }

    /** One stored pocket, read-only, for admin status/rescue use (0.1.1). */
    public record PocketInfo(int index, String kind, int byteLength, String rawEntry) { }

    /** Snapshot of every stored pocket in store order, including empty and config-hidden pockets. */
    public synchronized List<PocketInfo> snapshot() {
        List<PocketInfo> out = new ArrayList<>(pockets.size());
        for (int i = 0; i < pockets.size(); i++) {
            byte[] b = pockets.get(i);
            out.add(new PocketInfo(i, kinds.get(i), b == null ? 0 : b.length,
                    i < entries.size() ? entries.get(i) : null));
        }
        return out;
    }

    /** The verbatim stored Base64 entry for a pocket (the rescue-copy source); null if none. */
    public synchronized String rawEntry(int index) {
        return (index >= 0 && index < entries.size()) ? entries.get(index) : null;
    }

    /** Load from disk (missing file = empty pouch). Never throws. */
    public synchronized void load(ExcelPouch plugin) {
        pockets.clear();
        kinds.clear();
        entries.clear();
        if (file.isFile()) {
            try {
                YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
                List<String> encoded = yml.getStringList("pockets");
                List<byte[]> decoded = PouchFileCodec.decodeAll(encoded);
                for (int i = 0; i < decoded.size(); i++) {
                    pockets.add(decoded.get(i));
                    kinds.add(null);
                    entries.add(encoded.get(i));
                    if (decoded.get(i) == null && encoded.get(i) != null
                            && !PouchFileCodec.EMPTY.equals(encoded.get(i))) {
                        logger.warning("[ExcelPouch] " + owner + " pocket " + i
                                + " failed to decode; treating as empty (raw entry kept on disk until next save).");
                    }
                }
            } catch (Exception e) {
                broken = true;
                logger.warning("[ExcelPouch] could not read " + file.getName() + ": " + e.getMessage()
                        + " — starting empty and SUPPRESSING saves for this store so the file is never overwritten.");
                try {
                    Files.move(file.toPath(), file.toPath().resolveSibling(file.getName() + ".corrupt"));
                    logger.warning("[ExcelPouch] quarantined the unreadable file as " + file.getName() + ".corrupt");
                } catch (Exception moveFailed) {
                    logger.warning("[ExcelPouch] quarantine move failed (" + moveFailed.getMessage()
                            + "); the original file stays in place and unsaved.");
                }
            }
        }
        for (int i = 0; i < pockets.size(); i++) {
            if (pockets.get(i) != null) kinds.set(i, plugin.classifyStored(owner, pockets.get(i)));
        }
        loaded = true;
    }

    /** Atomic save (temp file + rename). Never throws. */
    public synchronized void save() {
        if (!loaded || broken) return;
        try {
            file.getParentFile().mkdirs();
            YamlConfiguration yml = new YamlConfiguration();
            yml.set("pockets", PouchFileCodec.encodeAll(pockets));
            File tmp = new File(file.getParentFile(), file.getName() + ".tmp");
            yml.save(tmp);
            try {
                Files.move(tmp.toPath(), file.toPath(),
                        StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            logger.warning("[ExcelPouch] could not save " + file.getName() + ": " + e.getMessage());
        }
    }

    public synchronized byte[] pocket(int index) {
        return (index >= 0 && index < pockets.size()) ? pockets.get(index) : null;
    }

    public synchronized String pocketKind(int index) {
        return (index >= 0 && index < kinds.size()) ? kinds.get(index) : null;
    }

    public synchronized void setPocket(int index, byte[] itemBytes, String kind) {
        while (pockets.size() <= index) { pockets.add(null); kinds.add(null); entries.add(null); }
        pockets.set(index, itemBytes);
        kinds.set(index, kind);
        entries.set(index, PouchFileCodec.encodePocket(itemBytes));
        save();
    }

    /** True if any stored pocket (visible or config-hidden) holds the kind. */
    public synchronized boolean holdsKind(String kindId) {
        for (String k : kinds) if (kindId.equals(k)) return true;
        return false;
    }
}
