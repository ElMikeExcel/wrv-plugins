#!/bin/bash
# Compile and run the ExcelPouch plain-JVM suites.
set -euo pipefail
cd "$(dirname "$0")"
JDK=~/workspace/.jdk25
rm -rf build/test-classes && mkdir -p build/test-classes
"$JDK/bin/javac" --release 21 -proc:none -nowarn -d build/test-classes \
  $(find src/com/winkreyes/excelpouch/core src/com/winkreyes/excelpouch/api -name '*.java') \
  $(find tests -name '*.java')
"$JDK/bin/java" -Dfixtures=tests/fixtures -cp build/test-classes TestMain
