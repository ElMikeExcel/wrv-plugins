import com.winkreyes.excelpouch.core.RefusalThrottle;

import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

public class RefusalThrottleTest {
    static void run() {
        System.out.println("== RefusalThrottleTest ==");
        AtomicLong now = new AtomicLong(10_000L);
        RefusalThrottle t = new RefusalThrottle(now::get);
        UUID a = UUID.randomUUID();
        UUID b = UUID.randomUUID();
        Check.ok(t.trySend(a), "first refusal sends");
        Check.ok(!t.trySend(a), "second refusal inside the window is suppressed");
        now.addAndGet(RefusalThrottle.WINDOW_MS - 1);
        Check.ok(!t.trySend(a), "still suppressed just before the window ends");
        now.addAndGet(1);
        Check.ok(t.trySend(a), "sends again at the window edge");
        Check.ok(t.trySend(b), "throttle is per-player");
        t.forget(a);
        Check.ok(t.trySend(a), "forget resets a player (quit cleanup)");
    }
}
