import com.winkreyes.excelpouch.core.AdminSelector;
import com.winkreyes.excelpouch.core.AdminSelector.Outcome;

import java.util.Arrays;
import java.util.List;

/**
 * AdminSelector (0.1.1): kind 0 / 1 / many, pocket:<n> in range /
 * out of range / addressing a config-hidden pocket, malformed forms.
 * The kind list is the store-order kind cache (null = empty pocket);
 * a list longer than the visible slot count models hidden pockets —
 * the resolver never sees the visible count, so hidden pockets are
 * addressable by construction.
 */
public class AdminSelectorTest {
    public static void run() {
        System.out.println("AdminSelectorTest:");
        // store: pocket0 wand, pocket1 empty, pocket2 compass (HIDDEN if slots=2), pocket3 wand
        List<String> store = Arrays.asList("magic_wand", null, "menu_compass", "magic_wand");

        var zero = AdminSelector.resolve("menu_compass", Arrays.asList("magic_wand", null));
        Check.eq(Outcome.ZERO, zero.outcome(), "kind with zero matches is ZERO");

        var one = AdminSelector.resolve("menu_compass", store);
        Check.eq(Outcome.UNIQUE, one.outcome(), "kind with one match is UNIQUE");
        Check.eq(2, one.pocket(), "unique kind resolves to its pocket (a hidden one)");

        var many = AdminSelector.resolve("magic_wand", store);
        Check.eq(Outcome.MANY, many.outcome(), "kind with two matches is MANY (never a silent pick)");
        Check.eq(List.of(0, 3), many.matches(), "MANY lists every matching pocket in store order");

        var p0 = AdminSelector.resolve("pocket:0", store);
        Check.eq(Outcome.POCKET, p0.outcome(), "pocket:0 resolves");
        Check.eq(0, p0.pocket(), "pocket:0 index");

        var hidden = AdminSelector.resolve("pocket:3", store);
        Check.eq(Outcome.POCKET, hidden.outcome(), "pocket:3 resolves past the visible slots");
        Check.eq(3, hidden.pocket(), "config-hidden pocket is addressable by pocket:<n>");

        var emptyPocket = AdminSelector.resolve("pocket:1", store);
        Check.eq(Outcome.POCKET, emptyPocket.outcome(), "pocket:<n> may address an empty pocket (caller reports the no-op)");

        Check.eq(Outcome.OUT_OF_RANGE, AdminSelector.resolve("pocket:4", store).outcome(), "pocket:4 of 4 is out of range");
        Check.eq(Outcome.OUT_OF_RANGE, AdminSelector.resolve("pocket:0", List.of()).outcome(), "pocket:0 of an empty store is out of range");
        Check.eq(Outcome.OUT_OF_RANGE, AdminSelector.resolve("pocket:-1", store).outcome(), "pocket:-1 is out of range");

        Check.eq(Outcome.MALFORMED, AdminSelector.resolve("", store).outcome(), "empty selector is malformed");
        Check.eq(Outcome.MALFORMED, AdminSelector.resolve("   ", store).outcome(), "blank selector is malformed");
        Check.eq(Outcome.MALFORMED, AdminSelector.resolve(null, store).outcome(), "null selector is malformed");
        Check.eq(Outcome.MALFORMED, AdminSelector.resolve("pocket:", store).outcome(), "pocket: with no number is malformed");
        Check.eq(Outcome.MALFORMED, AdminSelector.resolve("pocket:abc", store).outcome(), "pocket: with a non-number is malformed");
        Check.eq(Outcome.MALFORMED, AdminSelector.resolve("pocket:1.5", store).outcome(), "pocket: with a decimal is malformed");
        Check.eq(Outcome.MALFORMED, AdminSelector.resolve("dirt", store).outcome(), "unknown kind is malformed");
        Check.eq(Outcome.MALFORMED, AdminSelector.resolve("slot:1", store).outcome(), "unknown prefixed form is malformed");

        var caseKind = AdminSelector.resolve("Magic_Wand", List.of("magic_wand"));
        Check.eq(Outcome.UNIQUE, caseKind.outcome(), "kind matching is case-insensitive");
        var casePocket = AdminSelector.resolve("Pocket:1", store);
        Check.eq(Outcome.POCKET, casePocket.outcome(), "pocket: prefix is case-insensitive");
    }
}
