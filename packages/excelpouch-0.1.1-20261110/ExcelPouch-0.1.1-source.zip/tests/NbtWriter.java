import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPOutputStream;

/**
 * Test-only NBT writer: the inverse of core Nbt, used to prove the
 * parse -> re-encode -> parse round-trip is lossless at tree level
 * (the §6A Q1 assertion shape for plain-JVM suites; the Bukkit-level
 * deserialize/serialize version runs in the rig).
 */
public final class NbtWriter {
    private NbtWriter() { }

    public static byte[] writeRootGzip(Map<String, Object> root) throws IOException {
        ByteArrayOutputStream raw = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(raw);
        out.writeByte(10);
        writeUtf(out, "");
        writeCompound(out, root);
        out.flush();
        ByteArrayOutputStream gz = new ByteArrayOutputStream();
        try (GZIPOutputStream g = new GZIPOutputStream(gz)) { g.write(raw.toByteArray()); }
        return gz.toByteArray();
    }

    private static void writeUtf(DataOutputStream out, String s) throws IOException {
        byte[] b = s.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        out.writeShort(b.length);
        out.write(b);
    }

    private static int typeOf(Object v) {
        if (v instanceof Byte) return 1;
        if (v instanceof Short) return 2;
        if (v instanceof Integer) return 3;
        if (v instanceof Long) return 4;
        if (v instanceof Float) return 5;
        if (v instanceof Double) return 6;
        if (v instanceof byte[]) return 7;
        if (v instanceof String) return 8;
        if (v instanceof List) return 9;
        if (v instanceof Map) return 10;
        if (v instanceof int[]) return 11;
        if (v instanceof long[]) return 12;
        throw new IllegalArgumentException("unwritable " + v);
    }

    @SuppressWarnings("unchecked")
    private static void writePayload(DataOutputStream out, Object v) throws IOException {
        switch (typeOf(v)) {
            case 1 -> out.writeByte((Byte) v);
            case 2 -> out.writeShort((Short) v);
            case 3 -> out.writeInt((Integer) v);
            case 4 -> out.writeLong((Long) v);
            case 5 -> out.writeFloat((Float) v);
            case 6 -> out.writeDouble((Double) v);
            case 7 -> { byte[] b = (byte[]) v; out.writeInt(b.length); out.write(b); }
            case 8 -> writeUtf(out, (String) v);
            case 9 -> {
                List<Object> list = (List<Object>) v;
                out.writeByte(list.isEmpty() ? 0 : typeOf(list.get(0)));
                out.writeInt(list.size());
                for (Object e : list) writePayload(out, e);
            }
            case 10 -> writeCompound(out, (Map<String, Object>) v);
            case 11 -> { int[] a = (int[]) v; out.writeInt(a.length); for (int x : a) out.writeInt(x); }
            case 12 -> { long[] a = (long[]) v; out.writeInt(a.length); for (long x : a) out.writeLong(x); }
            default -> throw new IllegalStateException();
        }
    }

    private static void writeCompound(DataOutputStream out, Map<String, Object> map) throws IOException {
        for (Map.Entry<String, Object> e : map.entrySet()) {
            out.writeByte(typeOf(e.getValue()));
            writeUtf(out, e.getKey());
            writePayload(out, e.getValue());
        }
        out.writeByte(0);
    }
}
