import com.winkreyes.excelpouch.core.Nbt;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

public class NbtReaderTest {
    static void run(Path fixtures) throws Exception {
        System.out.println("== NbtReaderTest ==");
        byte[] real = Files.readAllBytes(fixtures.resolve("wand-real.bin"));
        Map<String, Object> root = Nbt.parseRoot(real);
        Check.eq("minecraft:stick", Nbt.string(root, "id"), "real wand id");
        Map<String, Object> wand = Nbt.compound(Nbt.compound(Nbt.compound(root, "components"),
                "minecraft:custom_data"), "wand");
        Check.ok(wand != null, "real wand compound present");
        Check.eq("14d09c01-016e-31d0-ae70-da2e4ca07e3e", Nbt.string(wand, "owner_id"), "real wand owner_id");
        Map<String, Object> spells = Nbt.compound(wand, "spell_inventory");
        Check.eq(4, ((Number) spells.get("aqualung")).intValue(), "spell level survives as NBT int");

        // Round-trip at tree level: parse -> write -> parse must deep-equal.
        byte[] rewritten = NbtWriter.writeRootGzip(root);
        Map<String, Object> root2 = Nbt.parseRoot(rewritten);
        Check.ok(Nbt.deepEquals(root, root2), "parse/encode/parse round-trip deep-equals (section 6A shape)");

        // Non-item trees parse too (plain compound).
        Map<String, Object> plain = Nbt.parseRoot(Files.readAllBytes(fixtures.resolve("plain-item.bin")));
        Check.ok(Nbt.compound(plain, "components") != null, "plain item components present");

        // Fail-closed cases.
        Check.ok(throwsIo(() -> Nbt.parseRoot(new byte[0])), "empty bytes rejected");
        Check.ok(throwsIo(() -> Nbt.parseRoot(new byte[] {1, 2, 3, 4, 5})), "garbage rejected");
        Check.ok(throwsIo(() -> Nbt.parseRoot(null)), "null rejected");
        byte[] truncated = new byte[40];
        System.arraycopy(real, 0, truncated, 0, 40);
        Check.ok(throwsIo(() -> Nbt.parseRoot(truncated)), "truncated wand rejected");

        // Deep-equality sensitivity: tag types and nested values matter.
        Map<String, Object> a = Nbt.parseRoot(Files.readAllBytes(fixtures.resolve("wand-synth.bin")));
        Map<String, Object> b = Nbt.parseRoot(Files.readAllBytes(fixtures.resolve("wand-other-owner.bin")));
        Check.ok(!Nbt.deepEquals(a, b), "different owner_id trees are NOT deep-equal");
        Map<String, Object> a2 = Nbt.parseRoot(Files.readAllBytes(fixtures.resolve("wand-synth.bin")));
        Check.ok(Nbt.deepEquals(a, a2), "same fixture parses deep-equal");
    }

    private interface IoRun { void go() throws Exception; }

    private static boolean throwsIo(IoRun r) {
        try { r.go(); return false; } catch (Exception e) { return true; }
    }
}
