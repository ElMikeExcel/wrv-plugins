import com.winkreyes.excelpouch.core.Nbt;
import com.winkreyes.excelpouch.core.PouchFileCodec;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class StoreCodecTest {
    static void run(Path fixtures) throws Exception {
        System.out.println("== StoreCodecTest ==");
        byte[] real = Files.readAllBytes(fixtures.resolve("wand-real.bin"));

        // The store encoding itself is byte-exact for every pocket.
        String enc = PouchFileCodec.encodePocket(real);
        Check.ok(Arrays.equals(real, PouchFileCodec.decodePocket(enc)),
                "real wand bytes survive the store codec byte-for-byte");
        Check.eq(PouchFileCodec.EMPTY, PouchFileCodec.encodePocket(null), "null pocket encodes as empty marker");
        Check.eq(null, PouchFileCodec.decodePocket(PouchFileCodec.EMPTY), "empty marker decodes to null");
        Check.eq(null, PouchFileCodec.decodePocket("!!!not-base64!!!"), "corrupt entry decodes to null (never throws)");
        Check.eq(null, PouchFileCodec.decodePocket(""), "empty string decodes to null");

        // Full store round-trip, then the section 6A assertion at
        // tree level: the wand compound after the full cycle must
        // deep-equal the wand compound before it.
        List<byte[]> store = new ArrayList<>(List.of(real, new byte[0]));
        store.set(1, null);
        List<byte[]> back = PouchFileCodec.decodeAll(PouchFileCodec.encodeAll(store));
        Check.eq(2, back.size(), "two pockets round-trip");
        Map<String, Object> before = Nbt.compound(Nbt.compound(Nbt.parseRoot(real), "components"), "minecraft:custom_data");
        Map<String, Object> after = Nbt.compound(Nbt.compound(Nbt.parseRoot(back.get(0)), "components"), "minecraft:custom_data");
        Check.ok(Nbt.deepEquals(before, after), "wand custom_data deep-equals after store round-trip (6A lossless)");
        Check.eq(null, back.get(1), "empty pocket stays empty");

        // Config shrink: a 3-pocket store under a 2-pocket config
        // keeps all three entries (size never deletes, SPEC section 4).
        List<byte[]> three = PouchFileCodec.decodeAll(PouchFileCodec.encodeAll(
                List.of(real, real, real)));
        Check.eq(3, three.size(), "stored entries beyond the visible size are preserved");

        Check.eq(0, PouchFileCodec.decodeAll(null).size(), "null list decodes empty");
    }
}
