import com.winkreyes.excelpouch.core.PouchLayout;

import java.util.Arrays;

public class PouchLayoutTest {
    static void run() {
        System.out.println("== PouchLayoutTest ==");
        // Launch shape (SPEC Part I section 4): 9-slot row, pockets 3 and 5, nameplate 4.
        Check.ok(Arrays.equals(new int[] {3, 5}, PouchLayout.pocketSlots(2)), "slots=2 pockets at GUI 3 and 5");
        Check.eq(4, PouchLayout.nameplateSlot(2), "slots=2 nameplate at GUI 4");
        Check.eq(9, PouchLayout.guiSize(2), "slots=2 GUI size 9");
        Check.eq(0, PouchLayout.pocketIndex(2, 3), "GUI 3 is pocket 0");
        Check.eq(1, PouchLayout.pocketIndex(2, 5), "GUI 5 is pocket 1");
        Check.eq(-1, PouchLayout.pocketIndex(2, 4), "GUI 4 (nameplate) is not a pocket");
        Check.eq(-1, PouchLayout.pocketIndex(2, 0), "GUI 0 (filler) is not a pocket");

        // Growth within one row: centered run.
        Check.ok(Arrays.equals(new int[] {4}, PouchLayout.pocketSlots(1)), "slots=1 centered at 4");
        Check.ok(Arrays.equals(new int[] {3, 4, 5}, PouchLayout.pocketSlots(3)), "slots=3 centered 3-5");
        Check.ok(Arrays.equals(new int[] {0, 1, 2, 3, 4, 5, 6, 7, 8}, PouchLayout.pocketSlots(9)), "slots=9 fills the row");
        Check.eq(-1, PouchLayout.nameplateSlot(3), "no nameplate outside the launch shape");

        // Multi-row: pockets first, GUI size rounds up to whole rows.
        Check.eq(18, PouchLayout.guiSize(10), "slots=10 GUI size 18");
        Check.eq(10, PouchLayout.pocketSlots(10).length, "slots=10 has 10 pockets");
        Check.eq(54, PouchLayout.guiSize(54), "slots=54 GUI size 54");

        // Clamping.
        Check.eq(1, PouchLayout.clampSlots(0), "slots clamp low at 1");
        Check.eq(54, PouchLayout.clampSlots(99), "slots clamp high at 54");
        Check.eq(9, PouchLayout.guiSize(0), "clamped slots=1 gives a 9 GUI");
    }
}
