import com.winkreyes.excelpouch.core.KindMatcher;
import com.winkreyes.excelpouch.core.WandInspector;

import java.util.Set;

public class KindMatcherTest {
    private static final String ME = "11111111-2222-3333-4444-555555555555";
    private static final String OTHER = "99999999-8888-7777-6666-555555555555";
    private static final Set<String> BOTH = Set.of(KindMatcher.MENU_COMPASS, KindMatcher.MAGIC_WAND);

    static void run() {
        System.out.println("== KindMatcherTest ==");
        Check.eq(KindMatcher.MENU_COMPASS,
                KindMatcher.match(facts("COMPASS", 1, true, WandInspector.Verdict.NOT_A_WAND, null), BOTH),
                "stamped compass matches menu_compass");
        Check.eq(KindMatcher.MENU_COMPASS,
                KindMatcher.match(facts("COMPASS", 3, true, WandInspector.Verdict.NOT_A_WAND, null), BOTH),
                "stacked stamped compass (existing dupe) still matches");
        Check.eq(null,
                KindMatcher.match(facts("COMPASS", 1, false, WandInspector.Verdict.NOT_A_WAND, null), BOTH),
                "plain unstamped compass refused");
        Check.eq(null,
                KindMatcher.match(facts("FILLED_MAP", 1, true, WandInspector.Verdict.NOT_A_WAND, null), BOTH),
                "stamp on a non-compass refused (material gate)");
        Check.eq(KindMatcher.MAGIC_WAND,
                KindMatcher.match(facts("STICK", 1, false, WandInspector.Verdict.WAND_OWNED, ME), BOTH),
                "own wand matches magic_wand");
        Check.eq(null,
                KindMatcher.match(facts("STICK", 1, false, WandInspector.Verdict.WAND_OWNED, OTHER), BOTH),
                "ANOTHER PLAYER'S WAND REFUSED (owner mismatch)");
        Check.eq(null,
                KindMatcher.match(facts("STICK", 1, false, WandInspector.Verdict.WAND_UNOWNED, null), BOTH),
                "unowned wand refused");
        Check.eq(null,
                KindMatcher.match(facts("STICK", 2, false, WandInspector.Verdict.WAND_OWNED, ME), BOTH),
                "stacked wands refused (amount must be 1)");
        Check.eq(null,
                KindMatcher.match(facts("DIRT", 1, false, WandInspector.Verdict.NOT_A_WAND, null), BOTH),
                "dirt refused (default-deny)");
        Check.eq(null,
                KindMatcher.match(facts("STICK", 1, false, WandInspector.Verdict.NOT_A_WAND, null), BOTH),
                "plain stick refused");

        // Allowlist config gates each kind independently.
        Check.eq(null,
                KindMatcher.match(facts("COMPASS", 1, true, WandInspector.Verdict.NOT_A_WAND, null),
                        Set.of(KindMatcher.MAGIC_WAND)),
                "compass refused when menu_compass disabled in config");
        Check.eq(null,
                KindMatcher.match(facts("STICK", 1, false, WandInspector.Verdict.WAND_OWNED, ME),
                        Set.of(KindMatcher.MENU_COMPASS)),
                "wand refused when magic_wand disabled in config");
        Check.eq(null, KindMatcher.match(null, BOTH), "null facts refused");
    }

    private static KindMatcher.ItemFacts facts(String material, int amount, boolean stamped,
                                               WandInspector.Verdict verdict, String ownerId) {
        return new KindMatcher.ItemFacts(material, amount, stamped, verdict, ownerId, ME);
    }
}
