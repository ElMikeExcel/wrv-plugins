import java.nio.file.Path;

public class TestMain {
    public static void main(String[] args) throws Exception {
        Path fixtures = Path.of(System.getProperty("fixtures", "tests/fixtures"));
        NbtReaderTest.run(fixtures);
        WandInspectorTest.run(fixtures);
        KindMatcherTest.run();
        PouchLayoutTest.run();
        StoreCodecTest.run(fixtures);
        RefusalThrottleTest.run();
        AdminSelectorTest.run();
        System.out.println("TOTAL: " + Check.passed + " passed, " + Check.failed + " failed");
        if (Check.failed > 0) System.exit(1);
    }
}
