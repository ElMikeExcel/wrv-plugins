import com.winkreyes.excelpouch.core.WandInspector;

import java.nio.file.Files;
import java.nio.file.Path;

public class WandInspectorTest {
    private static final String RIG = "14d09c01-016e-31d0-ae70-da2e4ca07e3e";

    static void run(Path fixtures) throws Exception {
        System.out.println("== WandInspectorTest ==");
        WandInspector.Result real = WandInspector.inspect(read(fixtures, "wand-real.bin"), "wand");
        Check.eq(WandInspector.Verdict.WAND_OWNED, real.verdict(), "REAL Magic wand (probe-captured) detected as owned wand");
        Check.eq(RIG, real.ownerId(), "real wand owner_id read");

        WandInspector.Result synth = WandInspector.inspect(read(fixtures, "wand-synth.bin"), "wand");
        Check.eq(WandInspector.Verdict.WAND_OWNED, synth.verdict(), "synthetic wand detected");
        Check.eq("11111111-2222-3333-4444-555555555555", synth.ownerId(), "synthetic owner_id read");

        WandInspector.Result other = WandInspector.inspect(read(fixtures, "wand-other-owner.bin"), "wand");
        Check.eq(WandInspector.Verdict.WAND_OWNED, other.verdict(), "other player's wand is still a wand");
        Check.eq("99999999-8888-7777-6666-555555555555", other.ownerId(), "other owner_id read (matcher refuses it)");

        Check.eq(WandInspector.Verdict.WAND_UNOWNED,
                WandInspector.inspect(read(fixtures, "wand-unowned.bin"), "wand").verdict(),
                "wand without owner_id is UNOWNED (pre-bind window, refused)");
        Check.eq(WandInspector.Verdict.NOT_A_WAND,
                WandInspector.inspect(read(fixtures, "wand-upgrade-only.bin"), "wand").verdict(),
                "wand_upgrade item is NOT a wand");
        Check.eq(WandInspector.Verdict.NOT_A_WAND,
                WandInspector.inspect(read(fixtures, "spell-item.bin"), "wand").verdict(),
                "spell item is NOT a wand");
        Check.eq(WandInspector.Verdict.NOT_A_WAND,
                WandInspector.inspect(read(fixtures, "plain-item.bin"), "wand").verdict(),
                "plain item is NOT a wand");

        // Configurable wand key (magic-wand-key): the wand2 fixture only matches under its own key.
        Check.eq(WandInspector.Verdict.NOT_A_WAND,
                WandInspector.inspect(read(fixtures, "wand-key2.bin"), "wand").verdict(),
                "wand under a different key is invisible to the default key");
        Check.eq(WandInspector.Verdict.WAND_OWNED,
                WandInspector.inspect(read(fixtures, "wand-key2.bin"), "wand2").verdict(),
                "custom magic-wand-key finds its wand");

        // Fail closed on junk.
        Check.eq(WandInspector.Verdict.NOT_A_WAND,
                WandInspector.inspect(new byte[] {9, 9, 9}, "wand").verdict(), "garbage bytes -> NOT_A_WAND");
        Check.eq(WandInspector.Verdict.NOT_A_WAND,
                WandInspector.inspect(null, "wand").verdict(), "null bytes -> NOT_A_WAND");
    }

    private static byte[] read(Path fixtures, String name) throws Exception {
        return Files.readAllBytes(fixtures.resolve(name));
    }
}
