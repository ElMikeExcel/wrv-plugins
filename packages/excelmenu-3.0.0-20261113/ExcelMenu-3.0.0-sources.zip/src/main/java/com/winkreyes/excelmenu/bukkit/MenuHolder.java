package com.winkreyes.excelmenu.bukkit;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.Map;

/**
 * Marks an inventory as an ExcelMenu view and remembers, per slot,
 * which definition item is rendered there — the click listener
 * trusts this map, never the ItemStack, so a renamed or copied item
 * can never smuggle a different action into a menu.
 */
final class MenuHolder implements InventoryHolder {

    private final com.winkreyes.excelmenu.core.MenuDef definition;
    private final java.util.UUID player;
    private Map<Integer, String> slotItems;
    private Inventory inventory;
    private long lastRenderMillis;

    MenuHolder(java.util.UUID player, com.winkreyes.excelmenu.core.MenuDef definition, Map<Integer, String> slotItems) {
        this.player = player;
        this.definition = definition;
        this.slotItems = slotItems;
    }

    String menuId() { return definition.id; }

    boolean matches(java.util.UUID viewer, com.winkreyes.excelmenu.core.MenuDef current) {
        return player.equals(viewer) && definition == current;
    }

    String itemAt(int slot) { return slotItems.get(slot); }

    void replaceSlotItems(Map<Integer, com.winkreyes.excelmenu.core.MenuDef.ItemDef> visible) {
        Map<Integer, String> next = new java.util.LinkedHashMap<>();
        for (Map.Entry<Integer, com.winkreyes.excelmenu.core.MenuDef.ItemDef> e
                : visible.entrySet()) {
            next.put(e.getKey(), e.getValue().id());
        }
        this.slotItems = next;
    }

    /** Keep timer-updated visuals and trusted click targets in sync, slot by slot.
     * Never replace mappings for slots that the timer did not render. */
    void replaceSlotItem(int slot, String itemId) {
        Map<Integer, String> next = new java.util.LinkedHashMap<>(slotItems);
        next.put(slot, itemId);
        slotItems = next;
    }

    void markRendered() { this.lastRenderMillis = System.currentTimeMillis(); }

    long lastRenderMillis() { return lastRenderMillis; }

    void bind(Inventory inventory) { this.inventory = inventory; }

    @Override
    public Inventory getInventory() { return inventory; }
}

// ExcelMenu — an Excel plugin by WinkReyesValley. (Excel signature — MikeExcel)
