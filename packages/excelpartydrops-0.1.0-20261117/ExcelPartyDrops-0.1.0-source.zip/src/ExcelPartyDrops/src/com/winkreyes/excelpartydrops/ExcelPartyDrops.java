package com.winkreyes.excelpartydrops;

import com.winkreyes.excelpartydrops.core.HintGate;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Random;

/**
 * ExcelPartyDrops — the elite party-drop multiplier
 * (PARTY-DROPS-SPEC-2026-10-20, WRV-099; Mike approved the spec
 * Oct 20, 2026, "Go for it", and the build the same night).
 *
 * When a natural EliteMobs elite dies, the players present at the
 * death (alive, same world, within the 50-block party radius — the
 * ExcelTogether XP-bonus range definition, copied not called) scale
 * the elite's VANILLA drop list: 1 + 0.5 x (participants - 1),
 * capped at 3x, with per-stack probabilistic rounding that is exact
 * in expectation. Solo is exactly vanilla. EliteMobs' generated gear
 * never passes through the drop list and is untouched (EM already
 * pays every >=10% damager their own roll); the coin shower (0.25
 * dial, FINAL) never enters the list either; dropped XP, Jobs and
 * mcMMO are not this plugin's lane.
 *
 * Visibility is a DECIDED quiet hint (Mike, Oct 20, 2026): an
 * occasional small action-bar note to the participants when a
 * multiplied drop lands — the hint teaches the social loop ("how
 * the server is meant to be played"). Never a broadcast, never a
 * title; per-player cooldown keeps it rare. One console audit line
 * per multiplied kill.
 *
 * EliteMobs is a SOFT depend: this class never references an
 * EliteMobs type. All EM contact lives in EmDeathListener, which is
 * only loaded and registered when EliteMobs is actually present
 * (the ExcelAbilityBridge guarded pattern). Without EliteMobs the
 * plugin enables, logs one line, and does nothing.
 */
public final class ExcelPartyDrops extends JavaPlugin {

    private boolean masterEnabled = true;
    private double partyRadius = 50.0;
    private double stepPerExtra = 0.5;
    private double multiplierCap = 3.0;
    private int participantCap = 5;
    private boolean debug = false;
    private HintGate hintGate = new HintGate(600_000L);
    private final Random random = new Random();
    private boolean emHooked = false;

    // ------------------------------------------------------------ lifecycle

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();

        Plugin em = Bukkit.getPluginManager().getPlugin("EliteMobs");
        if (em != null && em.isEnabled()) {
            // Only now is EmDeathListener loaded — it is the single
            // class that references EliteMobs API types.
            Bukkit.getPluginManager().registerEvents(new EmDeathListener(this), this);
            emHooked = true;
        }

        getLogger().info("ExcelPartyDrops enabled: " + (masterEnabled ? "ON" : "OFF (master switch)")
                + ", radius " + partyRadius + " blocks, step " + stepPerExtra
                + ", multiplier cap " + multiplierCap + ", participant cap " + participantCap
                + (emHooked ? ", EliteMobs hooked"
                            : ", EliteMobs NOT found - inert (no elite drops will be multiplied)"));
    }

    private void loadSettings() {
        masterEnabled = getConfig().getBoolean("enabled", true);

        partyRadius = getConfig().getDouble("party-radius", 50.0);
        if (Double.isNaN(partyRadius) || partyRadius <= 0.0 || partyRadius > 200.0) {
            getLogger().warning("party-radius " + partyRadius + " out of (0,200] - using 50.0");
            partyRadius = 50.0;
        }
        stepPerExtra = getConfig().getDouble("step-per-extra", 0.5);
        if (Double.isNaN(stepPerExtra) || stepPerExtra < 0.0 || stepPerExtra > 2.0) {
            getLogger().warning("step-per-extra " + stepPerExtra + " out of [0,2] - using 0.5");
            stepPerExtra = 0.5;
        }
        multiplierCap = getConfig().getDouble("multiplier-cap", 3.0);
        if (Double.isNaN(multiplierCap) || multiplierCap < 1.0 || multiplierCap > 10.0) {
            getLogger().warning("multiplier-cap " + multiplierCap + " out of [1,10] - using 3.0");
            multiplierCap = 3.0;
        }
        participantCap = getConfig().getInt("participant-cap", 5);
        if (participantCap < 1 || participantCap > 20) {
            getLogger().warning("participant-cap " + participantCap + " out of [1,20] - using 5");
            participantCap = 5;
        }
        long hintCooldownSeconds = getConfig().getLong("hint-cooldown-seconds", 600L);
        if (hintCooldownSeconds < 0L || hintCooldownSeconds > 86_400L) {
            getLogger().warning("hint-cooldown-seconds " + hintCooldownSeconds + " out of [0,86400] - using 600");
            hintCooldownSeconds = 600L;
        }
        hintGate = new HintGate(hintCooldownSeconds * 1000L);
        if (getConfig().getBoolean("respect-farming-cap", false)) {
            // Spec §5: the key is reserved for a future release. In
            // 0.1.0 it has no effect — say so in the log rather than
            // let a config file lie.
            getLogger().warning("respect-farming-cap=true is reserved and NOT implemented in 0.1.0"
                    + " - the multiplier behaves as if it were false (see config comments).");
        }
        debug = getConfig().getBoolean("debug", false);
    }

    // ------------------------------------------------------------ accessors for the EM listener

    public boolean masterEnabled() { return masterEnabled; }
    public double partyRadius() { return partyRadius; }
    public double stepPerExtra() { return stepPerExtra; }
    public double multiplierCap() { return multiplierCap; }
    public int participantCap() { return participantCap; }
    public boolean debug() { return debug; }
    public HintGate hintGate() { return hintGate; }
    public Random random() { return random; }

    // ------------------------------------------------------------ command

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("partydrops")) return false;
        if (!sender.hasPermission("excelpartydrops.admin")) {
            sender.sendMessage("You need the excelpartydrops.admin permission for that.");
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("status")) {
            sender.sendMessage("ExcelPartyDrops: " + (masterEnabled ? "ON" : "OFF (master switch)")
                    + ", radius " + partyRadius + ", step " + stepPerExtra
                    + ", multiplier cap " + multiplierCap + ", participant cap " + participantCap
                    + ", EliteMobs " + (emHooked ? "hooked" : "not hooked (inert)"));
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            loadSettings();
            sender.sendMessage("ExcelPartyDrops config reloaded: "
                    + (masterEnabled ? "ON" : "OFF (master switch)")
                    + ", radius " + partyRadius + ", step " + stepPerExtra
                    + ", multiplier cap " + multiplierCap + ", participant cap " + participantCap);
            return true;
        }
        sender.sendMessage("Usage: /partydrops status|reload");
        return true;
    }
}

// ExcelPartyDrops — an Excel plugin by WinkReyesValley. (Excel signature — MikeExcel)
