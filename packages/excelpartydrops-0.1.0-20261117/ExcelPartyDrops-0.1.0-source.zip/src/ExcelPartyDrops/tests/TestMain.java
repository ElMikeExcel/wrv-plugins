public class TestMain {
    public static void main(String[] args) {
        MultiplierMathTest.run();
        PartyRangeTest.run();
        ParticipantCounterTest.run();
        OriginGateTest.run();
        HintGateTest.run();
        System.out.println("TOTAL: " + Check.passed + " passed, " + Check.failed + " failed");
        if (Check.failed > 0) System.exit(1);
    }
}
