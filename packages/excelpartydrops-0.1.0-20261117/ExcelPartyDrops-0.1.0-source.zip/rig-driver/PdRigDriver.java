package pdrigdriver;

import com.magmaguy.elitemobs.api.EliteMobDeathEvent;
import com.magmaguy.elitemobs.entitytracker.EntityTracker;
import com.magmaguy.elitemobs.mobconstructor.EliteEntity;
import com.mojang.authlib.GameProfile;
import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ClientInformation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Wither;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Rig-only driver for the ExcelPartyDrops scratch server. Fake
 * ServerPlayers stage around a kill pad; the driver spawns zombies
 * with a chosen SpawnReason, polls EliteMobs' EntityTracker for the
 * conversion, kills them, and pairs each kill's vanilla drop sum
 * (EntityDeathEvent at LOWEST, before any plugin edits) with its
 * final drop sum (MONITOR, after ExcelPartyDrops). Every assertion
 * logs a RIGRESULT line. Commands:
 *   pdrig boot | stage <n> | batch <NATURAL|SPAWNER> <count> |
 *   wither | hint | quit
 * Never ships.
 */
public class PdRigDriver extends JavaPlugin implements Listener {

    static final int FLOOR = 120;
    static final double PAD_X = 0.5, PAD_Z = 0.5;
    static final UUID KILLER_UUID = UUID.fromString("aaaaaaaa-0000-0000-0000-000000000001");
    static final UUID BEDROCK_UUID = UUID.fromString("00000000-0000-0000-0009-01f05d0d739d");
    static final String[] NAMES = {"RigKiller", ".RigBedrock", "RigThree", "RigFour", "RigFive"};
    static final UUID[] UUIDS = {
            KILLER_UUID, BEDROCK_UUID,
            UUID.fromString("aaaaaaaa-0000-0000-0000-000000000003"),
            UUID.fromString("aaaaaaaa-0000-0000-0000-000000000004"),
            UUID.fromString("aaaaaaaa-0000-0000-0000-000000000005")};

    World world;
    final List<ServerPlayer> fakes = new ArrayList<>();
    final List<Player> fakePlayers = new ArrayList<>();

    // per-kill paired drop sums, keyed by entity UUID
    final Map<UUID, Integer> preSums = new HashMap<>();
    final Map<UUID, Integer> postSums = new HashMap<>();
    final Map<UUID, String> eliteInfo = new HashMap<>();
    int eliteDeathEvents = 0;

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
    }

    // ------------------------------------------------------------ probes

    static int dropSum(EntityDeathEvent e) {
        int s = 0;
        for (ItemStack st : e.getDrops()) if (st != null) s += st.getAmount();
        return s;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void probePre(EntityDeathEvent e) {
        preSums.put(e.getEntity().getUniqueId(), dropSum(e));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void probePost(EntityDeathEvent e) {
        postSums.put(e.getEntity().getUniqueId(), dropSum(e));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void probeSpawn(org.bukkit.event.entity.CreatureSpawnEvent e) {
        if (e.getEntity() instanceof Zombie) {
            UUID id = e.getEntity().getUniqueId();
            later(40, () -> {
                EliteEntity ee = EntityTracker.getEliteMobEntity(e.getEntity());
                log("spawnprobe reason=" + e.getSpawnReason() + " elite=" + (ee != null)
                        + (ee != null ? " natural=" + ee.isNaturalEntity() + " eeReason=" + ee.getSpawnReason() : "")
                        + " uuid=" + id);
            });
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void probeEliteDeath(EliteMobDeathEvent e) {
        eliteDeathEvents++;
        EliteEntity ee = e.getEliteEntity();
        if (ee != null) {
            eliteInfo.put(e.getEntity().getUniqueId(),
                    "natural=" + ee.isNaturalEntity() + " reason=" + ee.getSpawnReason()
                            + " antiExploit=" + ee.isTriggeredAntiExploit() + " level=" + ee.getLevel());
        }
    }

    // ------------------------------------------------------------ commands

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("pdrig") || args.length == 0) return false;
        switch (args[0].toLowerCase()) {
            case "boot" -> boot();
            case "stage" -> stage(Integer.parseInt(args[1]));
            case "batch" -> batch(CreatureSpawnEvent.SpawnReason.valueOf(args[1].toUpperCase()),
                    Integer.parseInt(args[2]));
            case "wither" -> witherTest();
            case "hint" -> hintTest();
            case "spawner" -> spawnerTest();
            case "gearkill" -> gearKillTest();
            case "partykill" -> partyKillTest();
            case "scan" -> {
                Location pad = new Location(world, PAD_X, FLOOR + 1, PAD_Z);
                int z = 0, el = 0;
                for (Entity e : world.getNearbyEntities(pad, 40, 12, 40)) {
                    if (e instanceof Zombie) { z++; if (EntityTracker.getEliteMobEntity(e) != null) el++; }
                }
                log("scan: zombies near pad=" + z + " elites=" + el);
            }
            case "quit" -> fakePlayers.forEach(p -> p.kickPlayer("rig done"));
            default -> sender.sendMessage("pdrig boot|stage <n>|batch <reason> <n>|wither|hint|quit");
        }
        return true;
    }

    void log(String msg) { getLogger().info("[RIG] " + msg); }

    void result(String test, boolean pass, String detail) {
        getLogger().info("RIGRESULT " + test + " " + (pass ? "PASS" : "FAIL") + " " + detail);
    }

    void later(long ticks, Runnable r) {
        new BukkitRunnable() { @Override public void run() { r.run(); } }.runTaskLater(this, ticks);
    }

    // ------------------------------------------------------------ fake players

    ServerPlayer makePlayer(UUID uuid, String name) {
        MinecraftServer server = ((org.bukkit.craftbukkit.CraftServer) getServer()).getServer();
        ServerLevel level = ((org.bukkit.craftbukkit.CraftWorld) world).getHandle();
        GameProfile profile = new GameProfile(uuid, name);
        ServerPlayer splayer = new ServerPlayer(server, level, profile, ClientInformation.createDefault());
        Connection conn = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(conn);
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(profile, false);
        splayer.connection = new ServerGamePacketListenerImpl(server, conn, splayer, cookie);
        server.getPlayerList().placeNewPlayer(conn, splayer, cookie);
        Bukkit.getPluginManager().callEvent(new PlayerJoinEvent(splayer.getBukkitEntity(), "rig join"));
        return splayer;
    }

    void park(Player p, double x) {
        p.teleport(new Location(world, x, FLOOR + 1, PAD_Z));
    }

    void boot() {
        world = Bukkit.getWorlds().get(0);
        world.setTime(6000L);
        for (String rule : new String[]{"gamerule advance_time false", "gamerule spawn_mobs false"}) {
            try { Bukkit.dispatchCommand(Bukkit.getConsoleSender(), rule); }
            catch (Exception ex) { log("boot hygiene: '" + rule + "' failed: " + ex.getMessage()); }
        }
        for (Entity e : world.getEntities()) {
            if (e instanceof org.bukkit.entity.Monster) e.remove();
        }
        // Platform: bedrock floor at FLOOR, air above, roof so staged zombies never burn.
        for (int x = -10; x <= 320; x++) {
            for (int z = -8; z <= 8; z++) {
                world.setType(x, FLOOR, z, Material.BEDROCK);
                for (int y = FLOOR + 1; y <= FLOOR + 5; y++) world.setType(x, y, z, Material.AIR);
                world.setType(x, FLOOR + 6, z, Material.STONE_BRICKS);
            }
        }
        for (int i = 0; i < NAMES.length; i++) {
            ServerPlayer sp = makePlayer(UUIDS[i], NAMES[i]);
            fakes.add(sp);
            Player p = sp.getBukkitEntity();
            fakePlayers.add(p);
            p.setGameMode(GameMode.SURVIVAL);
            p.setInvulnerable(true);
            p.setHealth(20.0);
            p.setFoodLevel(20);
            p.setSaturation(20f);
            park(p, 300 + i * 2);
        }
        park(fakePlayers.get(0), PAD_X);
        log("boot done: 5 fake players, killer at pad, others parked at x=300+");
        result("BOOT", true, "arena ready, players=" + fakePlayers.size());
    }

    /** Stage n fakes (including the killer) in range of the pad; park the rest. */
    void stage(int n) {
        for (int i = 0; i < fakePlayers.size(); i++) {
            if (i < n) park(fakePlayers.get(i), PAD_X + i * 5.0);
            else park(fakePlayers.get(i), 300 + i * 2);
        }
        log("staged " + n + " participant(s) in range");
    }

    // ------------------------------------------------------------ batch engine

    void batch(CreatureSpawnEvent.SpawnReason reason, int count) {
        preSums.clear(); postSums.clear(); eliteInfo.clear();
        int before = eliteDeathEvents;
        log("batch start: reason=" + reason + " count=" + count);
        batchStep(reason, count, 0, 0, 0, 0, before);
    }

    void batchStep(CreatureSpawnEvent.SpawnReason reason, int total, int done,
                   long preTotal, long postTotal, int eliteSeen, int eliteEventsBefore) {
        if (done >= total) {
            double ratio = preTotal == 0 ? -1 : (double) postTotal / preTotal;
            result("BATCH-" + reason, true,
                    "kills=" + done + " preTotal=" + preTotal + " postTotal=" + postTotal
                            + " ratio=" + String.format("%.3f", ratio)
                            + " eliteDeathEvents=" + (eliteDeathEvents - eliteEventsBefore)
                            + " trackedElites=" + eliteSeen);
            return;
        }
        Location at = new Location(world, PAD_X, FLOOR + 1, PAD_Z);
        Zombie z = world.spawn(at, Zombie.class, reason, true, e -> { });
        if (z == null) { result("BATCH-" + reason, false, "spawn returned null at kill " + done); return; }
        z.setAI(false);
        z.setShouldBurnInDay(false);
        z.setRemoveWhenFarAway(false);
        UUID id = z.getUniqueId();
        // Poll for EM conversion up to ~3 s, then kill regardless.
        new BukkitRunnable() {
            int waited = 0;
            @Override public void run() {
                EliteEntity ee = EntityTracker.getEliteMobEntity(z);
                if (ee != null || waited >= 60 || !z.isValid()) {
                    cancel();
                    boolean wasElite = ee != null;
                    z.damage(100000.0);
                    later(10, () -> {
                        Integer pre = preSums.get(id), post = postSums.get(id);
                        if (pre == null || post == null) {
                            result("BATCH-" + reason, false, "no death record for kill " + done
                                    + " (elite=" + wasElite + ", info=" + eliteInfo.get(id) + ")");
                            return;
                        }
                        if (done == 0 || done == total - 1) {
                            log("kill " + done + ": pre=" + pre + " post=" + post
                                    + " elite=" + wasElite + " " + eliteInfo.getOrDefault(id, "-"));
                        }
                        batchStep(reason, total, done + 1, preTotal + pre, postTotal + post,
                                eliteSeen + (wasElite ? 1 : 0), eliteEventsBefore);
                    });
                }
                waited += 5;
            }
        }.runTaskTimer(this, 5L, 5L);
    }

    // ------------------------------------------------------------ wither (seal boss boundary)

    void witherTest() {
        stage(3);
        preSums.clear(); postSums.clear();
        int evBefore = eliteDeathEvents;
        Location at = new Location(world, PAD_X, FLOOR + 1, PAD_Z);
        Wither w = world.spawn(at, Wither.class, CreatureSpawnEvent.SpawnReason.CUSTOM, true, e -> { });
        if (w == null) { result("WITHER", false, "spawn returned null"); return; }
        w.setAI(false);
        UUID id = w.getUniqueId();
        later(30, () -> {
            w.damage(100000.0);
            later(15, () -> {
                Integer pre = preSums.get(id), post = postSums.get(id);
                boolean noEliteEvent = eliteDeathEvents == evBefore;
                boolean pass = pre != null && pre.equals(post) && noEliteEvent;
                result("WITHER", pass, "pre=" + pre + " post=" + post
                        + " eliteDeathEventsDuring=" + (eliteDeathEvents - evBefore)
                        + " (vanilla boss: PartyDrops must never touch it)");
            });
        });
    }

    // ------------------------------------------------------------ EM gear coexistence

    /**
     * The killer fake actually FIGHTS natural elites (real player
     * damage, so EliteMobs' per-damager gear pipeline engages) with
     * a second participant in range. PASS evidence: across up to 6
     * kills, at least one EliteMobs-generated item lands in the
     * killer's inventory (EM gear carries a custom name/lore) while
     * the paired drop sums still scale — the two loot pipelines
     * coexist and neither disturbs the other.
     */
    void gearKillTest() {
        stage(2);
        Player killer = fakePlayers.get(0);
        killer.getInventory().clear();
        org.bukkit.inventory.ItemStack sword =
                new org.bukkit.inventory.ItemStack(Material.NETHERITE_SWORD);
        org.bukkit.inventory.meta.ItemMeta meta = sword.getItemMeta();
        meta.addEnchant(org.bukkit.enchantments.Enchantment.SHARPNESS, 40, true);
        sword.setItemMeta(meta);
        killer.getInventory().setItemInMainHand(sword);
        gearKillStep(0, 0);
    }

    void gearKillStep(int done, int gearSeen) {
        if (done >= 6) {
            result("GEARKILL", gearSeen > 0, "kills=6 emGearItemsInKillerInventory=" + gearSeen
                    + " (EM per-damager gear pipeline ran alongside the drop multiplier)");
            return;
        }
        Player killer = fakePlayers.get(0);
        Location at = new Location(world, PAD_X, FLOOR + 1, PAD_Z);
        Zombie z = world.spawn(at, Zombie.class, CreatureSpawnEvent.SpawnReason.NATURAL, true, e -> { });
        if (z == null) { result("GEARKILL", false, "spawn returned null"); return; }
        z.setShouldBurnInDay(false);
        z.setRemoveWhenFarAway(false);
        UUID id = z.getUniqueId();
        new BukkitRunnable() {
            int waited = 0;
            @Override public void run() {
                if (z.isDead() || !z.isValid()) {
                    cancel();
                    later(10, () -> {
                        int gear = countEmGear(killer);
                        Integer pre = preSums.get(id), post = postSums.get(id);
                        log("gearkill " + done + ": pre=" + pre + " post=" + post + " gearNow=" + gear);
                        gearKillStep(done + 1, Math.max(gearSeen, gear));
                    });
                    return;
                }
                if (waited % 10 == 0 && EntityTracker.getEliteMobEntity(z) != null) {
                    killer.attack(z);
                }
                if (waited > 600) { cancel(); result("GEARKILL", false, "elite never died (waited 600 ticks)"); }
                waited += 5;
            }
        }.runTaskTimer(this, 5L, 5L);
    }

    /**
     * Forms a REAL EliteMobs party between fake #1 and the Bedrock
     * fake through EM's own commands, then has the killer fight a
     * natural elite. The rig copy of ItemSettings.yml raises
     * flatDropRateV3 to 1.0 so a gear roll always happens. Watches
     * the killer's inventory and the ground near the pad through the
     * party loot-vote window (60s) for the EM-generated item.
     */
    void partyKillTest() {
        stage(2);
        Player killer = fakePlayers.get(0);
        Player bedrock = fakePlayers.get(1);
        killer.performCommand("em party create");
        later(10, () -> {
            killer.performCommand("em party invite .RigBedrock");
            later(10, () -> {
                bedrock.performCommand("em party accept");
                later(10, () -> {
                    log("party commands issued (create/invite/accept)");
                    killer.getInventory().clear();
                    org.bukkit.inventory.ItemStack sword =
                            new org.bukkit.inventory.ItemStack(Material.NETHERITE_SWORD);
                    org.bukkit.inventory.meta.ItemMeta meta = sword.getItemMeta();
                    meta.addEnchant(org.bukkit.enchantments.Enchantment.SHARPNESS, 40, true);
                    sword.setItemMeta(meta);
                    killer.getInventory().setItemInMainHand(sword);
                    partyKillFight(killer);
                });
            });
        });
    }

    void partyKillFight(Player killer) {
        Location at = new Location(world, PAD_X, FLOOR + 1, PAD_Z);
        Zombie z = world.spawn(at, Zombie.class, CreatureSpawnEvent.SpawnReason.NATURAL, true, e -> { });
        z.setShouldBurnInDay(false);
        z.setRemoveWhenFarAway(false);
        UUID id = z.getUniqueId();
        new BukkitRunnable() {
            int waited = 0;
            @Override public void run() {
                if (z.isDead() || !z.isValid()) {
                    cancel();
                    Integer pre = preSums.get(id), post = postSums.get(id);
                    log("partykill: drops pre=" + pre + " post=" + post + " — watching for EM gear (vote window)");
                    watchForGear(killer, 0);
                    return;
                }
                if (waited % 10 == 0 && EntityTracker.getEliteMobEntity(z) != null) killer.attack(z);
                if (waited > 600) { cancel(); result("PARTYKILL", false, "elite never died"); }
                waited += 5;
            }
        }.runTaskTimer(this, 5L, 5L);
    }

    void watchForGear(Player killer, int ticks) {
        int inv = countEmGear(killer);
        int ground = 0;
        Location pad = new Location(world, PAD_X, FLOOR + 1, PAD_Z);
        for (Entity e : world.getNearbyEntities(pad, 8, 5, 8)) {
            if (e instanceof org.bukkit.entity.Item it) {
                org.bukkit.inventory.ItemStack st = it.getItemStack();
                if (st.hasItemMeta() && (st.getItemMeta().hasDisplayName() || st.getItemMeta().hasLore())) ground++;
            }
        }
        if (inv > 0 || ground > 0) {
            result("PARTYKILL", true, "EM gear resolved: inKillerInventory=" + inv + " onGroundNearPad=" + ground
                    + " after ~" + (ticks / 20) + "s; vanilla drops on the same kill were scaled (see partykill line)");
            return;
        }
        if (ticks >= 1500) {
            result("PARTYKILL", false, "no EM gear seen in inventory or on ground within ~75s of the party kill");
            return;
        }
        later(20, () -> watchForGear(killer, ticks + 20));
    }

    int countEmGear(Player p) {
        int n = 0;
        for (org.bukkit.inventory.ItemStack st : p.getInventory().getContents()) {
            if (st == null || st.getType() == Material.NETHERITE_SWORD) continue;
            if (st.hasItemMeta() && (st.getItemMeta().hasDisplayName() || st.getItemMeta().hasLore())) n += st.getAmount();
        }
        return n;
    }

    // ------------------------------------------------------------ real spawner elite

    /**
     * Place a REAL zombie spawner block near the pad and wait for
     * EliteMobs to convert one of its spawns (rig config sets
     * doSpawnersSpawnEliteMobs: true). A genuine spawner-born elite
     * must pay exactly 1x with 3 participants staged — proving the
     * origin gate against the real thing, not an API reason enum.
     */
    void spawnerTest() {
        stage(3);
        Location pad = new Location(world, PAD_X, FLOOR + 1, PAD_Z);
        Location spawnerLoc = pad.clone().add(3, 0, 0);
        world.setType(spawnerLoc, Material.SPAWNER);
        org.bukkit.block.CreatureSpawner cs =
                (org.bukkit.block.CreatureSpawner) spawnerLoc.getBlock().getState();
        cs.setSpawnedType(org.bukkit.entity.EntityType.ZOMBIE);
        cs.setDelay(20);
        cs.update();
        log("spawner placed at " + spawnerLoc + " — waiting for a converted spawn (up to ~3 min)");
        new BukkitRunnable() {
            int waited = 0;
            @Override public void run() {
                Zombie found = null;
                for (Entity e : world.getNearbyEntities(pad, 12, 6, 12)) {
                    if (e instanceof Zombie zb && EntityTracker.getEliteMobEntity(zb) != null) { found = zb; break; }
                }
                if (found != null) {
                    cancel();
                    Zombie elite = found;
                    elite.setAI(false);
                    elite.setShouldBurnInDay(false);
                    elite.teleport(pad);
                    EliteEntity ee = EntityTracker.getEliteMobEntity(elite);
                    log("spawner elite found: natural=" + ee.isNaturalEntity()
                            + " reason=" + ee.getSpawnReason() + " level=" + ee.getLevel());
                    preSums.remove(elite.getUniqueId());
                    postSums.remove(elite.getUniqueId());
                    UUID id = elite.getUniqueId();
                    elite.damage(100000.0);
                    later(15, () -> {
                        Integer pre = preSums.get(id), post = postSums.get(id);
                        boolean pass = pre != null && pre.equals(post);
                        result("SPAWNER-ELITE", pass, "pre=" + pre + " post=" + post
                                + " info=" + eliteInfo.getOrDefault(id, "-")
                                + " (3 staged: spawner-born elite must pay exactly 1x)");
                        spawnerLoc.getBlock().setType(Material.AIR);
                    });
                    return;
                }
                if (waited >= 3600) {
                    cancel();
                    result("SPAWNER-ELITE", false, "no spawner elite appeared within ~3 min");
                    spawnerLoc.getBlock().setType(Material.AIR);
                }
                waited += 20;
            }
        }.runTaskTimer(this, 20L, 20L);
    }

    // ------------------------------------------------------------ hint capture

    /** Drain a fake player's EmbeddedChannel and count action-bar packets. */
    int drainActionBars(int fakeIndex) {
        ServerPlayer sp = fakes.get(fakeIndex);
        if (sp == null || sp.connection == null) return -1;
        Connection conn = sp.connection.connection;
        if (conn == null || !(conn.channel instanceof EmbeddedChannel ch)) return -1;
        ch.runPendingTasks();
        int n = 0;
        Object msg;
        while ((msg = ch.readOutbound()) != null) {
            if (msg.getClass().getSimpleName().contains("ActionBar")) n++;
        }
        return n;
    }

    void hintTest() {
        stage(2);
        // Drain join/setup noise from participant #2 (the Bedrock fake).
        drainActionBars(1);
        preSums.clear(); postSums.clear();
        hintStep(0);
    }

    void hintStep(int done) {
        if (done >= 3) {
            later(10, () -> {
                int bars = drainActionBars(1);
                result("HINT", bars == 1, "action-bar packets to participant over 3 multiplied kills=" + bars
                        + " (expect exactly 1: first kill teaches, cooldown keeps it quiet; -1 = capture unavailable)");
            });
            return;
        }
        Location at = new Location(world, PAD_X, FLOOR + 1, PAD_Z);
        Zombie z = world.spawn(at, Zombie.class, CreatureSpawnEvent.SpawnReason.NATURAL, true, e -> { });
        if (z == null) { result("HINT", false, "spawn returned null"); return; }
        z.setAI(false);
        z.setShouldBurnInDay(false);
        z.setRemoveWhenFarAway(false);
        new BukkitRunnable() {
            int waited = 0;
            @Override public void run() {
                if (EntityTracker.getEliteMobEntity(z) != null || waited >= 60 || !z.isValid()) {
                    cancel();
                    z.damage(100000.0);
                    later(12, () -> hintStep(done + 1));
                }
                waited += 5;
            }
        }.runTaskTimer(this, 5L, 5L);
    }
}

// ExcelPartyDrops rig driver — rig-only, never ships.
