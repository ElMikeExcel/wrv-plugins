#!/bin/bash
# Build PdRigDriver.jar for the ExcelPartyDrops scratch rig.
# Classpath: the rig's own Paper server jar (API + NMS), its runtime
# libraries, and the EliteMobs jar (API + EntityTracker polling).
set -euo pipefail
cd "$(dirname "$0")"
JDK=~/workspace/.jdk25
SERVER=~/workspace/excelpartydrops/scratch/server
EM=/home/hatch/workspace/minecraft-server/plugins/EliteMobs-10.9.8.jar
CP="$SERVER/versions/26.2/paper-26.2.jar:$HOME/workspace/.m2/repository/org/jetbrains/annotations/26.0.2/annotations-26.0.2.jar:$EM"
for j in $(find "$SERVER/libraries" -name '*.jar'); do CP="$CP:$j"; done
rm -rf build/classes && mkdir -p build/classes
"$JDK/bin/javac" -proc:none -nowarn -cp "$CP" -d build/classes $(find src -name '*.java')
cp plugin.yml build/classes/
"$JDK/bin/jar" --create --file PdRigDriver.jar -C build/classes .
ls -l PdRigDriver.jar
