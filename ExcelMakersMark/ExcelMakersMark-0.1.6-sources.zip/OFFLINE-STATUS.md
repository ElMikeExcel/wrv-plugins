# Expanded MakerMark integrated candidate — 2026-10-28

NOT YET APPROVED FOR INSTALL. Baseline is the verified 08:26 ordinary composition; frozen baseline remains untouched.

The user selected strict save-before-confirm at 15:16 UTC. This is settled, not another pending policy choice. The writer may pause future admissions after slow/uncertain disk calls, explicitly reports refusal, and cannot promise a hard fsync latency bound.

Current source integrates native Magic physical-slot/cache writes, downstream damage/death consumer, fresh native lore decoration, and bounded persisted-ID provisioning. All experimental flags remain off pending reviewed activation. The ordinary stats changes are NOT disabled by these archive flags.

The sole Magic owner provides observer and native lore hooks; this plugin does not package observer classes or install a second observer. Public magicHistoryBridge() returns the downstream Sink/Decorator to coordinated bootstrap. Exact dependency is the composed lore Magic JAR. Native slot access is refused during virtual/open inventories; the durable inbox retries after deactivation/rejoin. Existing Magic/Elite/shop protection is not broadly removed.

Verified current tests are in sibling runtime folders; these use real Paper entities/events and concrete native Wands with controlled player inventory interfaces, not a connected Java/Bedrock player. The full real cast initiation/native inventory lifecycle, new wand native-ID initialization, edit/upgrade integration and indirect projectile/DoT coverage still require explicit evidence. Unsupported evidence is refused, never assigned to whichever wand happens to be held.

Build uses pinned Paper 26.2-123, PlaceholderAPI 2.11.6 and the sole composed Magic JAR as provided dependencies. The dependency recovery receipt records official Maven checksum verification. No live/external publication or restart has occurred.
