package rig;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

/** Scratch-only rig harness: reads ExcelShops' live catalog + derived mobile catalog reflectively and logs parity evidence. Never shipped. */
public final class RigCheck extends JavaPlugin {
    @Override public void onEnable() {
        getServer().getScheduler().runTaskLater(this, this::check, 60L);
    }
    private Object call(Object target, String method) throws Exception {
        Method m = target.getClass().getMethod(method);
        return m.invoke(target);
    }
    private void check() {
        try {
            Plugin es = getServer().getPluginManager().getPlugin("ExcelShops");
            if (es == null) { getLogger().severe("RIGCHECK FAIL ExcelShops plugin missing"); return; }
            Object catalog = call(es, "getCatalog");
            if (catalog == null) { getLogger().severe("RIGCHECK FAIL catalog null (ExcelShops did not load a catalog)"); return; }
            Collection<?> all = (Collection<?>) call(catalog, "all");
            Map<String, long[]> offers = new LinkedHashMap<>();
            for (Object entry : all) {
                String id = (String) call(entry, "id");
                int bundle = (Integer) call(entry, "bundleSize");
                long price = (Long) call(entry, "bundlePrice");
                offers.put(id, new long[]{bundle, price});
            }
            getLogger().info("RIGCHECK CATALOG offers=" + offers.size());
            Object mobile = call(es, "getMobileCatalog");
            if (mobile == null) { getLogger().severe("RIGCHECK FAIL mobile catalog null"); return; }
            Map<String, long[]> products = new LinkedHashMap<>();
            Map<String, String> routes = new LinkedHashMap<>();
            List<String> categoryLines = new ArrayList<>();
            for (Object category : (Collection<?>) call(mobile, "categories")) {
                String cid = (String) call(category, "id");
                List<String> ids = new ArrayList<>();
                for (Object product : (Collection<?>) call(category, "products")) {
                    String id = (String) call(product, "id");
                    int bundle = (Integer) call(product, "bundleSize");
                    long price = (Long) call(product, "price");
                    String route = String.valueOf(call(product, "route"));
                    products.put(id, new long[]{bundle, price});
                    routes.put(id, route);
                    ids.add(id);
                }
                categoryLines.add("RIGCHECK CATEGORY " + cid + " count=" + ids.size() + " products=" + String.join(",", ids));
            }
            categoryLines.forEach(line -> getLogger().info(line));
            long ordinary = routes.values().stream().filter("ORDINARY"::equals).count();
            long specials = routes.size() - ordinary;
            getLogger().info("RIGCHECK MOBILE products=" + products.size() + " ordinary=" + ordinary + " specials=" + specials);
            int mismatches = 0;
            for (Map.Entry<String, long[]> offer : offers.entrySet()) {
                long[] product = products.get(offer.getKey());
                if (product == null) { getLogger().severe("RIGCHECK MISMATCH " + offer.getKey() + " missing from mobile shop"); mismatches++; continue; }
                if (product[0] != offer.getValue()[0] || product[1] != offer.getValue()[1]) {
                    getLogger().severe("RIGCHECK MISMATCH " + offer.getKey() + " catalog=" + offer.getValue()[0] + "/" + offer.getValue()[1]
                        + " mobile=" + product[0] + "/" + product[1]);
                    mismatches++;
                }
            }
            for (String spot : List.of("torch", "disc_pigstep", "light_block", "petrified_slab", "deepslate_tiles", "disc_tears"))
                if (products.containsKey(spot)) getLogger().info("RIGCHECK SPOT " + spot + " bundle=" + products.get(spot)[0] + " price=" + products.get(spot)[1]);
            getLogger().info(mismatches == 0 ? "RIGCHECK PARITY OK" : "RIGCHECK PARITY FAIL mismatches=" + mismatches);
            getLogger().info("RIGCHECK DONE");
        } catch (Exception failure) {
            getLogger().severe("RIGCHECK FAIL " + failure);
        }
    }
}
