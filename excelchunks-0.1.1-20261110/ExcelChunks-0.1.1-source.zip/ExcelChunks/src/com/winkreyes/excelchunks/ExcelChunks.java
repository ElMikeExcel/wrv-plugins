package com.winkreyes.excelchunks;

import com.winkreyes.excelchunks.core.CooldownStore;
import com.winkreyes.excelchunks.core.ItemSelection;
import com.winkreyes.excelchunks.core.StatusCommand;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

/**
 * ExcelChunks 0.1.0 — the /chunks view resync.
 *
 * 0.1.1 (console-admin packet, Mike's Nov 3, 2026 rule): adds
 * /chunks status — a global, read-only status (enabled/config
 * state) routed BEFORE the player-only gate below, runnable
 * from the console and gated by excelchunks.admin (default
 * op). The plugin holds no persistent per-player state, so a
 * global status is the whole console-admin surface (the
 * console-admin coverage audit, Nov 9, 2026). The self resync
 * below is unchanged.
 *
 * Bedrock players on this server (through Geyser) can end up with
 * a client view that disagrees with the server: a dropped item
 * renders floating in the air, renders nowhere at all, or sits
 * visible but refuses to be picked up — while the server's own
 * record of the item is correct the whole time. A relog cures it
 * because the client rebuilds its world view from scratch. Mike
 * asked for the same cure without the relog (Oct 22, 2026); the
 * command name /chunks is his pick.
 *
 * /chunks does two things, in order:
 *   1. Teleports the player to the exact spot they are already
 *      standing on (same world, x/y/z, yaw, pitch) — the teleport
 *      forces the position-correction / resend path for the
 *      player's own client.
 *   2. Cycles the player's view of every dropped item within 96
 *      blocks (the server's live misc tracking range): hide, then
 *      show a couple of ticks later, so the client throws its
 *      stale copy away and re-adds the item at the position the
 *      server actually holds.
 *
 * Only the caller's view is ever touched: hide/show are
 * per-viewer, the items themselves are never moved, removed, or
 * modified, and no other player sees anything happen. The hidden
 * state is per-viewer session state — it dies with the session,
 * so a disconnect mid-cycle can never leave an item hidden for
 * anyone; the scheduled show simply skips an offline player.
 *
 * Player-only, usable by every player (permission defaults to
 * true), 10-second per-player cooldown held in memory. No config
 * in v1: the constants below are the whole configuration.
 */
public final class ExcelChunks extends JavaPlugin {

    /** Refresh radius in blocks — the server's live misc entity-tracking range. */
    static final double RADIUS_BLOCKS = 96.0;
    /** Per-player cooldown between refreshes. */
    static final long COOLDOWN_MILLIS = 10_000L;
    /** Ticks the items stay hidden before the caller's view re-adds them. */
    static final long SHOW_DELAY_TICKS = 2L;

    private final CooldownStore cooldowns = new CooldownStore(COOLDOWN_MILLIS);

    @Override
    public void onEnable() {
        getLogger().info("ExcelChunks enabled: /chunks view resync ON (item radius "
                + (int) RADIUS_BLOCKS + " blocks, cooldown " + (COOLDOWN_MILLIS / 1000) + "s)");
    }

    @Override
    public void onDisable() {
        getLogger().info("ExcelChunks disabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("chunks")) return false;
        // 0.1.1: the console-admin status is routed BEFORE the
        // player-only gate — it is the one form a non-player
        // sender (the console) must be able to run.
        if (args.length >= 1 && StatusCommand.isStatus(args[0])) {
            handleStatus(sender);
            return true;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage("ExcelChunks: /chunks only works in game - it refreshes the view of the player who runs it.");
            return true;
        }

        long now = System.currentTimeMillis();
        if (!cooldowns.tryUse(player.getUniqueId(), now)) {
            long secs = (cooldowns.remainingMillis(player.getUniqueId(), now) + 999) / 1000;
            player.sendMessage("Hang on - your view was just refreshed. You can refresh again in " + secs + " seconds.");
            return true;
        }

        resync(player);
        return true;
    }

    /**
     * /chunks status (0.1.1): the global console-admin surface.
     * Gate first (console always; anyone else needs the admin
     * node), then the read-only status lines built from this
     * class's own constants. Touches no cooldown, moves nobody.
     */
    private void handleStatus(CommandSender sender) {
        boolean console = !(sender instanceof Player);
        if (!StatusCommand.isAdmin(console, sender.hasPermission(StatusCommand.PERMISSION))) {
            sender.sendMessage(StatusCommand.DENIED);
            return;
        }
        for (String line : StatusCommand.statusLines(
                getDescription().getVersion(), RADIUS_BLOCKS, COOLDOWN_MILLIS, SHOW_DELAY_TICKS)) {
            sender.sendMessage(line);
        }
    }

    /** The refresh itself: position resend first, then the item hide/show cycle. */
    private void resync(Player player) {
        // 1) Same-spot teleport: the resend path for the player's own client.
        Location here = player.getLocation().clone();
        try {
            player.teleport(here);
        } catch (Throwable t) {
            getLogger().warning("ExcelChunks: same-spot teleport failed for " + player.getName() + " - continuing with the item refresh");
        }

        // 2) Item refresh: gather the box (a superset of the sphere),
        // let the pure core pick the items actually within the radius.
        List<Entity> nearby = player.getNearbyEntities(RADIUS_BLOCKS, RADIUS_BLOCKS, RADIUS_BLOCKS);
        List<ItemSelection.Ent> view = new ArrayList<>(nearby.size());
        for (Entity e : nearby) {
            Location l = e.getLocation();
            view.add(new ItemSelection.Ent(l.getX(), l.getY(), l.getZ(), e.getType() == EntityType.ITEM));
        }
        List<Integer> picked = ItemSelection.select(here.getX(), here.getY(), here.getZ(), RADIUS_BLOCKS, view);

        List<Entity> items = new ArrayList<>(picked.size());
        for (int i : picked) {
            Entity item = nearby.get(i);
            try {
                player.hideEntity(this, item);
                items.add(item);
            } catch (Throwable ignored) {
                // A single bad entity never sinks the refresh.
            }
        }
        if (!items.isEmpty()) {
            getServer().getScheduler().runTaskLater(this, () -> {
                // The hide state is per-viewer session state: if the
                // player left, there is nothing to restore and nothing
                // stays hidden. If they are here, re-add every item.
                if (!player.isOnline()) return;
                for (Entity item : items) {
                    try {
                        player.showEntity(this, item);
                    } catch (Throwable ignored) {
                        // Never throw out of the restore step.
                    }
                }
            }, SHOW_DELAY_TICKS);
        }

        getLogger().info("ExcelChunks: " + player.getName() + " resynced view (" + items.size() + " item(s) refreshed)");
        player.sendMessage("View refreshed - dropped items around you have been re-synced.");
    }
}
