package com.winkreyes.excelchunks.core;

import java.util.List;

/**
 * The console-admin half of /chunks (0.1.1, Mike's Nov 3, 2026
 * console-admin rule; the console-admin coverage audit of Nov 9,
 * 2026 found 0.1.0 a FAIL because /chunks was self-only, so an
 * operator could not even inspect the plugin's state from the
 * console):
 *
 *   /chunks status
 *
 * gated by the excelchunks.admin permission (default: op). The
 * server console is an admin by construction (it satisfies
 * op-default permissions in Bukkit/Paper, and the glue also lets
 * a console sender through explicitly, the Landmarks/Cosmetics
 * shape), so the form runs from the Shockbyte console.
 *
 * ExcelChunks holds NO persistent per-player state — the only
 * state is the in-memory per-player cooldown and the built-in
 * constants (there is no config file in this plugin). A global
 * status is therefore the whole passing surface, exactly as the
 * audit sized it: it reports the plugin's enabled/config state
 * (version, the resync constants, the permission nodes) and
 * nothing else. It is READ-ONLY by construction — it touches no
 * cooldown record and moves no player.
 *
 * No Bukkit dependencies: the gate arithmetic and the exact
 * reply texts live here and are unit-tested on a plain JVM; the
 * glue only checks the sender and delivers the lines.
 */
public final class StatusCommand {

    /** The admin permission node (plugin.yml, default: op). */
    public static final String PERMISSION = "excelchunks.admin";

    /** Sent to a non-console sender who lacks the admin node. */
    public static final String DENIED =
            "You do not have permission to view ExcelChunks status (" + PERMISSION + ").";

    private StatusCommand() {}

    /**
     * The admin gate: the console always administers (it is the
     * operator channel this surface exists for); any other sender
     * needs the permission node (op by default).
     */
    public static boolean isAdmin(boolean senderIsConsole, boolean hasPermission) {
        return senderIsConsole || hasPermission;
    }

    /** True only for the exact status subcommand (case-insensitive). */
    public static boolean isStatus(String arg) {
        return arg != null && arg.trim().equalsIgnoreCase("status");
    }

    /**
     * The status lines, built from the plugin's real constants —
     * the same values the enable line prints and the resync path
     * uses, passed in by the glue so this text can never drift
     * from the behaviour it describes.
     */
    public static List<String> statusLines(String version, double radiusBlocks,
                                           long cooldownMillis, long showDelayTicks) {
        return List.of(
                "ExcelChunks status: enabled (v" + version + ")",
                "View resync: ON - same-spot teleport + dropped-item hide/show cycle; "
                        + "item radius " + (int) radiusBlocks + " blocks, cooldown "
                        + (cooldownMillis / 1000) + "s per player, hide/show delay "
                        + showDelayTicks + " ticks.",
                "Config: no config file - radius and cooldown are built-in constants. "
                        + "Permissions: excelchunks.use (default true) for /chunks; "
                        + PERMISSION + " (default op) for this status.");
    }
}
