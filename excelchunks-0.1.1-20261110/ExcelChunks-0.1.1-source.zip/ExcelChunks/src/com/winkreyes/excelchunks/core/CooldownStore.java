package com.winkreyes.excelchunks.core;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Per-player /chunks cooldowns. In-memory only — a restart clears
 * every cooldown, which is fine: the worst case is one player
 * refreshing twice in quick succession across a reboot.
 *
 * Pure logic (the clock is a parameter, in milliseconds) so the
 * plain-JVM suite can pin the boundary exactly. The cooldown
 * length itself is a constructor argument; the glue passes the
 * v1 constant (10 seconds).
 */
public final class CooldownStore {

    private final long cooldownMillis;
    private final Map<UUID, Long> lastUseByPlayer = new HashMap<>();

    public CooldownStore(long cooldownMillis) {
        if (cooldownMillis <= 0) throw new IllegalArgumentException("cooldown must be positive");
        this.cooldownMillis = cooldownMillis;
    }

    public long cooldownMillis() {
        return cooldownMillis;
    }

    /**
     * Try to use the command at {@code nowMillis}. Allowed (and
     * recorded) when the player has never used it or the full
     * cooldown has elapsed — the boundary is inclusive: a use at
     * exactly last + cooldown goes through. A denied try does NOT
     * move the player's timestamp, so spamming the command never
     * extends the wait.
     */
    public boolean tryUse(UUID id, long nowMillis) {
        if (id == null) throw new IllegalArgumentException("uuid is null");
        Long last = lastUseByPlayer.get(id);
        if (last != null && nowMillis - last < cooldownMillis) return false;
        lastUseByPlayer.put(id, nowMillis);
        return true;
    }

    /** Milliseconds left on the player's cooldown at {@code nowMillis}; 0 when ready. */
    public long remainingMillis(UUID id, long nowMillis) {
        if (id == null) return 0;
        Long last = lastUseByPlayer.get(id);
        if (last == null) return 0;
        long left = cooldownMillis - (nowMillis - last);
        return Math.max(0, left);
    }

    /** True when the player could use the command at {@code nowMillis}. */
    public boolean isReady(UUID id, long nowMillis) {
        return remainingMillis(id, nowMillis) == 0;
    }

    /** Drop a player's record entirely (their next use is a first use). */
    public void forget(UUID id) {
        if (id != null) lastUseByPlayer.remove(id);
    }

    public int size() {
        return lastUseByPlayer.size();
    }
}
