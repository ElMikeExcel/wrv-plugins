package com.winkreyes.excelchunks.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Which nearby entities /chunks refreshes: dropped ITEM entities
 * within the refresh radius of the player. Pure logic over plain
 * coordinates so the plain-JVM suite can pin the boundary; the
 * glue feeds it the entities Bukkit gathered (a 96-block box is a
 * superset of the 96-block sphere, so box-gather + this sphere
 * filter is exact).
 *
 * The measure is the straight 3D distance and the edge is
 * INCLUSIVE — an item at exactly the radius is refreshed (house
 * convention: caps read as "up to and including", as with the aim
 * assist's range). The radius matches the server's live misc
 * entity-tracking range (96), so the command never reaches for an
 * item the server is not already tracking for the player.
 */
public final class ItemSelection {

    /** One gathered entity, reduced to what selection needs. */
    public record Ent(double x, double y, double z, boolean item) {}

    private ItemSelection() {}

    /**
     * Indices (into {@code ents}, in the input order) of the item
     * entities within {@code radius} blocks of
     * ({@code px}, {@code py}, {@code pz}). Non-item entities are
     * never selected; an empty input selects nothing.
     */
    public static List<Integer> select(double px, double py, double pz, double radius, List<Ent> ents) {
        List<Integer> out = new ArrayList<>();
        if (ents == null || radius < 0) return out;
        double r2 = radius * radius;
        for (int i = 0; i < ents.size(); i++) {
            Ent e = ents.get(i);
            if (e == null || !e.item()) continue;
            double dx = e.x() - px;
            double dy = e.y() - py;
            double dz = e.z() - pz;
            if (dx * dx + dy * dy + dz * dz <= r2) out.add(i);
        }
        return out;
    }
}
