import com.winkreyes.excelchunks.core.CooldownStore;

import java.util.UUID;

public class CooldownStoreTest {
    static final UUID A = UUID.fromString("11111111-1111-1111-1111-111111111111");
    static final UUID B = UUID.fromString("22222222-2222-2222-2222-222222222222");
    static final long CD = 10_000L;
    static final long T0 = 1_000_000L;

    public static void run() {
        System.out.println("CooldownStoreTest");

        // A first use is always allowed, and it is recorded.
        CooldownStore s = new CooldownStore(CD);
        Check.ok(s.isReady(A, T0), "fresh store: player is ready");
        Check.eq(0L, s.remainingMillis(A, T0), "fresh store: no time remaining");
        Check.ok(s.tryUse(A, T0), "first use is allowed");
        Check.eq(1, s.size(), "the use was recorded");

        // Inside the cooldown the use is denied and time remains.
        Check.ok(!s.tryUse(A, T0), "immediate reuse is denied");
        Check.ok(!s.tryUse(A, T0 + 1), "reuse 1ms later is denied");
        Check.ok(!s.tryUse(A, T0 + CD - 1), "reuse 1ms before the boundary is denied");
        Check.eq(CD, s.remainingMillis(A, T0), "full cooldown remains at the use instant");
        Check.eq(5000L, s.remainingMillis(A, T0 + 5000), "half the cooldown remains halfway");
        Check.eq(1L, s.remainingMillis(A, T0 + CD - 1), "1ms remains just before the boundary");
        Check.ok(!s.isReady(A, T0 + CD - 1), "not ready just before the boundary");

        // A denied try does not move the timestamp (spam never extends the wait).
        Check.ok(!s.tryUse(A, T0 + 9000), "late-cooldown spam is still denied");
        Check.eq(1000L, s.remainingMillis(A, T0 + 9000), "the denial did not extend the cooldown");

        // The boundary is inclusive: exactly last + cooldown goes through.
        Check.eq(0L, s.remainingMillis(A, T0 + CD), "nothing remains at the boundary");
        Check.ok(s.isReady(A, T0 + CD), "ready at the boundary");
        Check.ok(s.tryUse(A, T0 + CD), "use at exactly last + cooldown is allowed");

        // The new use starts a fresh full cooldown.
        Check.ok(!s.tryUse(A, T0 + CD), "the boundary use re-arms the cooldown");
        Check.eq(CD, s.remainingMillis(A, T0 + CD), "fresh full cooldown after the boundary use");
        Check.ok(s.tryUse(A, T0 + 2 * CD + 12345), "a use long after expiry is allowed");

        // Players are independent.
        CooldownStore two = new CooldownStore(CD);
        Check.ok(two.tryUse(A, T0), "player A uses");
        Check.ok(two.tryUse(B, T0), "player B is not blocked by A's use");
        Check.ok(!two.tryUse(B, T0 + 1), "player B is on their own cooldown");
        Check.eq(2, two.size(), "both players are tracked");

        // forget() drops the record entirely.
        two.forget(A);
        Check.eq(1, two.size(), "forget drops exactly one record");
        Check.ok(two.isReady(A, T0 + 1), "a forgotten player is ready again at once");
        Check.ok(two.tryUse(A, T0 + 1), "a forgotten player's next use is a first use");
        two.forget(null);
        Check.eq(2, two.size(), "forget(null) is a no-op, no crash");

        // A custom cooldown length is honoured exactly.
        CooldownStore fast = new CooldownStore(250L);
        Check.eq(250L, fast.cooldownMillis(), "the configured cooldown reads back");
        Check.ok(fast.tryUse(A, 0L), "custom cooldown: first use allowed");
        Check.ok(!fast.tryUse(A, 249L), "custom cooldown: denied 1ms early");
        Check.ok(fast.tryUse(A, 250L), "custom cooldown: allowed at its boundary");

        // Null handling.
        boolean threw = false;
        try { s.tryUse(null, T0); } catch (IllegalArgumentException e) { threw = true; }
        Check.ok(threw, "tryUse(null) throws IllegalArgumentException");
        Check.eq(0L, s.remainingMillis(null, T0), "remainingMillis(null) reads 0, no crash");
        threw = false;
        try { new CooldownStore(0L); } catch (IllegalArgumentException e) { threw = true; }
        Check.ok(threw, "a zero cooldown is rejected");
        threw = false;
        try { new CooldownStore(-5L); } catch (IllegalArgumentException e) { threw = true; }
        Check.ok(threw, "a negative cooldown is rejected");
    }
}
