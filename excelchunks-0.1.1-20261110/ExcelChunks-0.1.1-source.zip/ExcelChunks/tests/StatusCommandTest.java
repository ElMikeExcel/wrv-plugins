import com.winkreyes.excelchunks.core.StatusCommand;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * 0.1.1 console-admin status checks: the gate arithmetic
 * (console allowed, node-holder allowed, non-admin player
 * denied), the exact status contents, the subcommand matcher,
 * and the shipped plugin.yml gate (version, the new admin node
 * defaulting to op, the use node and command permission
 * unchanged). Read-only by construction is pinned structurally:
 * StatusCommand holds no store reference at all — its only
 * inputs are the sender facts and the plugin constants.
 */
public class StatusCommandTest {

    public static void run() {
        System.out.println("StatusCommandTest");

        // Gate arithmetic.
        Check.ok(StatusCommand.isAdmin(true, false), "gate: console without the node is allowed");
        Check.ok(StatusCommand.isAdmin(true, true), "gate: console with the node is allowed");
        Check.ok(StatusCommand.isAdmin(false, true), "gate: player with the node is allowed");
        Check.ok(!StatusCommand.isAdmin(false, false), "gate: player without the node is denied");
        Check.eq("excelchunks.admin", StatusCommand.PERMISSION, "gate: the admin node name");
        Check.ok(StatusCommand.DENIED.contains("excelchunks.admin"),
                "gate: the denial names the node");

        // Subcommand matcher: exact word only, case-insensitive.
        Check.ok(StatusCommand.isStatus("status"), "matcher: 'status' matches");
        Check.ok(StatusCommand.isStatus("STATUS"), "matcher: 'STATUS' matches");
        Check.ok(StatusCommand.isStatus(" Status "), "matcher: padded 'status' matches");
        Check.ok(!StatusCommand.isStatus("stat"), "matcher: 'stat' does not match");
        Check.ok(!StatusCommand.isStatus("statusx"), "matcher: 'statusx' does not match");
        Check.ok(!StatusCommand.isStatus(""), "matcher: empty does not match");
        Check.ok(!StatusCommand.isStatus(null), "matcher: null does not match, no crash");

        // Status contents: the real constants, spelled out.
        List<String> lines = StatusCommand.statusLines("0.1.1", 96.0, 10_000L, 2L);
        Check.eq(3, lines.size(), "status: exactly three lines");
        Check.eq("ExcelChunks status: enabled (v0.1.1)", lines.get(0),
                "status: line 1 names enabled + version");
        Check.ok(lines.get(1).contains("radius 96 blocks"), "status: line 2 names the radius");
        Check.ok(lines.get(1).contains("cooldown 10s"), "status: line 2 names the cooldown");
        Check.ok(lines.get(1).contains("delay 2 ticks"), "status: line 2 names the hide/show delay");
        Check.ok(lines.get(2).contains("no config file"), "status: line 3 states there is no config file");
        Check.ok(lines.get(2).contains("excelchunks.admin"), "status: line 3 names the admin node");
        // The formatter follows its inputs (no hard-coded drift).
        List<String> other = StatusCommand.statusLines("9.9.9", 32.0, 5_000L, 4L);
        Check.ok(other.get(0).contains("v9.9.9"), "status: version follows the input");
        Check.ok(other.get(1).contains("radius 32 blocks"), "status: radius follows the input");
        Check.ok(other.get(1).contains("cooldown 5s"), "status: cooldown follows the input");

        // The shipped plugin.yml gate.
        String yml = readPluginYml();
        Check.ok(yml != null, "plugin.yml: readable from the tree");
        if (yml != null) {
            Check.ok(yml.contains("version: 0.1.1"), "plugin.yml: version is 0.1.1");
            Check.ok(yml.contains("excelchunks.admin:"), "plugin.yml: admin node declared");
            Check.ok(yml.contains("default: op"), "plugin.yml: admin node defaults to op");
            Check.ok(yml.contains("permission: excelchunks.use"),
                    "plugin.yml: command permission unchanged (excelchunks.use)");
            Check.ok(yml.contains("/chunks status"), "plugin.yml: usage names the status form");
        }
    }

    private static String readPluginYml() {
        for (Path p : new Path[]{Path.of("plugin.yml"), Path.of("ExcelChunks/plugin.yml"),
                Path.of("../plugin.yml")}) {
            try {
                if (Files.exists(p)) return Files.readString(p);
            } catch (Exception ignored) {
                // try the next candidate
            }
        }
        return null;
    }
}
