import com.winkreyes.excelchunks.core.ItemSelection;
import com.winkreyes.excelchunks.core.ItemSelection.Ent;

import java.util.List;

public class ItemSelectionTest {
    static final double R = 96.0;

    static Ent item(double x, double y, double z) { return new Ent(x, y, z, true); }
    static Ent mob(double x, double y, double z) { return new Ent(x, y, z, false); }

    public static void run() {
        System.out.println("ItemSelectionTest");

        // Nothing gathered, nothing selected.
        Check.eq(List.of(), ItemSelection.select(0, 0, 0, R, List.of()), "empty set selects nothing");
        Check.eq(List.of(), ItemSelection.select(0, 0, 0, R, null), "null set selects nothing, no crash");

        // An item on the player's exact spot is selected.
        Check.eq(List.of(0), ItemSelection.select(0, 0, 0, R, List.of(item(0, 0, 0))), "item at distance 0 is selected");

        // Well inside on each axis.
        Check.eq(List.of(0), ItemSelection.select(0, 0, 0, R, List.of(item(50, 0, 0))), "item 50 along +x is selected");
        Check.eq(List.of(0), ItemSelection.select(0, 0, 0, R, List.of(item(0, -50, 0))), "item 50 below is selected");
        Check.eq(List.of(0), ItemSelection.select(0, 0, 0, R, List.of(item(0, 0, -50))), "item 50 along -z is selected");

        // The edge is inclusive on every axis.
        Check.eq(List.of(0), ItemSelection.select(0, 0, 0, R, List.of(item(96, 0, 0))), "item at exactly 96 (+x) is selected");
        Check.eq(List.of(0), ItemSelection.select(0, 0, 0, R, List.of(item(-96, 0, 0))), "item at exactly 96 (-x) is selected");
        Check.eq(List.of(0), ItemSelection.select(0, 0, 0, R, List.of(item(0, 96, 0))), "item at exactly 96 above is selected");
        Check.eq(List.of(0), ItemSelection.select(0, 0, 0, R, List.of(item(0, 0, 96))), "item at exactly 96 (+z) is selected");

        // A hair past the edge is out.
        Check.eq(List.of(), ItemSelection.select(0, 0, 0, R, List.of(item(96.5, 0, 0))), "item at 96.5 is not selected");
        Check.eq(List.of(), ItemSelection.select(0, 0, 0, R, List.of(item(0, 0, -200))), "item at 200 is not selected");

        // The measure is the 3D distance, not the gather box: a corner of
        // the 96-box measures ~166 and is out; a diagonal inside 96 is in.
        Check.eq(List.of(), ItemSelection.select(0, 0, 0, R, List.of(item(96, 96, 96))), "box corner (96,96,96) is out - sphere, not box");
        Check.eq(List.of(0), ItemSelection.select(0, 0, 0, R, List.of(item(55, 55, 55))), "diagonal at ~95.3 is in");
        Check.eq(List.of(), ItemSelection.select(0, 0, 0, R, List.of(item(56, 56, 56))), "diagonal at ~97.0 is out");
        // Vertical counts the same as horizontal (a floating pile above the player).
        Check.eq(List.of(0), ItemSelection.select(0, 64, 0, R, List.of(item(3, 140, -4))), "item ~76 above the player is in");

        // Non-items are never selected, wherever they stand.
        Check.eq(List.of(), ItemSelection.select(0, 0, 0, R, List.of(mob(1, 0, 0))), "a mob at 1 block is not selected");
        Check.eq(List.of(), ItemSelection.select(0, 0, 0, R, List.of(mob(0, 0, 0))), "a mob on the spot is not selected");

        // A mixed crowd: only items, only in range, indices in input order.
        List<Ent> crowd = List.of(
                mob(5, 0, 0),          // 0: mob, in range - skipped
                item(10, 0, 0),        // 1: item, in
                item(150, 0, 0),       // 2: item, out of range
                item(0, 0, -96),       // 3: item, on the edge - in
                mob(0, 0, 0),          // 4: mob - skipped
                item(-20, 30, -20));   // 5: item, ~41 away - in
        Check.eq(List.of(1, 3, 5), ItemSelection.select(0, 0, 0, R, crowd), "mixed crowd selects exactly the in-range items, in order");

        // Selection is judged from the player's position, not the origin.
        Check.eq(List.of(0), ItemSelection.select(1000, 70, -1000, R, List.of(item(1096, 70, -1000))), "edge item relative to a far-away player is in");
        Check.eq(List.of(), ItemSelection.select(1000, 70, -1000, R, List.of(item(0, 70, 0))), "origin item is out for a far-away player");

        // The radius is a parameter, honoured exactly.
        Check.eq(List.of(0), ItemSelection.select(0, 0, 0, 10.0, List.of(item(10, 0, 0))), "radius 10: item at 10 is in");
        Check.eq(List.of(), ItemSelection.select(0, 0, 0, 10.0, List.of(item(20, 0, 0))), "radius 10: item at 20 is out");
        Check.eq(List.of(0), ItemSelection.select(0, 0, 0, 0.0, List.of(item(0, 0, 0))), "radius 0: item on the spot is in");
        Check.eq(List.of(), ItemSelection.select(0, 0, 0, 0.0, List.of(item(0.5, 0, 0))), "radius 0: item half a block off is out");
    }
}
