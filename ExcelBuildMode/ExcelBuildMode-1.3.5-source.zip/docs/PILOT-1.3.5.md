# ExcelBuildMode 1.3.5 — Windows-safe directory sync (design note)

An Excel plugin note for Wink Reyes Valley. November 14, 2026.
Lane 2 of the P-FSYNC-1 sweep, from the mirror storage-cause diagnosis
in `~/workspace/mirror-storage-diagnosis-20261114/DIAGNOSIS.md`.

## The failure this fixes

The durable stores end every save by fsync-ing the containing directory
(`FileChannel.open(directory, READ)` + `force(true)`) so the directory
entry itself is durable. That is legal on Linux, where the live server
runs, and impossible via Java NIO on Windows: the directory open itself
throws `AccessDeniedException`. On the PC test-server mirror the Nov 13
boot shows the result verbatim — `RecoveryJournal.forceDirectory` →
`FileChannel.open` → `AccessDeniedException:
plugins\ExcelBuildMode\recovery` — and the plugin degrades: storage is
reported unavailable and new Build entry is disabled. A minimal Java
probe on the PC (diagnosis) reproduced it exactly, and confirmed the
other half of the picture: create + write + fsync + delete of a FILE in
the same directory works fine. Only directory channels are refused.

Two boot ERRORs in the same log have a different, simpler cause and are
NOT this fix's subject: `ReviewHoldStore` / `BuildReturnStore`
constructor refusals ("directory is unavailable") fire because those
two directories were never provisioned on the mirror (the mirror tree
carries `recovery\` and `active-index\` only). The constructors'
provision-first refusal is deliberate design ("missing storage is not
an empty history") and is unchanged; the mirror rig provisions the two
directories, as the live installation did. What this fix removes is
those stores' save path failing on Windows once provisioned.

## The change (the whole delta vs 1.3.4)

One new package-private helper, `core/DirectorySync.bestEffort(Path)`:
attempt the directory open + force exactly as before, tolerate any
`IOException` from it. Four call-site conversions, no signature changes:

- `RecoveryJournal.forceDirectory` — delegates. Covers the constructor
  probe and every journal save (begin ×3, writeState).
- `ActiveSessionIndex.force` — delegates. A fourth durable store the
  diagnosis never reached: it is constructed immediately after the
  journal in the same enable block, so the journal failure masked it;
  its constructor and every save force the root directory the same way.
- `ReviewHoldStore.hold` — the inline post-move directory force now
  delegates.
- `BuildReturnStore.record` — the inline post-move directory force now
  delegates.

Unchanged, deliberately: every file-level `channel.force(true)` stays
mandatory and in place; the atomic-move writes are untouched; on Linux
the directory force still runs (nothing about live behavior changes).
Version 1.3.4 → 1.3.5 in plugin.yml (plus an appended description
sentence), the two startup banner strings, and the two test version
pins. New suite `DirectorySyncTests` (see below); the eight carried
suites are otherwise unmodified and hold their 1.3.4 totals.

## Swept and deliberately excluded

A full-tree sweep found one more directory force:
`PlayerDataProof.forceVerifiedMarker` fsyncs the playerdata file and
then its parent directory (line 75). It is NOT converted. That method
is not a store save — it is a fail-closed verification proof whose
contract is "fsync that same inode and parent directory, and reject
detectable replacement/change"; the post-force byte and stamp
re-checks are the safety property. Weakening its directory force to
best-effort would silently loosen a proof other flows rely on. On
Windows it keeps failing closed during recovery verification; changing
that is a separate design call for the supervisor, not a rider on this
fix.

## Proof shape

- Base gate: the unmodified 1.3.4 tree (copied from
  `~/workspace/buildmode-134-build/`) rebuilt byte-identical to the
  on-record candidate (SHA-256 39d86f3b…) before any edit.
- Nine suites via build.sh: the eight carried suites at their 1.3.4
  totals (CoreTests 5,710; RewardTests 5,283; RecoverySafetyTests 84;
  PlayerDataProofTests 145; PilotGateTests 338; BuildReturnTests 18;
  AdminTests 82, version pin moved; ReviewedTests 25) + NEW
  DirectorySyncTests 14: the unguarded idiom provably throws where a
  directory cannot be opened; bestEffort tolerates that failure
  (repeatedly, and without creating anything); save round-trips through
  all four stores (hold, build-return record, journal begin/complete,
  index begin/complete).
- Deterministic: in-place double-build and a clean-room rebuild both
  reproduce the candidate hash (BUILD-RECORD.md in the fix folder).
- Rig verification still owed (supervisor's step): a mirror boot with
  1.3.5 and the two unprovisioned directories provisioned must show
  zero storage ERRORs and enabled Build entry — the Windows half of
  the proof can only run on the PC.
